from __future__ import annotations

import argparse
import gzip
import json
import mimetypes
import os
import re
import time
import zipfile
import zlib
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urlparse
from urllib.request import Request, urlopen
from xml.sax.saxutils import escape as xml_escape


BASE_DIR = Path(__file__).resolve().parent
REQUEST_TIMEOUT = 20
MAX_LIMIT = 300
MAX_COMPETITORS = 10
COMPETITOR_REVIEW_LIMIT = 60
IMAGE_BASKET_LIMIT = 80
IMAGE_MAX_ATTEMPTS = 36
IMAGE_FOLDERS = ("images/big", "images/c516x688", "images/c246x328", "images/tm")
MARKETPLACE_WB = "wb"
MARKETPLACE_OZON = "ozon"
APP_VERSION = "wb-competitors-fix-1"
WB_SEARCH_ENDPOINTS = (
    "https://search.wb.ru/exactmatch/ru/common/v18/search",
    "https://u-search.wb.ru/exactmatch/ru/common/v18/search",
)


class AppError(Exception):
    def __init__(self, message: str, status: int = 500, details: str | None = None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.details = details


@dataclass(frozen=True)
class RemoteResult:
    url: str
    data: dict[str, Any]


STOPWORDS = {
    "а",
    "без",
    "более",
    "был",
    "была",
    "были",
    "было",
    "быть",
    "в",
    "вам",
    "вас",
    "весь",
    "во",
    "вот",
    "все",
    "всё",
    "всего",
    "вы",
    "где",
    "да",
    "даже",
    "для",
    "до",
    "его",
    "ее",
    "её",
    "если",
    "есть",
    "ещё",
    "же",
    "за",
    "и",
    "из",
    "или",
    "им",
    "их",
    "к",
    "как",
    "ко",
    "когда",
    "ли",
    "лучше",
    "мне",
    "мой",
    "мы",
    "на",
    "над",
    "нам",
    "нас",
    "не",
    "него",
    "нее",
    "ней",
    "нем",
    "нет",
    "ни",
    "но",
    "ну",
    "о",
    "об",
    "он",
    "она",
    "они",
    "оно",
    "от",
    "очень",
    "по",
    "под",
    "при",
    "про",
    "раз",
    "с",
    "со",
    "так",
    "там",
    "то",
    "тоже",
    "только",
    "у",
    "уже",
    "хотя",
    "чем",
    "что",
    "чтобы",
    "это",
    "этот",
    "эту",
    "я",
    "товар",
    "товара",
    "товару",
    "товаром",
    "wb",
    "wildberries",
    "беру",
    "брала",
    "брал",
    "заказ",
    "заказала",
    "заказал",
    "пришел",
    "пришла",
    "пришло",
    "пришли",
    "получила",
    "получил",
}


EMPTY_OPINIONS = {
    "",
    "-",
    "нет",
    "нету",
    "не нашла",
    "не нашел",
    "не нашёл",
    "не обнаружено",
    "не обнаружила",
    "не обнаружил",
    "нет недостатков",
    "без недостатков",
    "нет минусов",
    "минусов нет",
    "нет достоинств",
}


POSITIVE_PATTERNS = (
    "аккурат",
    "выгод",
    "доволь",
    "идеаль",
    "качеств",
    "класс",
    "красив",
    "крепк",
    "легк",
    "мягк",
    "нрав",
    "отлич",
    "понрав",
    "прекрас",
    "прият",
    "плотн",
    "рекоменд",
    "супер",
    "удоб",
    "хорош",
    "цена",
)

NEGATIVE_PATTERNS = (
    "брак",
    "большемер",
    "гряз",
    "дорог",
    "жмет",
    "жмёт",
    "запах",
    "колет",
    "крив",
    "маломер",
    "мят",
    "не подош",
    "не понрав",
    "не работает",
    "не соответствует",
    "нет ",
    "отвал",
    "плох",
    "порвал",
    "проблем",
    "рван",
    "скольз",
    "слом",
    "тонк",
    "ужас",
)


ASPECTS = {
    "quality": {
        "title": "Качество и материалы",
        "keywords": (
            "качеств",
            "материал",
            "ткан",
            "шов",
            "швы",
            "нитк",
            "плотн",
            "тонк",
            "прочн",
            "крепк",
            "пошив",
            "состав",
            "кожа",
            "пластик",
            "металл",
            "брак",
            "рван",
            "порвал",
        ),
    },
    "fit": {
        "title": "Размер и посадка",
        "keywords": (
            "размер",
            "маломер",
            "большемер",
            "посадк",
            "сидит",
            "сел",
            "села",
            "подош",
            "узк",
            "широк",
            "длин",
            "коротк",
            "объем",
            "объём",
            "рост",
        ),
    },
    "comfort": {
        "title": "Удобство",
        "keywords": (
            "удоб",
            "комфорт",
            "мягк",
            "прият",
            "носить",
            "жмет",
            "жмёт",
            "давит",
            "колет",
            "тяжел",
            "легк",
            "скольз",
        ),
    },
    "appearance": {
        "title": "Внешний вид",
        "keywords": (
            "красив",
            "цвет",
            "вид",
            "дизайн",
            "фото",
            "стиль",
            "выгляд",
            "ярк",
            "оттенок",
            "принт",
        ),
    },
    "price": {
        "title": "Цена и ценность",
        "keywords": (
            "цена",
            "стоим",
            "деньг",
            "дорог",
            "дешев",
            "выгод",
            "скидк",
            "ценник",
            "переплат",
        ),
    },
    "packaging": {
        "title": "Упаковка и доставка",
        "keywords": (
            "упаков",
            "достав",
            "коробк",
            "пакет",
            "мят",
            "цел",
            "быстро",
            "гряз",
            "пришел",
            "пришла",
            "пришло",
            "пришли",
        ),
    },
    "completeness": {
        "title": "Комплектация",
        "keywords": (
            "комплект",
            "набор",
            "штук",
            "пара",
            "не хватает",
            "влож",
            "насад",
            "детал",
            "инструкц",
        ),
    },
    "function": {
        "title": "Работа и функции",
        "keywords": (
            "работает",
            "работ",
            "заряд",
            "звук",
            "держит",
            "греет",
            "свет",
            "моет",
            "липнет",
            "клеит",
            "застеж",
            "замок",
            "молния",
            "кнопк",
            "аккумулятор",
            "батар",
        ),
    },
}


RECOMMENDATION_TEMPLATES = {
    "quality": {
        "content_title": "Показать качество без догадок",
        "content_action": (
            "Добавьте в первые 5 фото крупный план материала, швов и фактуры; в инфографике укажите состав, "
            "плотность, уход и что именно покупатель получает в упаковке."
        ),
        "product_title": "Усилить контроль качества партии",
        "product_action": (
            "Проверьте швы, торчащие нитки, плотность и повторяемость материала по партиям; заведите чек-лист "
            "перед отгрузкой и отдельно проверяйте товары, которые чаще попадают в негативные отзывы."
        ),
    },
    "fit": {
        "content_title": "Снять риск ошибки с размером",
        "content_action": (
            "Обновите размерную сетку фактическими замерами товара, добавьте подсказку «маломерит/большемерит», "
            "фото на модели или схему посадки с ростом и параметрами."
        ),
        "product_title": "Сверить лекала и фактические размеры",
        "product_action": (
            "Сравните реальные замеры партии с таблицей на карточке; если отклонения повторяются, скорректируйте "
            "размерный ряд или добавьте отдельный размер/посадку."
        ),
    },
    "comfort": {
        "content_title": "Объяснить комфорт в сценариях",
        "content_action": (
            "Добавьте блок «когда удобно использовать»: мягкость, вес, эластичность, посадка, сезонность и ограничения, "
            "чтобы ожидания совпадали с реальным использованием."
        ),
        "product_title": "Убрать источники дискомфорта",
        "product_action": (
            "Проверьте контактные зоны: резинки, швы, застёжки, жёсткие края, вес и скольжение; протестируйте товар "
            "в типовом сценарии использования, а не только визуально."
        ),
    },
    "appearance": {
        "content_title": "Переснять цвет и детали",
        "content_action": (
            "Сделайте фото при дневном нейтральном свете без сильной обработки, покажите оттенок рядом с белым/серым "
            "фоном и добавьте крупные кадры принта, фактуры и важных деталей."
        ),
        "product_title": "Стабилизировать внешний вид партии",
        "product_action": (
            "Сверьте фактический оттенок, принт и отделку с карточкой; если поставки отличаются, разделите варианты "
            "по цветам/партиям или обновляйте фото под текущую поставку."
        ),
    },
    "price": {
        "content_title": "Обосновать цену",
        "content_action": (
            "Вынесите в инфографику, за что платит покупатель: комплектность, материал, срок службы, гарантия, "
            "дополнительные элементы или выгоду набора."
        ),
        "product_title": "Добавить ценность без роста цены",
        "product_action": (
            "Проверьте, можно ли улучшить комплектацию, упаковку, инструкцию или гарантийную поддержку; если нельзя, "
            "пересмотрите цену, скидку или набор."
        ),
    },
    "packaging": {
        "content_title": "Показать упаковку и получение",
        "content_action": (
            "Добавьте фото комплекта в упаковке и коротко опишите, как товар защищён при доставке; отдельно покажите "
            "что должно прийти покупателю."
        ),
        "product_title": "Усилить упаковку и предпродажную проверку",
        "product_action": (
            "Добавьте защиту от помятостей, грязи и вскрытия; перед отгрузкой проверяйте целостность упаковки, "
            "маркировку и комплектность."
        ),
    },
    "completeness": {
        "content_title": "Сделать состав комплекта очевидным",
        "content_action": (
            "На отдельной инфографике перечислите все элементы комплекта, количество штук, размеры и исключения; "
            "покажите весь набор одним кадром."
        ),
        "product_title": "Ввести контроль комплектации",
        "product_action": (
            "Добавьте чек-лист сборки заказа и контроль веса/штрихкода для комплекта, чтобы не отправлять неполные "
            "наборы или другой вариант товара."
        ),
    },
    "function": {
        "content_title": "Показать работу товара в видео",
        "content_action": (
            "Добавьте короткое видео или серию кадров: включение, результат работы, важные характеристики, ограничения "
            "и простую инструкцию по использованию."
        ),
        "product_title": "Проверить функциональные узлы",
        "product_action": (
            "Проведите выборочную проверку функций, замков, кнопок, аккумулятора, креплений или расходников; отдельно "
            "фиксируйте дефекты, которые повторяются в отзывах."
        ),
    },
    "overall": {
        "content_title": "Закрыть частые сомнения в карточке",
        "content_action": (
            "Добавьте мини-FAQ по повторяющимся вопросам и замечаниям из отзывов: что входит, кому подходит, "
            "как выбрать и чего не стоит ожидать."
        ),
        "product_title": "Разобрать негативные отзывы вручную",
        "product_action": (
            "Сгруппируйте последние отзывы на 1-3 звезды, проверьте товар из спорных партий и заведите список "
            "корректирующих действий по каждой повторяющейся причине."
        ),
    },
}


def decode_body(raw: bytes, encoding: str) -> bytes:
    encoding = encoding.lower()
    if encoding == "gzip" or raw[:2] == b"\x1f\x8b":
        return gzip.decompress(raw)
    if encoding == "deflate":
        return zlib.decompress(raw)
    return raw


def remote_json(url: str, referer: str, attempts: int = 2, timeout: int = REQUEST_TIMEOUT) -> RemoteResult:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "application/json,text/plain,*/*",
        "Accept-Encoding": "gzip, deflate",
        "Origin": "https://www.wildberries.ru",
        "Referer": referer,
    }
    last_error: Exception | None = None

    for attempt in range(attempts):
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=timeout) as response:
                raw = response.read()
                encoding = response.headers.get("Content-Encoding", "")
            body = decode_body(raw, encoding).decode("utf-8", "replace")
            return RemoteResult(url=url, data=json.loads(body))
        except HTTPError as exc:
            last_error = exc
            if exc.code == 429 and attempt + 1 < attempts:
                time.sleep(1.2)
                continue
            if exc.code == 404:
                raise AppError("Wildberries не нашёл данные по этому артикулу.", 404)
            if exc.code == 429:
                raise AppError(
                    "Wildberries временно ограничил частоту запросов. Попробуйте ещё раз через минуту.",
                    429,
                )
            raise AppError(f"Wildberries вернул HTTP {exc.code}.", 502)
        except (URLError, TimeoutError) as exc:
            last_error = exc
            if attempt + 1 < attempts:
                time.sleep(0.8)
                continue
        except json.JSONDecodeError as exc:
            raise AppError("Wildberries вернул ответ в неожиданном формате.", 502, str(exc))

    raise AppError("Не удалось подключиться к Wildberries.", 502, str(last_error))


def article_from_input(value: str) -> int:
    value = value.strip()
    catalog_match = re.search(r"/catalog/(\d+)", value)
    if catalog_match:
        return int(catalog_match.group(1))
    digits = re.sub(r"\D+", "", value)
    if not digits:
        raise AppError("Введите артикул Wildberries или ссылку на товар.", 400)
    return int(digits)


def fetch_product(article: int) -> tuple[dict[str, Any], str]:
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    url = (
        "https://card.wb.ru/cards/v4/detail"
        f"?appType=1&curr=rub&dest=-1257786&hide_dtype=13&lang=ru&nm={article}&spp=30"
    )
    result = remote_json(url, referer)
    products = result.data.get("products") or result.data.get("data", {}).get("products") or []
    if not products:
        raise AppError("Карточка товара не найдена. Проверьте артикул.", 404)
    return products[0], result.url


def basket_host_candidates(article: int) -> list[int]:
    vol = article // 100000
    ranges = [
        (0, 143, 1),
        (144, 287, 2),
        (288, 431, 3),
        (432, 719, 4),
        (720, 1007, 5),
        (1008, 1061, 6),
        (1062, 1115, 7),
        (1116, 1169, 8),
        (1170, 1313, 9),
        (1314, 1601, 10),
        (1602, 1655, 11),
        (1656, 1919, 12),
        (1920, 2045, 13),
        (2046, 2189, 14),
        (2190, 2405, 15),
        (2406, 2621, 16),
        (2622, 2837, 17),
        (2838, 3053, 18),
        (3054, 3269, 19),
        (3270, 3485, 20),
        (3486, 3701, 21),
        (3702, 3917, 22),
        (3918, 4133, 23),
        (4134, 4349, 24),
        (4350, 4565, 25),
        (4566, 4781, 26),
        (4782, 4997, 27),
        (4998, 5213, 28),
        (5214, 5429, 29),
        (5430, 5645, 30),
    ]
    preferred = next((basket for start, end, basket in ranges if start <= vol <= end), None)
    if preferred is None and vol > ranges[-1][1]:
        estimated = ranges[-1][2] + ((vol - ranges[-1][1] - 1) // 216) + 1
        preferred = min(max(estimated, 1), IMAGE_BASKET_LIMIT)
    candidates = [preferred] if preferred else []
    if preferred:
        for offset in range(1, 13):
            lower = preferred - offset
            upper = preferred + offset
            if lower >= 1:
                candidates.append(lower)
            if upper <= IMAGE_BASKET_LIMIT:
                candidates.append(upper)
    candidates.extend(range(1, 31))
    candidates.extend(range(31, IMAGE_BASKET_LIMIT + 1))
    return [item for index, item in enumerate(candidates) if item and item not in candidates[:index]]


def wb_product_image_url(
    article: int,
    image_number: int = 1,
    basket: int | None = None,
    image_folder: str = "images/big",
) -> str:
    vol = article // 100000
    part = article // 1000
    basket_id = basket or basket_host_candidates(article)[0]
    return f"https://basket-{basket_id:02d}.wbbasket.ru/vol{vol}/part{part}/{article}/{image_folder}/{image_number}.webp"


def product_image_url_candidates(article: int, image_number: int = 1) -> list[str]:
    baskets = basket_host_candidates(article)
    primary_baskets = baskets[:28]
    fallback_baskets = baskets[28:58]
    candidates = [
        wb_product_image_url(article, image_number, basket, image_folder)
        for image_folder in IMAGE_FOLDERS[:2]
        for basket in primary_baskets
    ]
    candidates.extend(wb_product_image_url(article, image_number, basket) for basket in fallback_baskets)
    candidates.extend(
        wb_product_image_url(article, image_number, basket, image_folder)
        for image_folder in IMAGE_FOLDERS[2:]
        for basket in primary_baskets[:10]
    )
    return candidates


def product_image_url(article: int, image_number: int = 1) -> str:
    return f"/api/image?article={article}&n={image_number}"


def fetch_product_image(article: int, image_number: int = 1, timeout: int = 8) -> tuple[bytes, str, str]:
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": referer,
    }
    last_error: Exception | None = None
    request_timeout = min(float(timeout), 1.5)

    for url in product_image_url_candidates(article, image_number)[:IMAGE_MAX_ATTEMPTS]:
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=request_timeout) as response:
                body = response.read()
                content_type = response.headers.get("Content-Type") or "image/webp"
            if body and (content_type.startswith("image/") or body[:4] == b"RIFF"):
                return body, content_type if content_type.startswith("image/") else "image/webp", url
        except HTTPError as exc:
            last_error = exc
            if exc.code in (403, 404):
                continue
            raise AppError(f"Wildberries РІРµСЂРЅСѓР» HTTP {exc.code} РґР»СЏ С„РѕС‚Рѕ С‚РѕРІР°СЂР°.", 502)
        except (URLError, TimeoutError, OSError) as exc:
            last_error = exc
            continue

    raise AppError("Р¤РѕС‚Рѕ С‚РѕРІР°СЂР° РЅРµ РЅР°Р№РґРµРЅРѕ.", 404, str(last_error) if last_error else None)


def fetch_remote_image(url: str, referer: str = "", timeout: int = 8) -> tuple[bytes, str, str]:
    if not url:
        raise AppError("Ссылка на фото не найдена.", 404)
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    }
    if referer:
        headers["Referer"] = referer
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=timeout) as response:
            body = response.read()
            content_type = response.headers.get("Content-Type") or "image/jpeg"
        if body and (content_type.startswith("image/") or body[:4] == b"RIFF"):
            return body, content_type if content_type.startswith("image/") else "image/webp", url
    except HTTPError as exc:
        raise AppError(f"Сервер изображения вернул HTTP {exc.code}.", 502) from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise AppError("Не удалось загрузить фото товара.", 502, str(exc)) from exc
    raise AppError("Фото товара не найдено.", 404)


def parse_image_number(value: str | None) -> int:
    number = safe_int(value) or 1
    return min(max(number, 1), 12)


def fetch_card_metadata(article: int, max_hosts: int = 10, timeout: int = 3) -> tuple[dict[str, Any], str | None]:
    vol = article // 100000
    part = article // 1000
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "application/json,text/plain,*/*",
        "Accept-Encoding": "gzip, deflate",
        "Referer": referer,
    }

    for basket in basket_host_candidates(article)[:max_hosts]:
        url = f"https://basket-{basket:02d}.wbbasket.ru/vol{vol}/part{part}/{article}/info/ru/card.json"
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=timeout) as response:
                raw = response.read()
                encoding = response.headers.get("Content-Encoding", "")
            data = json.loads(decode_body(raw, encoding).decode("utf-8", "replace"))
            if isinstance(data, dict):
                return data, url
        except HTTPError as exc:
            if exc.code in (403, 404):
                continue
        except (URLError, TimeoutError, json.JSONDecodeError, OSError):
            continue
    return {}, None


def fetch_feedbacks(article: int, root: int | None) -> tuple[dict[str, Any], str]:
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    ids = []
    for candidate in (root, article):
        if candidate and candidate not in ids:
            ids.append(candidate)

    best: tuple[dict[str, Any], str] | None = None
    for feedback_id in ids:
        for host in ("feedbacks1.wb.ru", "feedbacks2.wb.ru"):
            for version in ("v2", "v1"):
                url = f"https://{host}/feedbacks/{version}/{feedback_id}"
                try:
                    result = remote_json(url, referer)
                except AppError as exc:
                    if exc.status == 404:
                        continue
                    raise

                data = result.data
                feedbacks = data.get("feedbacks") or []
                current_score = (
                    int(data.get("feedbackCountWithText") or 0),
                    len(feedbacks),
                    int(data.get("feedbackCount") or 0),
                )
                if best is None:
                    best = (data, result.url)
                else:
                    previous = best[0]
                    previous_score = (
                        int(previous.get("feedbackCountWithText") or 0),
                        len(previous.get("feedbacks") or []),
                        int(previous.get("feedbackCount") or 0),
                    )
                    if current_score > previous_score:
                        best = (data, result.url)

                if feedbacks:
                    return data, result.url

    if best is None:
        raise AppError("Отзывы по товару не найдены.", 404)
    return best


def as_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def normalize_opinion(text: str) -> str:
    normalized = re.sub(r"\s+", " ", text.strip().lower().replace("ё", "е"))
    return normalized.strip(" .,!?:;")


def has_real_text(text: str) -> bool:
    return bool(text.strip()) and normalize_opinion(text) not in EMPTY_OPINIONS


def safe_int(value: Any) -> int | None:
    try:
        if value is None or value == "":
            return None
        return int(float(value))
    except (TypeError, ValueError):
        return None


def safe_float(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return None


def marketplace_from_input(value: str | None) -> str:
    normalized = normalize_opinion(as_text(value))
    if normalized in ("ozon", "озон", "o3"):
        return MARKETPLACE_OZON
    return MARKETPLACE_WB


def ozon_identifier_from_input(value: str) -> tuple[str, str]:
    text = as_text(value)
    if not text:
        raise AppError("Введите SKU, product_id, offer_id или ссылку на товар Ozon.", 400)
    lowered = text.lower()
    if "ozon.ru" in lowered or "/product/" in lowered:
        parsed = urlparse(text if re.match(r"^https?://", text, re.I) else "https://" + text.lstrip("/"))
        match = re.search(r"-(\d+)(?:[/?#]|$)", parsed.path)
        if not match:
            match = re.search(r"/product/[^/?#]*?(\d+)(?:[/?#]|$)", parsed.path)
        if match:
            return "sku", match.group(1)
    if re.fullmatch(r"\d{5,}", text):
        return "sku", text
    return "offer_id", text


def ozon_public_product_path(value: str) -> str:
    text = as_text(value)
    if "ozon.ru" in text.lower():
        parsed = urlparse(text if re.match(r"^https?://", text, re.I) else "https://" + text.lstrip("/"))
        path = parsed.path or ""
        if parsed.query:
            path += "?" + parsed.query
        return path
    kind, identifier = ozon_identifier_from_input(value)
    if kind == "sku":
        return f"/product/{identifier}/"
    raise AppError("Для публичного режима Ozon нужна ссылка на товар или числовой SKU.", 400)


def ozon_public_json(path: str) -> tuple[dict[str, Any], str]:
    public_path = path if path.startswith("/") else "/" + path
    url = "https://www.ozon.ru/api/composer-api.bx/page/json/v2?url=" + quote(public_path, safe="/?=&")
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "application/json,text/plain,*/*",
        "Referer": "https://www.ozon.ru/",
    }
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=12) as response:
            raw = response.read()
            encoding = response.headers.get("Content-Encoding", "")
        data = json.loads(decode_body(raw, encoding).decode("utf-8", "replace"))
        if isinstance(data, dict):
            return data, url
    except HTTPError as exc:
        if exc.code == 403:
            raise AppError(
                "Ozon заблокировал публичную загрузку карточки с сервера. Для стабильного анализа Ozon добавьте Seller API ключи.",
                403,
                "Нужны переменные окружения OZON_CLIENT_ID и OZON_API_KEY.",
            ) from exc
        raise AppError(f"Ozon вернул HTTP {exc.code}.", 502) from exc
    except (URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        raise AppError("Не удалось подключиться к Ozon.", 502, str(exc)) from exc
    raise AppError("Ozon вернул ответ в неожиданном формате.", 502)


def decode_possible_json(value: Any) -> Any:
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("{") or text.startswith("["):
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return value
    return value


def walk_json_values(value: Any) -> list[Any]:
    value = decode_possible_json(value)
    result = [value]
    if isinstance(value, dict):
        for child in value.values():
            result.extend(walk_json_values(child))
    elif isinstance(value, list):
        for child in value:
            result.extend(walk_json_values(child))
    return result


def image_url_from_value(value: Any) -> str:
    if isinstance(value, str) and re.search(r"\.(?:jpg|jpeg|png|webp)(?:\?|$)", value, re.I):
        return value
    if isinstance(value, dict):
        for key in ("primary_image", "primaryImage", "coverImage", "image", "imageUrl", "url"):
            found = image_url_from_value(value.get(key))
            if found:
                return found
        for key in ("images", "pictures"):
            images = value.get(key)
            if isinstance(images, list):
                for item in images:
                    found = image_url_from_value(item)
                    if found:
                        return found
    if isinstance(value, list):
        for item in value:
            found = image_url_from_value(item)
            if found:
                return found
    return ""


def fetch_ozon_public_product(article_input: str) -> tuple[dict[str, Any], dict[str, Any], str, str | None]:
    path = ozon_public_product_path(article_input)
    data, source_url = ozon_public_json(path)
    identifier_kind, identifier = ozon_identifier_from_input(article_input)
    product_candidates = []
    for item in walk_json_values(data):
        if not isinstance(item, dict):
            continue
        name = as_text(item.get("name") or item.get("title") or item.get("productName"))
        image = image_url_from_value(item)
        rating = safe_float(item.get("rating") or item.get("reviewRating") or item.get("ratingValue"))
        reviews = safe_int(item.get("reviewsCount") or item.get("commentsCount") or item.get("feedbacks"))
        if name and (image or rating is not None or reviews is not None):
            product_candidates.append((item, name, image, rating, reviews))

    if not product_candidates:
        raise AppError("Ozon не отдал структуру карточки в публичном режиме.", 502)

    raw, name, image, rating, reviews = product_candidates[0]
    sku = safe_int(identifier) if identifier_kind == "sku" else safe_int(raw.get("sku") or raw.get("id"))
    product_id = safe_int(raw.get("product_id") or raw.get("productId"))
    article = sku or product_id or safe_int(identifier) or 0
    product = {
        "_marketplace": MARKETPLACE_OZON,
        "article": article,
        "sku": sku,
        "product_id": product_id,
        "offer_id": as_text(raw.get("offer_id") or raw.get("offerId") or (identifier if identifier_kind == "offer_id" else "")),
        "name": name,
        "brand": as_text(raw.get("brand") or raw.get("brandName")),
        "supplier": as_text(raw.get("seller") or raw.get("sellerName")),
        "imageUrl": image,
        "sourceImageUrl": image,
        "reviewRating": rating,
        "feedbacks": reviews or 0,
        "textFeedbacks": 0,
        "url": "https://www.ozon.ru" + path,
        "pics": 1 if image else 0,
    }
    feedbacks = {"feedbacks": [], "feedbackCount": reviews or 0, "feedbackCountWithText": 0, "valuation": rating}
    return product, feedbacks, source_url, None


def ozon_api_credentials() -> tuple[str, str] | None:
    client_id = os.environ.get("OZON_CLIENT_ID") or os.environ.get("OZON_SELLER_CLIENT_ID")
    api_key = os.environ.get("OZON_API_KEY") or os.environ.get("OZON_SELLER_API_KEY")
    if client_id and api_key:
        return client_id, api_key
    return None


def ozon_seller_request(path: str, payload: dict[str, Any], timeout: int = 20) -> dict[str, Any]:
    credentials = ozon_api_credentials()
    if not credentials:
        raise AppError(
            "Для стабильного анализа Ozon нужны ключи Seller API.",
            401,
            "Добавьте в Render переменные OZON_CLIENT_ID и OZON_API_KEY. Публичные страницы Ozon часто возвращают 403.",
        )
    client_id, api_key = credentials
    url = "https://api-seller.ozon.ru" + path
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Client-Id": client_id,
        "Api-Key": api_key,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        req = Request(url, data=body, headers=headers, method="POST")
        with urlopen(req, timeout=timeout) as response:
            raw = response.read()
            encoding = response.headers.get("Content-Encoding", "")
        data = json.loads(decode_body(raw, encoding).decode("utf-8", "replace"))
        if isinstance(data, dict):
            return data
    except HTTPError as exc:
        details = ""
        try:
            details = exc.read().decode("utf-8", "replace")
        except OSError:
            details = str(exc)
        raise AppError(f"Ozon Seller API вернул HTTP {exc.code}.", 502, details) from exc
    except (URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        raise AppError("Не удалось подключиться к Ozon Seller API.", 502, str(exc)) from exc
    raise AppError("Ozon Seller API вернул ответ в неожиданном формате.", 502)


def fetch_ozon_seller_product(article_input: str) -> tuple[dict[str, Any], dict[str, Any], str, str | None]:
    kind, identifier = ozon_identifier_from_input(article_input)
    product_query = {kind: [identifier]}
    info = ozon_seller_request("/v3/product/info/list", product_query)
    items = info.get("items") or info.get("result", {}).get("items") or []
    if not items and kind == "sku":
        info = ozon_seller_request("/v3/product/info/list", {"product_id": [identifier]})
        items = info.get("items") or info.get("result", {}).get("items") or []
    if not items:
        raise AppError("Товар Ozon не найден в Seller API. Проверьте SKU/product_id/offer_id.", 404)
    raw = items[0]
    product_id = safe_int(raw.get("product_id") or raw.get("id"))
    sku = safe_int(raw.get("sku") or (identifier if kind == "sku" else None))
    offer_id = as_text(raw.get("offer_id") or (identifier if kind == "offer_id" else ""))
    image = image_url_from_value(raw)
    card_url = f"https://www.ozon.ru/product/{sku or product_id}/"
    product = {
        "_marketplace": MARKETPLACE_OZON,
        "article": sku or product_id or safe_int(identifier) or 0,
        "sku": sku,
        "product_id": product_id,
        "offer_id": offer_id,
        "name": as_text(raw.get("name")),
        "brand": as_text(raw.get("brand") or raw.get("brand_name")),
        "supplier": as_text(raw.get("seller_name")),
        "imageUrl": image,
        "sourceImageUrl": image,
        "reviewRating": safe_float(raw.get("rating") or raw.get("rating_value")),
        "feedbacks": safe_int(raw.get("reviews_count") or raw.get("review_count")) or 0,
        "textFeedbacks": 0,
        "url": card_url,
        "pics": len(raw.get("images") or []) or (1 if image else 0),
    }

    attributes_meta: dict[str, Any] = {}
    attributes_url = None
    try:
        attr_filter: dict[str, Any] = {"visibility": "ALL"}
        if product_id:
            attr_filter["product_id"] = [str(product_id)]
        elif offer_id:
            attr_filter["offer_id"] = [offer_id]
        attr_payload = {"filter": attr_filter, "limit": 100, "sort_dir": "ASC"}
        attributes_meta = ozon_seller_request("/v3/products/info/attributes", attr_payload)
        attributes_url = "https://api-seller.ozon.ru/v3/products/info/attributes"
    except AppError:
        attributes_meta = {}

    try:
        feedbacks = fetch_ozon_seller_feedbacks(product, 120)
    except AppError as exc:
        feedbacks = {
            "feedbacks": [],
            "feedbackCount": product.get("feedbacks") or 0,
            "feedbackCountWithText": 0,
            "valuation": product.get("reviewRating"),
            "valuationDistribution": None,
            "matchingSizePercentages": {},
            "_warning": f"Отзывы Ozon не загружены: {exc.message}",
        }
    return product, feedbacks, "https://api-seller.ozon.ru/v3/product/info/list", attributes_url


def map_ozon_review(review: dict[str, Any]) -> dict[str, Any]:
    text = as_text(review.get("text") or review.get("review_text") or review.get("comment"))
    pros = as_text(review.get("pros") or review.get("positive") or review.get("advantages"))
    cons = as_text(review.get("cons") or review.get("negative") or review.get("disadvantages"))
    return {
        "id": review.get("id") or review.get("review_id"),
        "createdDate": review.get("published_at") or review.get("created_at") or review.get("date"),
        "productValuation": safe_int(review.get("rating")) or safe_int(review.get("valuation")),
        "pros": pros,
        "cons": cons,
        "text": text,
        "color": "",
        "size": "",
        "matchingSize": "",
        "sku": review.get("sku"),
        "product_id": review.get("product_id"),
    }


def fetch_ozon_seller_feedbacks(product: dict[str, Any], limit: int) -> dict[str, Any]:
    sku = safe_int(product.get("sku"))
    product_id = safe_int(product.get("product_id"))
    collected: list[dict[str, Any]] = []
    offset = 0
    page_limit = min(max(limit, 20), 100)
    while len(collected) < limit and offset < 500:
        payload = {"status": "ALL", "limit": page_limit, "offset": offset}
        data = ozon_seller_request("/v1/review/list", payload)
        raw_reviews = data.get("reviews") or data.get("result", {}).get("reviews") or data.get("items") or []
        if not raw_reviews:
            break
        for raw in raw_reviews:
            if not isinstance(raw, dict):
                continue
            raw_sku = safe_int(raw.get("sku"))
            raw_product_id = safe_int(raw.get("product_id"))
            if sku and raw_sku and raw_sku != sku:
                continue
            if product_id and raw_product_id and raw_product_id != product_id:
                continue
            collected.append(map_ozon_review(raw))
            if len(collected) >= limit:
                break
        if len(raw_reviews) < page_limit:
            break
        offset += page_limit

    distribution = normalize_distribution(None, collected)
    ratings = [safe_int(item.get("productValuation")) for item in collected if safe_int(item.get("productValuation"))]
    average = round(sum(ratings) / len(ratings), 2) if ratings else product.get("reviewRating")
    return {
        "feedbacks": collected,
        "feedbackCount": len(collected) or product.get("feedbacks") or 0,
        "feedbackCountWithText": sum(1 for item in collected if any(as_text(item.get(field)) for field in ("pros", "cons", "text"))),
        "valuation": average,
        "valuationDistribution": distribution,
        "matchingSizePercentages": {},
    }


def fetch_ozon_product_and_feedbacks(article_input: str, limit: int) -> tuple[dict[str, Any], dict[str, Any], str, str | None]:
    if ozon_api_credentials():
        return fetch_ozon_seller_product(article_input)
    try:
        return fetch_ozon_public_product(article_input)
    except AppError as public_error:
        if public_error.status == 403:
            raise public_error
        return fetch_ozon_seller_product(article_input)


def split_sentences(text: str) -> list[str]:
    clean = re.sub(r"\s+", " ", text).strip()
    if not clean:
        return []
    parts = re.split(r"(?<=[.!?…])\s+|[\n\r]+", clean)
    if len(parts) == 1 and len(clean) > 180:
        parts = re.split(r"\s*[;•]\s*|\s+-\s+", clean)
    return [part.strip(" \t.,;:") for part in parts if has_real_text(part)]


def token_list(text: str) -> list[str]:
    words = re.findall(r"[a-zа-яё0-9]+", text.lower().replace("ё", "е"))
    return [word for word in words if len(word) > 2 and word not in STOPWORDS and not word.isdigit()]


def sentiment_from_text(text: str) -> tuple[int, int]:
    lower = normalize_opinion(text)
    positive = sum(1 for pattern in POSITIVE_PATTERNS if pattern in lower)
    negative = sum(1 for pattern in NEGATIVE_PATTERNS if pattern in lower)
    if "не " in lower:
        for pattern in ("подош", "понрав", "работ", "соответств"):
            if f"не {pattern}" in lower:
                negative += 2
    return positive, negative


def classify_sentence(field: str, sentence: str, rating: int | None) -> str:
    positive, negative = sentiment_from_text(sentence)
    normalized = normalize_opinion(sentence)
    if normalized in EMPTY_OPINIONS:
        return "neutral"
    if field == "pros":
        if negative > positive and positive == 0:
            return "negative"
        return "positive"
    if field == "cons":
        if normalized in EMPTY_OPINIONS or normalized.startswith("нет "):
            return "neutral"
        return "negative"
    if negative > positive:
        return "negative"
    if positive > negative:
        return "positive"
    if rating is not None and rating <= 3:
        return "negative"
    if rating is not None and rating >= 4:
        return "positive"
    return "neutral"


def detect_aspects(sentence: str) -> list[str]:
    lower = normalize_opinion(sentence)
    matches = []
    for key, meta in ASPECTS.items():
        if any(keyword in lower for keyword in meta["keywords"]):
            matches.append(key)
    return matches or ["overall"]


def short_text(text: str, max_len: int = 180) -> str:
    clean = re.sub(r"\s+", " ", text).strip()
    if len(clean) <= max_len:
        return clean
    return clean[: max_len - 1].rstrip() + "…"


def feedback_date(feedback: dict[str, Any]) -> str:
    raw = as_text(feedback.get("createdDate") or feedback.get("updatedDate"))
    return raw[:10] if raw else ""


def review_text(feedback: dict[str, Any], preferred: str | None = None) -> str:
    fields = []
    if preferred == "positive":
        fields = [as_text(feedback.get("pros")), as_text(feedback.get("text"))]
    elif preferred == "negative":
        fields = [as_text(feedback.get("cons")), as_text(feedback.get("text"))]
    else:
        fields = [
            as_text(feedback.get("pros")),
            as_text(feedback.get("cons")),
            as_text(feedback.get("text")),
        ]
    return short_text(" ".join(part for part in fields if has_real_text(part)), 220)


def top_terms(sentences: list[str], max_items: int = 10) -> list[dict[str, Any]]:
    counter: Counter[str] = Counter()
    for sentence in sentences:
        words = token_list(sentence)
        counter.update(words)
        for first, second in zip(words, words[1:]):
            if first != second and first not in STOPWORDS and second not in STOPWORDS:
                counter[f"{first} {second}"] += 1

    items = []
    for term, count in counter.most_common(max_items * 3):
        if " " in term and count < 2:
            continue
        items.append({"term": term, "count": count})
        if len(items) >= max_items:
            break
    return items


def normalize_distribution(raw: Any, feedbacks: list[dict[str, Any]]) -> dict[str, int]:
    distribution = {str(star): 0 for star in range(1, 6)}
    if isinstance(raw, dict):
        for key, value in raw.items():
            if str(key) in distribution:
                distribution[str(key)] = int(value or 0)
    elif isinstance(raw, list):
        for item in raw:
            if isinstance(item, dict):
                star = str(item.get("valuation") or item.get("rating") or item.get("star") or "")
                if star in distribution:
                    distribution[star] = int(item.get("count") or item.get("value") or 0)

    if not any(distribution.values()):
        for feedback in feedbacks:
            rating = safe_int(feedback.get("productValuation"))
            if rating and 1 <= rating <= 5:
                distribution[str(rating)] += 1
    return distribution


def summarize_aspect(
    key: str,
    data: dict[str, Any],
    polarity: str,
) -> dict[str, Any]:
    title = "Общее впечатление" if key == "overall" else ASPECTS[key]["title"]
    pos_count = data["positive"]
    neg_count = data["negative"]
    terms = [item["term"] for item in top_terms(data["sentences"], 4)]
    evidence_key = "positive_examples" if polarity == "positive" else "negative_examples"
    evidence = data[evidence_key][:3]

    if polarity == "positive":
        summary = f"{pos_count} положительных упоминаний"
        if neg_count:
            summary += f", есть {neg_count} проблемных"
    else:
        summary = f"{neg_count} проблемных упоминаний"
        if pos_count:
            summary += f", при этом {pos_count} положительных"
    if terms:
        summary += ". Часто встречается: " + ", ".join(terms)
    summary += "."

    return {
        "key": key,
        "title": title,
        "summary": summary,
        "positiveMentions": pos_count,
        "negativeMentions": neg_count,
        "mentions": pos_count if polarity == "positive" else neg_count,
        "balance": pos_count - neg_count,
        "terms": terms,
        "evidence": evidence,
    }


def select_examples(feedbacks: list[dict[str, Any]], polarity: str, limit: int = 4) -> list[dict[str, Any]]:
    examples = []
    for feedback in feedbacks:
        rating = safe_int(feedback.get("productValuation"))
        text = review_text(feedback, polarity)
        if not text:
            continue
        if polarity == "positive" and rating is not None and rating < 4:
            continue
        if polarity == "negative" and rating is not None and rating > 3 and not has_real_text(as_text(feedback.get("cons"))):
            continue
        examples.append(
            {
                "rating": rating,
                "date": feedback_date(feedback),
                "text": text,
                "color": as_text(feedback.get("color")),
                "size": as_text(feedback.get("size")),
            }
        )
        if len(examples) >= limit:
            break
    return examples


def build_verdict(
    avg_rating: float | None,
    distribution: dict[str, int],
    text_count: int,
    weak_count: int,
) -> str:
    total = sum(distribution.values())
    positive = distribution["4"] + distribution["5"]
    negative = distribution["1"] + distribution["2"] + distribution["3"]
    positive_pct = round(positive * 100 / total) if total else 0
    negative_pct = round(negative * 100 / total) if total else 0

    if text_count == 0:
        return "У товара пока нет доступных текстовых отзывов, поэтому выводы ограничены рейтингом."
    if avg_rating and avg_rating >= 4.6 and negative_pct <= 15:
        return f"Покупатели в целом довольны: {positive_pct}% оценок на 4-5 звёзд, явных проблем немного."
    if weak_count >= 3 or negative_pct >= 30:
        return f"Отзывы смешанные: {negative_pct}% оценок на 1-3 звезды, слабые места стоит проверить перед закупкой."
    return f"Картина скорее положительная: {positive_pct}% оценок на 4-5 звёзд, но в отзывах есть повторяющиеся замечания."


def recommendation_priority(mentions: int, negative_pct: int | None) -> str:
    if mentions >= 4 or (negative_pct is not None and negative_pct >= 25):
        return "high"
    if mentions >= 2 or (negative_pct is not None and negative_pct >= 12):
        return "medium"
    return "low"


def priority_label(priority: str) -> str:
    return {
        "high": "Высокий",
        "medium": "Средний",
        "low": "Низкий",
    }.get(priority, "Средний")


def clamp_photo_value(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def photo_recommendation(priority: str, title: str, action: str, reason: str) -> dict[str, Any]:
    return {
        "priority": priority,
        "priorityLabel": priority_label(priority),
        "title": title,
        "action": action,
        "reason": reason,
    }


def photo_score_label(score: float | int | None) -> str:
    if score is None:
        return "Нет оценки"
    if score >= 82:
        return "Сильное первое фото"
    if score >= 66:
        return "Хорошая база"
    if score >= 50:
        return "Нужно усилить"
    return "Слабое первое фото"


def photo_metric_payload(label: str, value: float | int | None, unit: str, verdict: str) -> dict[str, Any]:
    return {
        "label": label,
        "value": None if value is None else round(float(value), 1),
        "unit": unit,
        "verdict": verdict,
    }


def photo_criterion_status(score: float | int | None) -> str:
    if score is None:
        return "нет оценки"
    if score >= 82:
        return "сильно"
    if score >= 66:
        return "норма"
    if score >= 50:
        return "усилить"
    return "критично"


def photo_criterion_payload(
    key: str,
    label: str,
    score: float | int | None,
    summary: str,
    action: str,
    evidence: list[str] | None = None,
) -> dict[str, Any]:
    clean_score = None if score is None else round(clamp_photo_value(float(score)))
    return {
        "key": key,
        "label": label,
        "score": clean_score,
        "status": photo_criterion_status(clean_score),
        "summary": summary,
        "action": action,
        "evidence": [item for item in (evidence or []) if item][:3],
    }


def short_photo_meaning(product: dict[str, Any] | None, fallback_title: str) -> str:
    product = product or {}
    source = as_text(product.get("entity") or product.get("subjectName") or product.get("name") or fallback_title)
    words = re.split(r"\s+", source.strip())
    return " ".join(words[:7]) or "товар и его главная выгода"


def analyze_first_photo(
    article: int,
    product: dict[str, Any] | None = None,
    strengths: list[dict[str, Any]] | None = None,
    weaknesses: list[dict[str, Any]] | None = None,
    image_number: int = 1,
    image_url_override: str | None = None,
    source_url_override: str | None = None,
    image_fetcher: Any | None = None,
    marketplace_label: str = "WB",
) -> dict[str, Any]:
    image_url = image_url_override or product_image_url(article, image_number)
    fallback_source_url = source_url_override or wb_product_image_url(article, image_number)
    title = as_text((product or {}).get("name")) or f"Артикул {article}"

    try:
        from PIL import Image, ImageFilter
    except ImportError as exc:
        return {
            "ok": False,
            "status": "library_missing",
            "imageUrl": image_url,
            "sourceUrl": fallback_source_url,
            "summary": "Серверу нужна библиотека Pillow, чтобы анализировать первое фото.",
            "recommendations": [
                photo_recommendation(
                    "medium",
                    "Проверить сборку сервиса",
                    "Добавить Pillow в зависимости и заново развернуть сервис на Render.",
                    str(exc),
                )
            ],
        }

    try:
        if image_fetcher:
            body, content_type, source_url = image_fetcher()
        else:
            body, content_type, source_url = fetch_product_image(article, image_number, timeout=6)
        with Image.open(BytesIO(body)) as original_image:
            original_image.load()
            width, height = original_image.size
            rgb = original_image.convert("RGB")

        sample = rgb.copy()
        sample.thumbnail((360, 360))
        sample_width, sample_height = sample.size
        pixels = list(sample.getdata())
        pixel_count = max(len(pixels), 1)

        luminance_values: list[float] = []
        saturation_values: list[float] = []
        light_background_pixels = 0
        dark_pixels = 0

        for red, green, blue in pixels:
            luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue
            max_channel = max(red, green, blue)
            min_channel = min(red, green, blue)
            saturation = 0.0 if max_channel == 0 else (max_channel - min_channel) * 100 / max_channel
            luminance_values.append(luminance)
            saturation_values.append(saturation)
            if luminance >= 235 and saturation <= 18:
                light_background_pixels += 1
            if luminance <= 48:
                dark_pixels += 1

        brightness = sum(luminance_values) * 100 / (pixel_count * 255)
        average_luminance = sum(luminance_values) / pixel_count
        luminance_std = (sum((value - average_luminance) ** 2 for value in luminance_values) / pixel_count) ** 0.5
        contrast = clamp_photo_value(luminance_std * 100 / 64)
        saturation = sum(saturation_values) / pixel_count
        light_background_share = light_background_pixels * 100 / pixel_count
        dark_share = dark_pixels * 100 / pixel_count

        corner_width = max(1, sample_width // 8)
        corner_height = max(1, sample_height // 8)
        corner_pixels: list[tuple[int, int, int]] = []
        for y in range(sample_height):
            y_is_corner = y < corner_height or y >= sample_height - corner_height
            if not y_is_corner:
                continue
            row_offset = y * sample_width
            for x in range(sample_width):
                if x < corner_width or x >= sample_width - corner_width:
                    corner_pixels.append(pixels[row_offset + x])
        if corner_pixels:
            background_color = tuple(
                sum(pixel[channel] for pixel in corner_pixels) / len(corner_pixels)
                for channel in range(3)
            )
        else:
            background_color = (255.0, 255.0, 255.0)

        subject_pixels = 0
        foreground_mask: list[bool] = []
        for red, green, blue in pixels:
            color_distance = (
                (red - background_color[0]) ** 2
                + (green - background_color[1]) ** 2
                + (blue - background_color[2]) ** 2
            ) ** 0.5
            is_foreground = color_distance >= 38
            foreground_mask.append(is_foreground)
            if is_foreground:
                subject_pixels += 1
        subject_share = subject_pixels * 100 / pixel_count

        gray = sample.convert("L")
        edge_image = gray.filter(ImageFilter.FIND_EDGES)
        edge_values = list(edge_image.getdata())
        edge_mean = (sum(edge_values) / max(len(edge_values), 1)) * 100 / 255
        detail_score = clamp_photo_value(edge_mean * 7.5)
        aspect_ratio = width / height if height else 0
        megapixels = width * height / 1_000_000

        brightness_score = clamp_photo_value(100 - abs(brightness - 68) * 2.1)
        saturation_score = clamp_photo_value(100 - abs(saturation - 24) * 1.7)
        if subject_share < 34:
            subject_score = clamp_photo_value(42 + subject_share * 1.35)
        elif subject_share > 78:
            subject_score = clamp_photo_value(100 - (subject_share - 78) * 2.2)
        else:
            subject_score = 100.0
        background_score = 90.0 if light_background_share >= 45 else 76.0 if light_background_share >= 25 else 62.0
        ratio_score = 100.0 if 0.68 <= aspect_ratio <= 0.84 else 78.0 if 0.84 < aspect_ratio <= 1.05 else 64.0
        active_count = max(sum(1 for active in foreground_mask if active), 1)
        x_sum = 0
        y_sum = 0
        for index, active in enumerate(foreground_mask):
            if not active:
                continue
            y, x = divmod(index, sample_width)
            x_sum += x
            y_sum += y
        subject_center_x = (x_sum / active_count) / max(sample_width - 1, 1)
        subject_center_y = (y_sum / active_count) / max(sample_height - 1, 1)
        center_offset = ((subject_center_x - 0.5) ** 2 + (subject_center_y - 0.5) ** 2) ** 0.5 * 100
        center_score = clamp_photo_value(100 - center_offset * 2.6)

        def zone_edge_score(x1: float, y1: float, x2: float, y2: float) -> float:
            left = max(0, min(sample_width - 1, int(sample_width * x1)))
            top = max(0, min(sample_height - 1, int(sample_height * y1)))
            right = max(left + 1, min(sample_width, int(sample_width * x2)))
            bottom = max(top + 1, min(sample_height, int(sample_height * y2)))
            total = 0
            edge_total = 0
            for y in range(top, bottom):
                offset = y * sample_width
                for x in range(left, right):
                    total += 1
                    edge_total += edge_values[offset + x]
            return clamp_photo_value((edge_total / max(total, 1)) * 100 / 255 * 7.5)

        top_left_activity = zone_edge_score(0.0, 0.0, 0.25, 0.18)
        top_right_activity = zone_edge_score(0.75, 0.0, 1.0, 0.18)
        bottom_activity = zone_edge_score(0.0, 0.78, 1.0, 1.0)
        marketplace_zone_activity = max(top_left_activity, top_right_activity, bottom_activity)
        visual_load = clamp_photo_value(
            subject_share * 0.32 + detail_score * 0.38 + saturation * 0.42 + max(contrast - 45, 0) * 0.15
        )
        offer_overload_score = clamp_photo_value(
            100 - max(0, visual_load - 64) * 2.3 - max(0, 24 - visual_load) * 1.2
        )
        mobile_text_score = clamp_photo_value(
            0.34 * contrast + 0.28 * brightness_score + 0.22 * background_score + 0.16 * offer_overload_score
        )
        composition_score = clamp_photo_value(
            0.30 * center_score + 0.25 * contrast + 0.20 * saturation_score + 0.15 * background_score + 0.10 * subject_score
        )
        standout_score = clamp_photo_value(0.35 * contrast + 0.25 * saturation_score + 0.20 * detail_score + 0.20 * subject_score)
        safe_zone_score = clamp_photo_value(100 - max(0, marketplace_zone_activity - 30) * 2.0)
        base_visual_score = round(
            0.24 * subject_score
            + 0.20 * contrast
            + 0.16 * brightness_score
            + 0.14 * saturation_score
            + 0.14 * detail_score
            + 0.07 * background_score
            + 0.05 * ratio_score
        )

        metrics = {
            "brightnessPercent": round(brightness, 1),
            "contrastScore": round(contrast, 1),
            "saturationPercent": round(saturation, 1),
            "productSharePercent": round(subject_share, 1),
            "lightBackgroundPercent": round(light_background_share, 1),
            "darkPercent": round(dark_share, 1),
            "detailScore": round(detail_score, 1),
            "aspectRatio": round(aspect_ratio, 3),
            "width": width,
            "height": height,
            "megapixels": round(megapixels, 2),
            "fileSizeKb": round(len(body) / 1024, 1),
            "baseVisualScore": base_visual_score,
            "visualLoadPercent": round(visual_load, 1),
            "marketplaceZoneActivityPercent": round(marketplace_zone_activity, 1),
            "centerOffsetPercent": round(center_offset, 1),
        }

        strengths_found: list[str] = []
        risks: list[str] = []
        recommendations: list[dict[str, Any]] = []
        designer_brief: list[str] = []
        best_strength = next((item.get("title") for item in strengths or [] if item.get("title")), "")
        main_weakness = next((item.get("title") for item in weaknesses or [] if item.get("title")), "")
        one_second_meaning = short_photo_meaning(product, title)
        primary_offer = best_strength or main_weakness or one_second_meaning
        needs_action = (
            f"Закрыть главное возражение покупателей: «{main_weakness}»."
            if main_weakness
            else f"Усилить на первом экране доказанную сильную сторону: «{best_strength}»."
            if best_strength
            else "Добавить на первый экран одну конкретную выгоду, а не общий рекламный лозунг."
        )
        needs_score = 82 if best_strength and main_weakness else 74 if (best_strength or main_weakness) else 58
        meaning_score = clamp_photo_value(0.62 * subject_score + 0.23 * contrast + 0.15 * detail_score)

        criteria = [
            photo_criterion_payload(
                "one_second_meaning",
                "Смысл за 1 секунду",
                meaning_score,
                f"Должно мгновенно считываться: «{one_second_meaning}».",
                f"Собрать обложку вокруг одной мысли: товар + выгода «{primary_offer}».",
                [
                    f"Товар в кадре: {round(subject_share)}%.",
                    f"Контраст: {round(contrast)}/100.",
                ],
            ),
            photo_criterion_payload(
                "product_scale",
                "Товар крупно и понятно",
                subject_score,
                "Оцениваем, насколько главный объект заметен в миниатюре и не зажат краями.",
                "Перекадрировать так, чтобы товар был главным объектом, а ключевая деталь читалась без приближения.",
                [f"Оценочная доля товара/объекта в кадре: {round(subject_share)}%."],
            ),
            photo_criterion_payload(
                "offers_load",
                "Офферы и перегруз",
                offer_overload_score,
                "На обложке должна быть одна главная выгода; перегруз текстом и акцентами снижает скорость выбора.",
                "Оставить один оффер на первом фото, второстепенные преимущества перенести на 2-3 слайд.",
                [f"Индекс визуальной загруженности: {round(visual_load)}%."],
            ),
            photo_criterion_payload(
                "mobile_readability",
                "Текст читается с телефона",
                mobile_text_score,
                "Если на обложке есть текст, он должен читаться в маленькой карточке выдачи.",
                "Проверить макет в размере 120-160 px: максимум 3-5 слов крупным кеглем, высокий контраст с фоном.",
                [
                    f"Контраст: {round(contrast)}/100.",
                    f"Перегруз: {round(visual_load)}%.",
                ],
            ),
            photo_criterion_payload(
                "composition_hierarchy",
                "Композиция и иерархия",
                composition_score,
                "Проверяем центр композиции, контраст, цветовую гамму и понятный главный акцент.",
                "Выстроить иерархию: сначала товар, затем короткая выгода, затем доказательство/деталь.",
                [
                    f"Смещение главного объекта от центра: {round(center_offset)}%.",
                    f"Цветовой акцент: {round(saturation)}%.",
                ],
            ),
            photo_criterion_payload(
                "competitive_standout",
                "Выделение среди конкурентов",
                standout_score,
                "Фото должно отличаться в выдаче за счет чистого силуэта, контраста, цвета или понятного результата.",
                "Добавить управляемый отличительный элемент: фирменный цвет, результат применения или сильную выгоду без шума.",
                [
                    f"Контраст: {round(contrast)}/100.",
                    f"Детальность: {round(detail_score)}/100.",
                ],
            ),
            photo_criterion_payload(
                "needs_objections",
                "Потребности и возражения",
                needs_score,
                "Обложка должна отвечать на главный мотив покупки и заранее снижать самое частое сомнение.",
                needs_action,
                [item for item in [f"Сила из отзывов: {best_strength}" if best_strength else "", f"Возражение: {main_weakness}" if main_weakness else ""] if item],
            ),
            photo_criterion_payload(
                "marketplace_safe_zones",
                f"Зоны плашек {marketplace_label}",
                safe_zone_score,
                f"Важный текст, лицо товара и ключевые детали не должны попадать в зоны бейджей, скидок и нижних плашек {marketplace_label}.",
                f"Освободить верхние углы и нижние 20-22% кадра от важного текста и ключевых деталей товара под плашки {marketplace_label}.",
                [
                    f"Активность в риск-зонах: {round(marketplace_zone_activity)}%.",
                    f"Верх слева: {round(top_left_activity)}%, верх справа: {round(top_right_activity)}%, низ: {round(bottom_activity)}%.",
                ],
            ),
        ]
        weighted_criteria = {
            "one_second_meaning": 0.17,
            "product_scale": 0.16,
            "offers_load": 0.12,
            "mobile_readability": 0.12,
            "composition_hierarchy": 0.16,
            "competitive_standout": 0.12,
            "needs_objections": 0.10,
            "marketplace_safe_zones": 0.05,
        }
        score = round(
            sum((item.get("score") or 0) * weighted_criteria.get(item.get("key"), 0.1) for item in criteria)
            / max(sum(weighted_criteria.values()), 1)
        )
        low_criteria = [item for item in criteria if (item.get("score") or 0) < 58]
        for item in low_criteria[:2]:
            recommendations.append(
                photo_recommendation(
                    "high" if (item.get("score") or 0) < 50 else "medium",
                    f"Усилить критерий: {item.get('label')}",
                    item.get("action") or "Переделать первый экран по этому критерию.",
                    item.get("summary") or "",
                )
            )
        designer_brief.append(f"Главный смысл первого фото: «{one_second_meaning}» + одна выгода «{primary_offer}».")

        if 48 <= brightness <= 82:
            strengths_found.append("Фото достаточно светлое: товар легче воспринимается в выдаче.")
        if contrast >= 52:
            strengths_found.append("Контраст выше среднего: контуры товара и элементы должны считываться увереннее.")
        if 34 <= subject_share <= 78:
            strengths_found.append("Товар занимает заметную часть кадра, но у изображения остаётся визуальный воздух.")
        if light_background_share >= 45:
            strengths_found.append("Светлый фон подходит для маркетплейса и не спорит с товаром.")

        if subject_share < 34:
            risks.append("Товар выглядит мелко: в поисковой выдаче его будет сложнее быстро распознать.")
            recommendations.append(
                photo_recommendation(
                    "high",
                    "Укрупнить товар в кадре",
                    "Перекадрировать первое фото так, чтобы товар занимал больше площади, а ключевая деталь была видна без приближения.",
                    f"Сейчас товар занимает примерно {round(subject_share)}% изображения.",
                )
            )
            designer_brief.append(f"Сделать товар крупнее: главный объект должен читаться в миниатюре {marketplace_label} без увеличения.")
        elif subject_share > 78:
            risks.append("Кадр может быть перегружен: товару и текстовым выгодам может не хватать свободного пространства.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Добавить воздуха вокруг товара",
                    "Чуть отдалить объект или переразложить композицию, чтобы оставить место под 1 сильную выгоду и не зажимать края.",
                    f"Оценочная заполненность кадра: {round(subject_share)}%.",
                )
            )

        if contrast < 45:
            risks.append("Низкий контраст: товар, тени или текстовые элементы могут сливаться с фоном.")
            recommendations.append(
                photo_recommendation(
                    "high",
                    "Усилить контраст и границы",
                    "Добавить мягкую тень, локальное затемнение/осветление и проверить читаемость на маленькой превью-карточке.",
                    f"Контраст первого фото: {round(contrast)}/100.",
                )
            )
            designer_brief.append("Проверить превью 120-160 px: товар и главная выгода должны читаться сразу.")

        if brightness < 46:
            risks.append("Фото темновато: товар может выглядеть дешевле и терять детали.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Осветлить первое фото",
                    "Поднять экспозицию и фон, но сохранить объём товара через тени и контур.",
                    f"Яркость первого фото: {round(brightness)}%.",
                )
            )
        elif brightness > 86:
            risks.append("Фото слишком светлое: светлые детали товара могут пропадать на фоне.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Вернуть объём светлым зонам",
                    "Снизить пересвет, добавить аккуратную тень или контур, чтобы края товара не растворялись.",
                    f"Яркость первого фото: {round(brightness)}%.",
                )
            )

        if saturation < 10:
            risks.append("Мало цветового акцента: карточка может теряться рядом с более выразительными конкурентами.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Добавить фирменный акцент",
                    "Использовать 1-2 цвета бренда для плашки, стрелки или короткой выгоды, не перекрывая сам товар.",
                    f"Средняя насыщенность: {round(saturation)}%.",
                )
            )
        elif saturation > 48:
            risks.append("Цвета очень насыщенные: есть риск ощущения дешёвой или перегруженной инфографики.")
            recommendations.append(
                photo_recommendation(
                    "low",
                    "Упростить цветовые акценты",
                    "Оставить один главный акцентный цвет и убрать второстепенный визуальный шум.",
                    f"Средняя насыщенность: {round(saturation)}%.",
                )
            )

        if detail_score < 26:
            risks.append("Мало визуальных деталей: покупателю может быть трудно понять материал, фактуру или комплектацию.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Показать важную деталь крупнее",
                    "Добавить рядом увеличенный фрагмент, фактуру, комплектацию или главный элемент, который влияет на выбор.",
                    f"Детальность первого фото: {round(detail_score)}/100.",
                )
            )

        if not (0.68 <= aspect_ratio <= 0.84):
            recommendations.append(
                photo_recommendation(
                    "low",
                    "Проверить вертикальное кадрирование",
                    "Подготовить первый слайд под витринный вертикальный формат: товар по центру, без обрезанных краёв.",
                    f"Текущее соотношение сторон: {width}×{height}.",
                )
            )

        best_strength = next((item.get("title") for item in strengths or [] if item.get("title")), "")
        main_weakness = next((item.get("title") for item in weaknesses or [] if item.get("title")), "")
        if best_strength:
            designer_brief.append(f"Вынести на первый экран выгоду по сильной стороне из отзывов: «{best_strength}».")
        if main_weakness:
            designer_brief.append(f"Закрыть возражение в первом или втором слайде: «{main_weakness}».")
        designer_brief.append("Собрать первый экран по схеме: товар крупно + одна главная выгода + короткое доказательство.")

        if not strengths_found:
            strengths_found.append("Фото загружено и пригодно для базового визуального аудита.")
        if not recommendations:
            recommendations.append(
                photo_recommendation(
                    "low",
                    "Закрепить сильный первый экран",
                    "Оставить текущую базовую композицию, но протестировать вариант с одной короткой выгодой на первом фото.",
                    "По базовым метрикам критичных визуальных проблем не найдено.",
                )
            )

        summary = (
            f"{photo_score_label(score)}: визуальная оценка {score}/100. "
            f"Для товара «{title}» главный резерв — {recommendations[0]['title'].lower()}."
        )

        return {
            "ok": True,
            "status": "analyzed",
            "imageNumber": image_number,
            "imageUrl": image_url,
            "sourceUrl": source_url,
            "contentType": content_type,
            "score": score,
            "scoreLabel": photo_score_label(score),
            "summary": summary,
            "metrics": metrics,
            "metricCards": [
                photo_metric_payload("Яркость", brightness, "%", "норма" if 48 <= brightness <= 82 else "проверить"),
                photo_metric_payload("Контраст", contrast, "/100", "норма" if contrast >= 52 else "усилить"),
                photo_metric_payload("Цветовой акцент", saturation, "%", "норма" if 10 <= saturation <= 48 else "проверить"),
                photo_metric_payload("Товар в кадре", subject_share, "%", "норма" if 34 <= subject_share <= 78 else "перекадрировать"),
                photo_metric_payload("Светлый фон", light_background_share, "%", "норма" if light_background_share >= 45 else "проверить"),
                photo_metric_payload("Детальность", detail_score, "/100", "норма" if detail_score >= 26 else "усилить"),
                photo_metric_payload("Перегруз", visual_load, "%", "норма" if 24 <= visual_load <= 64 else "проверить"),
                photo_metric_payload(f"Зоны {marketplace_label}", marketplace_zone_activity, "%", "чисто" if marketplace_zone_activity < 18 else "проверить"),
            ],
            "criteria": criteria,
            "strengths": strengths_found[:4],
            "risks": risks[:5],
            "recommendations": recommendations[:5],
            "designerBrief": designer_brief[:5],
        }
    except AppError as exc:
        return {
            "ok": False,
            "status": "image_unavailable",
            "imageUrl": image_url,
            "sourceUrl": fallback_source_url,
            "summary": "Не удалось загрузить первое фото товара для визуального анализа.",
            "error": exc.message,
            "recommendations": [
                photo_recommendation(
                    "medium",
                    "Проверить первое фото карточки",
                    f"Открыть товар на {marketplace_label} и убедиться, что первое изображение загружается и не скрыто ограничениями площадки.",
                    exc.message,
                )
            ],
        }
    except Exception as exc:
        return {
            "ok": False,
            "status": "analysis_error",
            "imageUrl": image_url,
            "sourceUrl": fallback_source_url,
            "summary": "Первое фото найдено, но визуальный анализ временно не выполнен.",
            "error": str(exc),
            "recommendations": [
                photo_recommendation(
                    "low",
                    "Повторить анализ позже",
                    "Если фото в карточке открывается, повторите анализ после обновления сервиса или уменьшите нагрузку.",
                    str(exc),
                )
            ],
        }


def recommendation_reason(aspect: dict[str, Any], negative_pct: int | None) -> str:
    mentions = aspect.get("negativeMentions") or aspect.get("mentions") or 0
    title = aspect.get("title") or "Общее впечатление"
    terms = aspect.get("terms") or []
    reason = f"В теме «{title}» найдено {mentions} проблемных упоминаний."
    if terms:
        reason += " Частые слова: " + ", ".join(terms[:4]) + "."
    if negative_pct is not None and negative_pct >= 12:
        reason += f" Доля оценок 1-3★: {negative_pct}%."
    return reason


def make_recommendation(area: str, aspect: dict[str, Any], negative_pct: int | None) -> dict[str, Any]:
    key = aspect.get("key") or "overall"
    template = RECOMMENDATION_TEMPLATES.get(key, RECOMMENDATION_TEMPLATES["overall"])
    priority = recommendation_priority(int(aspect.get("negativeMentions") or aspect.get("mentions") or 0), negative_pct)
    title_key = "content_title" if area == "content" else "product_title"
    action_key = "content_action" if area == "content" else "product_action"

    return {
        "id": f"{area}-{key}",
        "area": area,
        "aspect": aspect.get("title") or "Общее впечатление",
        "priority": priority,
        "priorityLabel": priority_label(priority),
        "title": template[title_key],
        "action": template[action_key],
        "reason": recommendation_reason(aspect, negative_pct),
        "evidence": (aspect.get("evidence") or [])[:2],
    }


def make_strength_recommendation(strength: dict[str, Any]) -> dict[str, Any]:
    key = strength.get("key") or "overall"
    aspect_title = strength.get("title") or "сильную сторону"
    terms = strength.get("terms") or []
    reason = f"Эту тему уже хвалят: {strength.get('positiveMentions') or strength.get('mentions') or 0} положительных упоминаний."
    if terms:
        reason += " Формулировки покупателей: " + ", ".join(terms[:4]) + "."

    return {
        "id": f"content-amplify-{key}",
        "area": "content",
        "aspect": aspect_title,
        "priority": "medium",
        "priorityLabel": priority_label("medium"),
        "title": "Усилить то, что уже продаёт",
        "action": (
            f"Вынесите «{aspect_title.lower()}» в главное фото, инфографику или первые строки описания; "
            "используйте реальные слова покупателей и подкрепите их фото/видео доказательством."
        ),
        "reason": reason,
        "evidence": (strength.get("evidence") or [])[:2],
    }


def add_unique_recommendation(items: list[dict[str, Any]], item: dict[str, Any], limit: int) -> None:
    if len(items) >= limit:
        return
    if any(existing["id"] == item["id"] for existing in items):
        return
    items.append(item)


def option_value_text(option: dict[str, Any]) -> str:
    values = option.get("variable_values")
    if isinstance(values, list) and values:
        return "; ".join(as_text(value) for value in values if as_text(value))
    value = option.get("value")
    if isinstance(value, list):
        return "; ".join(as_text(item) for item in value if as_text(item))
    return as_text(value)


def card_option_items(card_meta: dict[str, Any]) -> list[dict[str, str]]:
    items: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()

    def add_option(option: dict[str, Any], source: str) -> None:
        name = as_text(option.get("name"))
        value = option_value_text(option)
        if not name or not value:
            return
        key = (name.lower(), value.lower())
        if key in seen:
            return
        seen.add(key)
        items.append({"name": name, "value": value, "source": source})

    for group in card_meta.get("grouped_options") or []:
        if not isinstance(group, dict):
            continue
        source = as_text(group.get("group_name")) or "Характеристики карточки"
        for option in group.get("options") or []:
            if isinstance(option, dict):
                add_option(option, source)

    for option in card_meta.get("options") or []:
        if isinstance(option, dict):
            add_option(option, "Характеристики карточки")

    return items


def product_characteristic_items(product: dict[str, Any], card_meta: dict[str, Any]) -> list[dict[str, str]]:
    items = card_option_items(card_meta)
    seen = {(item["name"].lower(), item["value"].lower()) for item in items}

    def add(name: str, value: str, source: str) -> None:
        value = short_text(value, 120)
        if not name or not value:
            return
        key = (name.lower(), value.lower())
        if key in seen:
            return
        seen.add(key)
        items.append({"name": name, "value": value, "source": source})

    colors = product.get("colors")
    if isinstance(colors, list):
        color_names = [as_text(item.get("name")) for item in colors if isinstance(item, dict) and as_text(item.get("name"))]
        if color_names:
            add("Цвет", "; ".join(color_names[:4]), "Карточка товара")

    sizes = product.get("sizes")
    if isinstance(sizes, list):
        size_names = []
        for item in sizes[:8]:
            if not isinstance(item, dict):
                continue
            size = as_text(item.get("origName") or item.get("name"))
            if size and size not in size_names:
                size_names.append(size)
        if size_names:
            add("Размерный ряд", "; ".join(size_names), "Карточка товара")

    volume = safe_float(product.get("volume"))
    if volume:
        add("Объем упаковки", f"{volume:g}", "Карточка товара")
    weight = safe_float(product.get("weight"))
    if weight:
        add("Вес", f"{weight:g}", "Карточка товара")

    description = as_text(card_meta.get("description"))
    if description and len(items) < 4:
        for sentence in split_sentences(description):
            if len(sentence) < 28:
                continue
            add("Описание", sentence, "Описание карточки")
            if len(items) >= 5:
                break

    return items


def hpv_related_key(name: str, value: str) -> str:
    text = normalize_opinion(f"{name} {value}")
    if any(word in text for word in ("состав", "материал", "ткан", "хлоп", "шерст", "полиэстер", "эластан", "кожа")):
        return "quality"
    if any(word in text for word in ("размер", "рост", "длина", "ширина", "посад", "обхват")):
        return "fit"
    if any(word in text for word in ("цвет", "оттен", "принт", "рисунок", "дизайн")):
        return "appearance"
    if any(word in text for word in ("назнач", "сезон", "повсед", "спорт", "дом", "школ", "работ")):
        return "comfort"
    if any(word in text for word in ("комплект", "набор", "штук", "пара", "колич")):
        return "completeness"
    if any(word in text for word in ("вес", "объем", "размер упаков", "габарит")):
        return "packaging"
    if any(word in text for word in ("уход", "стир", "мыть", "чист")):
        return "quality"
    return "overall"


def hpv_copy(name: str, value: str, product_title: str, category: str, key: str) -> dict[str, str]:
    subject = category or product_title or "товар"
    characteristic = f"{name}: {value}"
    if key == "quality":
        return {
            "advantage": "Покупатель видит не сухой состав, а причину доверять качеству, фактуре и сроку службы.",
            "benefit": f"{subject}: материал и исполнение подобраны так, чтобы товар был приятен в использовании и выглядел аккуратно после покупки.",
            "cardText": f"Заменить сухое «{characteristic}» на выгоду: «Комфортный материал для ежедневного использования: приятен к телу, держит форму и не выглядит дешево».",
            "infographicText": "Слайд: «Материал = комфорт каждый день» + крупный план фактуры/шва/детали.",
        }
    if key == "fit":
        return {
            "advantage": "Размерная информация снижает риск ошибки и возврата.",
            "benefit": "Покупатель быстрее понимает, подойдет ли товар именно ему, и увереннее добавляет его в корзину.",
            "cardText": f"Заменить «{characteristic}» на: «Легко выбрать размер: ориентируйтесь на фактические параметры и посадку, чтобы не заказывать наугад».",
            "infographicText": "Слайд: «Как выбрать размер» + схема замеров, посадка, подсказка маломерит/в размер/большемерит.",
        }
    if key == "appearance":
        return {
            "advantage": "Визуальная характеристика превращается в обещание понятного внешнего вида без сюрпризов.",
            "benefit": "Покупатель заранее понимает оттенок, стиль и сочетание товара с другими вещами.",
            "cardText": f"Заменить «{characteristic}» на: «Цвет и внешний вид легко сочетать в базовых образах; оттенок показан на фото без лишней обработки».",
            "infographicText": "Слайд: «Реальный цвет» + фото при дневном свете и крупный план детали.",
        }
    if key == "comfort":
        return {
            "advantage": "Назначение объясняет сценарий использования, а не просто перечисляет категорию.",
            "benefit": f"Покупатель понимает, когда и зачем брать этот {subject.lower()}, и быстрее соотносит товар со своей задачей.",
            "cardText": f"Заменить «{characteristic}» на: «Подходит для конкретного сценария: каждый день, дорога, дом, работа или подарок — без лишних сомнений при выборе».",
            "infographicText": "Слайд: «Когда использовать» + 3 сценария применения и понятные пиктограммы.",
        }
    if key == "completeness":
        return {
            "advantage": "Комплектация показывает экономию, удобство и отсутствие сюрпризов при получении.",
            "benefit": "Покупатель сразу понимает, что входит в заказ и почему набор выгоднее одиночной покупки.",
            "cardText": f"Заменить «{characteristic}» на: «Все нужное сразу в одном заказе: понятная комплектация, удобно для себя, семьи или запаса».",
            "infographicText": "Слайд: «Что входит в набор» + разложить комплект по элементам/количеству.",
        }
    if key == "packaging":
        return {
            "advantage": "Габариты и упаковка становятся аргументом про доставку, хранение и получение товара без повреждений.",
            "benefit": "Покупатель понимает, как товар придет, сколько места займет и что защищено при доставке.",
            "cardText": f"Заменить «{characteristic}» на: «Удобно получить и хранить: упаковка защищает товар и не занимает лишнее место».",
            "infographicText": "Слайд: «Получаете аккуратно упакованный товар» + фото упаковки и состава заказа.",
        }
    return {
        "advantage": "Характеристика становится понятным аргументом выбора.",
        "benefit": "Покупатель видит не параметр ради параметра, а личную пользу: проще выбрать, меньше сомнений, понятнее ожидания.",
        "cardText": f"Заменить «{characteristic}» на: «Эта характеристика дает понятную пользу при использовании: товар проще выбрать и легче оценить до покупки».",
        "infographicText": "Слайд: «Почему это важно» + параметр, простая выгода и визуальное доказательство.",
    }


def hpv_reason(key: str, strengths: list[dict[str, Any]], weaknesses: list[dict[str, Any]]) -> str:
    weak = next((item for item in weaknesses if item.get("key") == key), None)
    strong = next((item for item in strengths if item.get("key") == key), None)
    if weak:
        terms = weak.get("terms") or []
        reason = f"В отзывах есть риск по теме «{weak.get('title')}»: {weak.get('negativeMentions') or weak.get('mentions')} проблемных упоминаний."
        if terms:
            reason += " Частые слова: " + ", ".join(terms[:3]) + "."
        return reason
    if strong:
        terms = strong.get("terms") or []
        reason = f"Эту тему уже хвалят: {strong.get('positiveMentions') or strong.get('mentions')} положительных упоминаний."
        if terms:
            reason += " Можно использовать слова покупателей: " + ", ".join(terms[:3]) + "."
        return reason
    return "В карточке есть характеристика, но ее лучше раскрыть как выгоду в первом экране и инфографике."


def build_hpv_recommendations(
    product: dict[str, Any],
    card_meta: dict[str, Any] | None,
    strengths: list[dict[str, Any]],
    weaknesses: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    card_meta = card_meta or {}
    product_title = as_text(card_meta.get("imt_name") or product.get("name"))
    category = as_text(card_meta.get("subj_name") or product.get("entity"))
    source_items = product_characteristic_items(product, card_meta)

    if not source_items:
        source_items = [
            {
                "name": "Сильная сторона из отзывов",
                "value": strengths[0].get("title") if strengths else product_title or "товар",
                "source": "Отзывы покупателей",
            }
        ]

    priority_order = {
        "quality": 0,
        "fit": 1,
        "comfort": 2,
        "appearance": 3,
        "completeness": 4,
        "packaging": 5,
        "overall": 6,
    }
    prepared = []
    for item in source_items:
        key = hpv_related_key(item["name"], item["value"])
        prepared.append((priority_order.get(key, 6), key, item))
    prepared.sort(key=lambda item: (item[0], len(item[2]["value"])))

    rows = []
    seen_keys: set[str] = set()
    for _, key, item in prepared:
        identity = f"{item['name'].lower()}:{item['value'].lower()}"
        if identity in seen_keys:
            continue
        seen_keys.add(identity)
        copy = hpv_copy(item["name"], item["value"], product_title, category, key)
        priority = "high" if any(weak.get("key") == key for weak in weaknesses) else "medium"
        if key == "overall":
            priority = "low"
        rows.append(
            {
                "id": f"hpv-{len(rows) + 1}-{key}",
                "priority": priority,
                "priorityLabel": priority_label(priority),
                "source": item["source"],
                "aspect": ASPECTS.get(key, {}).get("title", "Общее впечатление"),
                "characteristic": f"{item['name']}: {item['value']}",
                "advantage": copy["advantage"],
                "benefit": copy["benefit"],
                "cardText": copy["cardText"],
                "infographicText": copy["infographicText"],
                "why": hpv_reason(key, strengths, weaknesses),
            }
        )
        if len(rows) >= 6:
            break
    return rows


def build_recommendations(
    strengths: list[dict[str, Any]],
    weaknesses: list[dict[str, Any]],
    negative_pct: int | None,
    matching_size: dict[str, Any],
    text_count: int,
    product_card: dict[str, Any] | None = None,
    card_meta: dict[str, Any] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    content: list[dict[str, Any]] = []
    product_recs: list[dict[str, Any]] = []

    for weakness in weaknesses[:4]:
        add_unique_recommendation(content, make_recommendation("content", weakness, negative_pct), 5)
        add_unique_recommendation(product_recs, make_recommendation("product", weakness, negative_pct), 5)

    if matching_size:
        smaller = int(matching_size.get("smaller") or 0)
        bigger = int(matching_size.get("bigger") or 0)
        if max(smaller, bigger) >= 8 and not any(item["id"] == "content-fit" for item in content):
            fit_aspect = {
                "key": "fit",
                "title": ASPECTS["fit"]["title"],
                "mentions": max(smaller, bigger),
                "negativeMentions": max(smaller, bigger),
                "terms": ["маломерит" if smaller >= bigger else "большемерит"],
                "evidence": [],
            }
            add_unique_recommendation(content, make_recommendation("content", fit_aspect, negative_pct), 5)
            add_unique_recommendation(product_recs, make_recommendation("product", fit_aspect, negative_pct), 5)

    for strength in strengths[:3]:
        add_unique_recommendation(content, make_strength_recommendation(strength), 5)

    if text_count < 20:
        add_unique_recommendation(
            content,
            {
                "id": "content-more-proof",
                "area": "content",
                "aspect": "Доверие к карточке",
                "priority": "medium",
                "priorityLabel": priority_label("medium"),
                "title": "Добавить больше доказательств в карточку",
                "action": (
                    "Так как текстовых отзывов мало, компенсируйте неопределённость: больше реальных фото, видео, "
                    "замеры, комплектация, честные ограничения и ответы на типовые вопросы."
                ),
                "reason": f"Доступно только {text_count} текстовых отзывов, выводы по ним менее устойчивы.",
                "evidence": [],
            },
            5,
        )

    if not product_recs:
        add_unique_recommendation(
            product_recs,
            {
                "id": "product-maintain-quality",
                "area": "product",
                "aspect": "Контроль качества",
                "priority": "low",
                "priorityLabel": priority_label("low"),
                "title": "Сохранить текущий уровень товара",
                "action": (
                    "Повторяющихся проблем мало: закрепите чек-лист качества для поставщика и отслеживайте новые "
                    "отзывы на 1-3★, чтобы быстро ловить просадку партии."
                ),
                "reason": "В текстах нет сильного повторяющегося негативного сигнала.",
                "evidence": [],
            },
            5,
        )

    priority_order = {"high": 0, "medium": 1, "low": 2}
    priority_actions = sorted(
        content[:2] + product_recs[:3],
        key=lambda item: (priority_order.get(item["priority"], 1), item["area"]),
    )[:4]

    return {
        "content": content,
        "product": product_recs,
        "priorityActions": priority_actions,
        "hpv": build_hpv_recommendations(product_card or {}, card_meta or {}, strengths, weaknesses),
    }


def xlsx_col(index: int) -> str:
    result = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        result = chr(65 + remainder) + result
    return result


def xlsx_ref(row_count: int, col_count: int) -> str:
    if row_count <= 0 or col_count <= 0:
        return "A1"
    return f"A1:{xlsx_col(col_count)}{row_count}"


def xlsx_text(value: Any, style: int | None = None) -> dict[str, Any]:
    return {"value": "" if value is None else str(value), "type": "text", "style": style}


def xlsx_number(value: Any, style: int | None = None) -> dict[str, Any]:
    number = safe_float(value)
    return {"value": "" if number is None else number, "type": "number", "style": style}


def xlsx_date(value: Any, style: int | None = None) -> dict[str, Any]:
    text = as_text(value)
    if not text:
        return xlsx_text("", style)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        try:
            parsed = datetime.fromisoformat(text[:10])
        except ValueError:
            return xlsx_text(text[:10], style)
    base = datetime(1899, 12, 30, tzinfo=timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    serial = (parsed.astimezone(timezone.utc) - base).total_seconds() / 86400
    return {"value": serial, "type": "number", "style": style or 5}


def xlsx_percent(value: Any, style: int | None = None) -> dict[str, Any]:
    number = safe_float(value)
    if number is None:
        return xlsx_text("", style)
    if number > 1:
        number = number / 100
    return {"value": number, "type": "number", "style": style or 6}


def xlsx_header_row(headers: list[str]) -> list[dict[str, Any]]:
    return [xlsx_text(header, 1) for header in headers]


def xlsx_cell_xml(cell: dict[str, Any], cell_ref: str) -> str:
    value = cell.get("value", "")
    style = cell.get("style")
    style_attr = f' s="{style}"' if style is not None else ""
    if value == "":
        return f'<c r="{cell_ref}"{style_attr}/>'
    if cell.get("type") == "number":
        return f'<c r="{cell_ref}"{style_attr}><v>{value}</v></c>'
    escaped = xml_escape(str(value))
    return f'<c r="{cell_ref}" t="inlineStr"{style_attr}><is><t>{escaped}</t></is></c>'


def xlsx_worksheet_xml(
    rows: list[list[dict[str, Any]]],
    widths: list[float] | None = None,
    freeze_header: bool = True,
    auto_filter: bool = True,
) -> str:
    row_count = len(rows)
    col_count = max((len(row) for row in rows), default=1)
    dimension = xlsx_ref(row_count, col_count)
    cols_xml = ""
    if widths:
        cols = []
        for index, width in enumerate(widths, start=1):
            cols.append(f'<col min="{index}" max="{index}" width="{width}" customWidth="1"/>')
        cols_xml = "<cols>" + "".join(cols) + "</cols>"

    sheet_views = ""
    if freeze_header and row_count > 1:
        sheet_views = (
            '<sheetViews><sheetView workbookViewId="0">'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            "</sheetView></sheetViews>"
        )
    else:
        sheet_views = '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'

    sheet_rows = []
    for row_index, row in enumerate(rows, start=1):
        cells = []
        for col_index in range(1, col_count + 1):
            cell = row[col_index - 1] if col_index <= len(row) else xlsx_text("")
            cells.append(xlsx_cell_xml(cell, f"{xlsx_col(col_index)}{row_index}"))
        sheet_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')

    filter_xml = f'<autoFilter ref="{dimension}"/>' if auto_filter and row_count > 1 and col_count > 1 else ""
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        f'<dimension ref="{dimension}"/>'
        f"{sheet_views}"
        '<sheetFormatPr defaultRowHeight="15"/>'
        f"{cols_xml}"
        f'<sheetData>{"".join(sheet_rows)}</sheetData>'
        f"{filter_xml}"
        "</worksheet>"
    )


def xlsx_styles_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="2">
    <numFmt numFmtId="164" formatCode="yyyy-mm-dd"/>
    <numFmt numFmtId="165" formatCode="0.0%"/>
  </numFmts>
  <fonts count="3">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font>
    <font><b/><sz val="14"/><name val="Calibri"/></font>
  </fonts>
  <fills count="4">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF245F73"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFEFF4F0"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFD9DFD8"/></left><right style="thin"><color rgb="FFD9DFD8"/></right><top style="thin"><color rgb="FFD9DFD8"/></top><bottom style="thin"><color rgb="FFD9DFD8"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="8">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
    <xf numFmtId="2" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
    <xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def workbook_xml(sheet_names: list[str]) -> str:
    sheets_xml = []
    for index, name in enumerate(sheet_names, start=1):
        sheets_xml.append(
            f'<sheet name="{xml_escape(name)}" sheetId="{index}" r:id="rId{index}"/>'
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheets>{"".join(sheets_xml)}</sheets>'
        "</workbook>"
    )


def workbook_rels_xml(sheet_count: int) -> str:
    rels = []
    for index in range(1, sheet_count + 1):
        rels.append(
            f'<Relationship Id="rId{index}" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
            f'Target="worksheets/sheet{index}.xml"/>'
        )
    rels.append(
        f'<Relationship Id="rId{sheet_count + 1}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/>'
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'{"".join(rels)}'
        "</Relationships>"
    )


def content_types_xml(sheet_count: int) -> str:
    overrides = [
        '<Override PartName="/xl/workbook.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
        '<Override PartName="/docProps/core.xml" '
        'ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
        '<Override PartName="/docProps/app.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
    ]
    for index in range(1, sheet_count + 1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{index}.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        f'{"".join(overrides)}'
        "</Types>"
    )


def root_rels_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" '
        'Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" '
        'Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" '
        'Target="docProps/app.xml"/>'
        "</Relationships>"
    )


def core_props_xml() -> str:
    created = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        "<dc:creator>WB Review Analyzer</dc:creator>"
        "<cp:lastModifiedBy>WB Review Analyzer</cp:lastModifiedBy>"
        f'<dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created>'
        f'<dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified>'
        "</cp:coreProperties>"
    )


def app_props_xml(sheet_names: list[str]) -> str:
    titles = "".join(f'<vt:lpstr>{xml_escape(name)}</vt:lpstr>' for name in sheet_names)
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        "<Application>WB Review Analyzer</Application>"
        f"<Worksheets>{len(sheet_names)}</Worksheets>"
        '<TitlesOfParts><vt:vector size="'
        f'{len(sheet_names)}" baseType="lpstr">{titles}</vt:vector></TitlesOfParts>'
        "</Properties>"
    )


def evidence_to_text(evidence: list[dict[str, Any]]) -> str:
    parts = []
    for item in evidence[:3]:
        rating = f"{item.get('rating')}★" if item.get("rating") else "без оценки"
        date = f", {item.get('date')}" if item.get("date") else ""
        parts.append(f"{rating}{date}: {item.get('text')}")
    return " | ".join(parts)


def terms_to_text(terms: list[Any]) -> str:
    if not terms:
        return ""
    if isinstance(terms[0], dict):
        return ", ".join(f"{item.get('term')} ({item.get('count')})" for item in terms)
    return ", ".join(str(term) for term in terms)


def recommendation_rows(recommendations: dict[str, list[dict[str, Any]]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "Раздел",
                "Приоритет",
                "Блок",
                "Аспект",
                "Рекомендация",
                "Что сделать",
                "Почему",
                "Примеры из отзывов",
            ]
        )
    ]
    sections = [
        ("Что сделать сначала", recommendations.get("priorityActions") or []),
        ("Контент карточки", recommendations.get("content") or []),
        ("Товар и поставка", recommendations.get("product") or []),
    ]
    for section, items in sections:
        for item in items:
            rows.append(
                [
                    xlsx_text(section, 2),
                    xlsx_text(item.get("priorityLabel"), 2),
                    xlsx_text("Товар" if item.get("area") == "product" else "Контент", 2),
                    xlsx_text(item.get("aspect"), 2),
                    xlsx_text(item.get("title"), 2),
                    xlsx_text(item.get("action"), 2),
                    xlsx_text(item.get("reason"), 2),
                    xlsx_text(evidence_to_text(item.get("evidence") or []), 2),
                ]
            )
    return rows


def hpv_rows(items: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "Источник",
                "Приоритет",
                "Аспект",
                "Характеристика",
                "Преимущество",
                "Выгода",
                "Текст для карточки",
                "Текст для инфографики",
                "Почему",
            ]
        )
    ]
    for item in items:
        rows.append(
            [
                xlsx_text(item.get("source"), 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("aspect"), 2),
                xlsx_text(item.get("characteristic"), 2),
                xlsx_text(item.get("advantage"), 2),
                xlsx_text(item.get("benefit"), 2),
                xlsx_text(item.get("cardText"), 2),
                xlsx_text(item.get("infographicText"), 2),
                xlsx_text(item.get("why"), 2),
            ]
        )
    if len(rows) == 1:
        rows.append([xlsx_text("Нет данных для ХПВ-рекомендаций.", 2)])
    return rows


def photo_rows(photo: dict[str, Any] | None) -> list[list[dict[str, Any]]]:
    photo = photo or {}
    rows = [
        xlsx_header_row(["Тип", "Показатель", "Балл/значение", "Статус", "Диагноз", "Что сделать", "Доказательства"]),
    ]
    if not photo:
        rows.append([xlsx_text("Нет данных по первому фото.", 2)])
        return rows

    rows.append(
        [
            xlsx_text("Итог", 2),
            xlsx_text(photo.get("scoreLabel"), 2),
            xlsx_number(photo.get("score"), 4),
            xlsx_text(photo.get("status"), 2),
            xlsx_text(photo.get("summary"), 2),
            xlsx_text("", 2),
            xlsx_text(photo.get("sourceUrl"), 2),
        ]
    )
    for item in photo.get("criteria") or []:
        rows.append(
            [
                xlsx_text("Критерий", 2),
                xlsx_text(item.get("label"), 2),
                xlsx_number(item.get("score"), 4),
                xlsx_text(item.get("status"), 2),
                xlsx_text(item.get("summary"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text("; ".join(item.get("evidence") or []), 2),
            ]
        )
    for item in photo.get("metricCards") or []:
        value = item.get("value")
        unit = item.get("unit") or ""
        rows.append(
            [
                xlsx_text("Метрика", 2),
                xlsx_text(item.get("label"), 2),
                xlsx_text(f"{value}{unit}" if value is not None else "", 2),
                xlsx_text(item.get("verdict"), 2),
                xlsx_text("", 2),
                xlsx_text("", 2),
                xlsx_text("", 2),
            ]
        )
    for item in photo.get("recommendations") or []:
        rows.append(
            [
                xlsx_text("Рекомендация", 2),
                xlsx_text(item.get("title"), 2),
                xlsx_text("", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("reason"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text("", 2),
            ]
        )
    return rows


def aspect_rows(title: str, items: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "Аспект",
                "Упоминания",
                "Позитивные",
                "Негативные",
                "Баланс",
                "Частые слова",
                "Кратко",
                "Примеры из отзывов",
            ]
        )
    ]
    for item in items:
        rows.append(
            [
                xlsx_text(item.get("title"), 2),
                xlsx_number(item.get("mentions"), 4),
                xlsx_number(item.get("positiveMentions"), 4),
                xlsx_number(item.get("negativeMentions"), 4),
                xlsx_number(item.get("balance"), 4),
                xlsx_text(terms_to_text(item.get("terms") or []), 2),
                xlsx_text(item.get("summary"), 2),
                xlsx_text(evidence_to_text(item.get("evidence") or []), 2),
            ]
        )
    if len(rows) == 1:
        rows.append([xlsx_text(f"Нет данных для листа «{title}».", 2)])
    return rows


def topics_rows(terms: dict[str, list[dict[str, Any]]]) -> list[list[dict[str, Any]]]:
    rows = [xlsx_header_row(["Тип", "Тема", "Количество"])]
    labels = {"positive": "Часто хвалят", "negative": "Часто критикуют", "neutral": "Нейтральные темы"}
    for key in ("positive", "negative", "neutral"):
        for item in terms.get(key) or []:
            rows.append([xlsx_text(labels[key], 2), xlsx_text(item.get("term"), 2), xlsx_number(item.get("count"), 4)])
    return rows


def examples_rows(examples: dict[str, list[dict[str, Any]]]) -> list[list[dict[str, Any]]]:
    rows = [xlsx_header_row(["Тип", "Оценка", "Дата", "Цвет", "Размер", "Текст"])]
    labels = {"positive": "Плюс", "negative": "Минус"}
    for key in ("positive", "negative"):
        for item in examples.get(key) or []:
            rows.append(
                [
                    xlsx_text(labels[key], 2),
                    xlsx_number(item.get("rating"), 4),
                    xlsx_date(item.get("date")),
                    xlsx_text(item.get("color"), 2),
                    xlsx_text(item.get("size"), 2),
                    xlsx_text(item.get("text"), 2),
                ]
            )
    return rows


def feedback_rows(feedbacks: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "ID отзыва",
                "Дата",
                "Оценка",
                "Цвет",
                "Размер",
                "Соответствие размеру",
                "Достоинства",
                "Недостатки",
                "Комментарий",
                "Теги",
            ]
        )
    ]
    for feedback in feedbacks:
        tags = feedback.get("tags") or []
        tag_text = ", ".join(str(tag.get("status") or tag.get("id")) for tag in tags if isinstance(tag, dict))
        rows.append(
            [
                xlsx_text(feedback.get("id"), 2),
                xlsx_date(feedback.get("createdDate")),
                xlsx_number(feedback.get("productValuation"), 4),
                xlsx_text(feedback.get("color"), 2),
                xlsx_text(feedback.get("size"), 2),
                xlsx_text(feedback.get("matchingSize") or feedback.get("matchingDescription"), 2),
                xlsx_text(feedback.get("pros"), 2),
                xlsx_text(feedback.get("cons"), 2),
                xlsx_text(feedback.get("text"), 2),
                xlsx_text(tag_text, 2),
            ]
        )
    return rows


def summary_rows(analysis: dict[str, Any]) -> list[list[dict[str, Any]]]:
    product = analysis["product"]
    summary = analysis["summary"]
    size = summary.get("matchingSizePercentages") or {}
    marketplace_label = product.get("marketplaceLabel") or "WB"
    rows = [
        [xlsx_text(f"Анализ отзывов {marketplace_label}", 3), xlsx_text("", 3)],
        [xlsx_text("Показатель", 1), xlsx_text("Значение", 1)],
        [xlsx_text("Артикул", 2), xlsx_text(product.get("article"), 2)],
        [xlsx_text("ID / root / product_id", 2), xlsx_text(product.get("root"), 2)],
        [xlsx_text("Бренд", 2), xlsx_text(product.get("brand"), 2)],
        [xlsx_text("Название", 2), xlsx_text(product.get("name"), 2)],
        [xlsx_text("Поставщик", 2), xlsx_text(product.get("supplier"), 2)],
        [xlsx_text("Средняя оценка", 2), xlsx_number(summary.get("averageRating"), 4)],
        [xlsx_text("Всего отзывов", 2), xlsx_number(summary.get("feedbackCount"), 4)],
        [xlsx_text("Текстовых отзывов", 2), xlsx_number(summary.get("textFeedbackCount"), 4)],
        [xlsx_text("Загружено в анализ", 2), xlsx_number(summary.get("loadedReviews"), 4)],
        [xlsx_text("Оценки 4-5★", 2), xlsx_percent(summary.get("positiveRatingPercent"))],
        [xlsx_text("Оценки 1-3★", 2), xlsx_percent(summary.get("negativeRatingPercent"))],
        [xlsx_text("Размер в размер", 2), xlsx_percent(size.get("ok"))],
        [xlsx_text("Маломерит", 2), xlsx_percent(size.get("smaller"))],
        [xlsx_text("Большемерит", 2), xlsx_percent(size.get("bigger"))],
        [xlsx_text("Вердикт", 2), xlsx_text(summary.get("verdict"), 2)],
        [xlsx_text("Ссылка на товар", 2), xlsx_text(product.get("url"), 2)],
        [xlsx_text("Дата выгрузки", 2), xlsx_date(datetime.now(timezone.utc).isoformat())],
    ]

    distribution = summary.get("distribution") or {}
    rows.extend(
        [
            [xlsx_text("", 2), xlsx_text("", 2)],
            [xlsx_text("Распределение оценок", 1), xlsx_text("Количество", 1)],
        ]
    )
    for star in ("5", "4", "3", "2", "1"):
        rows.append([xlsx_text(f"{star}★", 2), xlsx_number(distribution.get(star), 4)])
    return rows


def build_xlsx(sheets: list[dict[str, Any]]) -> bytes:
    sheet_names = [sheet["name"] for sheet in sheets]
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types_xml(len(sheets)))
        archive.writestr("_rels/.rels", root_rels_xml())
        archive.writestr("docProps/core.xml", core_props_xml())
        archive.writestr("docProps/app.xml", app_props_xml(sheet_names))
        archive.writestr("xl/workbook.xml", workbook_xml(sheet_names))
        archive.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml(len(sheets)))
        archive.writestr("xl/styles.xml", xlsx_styles_xml())
        for index, sheet in enumerate(sheets, start=1):
            archive.writestr(
                f"xl/worksheets/sheet{index}.xml",
                xlsx_worksheet_xml(
                    sheet["rows"],
                    widths=sheet.get("widths"),
                    freeze_header=sheet.get("freeze_header", True),
                    auto_filter=sheet.get("auto_filter", True),
                ),
            )
    return buffer.getvalue()


def build_export_workbook(analysis: dict[str, Any], feedback_data: dict[str, Any], limit: int) -> bytes:
    feedbacks = (feedback_data.get("feedbacks") or [])[:limit]
    sheets = [
        {
            "name": "Сводка",
            "rows": summary_rows(analysis),
            "widths": [28, 80],
            "freeze_header": False,
            "auto_filter": False,
        },
        {
            "name": "Рекомендации",
            "rows": recommendation_rows(analysis.get("recommendations") or {}),
            "widths": [22, 14, 14, 24, 34, 70, 70, 70],
        },
        {
            "name": "ХПВ",
            "rows": hpv_rows((analysis.get("recommendations") or {}).get("hpv") or []),
            "widths": [22, 14, 22, 42, 52, 58, 72, 62, 58],
        },
        {
            "name": "Первое фото",
            "rows": photo_rows(analysis.get("firstPhotoAnalysis") or {}),
            "widths": [18, 28, 16, 16, 60, 70, 60],
        },
        {
            "name": "Сильные",
            "rows": aspect_rows("Сильные", analysis.get("strengths") or []),
            "widths": [24, 14, 14, 14, 12, 38, 70, 70],
        },
        {
            "name": "Слабые",
            "rows": aspect_rows("Слабые", analysis.get("weaknesses") or []),
            "widths": [24, 14, 14, 14, 12, 38, 70, 70],
        },
        {
            "name": "Темы",
            "rows": topics_rows(analysis.get("terms") or {}),
            "widths": [22, 36, 14],
        },
        {
            "name": "Примеры",
            "rows": examples_rows(analysis.get("examples") or {}),
            "widths": [14, 10, 14, 18, 18, 90],
        },
        {
            "name": "Отзывы",
            "rows": feedback_rows(feedbacks),
            "widths": [28, 14, 10, 18, 16, 24, 60, 60, 90, 20],
        },
    ]
    return build_xlsx(sheets)


def export_article(article_input: str, limit_input: str | None, marketplace_input: str | None = None) -> tuple[int, bytes, str]:
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    marketplace = marketplace_from_input(marketplace_input)
    if marketplace == MARKETPLACE_OZON:
        product, feedback_data, card_url, card_meta_url = fetch_ozon_product_and_feedbacks(article_input, limit)
        article = safe_int(product.get("article")) or safe_int(product.get("sku")) or safe_int(product.get("product_id")) or 0
        analysis = analyze_feedbacks(article, product, feedback_data, card_url, card_url, limit, {}, card_meta_url)
        return article, build_export_workbook(analysis, feedback_data, limit), MARKETPLACE_OZON

    article = article_from_input(article_input)
    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    feedback_data, feedback_url = fetch_feedbacks(article, root)
    analysis = analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)
    return article, build_export_workbook(analysis, feedback_data, limit), MARKETPLACE_WB


def priority_rank(priority: str) -> int:
    return {"high": 0, "medium": 1, "low": 2}.get(priority, 1)


def docx_rgb(value: str) -> Any:
    from docx.shared import RGBColor

    value = value.lstrip("#")
    return RGBColor(int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def docx_set_run(run: Any, size: float | None = None, bold: bool | None = None, color: str | None = None) -> None:
    from docx.oxml.ns import qn
    from docx.shared import Pt

    run.font.name = "Calibri"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = docx_rgb(color)


def docx_set_paragraph(paragraph: Any, before: int = 0, after: int = 6, line: float = 1.25) -> None:
    from docx.shared import Pt

    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = line


def docx_add_heading(doc: Any, text: str, level: int = 1) -> Any:
    sizes = {1: 16, 2: 13, 3: 12}
    colors = {1: "2E74B5", 2: "2E74B5", 3: "1F4D78"}
    before = {1: 18, 2: 14, 3: 10}
    after = {1: 10, 2: 7, 3: 5}
    paragraph = doc.add_paragraph()
    docx_set_paragraph(paragraph, before=before[level], after=after[level])
    run = paragraph.add_run(text)
    docx_set_run(run, size=sizes[level], bold=True, color=colors[level])
    return paragraph


def docx_add_para(doc: Any, text: str, bold_label: str | None = None, after: int = 6) -> Any:
    paragraph = doc.add_paragraph()
    docx_set_paragraph(paragraph, after=after)
    if bold_label:
        label_run = paragraph.add_run(f"{bold_label}: ")
        docx_set_run(label_run, size=11, bold=True)
    run = paragraph.add_run(text)
    docx_set_run(run, size=11)
    return paragraph


def docx_element(tag: str) -> Any:
    from docx.oxml import OxmlElement

    return OxmlElement(tag)


def docx_set_cell_shading(cell: Any, fill: str) -> None:
    from docx.oxml.ns import qn

    tc_pr = cell._tc.get_or_add_tcPr()
    shading = docx_element("w:shd")
    shading.set(qn("w:fill"), fill)
    tc_pr.append(shading)


def docx_set_cell_margins(table: Any, top: int = 80, bottom: int = 80, start: int = 120, end: int = 120) -> None:
    from docx.oxml.ns import qn

    tbl_pr = table._tbl.tblPr
    cell_mar = tbl_pr.find(qn("w:tblCellMar"))
    if cell_mar is None:
        cell_mar = docx_element("w:tblCellMar")
        tbl_pr.append(cell_mar)
    for side, value in (("top", top), ("bottom", bottom), ("start", start), ("end", end)):
        node = cell_mar.find(qn(f"w:{side}"))
        if node is None:
            node = docx_element(f"w:{side}")
            cell_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def docx_set_table_geometry(table: Any, widths_dxa: list[int], indent_dxa: int = 120) -> None:
    from docx.oxml.ns import qn

    table.autofit = False
    tbl = table._tbl
    tbl_pr = tbl.tblPr

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = docx_element("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_dxa)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = docx_element("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent_dxa))
    tbl_ind.set(qn("w:type"), "dxa")

    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = docx_element("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    old_grid = tbl.find(qn("w:tblGrid"))
    if old_grid is not None:
        tbl.remove(old_grid)
    grid = docx_element("w:tblGrid")
    for width in widths_dxa:
        grid_col = docx_element("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)
    tbl.insert(1, grid)

    for row in table.rows:
        for index, cell in enumerate(row.cells):
            width = widths_dxa[min(index, len(widths_dxa) - 1)]
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = docx_element("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")


def docx_fill_cell(cell: Any, text: str, bold: bool = False, fill: str | None = None) -> None:
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if fill:
        docx_set_cell_shading(cell, fill)
    paragraph = cell.paragraphs[0]
    docx_set_paragraph(paragraph, after=0)
    run = paragraph.add_run(as_text(text))
    docx_set_run(run, size=10.5, bold=bold, color="000000")


def docx_add_table(
    doc: Any,
    headers: list[str],
    rows: list[list[Any]],
    widths_dxa: list[int],
    header_fill: str = "E8EEF5",
) -> Any:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    docx_set_table_geometry(table, widths_dxa)
    docx_set_cell_margins(table)

    header_cells = table.rows[0].cells
    for index, header in enumerate(headers):
        docx_fill_cell(header_cells[index], header, bold=True, fill=header_fill)

    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            docx_fill_cell(cells[index], as_text(value))
    return table


def docx_add_callout(doc: Any, title: str, body: str) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    docx_set_table_geometry(table, [9360], indent_dxa=120)
    docx_set_cell_margins(table, top=120, bottom=120, start=160, end=160)
    cell = table.rows[0].cells[0]
    docx_set_cell_shading(cell, "F4F6F9")
    paragraph = cell.paragraphs[0]
    docx_set_paragraph(paragraph, after=3)
    title_run = paragraph.add_run(title)
    docx_set_run(title_run, size=11, bold=True, color="1F3A5F")
    paragraph.add_run("\n")
    body_run = paragraph.add_run(body)
    docx_set_run(body_run, size=10.5)


def docx_style_document(doc: Any) -> None:
    from docx.shared import Inches, Pt

    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25


def docx_product_title(product: dict[str, Any]) -> str:
    title = " · ".join(part for part in [as_text(product.get("brand")), as_text(product.get("name"))] if part)
    return title or f"Артикул {product.get('article')}"


def brief_goal(analysis: dict[str, Any]) -> str:
    summary = analysis["summary"]
    weaknesses = analysis.get("weaknesses") or []
    strengths = analysis.get("strengths") or []
    weak_names = ", ".join(item.get("title", "").lower() for item in weaknesses[:3]) or "повторяющиеся возражения"
    strong_names = ", ".join(item.get("title", "").lower() for item in strengths[:2]) or "сильные стороны товара"
    return (
        f"Обновить визуальный контент карточки так, чтобы усилить {strong_names} и закрыть {weak_names}. "
        f"Текущий ориентир по отзывам: {summary.get('averageRating') or 'нет оценки'}★, "
        f"{summary.get('textFeedbackCount')} текстовых отзывов."
    )


def brief_slide_plan(analysis: dict[str, Any]) -> list[list[str]]:
    content_recs = analysis.get("recommendations", {}).get("content") or []
    strengths = analysis.get("strengths") or []
    weaknesses = analysis.get("weaknesses") or []
    weakness_keys = {item.get("key") for item in weaknesses}

    rows = [
        [
            "1",
            "Главное фото",
            "Чистый кадр товара без перегруза текстом; товар должен быть крупным, резким и понятным с первого взгляда.",
            "Покупатель за 1-2 секунды понимает, что продаётся, какой вариант/цвет выбран и почему товар выглядит аккуратно.",
        ],
        [
            "2",
            "Слайд с главным УТП",
            "Вынести 1-2 сильные стороны из отзывов: " + terms_to_text([item.get("title") for item in strengths[:2] if item.get("title")]),
            "Формулировки опираются на реальные отзывы, без неподтверждённых обещаний.",
        ],
    ]

    if "fit" in weakness_keys or (analysis["summary"].get("matchingSizePercentages") or {}):
        rows.append(
            [
                str(len(rows) + 1),
                "Размеры и посадка",
                "Сделать инфографику с фактическими замерами, подсказкой по выбору размера и визуальной схемой посадки.",
                "Покупатель понимает, брать свой размер, больше или меньше; нет противоречий с отзывами.",
            ]
        )

    if "quality" in weakness_keys or any(item.get("key") == "quality" for item in strengths):
        rows.append(
            [
                str(len(rows) + 1),
                "Материал и детали",
                "Показать крупные планы материала, швов, фактуры, креплений или критичных деталей.",
                "На макете видны детали, о которых пишут покупатели; ретушь не скрывает фактуру и возможные ограничения.",
            ]
        )

    if "appearance" in weakness_keys:
        rows.append(
            [
                str(len(rows) + 1),
                "Цвет и внешний вид",
                "Переснять цвет при нейтральном свете, добавить кадр без фильтров и крупный план оттенка/принта.",
                "Цвет на фото не конфликтует с реальным товаром и снижает риск жалоб «не тот цвет».",
            ]
        )

    if "packaging" in weakness_keys or "completeness" in weakness_keys:
        rows.append(
            [
                str(len(rows) + 1),
                "Комплектация и упаковка",
                "Показать полный комплект одним кадром, упаковку, количество штук и что именно приходит покупателю.",
                "Состав заказа понятен без чтения длинного описания.",
            ]
        )

    rows.append(
        [
            str(len(rows) + 1),
            "Финальный слайд доверия",
            "Короткий блок с уходом, ограничениями, гарантией/возвратом или честным FAQ по повторяющимся вопросам.",
            "Закрывает типовые сомнения и не обещает того, что товар не подтверждает отзывами.",
        ]
    )
    return rows


def brief_priority_rows(analysis: dict[str, Any]) -> list[list[str]]:
    actions = sorted(
        analysis.get("recommendations", {}).get("priorityActions") or [],
        key=lambda item: priority_rank(item.get("priority", "medium")),
    )
    rows = []
    for index, item in enumerate(actions[:6], start=1):
        rows.append(
            [
                str(index),
                item.get("priorityLabel", ""),
                "Товар" if item.get("area") == "product" else "Контент",
                item.get("title", ""),
                item.get("action", ""),
                item.get("reason", ""),
            ]
        )
    return rows


def brief_content_rows(analysis: dict[str, Any]) -> list[list[str]]:
    rows = []
    for item in analysis.get("recommendations", {}).get("content") or []:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("aspect", ""),
                item.get("title", ""),
                item.get("action", ""),
                item.get("reason", ""),
                evidence_to_text(item.get("evidence") or []),
            ]
        )
    return rows


def brief_hpv_rows(analysis: dict[str, Any]) -> list[list[str]]:
    rows = []
    for item in (analysis.get("recommendations", {}).get("hpv") or [])[:6]:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("characteristic", ""),
                item.get("advantage", ""),
                item.get("benefit", ""),
                item.get("cardText", ""),
                item.get("infographicText", ""),
            ]
        )
    return rows


def brief_product_signal_rows(analysis: dict[str, Any]) -> list[list[str]]:
    rows = []
    for item in analysis.get("recommendations", {}).get("product") or []:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("aspect", ""),
                item.get("title", ""),
                item.get("action", ""),
                item.get("reason", ""),
            ]
        )
    return rows


def brief_photo_criteria_rows(analysis: dict[str, Any]) -> list[list[str]]:
    photo = analysis.get("firstPhotoAnalysis") or {}
    rows = []
    for item in photo.get("criteria") or []:
        score = item.get("score")
        rows.append(
            [
                item.get("label", ""),
                f"{score}/100" if score is not None else item.get("status", ""),
                item.get("summary", ""),
                item.get("action", ""),
            ]
        )
    return rows


def brief_acceptance_rows(marketplace_label: str = "WB") -> list[list[str]]:
    return [
        ["☐", "Главное фото ясно показывает товар, вариант и масштаб без визуального шума."],
        ["☐", f"Важный текст и ключевые детали не попадают в верхние углы и нижнюю зону плашек {marketplace_label}."],
        ["☐", "Первые 5 изображений закрывают главные возражения из отзывов."],
        ["☐", "Цвет, материал, размер, комплектация и ограничения показаны честно и без сильной ретуши."],
        ["☐", "Каждый инфографический слайд содержит одну мысль и читается на мобильном экране."],
        ["☐", "Тексты на макетах короткие, проверяемые и не обещают неподтверждённых свойств."],
        ["☐", f"Исходники и экспорт подготовлены под актуальные требования {marketplace_label}."],
    ]


def build_brief_docx(analysis: dict[str, Any]) -> bytes:
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt
    except ImportError as exc:
        raise AppError("Не удалось сформировать DOCX: не установлен python-docx.", 500, str(exc))

    product = analysis["product"]
    summary = analysis["summary"]
    marketplace_label = product.get("marketplaceLabel") or "WB"
    doc = Document()
    docx_style_document(doc)

    header = doc.sections[0].header.paragraphs[0]
    docx_set_paragraph(header, after=0)
    run = header.add_run(f"ТЗ по контенту {marketplace_label}")
    docx_set_run(run, size=9, color="5C655E")

    footer = doc.sections[0].footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    docx_set_paragraph(footer, after=0)
    footer_run = footer.add_run("Сформировано анализатором отзывов")
    docx_set_run(footer_run, size=9, color="5C655E")

    title = doc.add_paragraph()
    docx_set_paragraph(title, after=4)
    title_run = title.add_run("Техническое задание дизайнеру")
    docx_set_run(title_run, size=24, bold=True, color="000000")

    subtitle = doc.add_paragraph()
    docx_set_paragraph(subtitle, after=12)
    sub_run = subtitle.add_run(docx_product_title(product))
    docx_set_run(sub_run, size=13, color="5C655E")

    metadata_rows = [
        ["Артикул", product.get("article")],
        ["Средняя оценка", f"{summary.get('averageRating') or 'нет данных'}★"],
        ["Отзывы / текстовые", f"{summary.get('feedbackCount')} / {summary.get('textFeedbackCount')}"],
        ["Ссылка", product.get("url")],
    ]
    docx_add_table(doc, ["Параметр", "Значение"], metadata_rows, [1800, 7560])

    docx_add_callout(doc, "Цель обновления контента", brief_goal(analysis))

    docx_add_heading(doc, "1. Что сделать в первую очередь", 1)
    priority_rows = brief_priority_rows(analysis) or [["1", "Средний", "Контент", "Подготовить базовое обновление", "Обновить первые изображения карточки по выводам из отзывов.", "Данных мало, используйте сводку и примеры отзывов как ориентир."]]
    docx_add_table(
        doc,
        ["№", "Приоритет", "Блок", "Задача", "Действие", "Основание"],
        priority_rows,
        [420, 900, 900, 1700, 3000, 2440],
    )

    docx_add_heading(doc, "2. Структура визуального контента", 1)
    docx_add_table(
        doc,
        ["№", "Элемент", "Что подготовить", "Критерий приемки"],
        brief_slide_plan(analysis),
        [420, 1500, 3900, 3540],
    )

    docx_add_heading(doc, "3. Анализ первого фото", 1)
    photo_criteria_rows = brief_photo_criteria_rows(analysis)
    if photo_criteria_rows:
        docx_add_table(
            doc,
            ["Критерий", "Оценка", "Диагноз", "Что сделать"],
            photo_criteria_rows,
            [1700, 900, 3100, 3660],
        )
    else:
        docx_add_para(doc, f"Первое фото не удалось загрузить для визуального анализа. Проверьте доступность изображения на {marketplace_label}.")

    docx_add_heading(doc, "4. Контентные задачи из отзывов", 1)
    content_rows = brief_content_rows(analysis)
    if content_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Аспект", "Рекомендация", "Что сделать", "Почему", "Отзывы"],
            content_rows,
            [900, 1300, 1600, 2900, 1700, 960],
        )
    else:
        docx_add_para(doc, "Повторяющихся контентных задач не найдено. Сфокусируйтесь на чистой пересъёмке и понятной структуре карточки.")

    docx_add_heading(doc, "5. ХПВ: характеристики в выгоды", 1)
    hpv_brief_rows = brief_hpv_rows(analysis)
    if hpv_brief_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Характеристика", "Преимущество", "Выгода", "Текст карточки", "Инфографика"],
            hpv_brief_rows,
            [820, 1500, 1900, 1900, 1900, 1340],
        )
    else:
        docx_add_para(doc, "Расширенные характеристики карточки не найдены. Используйте сильные стороны из отзывов как основу для ХПВ.")

    docx_add_heading(doc, "6. Сигналы, которые нельзя маскировать дизайном", 1)
    docx_add_para(
        doc,
        "Если отзыв указывает на реальную проблему товара или партии, контент должен честно объяснить ограничение либо задача должна уйти поставщику на исправление.",
    )
    product_rows = brief_product_signal_rows(analysis)
    if product_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Аспект", "Сигнал", "Что проверить", "Почему"],
            product_rows,
            [900, 1400, 1700, 3300, 2060],
        )

    docx_add_heading(doc, "7. Чек-лист приемки макетов", 1)
    docx_add_table(doc, ["Готово", "Критерий"], brief_acceptance_rows(marketplace_label), [720, 8640])

    docx_add_heading(doc, "8. Рабочие правила для дизайнера", 1)
    rules = [
        ("Мобильная читаемость", "Проверить каждый слайд в маленьком размере: текст должен читаться без увеличения."),
        ("Одна мысль на слайд", "Не смешивать размер, материал, преимущества и комплектацию в одном перегруженном макете."),
        ("Честность визуала", "Не менять оттенок, фактуру и пропорции товара так, чтобы это усиливало расхождение с отзывами."),
        ("Исходники", "Передать редактируемые исходники, финальные экспорты и список использованных текстовых формулировок."),
    ]
    docx_add_table(doc, ["Правило", "Требование"], rules, [1800, 7560])

    docx_add_heading(doc, "9. Доказательная база из отзывов", 1)
    examples = []
    for label, items in (("Плюс", analysis.get("examples", {}).get("positive") or []), ("Минус", analysis.get("examples", {}).get("negative") or [])):
        for item in items[:4]:
            examples.append([label, f"{item.get('rating') or ''}★", item.get("date", ""), item.get("text", "")])
    if examples:
        docx_add_table(doc, ["Тип", "Оценка", "Дата", "Фрагмент"], examples, [800, 700, 1000, 6860])

    buffer = BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def brief_article(article_input: str, limit_input: str | None, marketplace_input: str | None = None) -> tuple[int, bytes, str]:
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    marketplace = marketplace_from_input(marketplace_input)
    if marketplace == MARKETPLACE_OZON:
        analysis = analyze_article(article_input, str(limit), MARKETPLACE_OZON)
        article = safe_int((analysis.get("product") or {}).get("article")) or 0
        return article, build_brief_docx(analysis), MARKETPLACE_OZON

    article = article_from_input(article_input)
    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    feedback_data, feedback_url = fetch_feedbacks(article, root)
    analysis = analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)
    return article, build_brief_docx(analysis), MARKETPLACE_WB


def unique_texts(values: list[str], limit: int | None = None) -> list[str]:
    result = []
    seen = set()
    for value in values:
        cleaned = re.sub(r"\s+", " ", as_text(value)).strip()
        key = cleaned.lower()
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(cleaned)
        if limit and len(result) >= limit:
            break
    return result


def product_variant_tokens(product: dict[str, Any]) -> tuple[set[str], set[str]]:
    color_tokens: set[str] = set()
    size_tokens: set[str] = set()

    colors = product.get("colors")
    if isinstance(colors, list):
        for color in colors:
            if isinstance(color, dict):
                color_tokens.update(token_list(as_text(color.get("name"))))

    sizes = product.get("sizes")
    if isinstance(sizes, list):
        for size in sizes:
            if isinstance(size, dict):
                size_tokens.update(token_list(" ".join([as_text(size.get("name")), as_text(size.get("origName"))])))

    return color_tokens, size_tokens


def competitor_text(product: dict[str, Any]) -> str:
    parts = [
        as_text(product.get("name")),
        as_text(product.get("entity")),
        as_text(product.get("brand")),
        as_text(product.get("supplier")),
    ]
    color_tokens, size_tokens = product_variant_tokens(product)
    parts.extend(sorted(color_tokens))
    parts.extend(sorted(size_tokens))
    return " ".join(part for part in parts if part)


def competitor_profile(product: dict[str, Any], card_meta: dict[str, Any] | None) -> dict[str, Any]:
    card_meta = card_meta or {}
    title_text = " ".join(
        part
        for part in [
            as_text(product.get("name")),
            as_text(product.get("entity")),
            as_text(card_meta.get("imt_name")),
            as_text(card_meta.get("subj_name")),
        ]
        if part
    )
    characteristic_items = product_characteristic_items(product, card_meta)
    characteristic_text = " ".join(f"{item['name']} {item['value']}" for item in characteristic_items)
    color_tokens, size_tokens = product_variant_tokens(product)

    title_tokens = set(token_list(title_text))
    characteristic_tokens = set(token_list(characteristic_text)) - title_tokens

    return {
        "subjectId": safe_int(product.get("subjectId")),
        "subjectParentId": safe_int(product.get("subjectParentId")),
        "entity": normalize_opinion(as_text(product.get("entity") or card_meta.get("subj_name"))),
        "titleTokens": title_tokens,
        "characteristicTokens": characteristic_tokens,
        "colorTokens": color_tokens,
        "sizeTokens": size_tokens,
        "characteristics": characteristic_items,
    }


def characteristic_query_terms(product: dict[str, Any], card_meta: dict[str, Any] | None) -> list[str]:
    terms = []
    priority_names = ("пол", "назнач", "комплект", "набор", "цвет", "сезон")
    for item in product_characteristic_items(product, card_meta or {}):
        name = normalize_opinion(item["name"])
        if not any(priority in name for priority in priority_names):
            continue
        for token in token_list(item["value"]):
            if len(token) >= 4:
                terms.append(token)
    return unique_texts(terms, 4)


def search_query_candidates(product: dict[str, Any], card_meta: dict[str, Any] | None = None) -> list[str]:
    candidates = []
    entity = as_text(product.get("entity") or (card_meta or {}).get("subj_name"))
    name = as_text((card_meta or {}).get("imt_name") or product.get("name"))
    combined = " ".join(part for part in [name, entity] if part)

    for raw in (name, combined):
        text = as_text(raw)
        if len(text) >= 3:
            candidates.append(text)

    for term in characteristic_query_terms(product, card_meta)[:2]:
        if entity:
            candidates.append(f"{term} {entity}")

    if combined and normalize_opinion(name) != normalize_opinion(entity):
        candidates.append(combined)

    if len(entity) >= 3:
        candidates.append(entity)

    return unique_texts(candidates, 3) or [as_text(product.get("name")) or str(product.get("id"))]


def fetch_search_products(query: str, page: int = 1) -> tuple[list[dict[str, Any]], str]:
    encoded = quote(query, safe="")
    referer = f"https://www.wildberries.ru/catalog/0/search.aspx?search={encoded}"
    errors = []
    for endpoint in WB_SEARCH_ENDPOINTS:
        url = (
            endpoint
            + "?ab_testid=new_benefit_sort&appType=1&curr=rub&dest=-1257786"
            + "&inheritFilters=false&lang=ru"
            + f"&page={page}&query={encoded}&resultset=catalog&sort=popular&spp=30"
            + "&suppressSpellcheck=false"
        )
        try:
            result = remote_json(url, referer, attempts=2, timeout=8)
        except AppError as exc:
            errors.append(f"{endpoint}: {exc.message}")
            if exc.status == 429:
                time.sleep(0.7)
                continue
            continue

        products = result.data.get("products") or result.data.get("data", {}).get("products") or []
        return [product for product in products if isinstance(product, dict)], result.url

    details = "; ".join(errors) if errors else None
    if any("ограничил частоту" in error.lower() for error in errors):
        raise AppError(
            "Wildberries временно ограничил поиск конкурентов. Пробую другие источники и более мягкий режим.",
            429,
            details,
        )
    raise AppError("Не удалось получить поисковую выдачу Wildberries для подбора конкурентов.", 502, details)


def candidate_similarity_score(candidate: dict[str, Any], profile: dict[str, Any]) -> tuple[float, list[str]]:
    score = 0.0
    reasons = []
    candidate_subject = safe_int(candidate.get("subjectId"))
    candidate_parent = safe_int(candidate.get("subjectParentId"))
    candidate_entity = normalize_opinion(as_text(candidate.get("entity")))
    candidate_tokens = set(token_list(competitor_text(candidate)))

    if profile["subjectId"] and candidate_subject == profile["subjectId"]:
        score += 55
        reasons.append("та же категория")
    elif profile["subjectParentId"] and candidate_parent == profile["subjectParentId"]:
        score += 20
        reasons.append("родственная категория")
    else:
        score -= 25

    if profile["entity"] and candidate_entity == profile["entity"]:
        score += 12
        reasons.append("совпадает тип товара")

    title_tokens = profile["titleTokens"]
    title_matches = title_tokens & candidate_tokens
    if title_matches:
        score += min(len(title_matches) * 8, 36)
        reasons.append("похожий заголовок: " + ", ".join(sorted(title_matches)[:4]))
        union = title_tokens | candidate_tokens
        if union:
            score += round(len(title_matches) * 24 / len(union), 2)
    else:
        score -= 12

    characteristic_matches = profile["characteristicTokens"] & candidate_tokens
    if characteristic_matches:
        score += min(len(characteristic_matches) * 7, 35)
        reasons.append("совпали характеристики: " + ", ".join(sorted(characteristic_matches)[:4]))

    candidate_colors, candidate_sizes = product_variant_tokens(candidate)
    color_matches = profile["colorTokens"] & candidate_colors
    if color_matches:
        score += 8
        reasons.append("совпадает цвет")
    size_matches = profile["sizeTokens"] & candidate_sizes
    if size_matches:
        score += 6
        reasons.append("пересекаются размеры")

    feedbacks = int(candidate.get("feedbacks") or candidate.get("nmFeedbacks") or 0)
    if feedbacks >= 1000:
        score += 5
    elif feedbacks >= 100:
        score += 3

    return round(score, 2), reasons[:5]


def competitor_candidates(
    article: int,
    product: dict[str, Any],
    card_meta: dict[str, Any] | None,
    target_count: int,
) -> tuple[list[dict[str, Any]], list[str], str | None]:
    profile = competitor_profile(product, card_meta)
    collected: dict[int, dict[str, Any]] = {}
    seen: set[int] = {article}
    used_queries = []
    first_url = None

    queries = search_query_candidates(product, card_meta)
    for query_index, query in enumerate(queries):
        used_queries.append(query)
        for page in (1, 2):
            try:
                products, source_url = fetch_search_products(query, page)
                first_url = first_url or source_url
            except AppError as exc:
                if exc.status == 429:
                    time.sleep(0.9 + query_index * 0.25)
                continue

            for candidate in products:
                nm_id = safe_int(candidate.get("id"))
                if not nm_id or nm_id in seen:
                    continue
                seen.add(nm_id)
                if int(candidate.get("feedbacks") or candidate.get("nmFeedbacks") or 0) <= 0:
                    continue
                if safe_float(candidate.get("reviewRating") or candidate.get("nmReviewRating")) is None:
                    continue

                score, reasons = candidate_similarity_score(candidate, profile)
                if score < 30 and not (profile["subjectId"] and safe_int(candidate.get("subjectId")) == profile["subjectId"]):
                    continue

                payload = dict(candidate)
                payload["_matchScore"] = score
                payload["_matchReasons"] = reasons
                payload["_searchQuery"] = query
                collected[nm_id] = payload

            if len(collected) >= max(target_count * 4, target_count + 8):
                break
            if query_index == 0 and page == 1 and len(collected) >= target_count:
                break
        if len(collected) >= max(target_count * 4, target_count + 8):
            break
        if query_index == 0 and len(collected) >= target_count:
            break

    candidates = sorted(
        collected.values(),
        key=lambda item: (
            float(item.get("_matchScore") or 0),
            int(item.get("feedbacks") or item.get("nmFeedbacks") or 0),
        ),
        reverse=True,
    )
    return candidates[: max(target_count * 4, target_count)], used_queries, first_url


def competitor_product_payload(product: dict[str, Any], analysis: dict[str, Any]) -> dict[str, Any]:
    summary = analysis["summary"]
    return {
        "article": product.get("id") or analysis["product"].get("article"),
        "root": product.get("root") or analysis["product"].get("root"),
        "name": as_text(product.get("name") or analysis["product"].get("name")),
        "brand": as_text(product.get("brand") or analysis["product"].get("brand")),
        "supplier": as_text(product.get("supplier") or analysis["product"].get("supplier")),
        "reviewRating": summary.get("averageRating"),
        "feedbacks": summary.get("feedbackCount"),
        "textFeedbacks": summary.get("textFeedbackCount"),
        "loadedReviews": summary.get("loadedReviews"),
        "positiveRatingPercent": summary.get("positiveRatingPercent"),
        "negativeRatingPercent": summary.get("negativeRatingPercent"),
        "matchScore": product.get("_matchScore"),
        "matchReasons": product.get("_matchReasons") or [],
        "searchQuery": product.get("_searchQuery"),
        "url": f"https://www.wildberries.ru/catalog/{product.get('id')}/detail.aspx",
        "imageUrl": analysis["product"].get("imageUrl"),
        "firstPhotoAnalysis": analysis.get("firstPhotoAnalysis"),
        "topStrengths": [item.get("title") for item in (analysis.get("strengths") or [])[:3]],
        "topWeaknesses": [item.get("title") for item in (analysis.get("weaknesses") or [])[:3]],
    }


def competitor_card_only_feedback_data(product: dict[str, Any], warning: str) -> dict[str, Any]:
    return {
        "feedbacks": [],
        "feedbackCount": safe_int(product.get("feedbacks") or product.get("nmFeedbacks")) or 0,
        "feedbackCountWithText": 0,
        "valuation": safe_float(product.get("reviewRating") or product.get("nmReviewRating")),
        "valuationDistribution": {},
        "matchingSizePercentages": {},
        "_warning": warning,
    }


def aspect_totals(analysis: dict[str, Any]) -> dict[str, dict[str, float]]:
    totals: dict[str, dict[str, float]] = {}
    for item in (analysis.get("strengths") or []) + (analysis.get("weaknesses") or []):
        key = item.get("key") or "overall"
        current = totals.setdefault(key, {"positive": 0.0, "negative": 0.0, "mentions": 0.0})
        current["positive"] = max(current["positive"], float(item.get("positiveMentions") or 0))
        current["negative"] = max(current["negative"], float(item.get("negativeMentions") or 0))
        current["mentions"] = max(current["mentions"], float(item.get("mentions") or 0))
    return totals


def rate_per_100(value: float, loaded_reviews: int | None) -> float:
    denominator = max(int(loaded_reviews or 0), 1)
    return round(value * 100 / denominator, 1)


def competitor_benchmark(your_analysis: dict[str, Any], competitor_analyses: list[dict[str, Any]]) -> dict[str, Any]:
    def avg(values: list[float | int | None]) -> float | None:
        clean = [float(value) for value in values if value is not None]
        if not clean:
            return None
        return round(sum(clean) / len(clean), 2)

    your_summary = your_analysis["summary"]
    competitor_summaries = [analysis["summary"] for analysis in competitor_analyses]
    return {
        "your": {
            "averageRating": your_summary.get("averageRating"),
            "feedbackCount": your_summary.get("feedbackCount"),
            "textFeedbackCount": your_summary.get("textFeedbackCount"),
            "positiveRatingPercent": your_summary.get("positiveRatingPercent"),
            "negativeRatingPercent": your_summary.get("negativeRatingPercent"),
        },
        "competitorsAvg": {
            "averageRating": avg([item.get("averageRating") for item in competitor_summaries]),
            "feedbackCount": avg([item.get("feedbackCount") for item in competitor_summaries]),
            "textFeedbackCount": avg([item.get("textFeedbackCount") for item in competitor_summaries]),
            "positiveRatingPercent": avg([item.get("positiveRatingPercent") for item in competitor_summaries]),
            "negativeRatingPercent": avg([item.get("negativeRatingPercent") for item in competitor_summaries]),
        },
    }


def average_photo_metric(photo_items: list[dict[str, Any]], key: str) -> float | None:
    values = [
        safe_float((item.get("metrics") or {}).get(key))
        for item in photo_items
        if item.get("ok") and (item.get("metrics") or {}).get(key) is not None
    ]
    clean = [value for value in values if value is not None]
    if not clean:
        return None
    return round(sum(clean) / len(clean), 1)


def photo_competitor_item(analysis: dict[str, Any]) -> dict[str, Any] | None:
    photo = analysis.get("firstPhotoAnalysis") or {}
    product = analysis.get("product") or {}
    score = safe_float(photo.get("score"))
    if not photo.get("ok") or score is None:
        return None
    title = [product.get("brand"), product.get("name")]
    return {
        "article": product.get("article"),
        "title": " · ".join(as_text(part) for part in title if as_text(part)) or f"Артикул {product.get('article')}",
        "url": product.get("url"),
        "imageUrl": product.get("imageUrl") or photo.get("imageUrl"),
        "sourceUrl": photo.get("sourceUrl") or product.get("sourceImageUrl"),
        "score": round(score),
        "scoreLabel": photo.get("scoreLabel"),
        "metrics": photo.get("metrics") or {},
        "criteria": photo.get("criteria") or [],
    }


def photo_criteria_map(photo: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        as_text(item.get("key")): item
        for item in (photo.get("criteria") or [])
        if isinstance(item, dict) and item.get("key")
    }


def photo_criterion_score(photo: dict[str, Any], key: str) -> float | None:
    item = photo_criteria_map(photo).get(key)
    return safe_float((item or {}).get("score"))


def competitor_criterion_avg(photo_items: list[dict[str, Any]], key: str) -> float | None:
    values = [safe_float(photo_criteria_map(item).get(key, {}).get("score")) for item in photo_items]
    clean = [value for value in values if value is not None]
    if not clean:
        return None
    return round(sum(clean) / len(clean), 1)


def comparison_phrase(your_value: float | None, competitor_value: float | None, label: str, unit: str = "") -> str:
    if your_value is None or competitor_value is None:
        return ""
    return f"{label}: у вас {round(your_value)}{unit}, у конкурентов в среднем {round(competitor_value)}{unit}."


def build_market_photo_patterns(competitor_photos: list[dict[str, Any]], avg_value: Any) -> list[str]:
    patterns: list[str] = []
    comp_subject = avg_value("productSharePercent")
    comp_contrast = avg_value("contrastScore")
    comp_saturation = avg_value("saturationPercent")
    comp_load = avg_value("visualLoadPercent")
    comp_safe_zones = avg_value("marketplaceZoneActivityPercent")
    comp_readability = competitor_criterion_avg(competitor_photos, "mobile_readability")
    comp_standout = competitor_criterion_avg(competitor_photos, "competitive_standout")

    if comp_subject is not None:
        if comp_subject >= 62:
            patterns.append(f"Конкуренты делают товар главным объектом: в среднем он занимает около {round(comp_subject)}% кадра.")
        elif comp_subject <= 42:
            patterns.append(f"В нише часто оставляют много воздуха вокруг товара: средняя заполненность кадра около {round(comp_subject)}%.")
        else:
            patterns.append(f"Средний паттерн ниши — умеренно крупный товар без плотной обрезки: около {round(comp_subject)}% кадра.")
    if comp_contrast is not None:
        if comp_contrast >= 62:
            patterns.append(f"Обложки конкурентов заметны за счет контраста: средний контраст {round(comp_contrast)}/100.")
        elif comp_contrast <= 46:
            patterns.append(f"У конкурентов слабый контраст, поэтому можно выделиться более чистым силуэтом и фоном.")
    if comp_saturation is not None:
        if comp_saturation <= 12:
            patterns.append("Цветовые акценты в нише используются сдержанно: есть шанс выделиться одним фирменным цветом без перегруза.")
        elif comp_saturation >= 34:
            patterns.append("Конкуренты активно используют цвет, поэтому важна строгая иерархия: один главный акцент, а не несколько спорящих элементов.")
    if comp_load is not None and comp_load >= 58:
        patterns.append(f"Многие обложки выглядят насыщенно: средний индекс визуальной загруженности {round(comp_load)}%.")
    elif comp_load is not None and comp_load <= 34:
        patterns.append("Конкуренты чаще используют чистые обложки без большого количества элементов.")
    if comp_readability is not None and comp_readability >= 70:
        patterns.append("У сильных конкурентов первый экран, вероятно, читается с телефона: высокая мобильная читаемость обложки.")
    if comp_standout is not None and comp_standout < 66:
        patterns.append("В нише нет сильного визуального стандарта выделения, поэтому можно выиграть за счет ясной выгоды и аккуратного контраста.")
    if comp_safe_zones is not None and comp_safe_zones >= 52:
        patterns.append("У части конкурентов важные элементы находятся близко к зонам плашек WB, это можно использовать как преимущество чистой компоновкой.")

    return unique_texts(patterns, 5)


def build_your_cover_points(
    your_photo: dict[str, Any],
    competitor_photos: list[dict[str, Any]],
    avg_value: Any,
) -> tuple[list[str], list[str]]:
    strengths: list[str] = []
    weaknesses: list[str] = []
    your_metrics = your_photo.get("metrics") or {}

    comparisons = [
        ("one_second_meaning", "Понятность за 1 секунду", "/100"),
        ("product_scale", "Крупность и понятность товара", "/100"),
        ("mobile_readability", "Читаемость с телефона", "/100"),
        ("composition_hierarchy", "Композиция и визуальная иерархия", "/100"),
        ("competitive_standout", "Выделение в выдаче", "/100"),
        ("needs_objections", "Мотивация открыть карточку", "/100"),
        ("marketplace_safe_zones", "Чистота зон WB", "/100"),
    ]
    for key, label, unit in comparisons:
        your_score = photo_criterion_score(your_photo, key)
        comp_score = competitor_criterion_avg(competitor_photos, key)
        phrase = comparison_phrase(your_score, comp_score, label, unit)
        if your_score is None:
            continue
        if comp_score is not None and your_score >= comp_score + 7:
            strengths.append(phrase)
        elif your_score < 62 or (comp_score is not None and your_score + 7 < comp_score):
            weaknesses.append(phrase or f"{label}: критерий требует усиления, текущая оценка {round(your_score)}/100.")

    metric_checks = [
        ("productSharePercent", "Товар в кадре", "%", 8),
        ("contrastScore", "Контраст", "/100", 8),
        ("visualLoadPercent", "Визуальная загруженность", "%", 12),
    ]
    for key, label, unit, threshold in metric_checks:
        your_value = safe_float(your_metrics.get(key))
        comp_value = avg_value(key)
        if your_value is None or comp_value is None:
            continue
        phrase = comparison_phrase(your_value, comp_value, label, unit)
        if key == "visualLoadPercent":
            if your_value + threshold < comp_value:
                strengths.append(f"{phrase} Обложка чище и должна быстрее считываться.")
            elif your_value > comp_value + threshold:
                weaknesses.append(f"{phrase} Есть риск перегруза первого экрана.")
        elif your_value >= comp_value + threshold:
            strengths.append(phrase)
        elif your_value + threshold < comp_value:
            weaknesses.append(phrase)

    if not strengths:
        score = safe_float(your_photo.get("score"))
        if score is not None:
            strengths.append(f"Базовая оценка обложки {round(score)}/100: есть рабочая основа для тестов.")
    if not weaknesses:
        weaknesses.append("Сильного отставания по базовым метрикам не видно; главный резерв — протестировать смысл и оффер на первом фото.")

    return unique_texts(strengths, 4), unique_texts(weaknesses, 4)


def build_ab_test_hypotheses(
    your_photo: dict[str, Any],
    competitor_photos: list[dict[str, Any]],
    avg_value: Any,
    actions: list[dict[str, Any]],
) -> list[dict[str, str]]:
    your_metrics = your_photo.get("metrics") or {}
    hypotheses: list[dict[str, str]] = []

    def add(title: str, variant_a: str, variant_b: str, reason: str, metric: str) -> None:
        if len(hypotheses) >= 3:
            return
        hypotheses.append(
            {
                "title": title,
                "variantA": variant_a,
                "variantB": variant_b,
                "reason": reason,
                "successMetric": metric,
            }
        )

    one_second = photo_criterion_score(your_photo, "one_second_meaning")
    needs = photo_criterion_score(your_photo, "needs_objections")
    if (one_second is not None and one_second < 72) or (needs is not None and needs < 76):
        add(
            "Проверить главный смысл обложки",
            "Товар крупно + короткий нейтральный оффер о типе товара.",
            "Товар крупно + выгода, закрывающая главное возражение покупателей.",
            "Если покупатель быстрее понимает пользу, CTR карточки должен вырасти.",
            "CTR из выдачи WB и добавления в корзину после открытия.",
        )

    your_subject = safe_float(your_metrics.get("productSharePercent"))
    comp_subject = avg_value("productSharePercent")
    if your_subject is not None and comp_subject is not None and (your_subject + 8 < comp_subject or your_subject > 78):
        add(
            "Протестировать масштаб товара",
            "Текущий масштаб и композиция.",
            "Перекадрирование: товар крупнее/чище, ключевая деталь видна в миниатюре.",
            comparison_phrase(your_subject, comp_subject, "Товар в кадре", "%") or "Масштаб влияет на скорость распознавания товара.",
            "CTR карточки и глубина просмотра фото.",
        )

    standout = photo_criterion_score(your_photo, "competitive_standout")
    your_contrast = safe_float(your_metrics.get("contrastScore"))
    comp_contrast = avg_value("contrastScore")
    if (standout is not None and standout < 70) or (
        your_contrast is not None and comp_contrast is not None and your_contrast + 8 < comp_contrast
    ):
        add(
            "Усилить заметность в выдаче",
            "Чистая обложка без дополнительного акцента.",
            "Один управляемый акцент: контрастный фон/плашка/стрелка + 2-4 слова выгоды.",
            comparison_phrase(your_contrast, comp_contrast, "Контраст", "/100") or "Нужно проверить, что обложка выделяется рядом с конкурентами.",
            "CTR из поисковой выдачи и доля переходов из рекомендаций.",
        )

    readability = photo_criterion_score(your_photo, "mobile_readability")
    load = safe_float(your_metrics.get("visualLoadPercent"))
    if (readability is not None and readability < 72) or (load is not None and load > 60):
        add(
            "Проверить читаемость оффера с телефона",
            "Оффер как сейчас, без сокращения.",
            "Один крупный тезис до 3-5 слов, остальное перенести на второй слайд.",
            "Перегруженная обложка может быть понятной в редакторе, но теряться в мобильной выдаче WB.",
            "CTR на мобильном трафике и досмотры второго/третьего фото.",
        )

    if len(hypotheses) < 2:
        add(
            "Сравнить смысловые акценты",
            "Первое фото с акцентом на внешний вид товара.",
            "Первое фото с акцентом на результат/выгоду использования.",
            "По базовым метрикам сильного провала нет, значит тестировать нужно смысл, который мотивирует открыть карточку.",
            "CTR карточки и конверсия в корзину.",
        )
    if len(hypotheses) < 3:
        action_title = (actions[0] or {}).get("title") if actions else ""
        add(
            "Проверить версию против лучшего конкурента",
            "Текущая обложка.",
            "Вариант с визуальным паттерном лучшего конкурента, но с вашей выгодой и фирменным цветом.",
            action_title or "Лучший конкурент показывает ориентир по первому фото, но его можно адаптировать без копирования.",
            "CTR относительно текущей версии и изменение позиции по поведенческим сигналам.",
        )

    return hypotheses[:3]


def first_photo_comparison(your_analysis: dict[str, Any], competitor_analyses: list[dict[str, Any]]) -> dict[str, Any]:
    your_photo = your_analysis.get("firstPhotoAnalysis") or {}
    competitor_photos = [
        item
        for item in (photo_competitor_item(analysis) for analysis in competitor_analyses)
        if item is not None
    ]
    if not competitor_photos:
        return {
            "available": False,
            "verdict": "Первые фото конкурентов не удалось загрузить для сравнения.",
            "clickVerdict": "Сравнить понятность, заметность и мотивацию к клику пока нельзя: фото конкурентов недоступны.",
            "marketPatterns": [],
            "yourCoverStrengths": [],
            "yourCoverWeaknesses": ["Нужно повторить сравнение, чтобы понять, как наша обложка выглядит рядом с конкурентами."],
            "abTestHypotheses": [
                {
                    "title": "Проверить главный смысл первого фото",
                    "variantA": "Текущая обложка.",
                    "variantB": "Товар крупно + одна конкретная выгода, закрывающая главное возражение.",
                    "reason": "Даже без конкурентов можно проверить, понятнее ли новая обложка мотивирует открыть карточку.",
                    "successMetric": "CTR карточки и конверсия в корзину.",
                }
            ],
            "actions": [
                photo_recommendation(
                    "low",
                    "Повторить сравнение позже",
                    "Запустить анализ конкурентов ещё раз: иногда Wildberries временно не отдаёт изображения.",
                    "Визуальная часть сравнения зависит от доступности первых фото WB.",
                )
            ],
        }

    def avg_value(key: str) -> float | None:
        values = [safe_float((item.get("metrics") or {}).get(key)) for item in competitor_photos]
        clean = [value for value in values if value is not None]
        if not clean:
            return None
        return round(sum(clean) / len(clean), 1)

    comp_score = round(sum(float(item["score"]) for item in competitor_photos) / len(competitor_photos), 1)
    best = max(competitor_photos, key=lambda item: float(item["score"]))
    your_score = safe_float(your_photo.get("score"))
    your_metrics = your_photo.get("metrics") or {}
    actions: list[dict[str, Any]] = []
    market_patterns = build_market_photo_patterns(competitor_photos, avg_value)

    if not your_photo.get("ok") or your_score is None:
        verdict = "Ваше первое фото не удалось оценить, но фото конкурентов доступны для ориентира."
        actions.append(
            photo_recommendation(
                "high",
                "Проверить доступность первого фото",
                "Убедиться, что первое изображение карточки открывается на WB и не заменено пустым/ошибочным файлом.",
                your_photo.get("error") or "Сервис не получил изображение для анализа.",
            )
        )
    else:
        delta = round(your_score - comp_score, 1)
        if delta >= 7:
            verdict = f"Первое фото сильнее среднего уровня конкурентов: {round(your_score)}/100 против {round(comp_score)}/100."
        elif delta <= -7:
            verdict = f"Первое фото слабее среднего уровня конкурентов: {round(your_score)}/100 против {round(comp_score)}/100."
        else:
            verdict = f"Первое фото близко к конкурентам: {round(your_score)}/100 против {round(comp_score)}/100."

        comp_subject = avg_value("productSharePercent")
        your_subject = safe_float(your_metrics.get("productSharePercent"))
        if comp_subject is not None and your_subject is not None and your_subject + 8 < comp_subject:
            actions.append(
                photo_recommendation(
                    "high",
                    "Сделать товар заметнее конкурентов",
                    "Увеличить товар в первом кадре или показать главный элемент крупнее, чтобы карточка быстрее считывалась в выдаче.",
                    f"У вас товар занимает около {round(your_subject)}%, у конкурентов в среднем {round(comp_subject)}%.",
                )
            )

        comp_contrast = avg_value("contrastScore")
        your_contrast = safe_float(your_metrics.get("contrastScore"))
        if comp_contrast is not None and your_contrast is not None and your_contrast + 8 < comp_contrast:
            actions.append(
                photo_recommendation(
                    "medium",
                    "Поднять контраст до уровня рынка",
                    "Добавить аккуратные тени, контуры или более чистое разделение товара и фона.",
                    f"Контраст у вас {round(your_contrast)}/100, у конкурентов в среднем {round(comp_contrast)}/100.",
                )
            )

        comp_saturation = avg_value("saturationPercent")
        your_saturation = safe_float(your_metrics.get("saturationPercent"))
        if comp_saturation is not None and your_saturation is not None and your_saturation + 8 < comp_saturation:
            actions.append(
                photo_recommendation(
                    "medium",
                    "Добавить управляемый цветовой акцент",
                    "Использовать цвет бренда или короткую плашку с выгодой, чтобы первое фото выделялось без визуального шума.",
                    f"Цветовой акцент у вас {round(your_saturation)}%, у конкурентов в среднем {round(comp_saturation)}%.",
                )
            )

        comp_detail = avg_value("detailScore")
        your_detail = safe_float(your_metrics.get("detailScore"))
        if comp_detail is not None and your_detail is not None and your_detail + 8 < comp_detail:
            actions.append(
                photo_recommendation(
                    "medium",
                    "Показать больше доказательных деталей",
                    "Добавить крупный фрагмент материала, комплектации или важной функции на первый/второй слайд.",
                    f"Детальность у вас {round(your_detail)}/100, у конкурентов в среднем {round(comp_detail)}/100.",
                )
            )

        if not actions:
            actions.append(
                photo_recommendation(
                    "low",
                    "Тестировать смысл, а не только картинку",
                    "Сделать A/B-вариант первого фото с другой главной выгодой: акцент на результате, комплектации или снятии возражения.",
                    "По базовым визуальным метрикам сильного отставания от конкурентов не найдено.",
                )
            )

    if your_photo.get("ok") and your_score is not None:
        your_strengths, your_weaknesses = build_your_cover_points(your_photo, competitor_photos, avg_value)
        ab_hypotheses = build_ab_test_hypotheses(your_photo, competitor_photos, avg_value, actions)
        clarity = photo_criterion_score(your_photo, "one_second_meaning")
        visibility = photo_criterion_score(your_photo, "competitive_standout")
        motivation = photo_criterion_score(your_photo, "needs_objections")
        comp_clarity = competitor_criterion_avg(competitor_photos, "one_second_meaning")
        comp_visibility = competitor_criterion_avg(competitor_photos, "competitive_standout")
        comp_motivation = competitor_criterion_avg(competitor_photos, "needs_objections")
        click_verdict_parts = [
            comparison_phrase(clarity, comp_clarity, "понятность", "/100"),
            comparison_phrase(visibility, comp_visibility, "заметность", "/100"),
            comparison_phrase(motivation, comp_motivation, "мотивация открыть карточку", "/100"),
        ]
        click_verdict = " ".join(part for part in click_verdict_parts if part) or (
            "Оцениваем обложку по трем задачам: быстро понять товар, заметить его в выдаче и захотеть открыть карточку."
        )
    else:
        your_strengths = []
        your_weaknesses = ["Наше первое фото не удалось загрузить, поэтому нельзя честно оценить понятность, заметность и мотивацию к клику."]
        ab_hypotheses = [
            {
                "title": "Проверить доступную версию первого фото",
                "variantA": "Текущее первое фото после восстановления загрузки.",
                "variantB": "Пересобранная обложка: товар крупно + одна выгода + чистые зоны WB.",
                "reason": "Без стабильной загрузки фото карточка теряет визуальную конкурентность в выдаче.",
                "successMetric": "CTR карточки и отсутствие ошибок загрузки первого изображения.",
            }
        ]
        click_verdict = "Наше фото не оценено: сначала нужно восстановить загрузку, затем сравнить понятность, заметность и мотивацию к клику."

    return {
        "available": True,
        "verdict": verdict,
        "clickVerdict": click_verdict,
        "marketPatterns": market_patterns,
        "yourCoverStrengths": your_strengths,
        "yourCoverWeaknesses": your_weaknesses,
        "abTestHypotheses": ab_hypotheses,
        "your": {
            "score": None if your_score is None else round(your_score),
            "scoreLabel": your_photo.get("scoreLabel"),
            "imageUrl": your_photo.get("imageUrl"),
            "metrics": your_metrics,
            "criteria": your_photo.get("criteria") or [],
        },
        "competitorsAvg": {
            "score": comp_score,
            "brightnessPercent": avg_value("brightnessPercent"),
            "contrastScore": avg_value("contrastScore"),
            "saturationPercent": avg_value("saturationPercent"),
            "productSharePercent": avg_value("productSharePercent"),
            "lightBackgroundPercent": avg_value("lightBackgroundPercent"),
            "detailScore": avg_value("detailScore"),
            "visualLoadPercent": avg_value("visualLoadPercent"),
            "marketplaceZoneActivityPercent": avg_value("marketplaceZoneActivityPercent"),
            "oneSecondMeaningScore": competitor_criterion_avg(competitor_photos, "one_second_meaning"),
            "mobileReadabilityScore": competitor_criterion_avg(competitor_photos, "mobile_readability"),
            "competitiveStandoutScore": competitor_criterion_avg(competitor_photos, "competitive_standout"),
            "needsObjectionsScore": competitor_criterion_avg(competitor_photos, "needs_objections"),
        },
        "bestCompetitor": best,
        "actions": actions[:5],
        "competitors": competitor_photos[:10],
    }


def compare_aspects(your_analysis: dict[str, Any], competitor_analyses: list[dict[str, Any]]) -> list[dict[str, Any]]:
    your_totals = aspect_totals(your_analysis)
    competitor_totals: dict[str, dict[str, float]] = {}
    competitor_loaded = sum(int(analysis["summary"].get("loadedReviews") or 0) for analysis in competitor_analyses)

    for analysis in competitor_analyses:
        for key, values in aspect_totals(analysis).items():
            current = competitor_totals.setdefault(key, {"positive": 0.0, "negative": 0.0})
            current["positive"] += values["positive"]
            current["negative"] += values["negative"]

    your_loaded = int(your_analysis["summary"].get("loadedReviews") or 0)
    keys = set(your_totals) | set(competitor_totals)
    rows = []
    for key in keys:
        your_values = your_totals.get(key, {"positive": 0.0, "negative": 0.0})
        comp_values = competitor_totals.get(key, {"positive": 0.0, "negative": 0.0})
        your_pos = rate_per_100(your_values["positive"], your_loaded)
        your_neg = rate_per_100(your_values["negative"], your_loaded)
        comp_pos = rate_per_100(comp_values["positive"], competitor_loaded)
        comp_neg = rate_per_100(comp_values["negative"], competitor_loaded)

        if your_neg > comp_neg + 2:
            status = "У нас слабее"
            recommendation = RECOMMENDATION_TEMPLATES.get(key, RECOMMENDATION_TEMPLATES["overall"])["content_action"]
            priority = "high"
        elif comp_pos > your_pos + 3:
            status = "Конкуренты сильнее"
            title = "Общее впечатление" if key == "overall" else ASPECTS.get(key, {}).get("title", key)
            recommendation = f"Показать и доказать «{title.lower()}» сильнее: вынести аргумент в первые изображения и подкрепить фото/видео."
            priority = "medium"
        elif your_pos > comp_pos + 3 and your_neg <= comp_neg + 1:
            status = "Наше преимущество"
            title = "Общее впечатление" if key == "overall" else ASPECTS.get(key, {}).get("title", key)
            recommendation = f"Закрепить преимущество по теме «{title.lower()}» в главном фото, инфографике и ТЗ дизайнеру."
            priority = "medium"
        else:
            status = "Паритет"
            recommendation = "Поддерживать текущий уровень и отслеживать новые негативные отзывы."
            priority = "low"

        rows.append(
            {
                "key": key,
                "title": "Общее впечатление" if key == "overall" else ASPECTS.get(key, {}).get("title", key),
                "status": status,
                "priority": priority,
                "priorityLabel": priority_label(priority),
                "yourPositivePer100": your_pos,
                "yourNegativePer100": your_neg,
                "competitorPositivePer100": comp_pos,
                "competitorNegativePer100": comp_neg,
                "recommendation": recommendation,
            }
        )

    rows.sort(
        key=lambda row: (
            {"У нас слабее": 0, "Конкуренты сильнее": 1, "Наше преимущество": 2, "Паритет": 3}.get(row["status"], 4),
            -abs(row["yourNegativePer100"] - row["competitorNegativePer100"]),
        )
    )
    return rows[:8]


def competitor_action_plan(
    your_analysis: dict[str, Any],
    competitor_analyses: list[dict[str, Any]],
    aspect_comparison: list[dict[str, Any]],
    benchmark: dict[str, Any],
) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    for row in aspect_comparison:
        if row["status"] in ("У нас слабее", "Конкуренты сильнее"):
            actions.append(
                {
                    "priority": row["priority"],
                    "priorityLabel": row["priorityLabel"],
                    "area": "Контент",
                    "title": f"Усилить: {row['title']}",
                    "action": row["recommendation"],
                    "why": (
                        f"У нас: +{row['yourPositivePer100']} / -{row['yourNegativePer100']} упоминаний на 100 отзывов; "
                        f"у конкурентов: +{row['competitorPositivePer100']} / -{row['competitorNegativePer100']}."
                    ),
                }
            )

    your = benchmark["your"]
    comp = benchmark["competitorsAvg"]
    if comp.get("feedbackCount") and your.get("feedbackCount") and comp["feedbackCount"] > your["feedbackCount"] * 2:
        actions.append(
            {
                "priority": "medium",
                "priorityLabel": priority_label("medium"),
                "area": "Контент",
                "title": "Усилить доверие к карточке",
                "action": "Добавить больше доказательств: реальные фото, видео, крупные планы, FAQ и ответы на частые сомнения.",
                "why": f"У конкурентов в среднем больше отзывов: {round(comp['feedbackCount'])} против {your['feedbackCount']} у нас.",
            }
        )

    if comp.get("averageRating") and your.get("averageRating") and comp["averageRating"] > your["averageRating"] + 0.15:
        actions.append(
            {
                "priority": "high",
                "priorityLabel": priority_label("high"),
                "area": "Товар",
                "title": "Разобрать разрыв в рейтинге",
                "action": "Сравнить слабые стороны товара с конкурентами и проверить, не связаны ли претензии с партией, упаковкой или ожиданиями из карточки.",
                "why": f"Средняя оценка конкурентов выше: {comp['averageRating']} против {your['averageRating']} у нас.",
            }
        )

    if not actions:
        for row in aspect_comparison[:3]:
            if row["status"] == "Наше преимущество":
                actions.append(
                    {
                        "priority": "medium",
                        "priorityLabel": priority_label("medium"),
                        "area": "Контент",
                        "title": f"Закрепить преимущество: {row['title']}",
                        "action": row["recommendation"],
                        "why": "По этой теме наш товар выглядит сильнее конкурентов в отзывах.",
                    }
                )

    priority_order = {"high": 0, "medium": 1, "low": 2}
    unique = []
    seen = set()
    for action in sorted(actions, key=lambda item: priority_order.get(item["priority"], 1)):
        key = (action["title"], action["area"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(action)
        if len(unique) >= 6:
            break
    return unique


def plural_ru(value: int, one: str, few: str, many: str) -> str:
    number = abs(int(value))
    if 11 <= number % 100 <= 14:
        return many
    last = number % 10
    if last == 1:
        return one
    if 2 <= last <= 4:
        return few
    return many


def competitor_verdict(benchmark: dict[str, Any], aspect_comparison: list[dict[str, Any]], competitor_count: int) -> str:
    weak = sum(1 for row in aspect_comparison if row["status"] in ("У нас слабее", "Конкуренты сильнее"))
    strong = sum(1 for row in aspect_comparison if row["status"] == "Наше преимущество")
    your_rating = benchmark["your"].get("averageRating")
    comp_rating = benchmark["competitorsAvg"].get("averageRating")
    if competitor_count == 0:
        return "Не удалось собрать достаточно конкурентов для сравнения."
    competitor_word = plural_ru(competitor_count, "конкурента", "конкурентов", "конкурентов")
    if comp_rating and your_rating and your_rating >= comp_rating and strong >= weak:
        return f"На фоне {competitor_count} {competitor_word} товар выглядит устойчиво: рейтинг не ниже рынка, сильные стороны стоит активнее вынести в контент."
    if weak:
        zone_word = plural_ru(weak, "зона", "зоны", "зон")
        return f"На фоне {competitor_count} {competitor_word} есть {weak} {zone_word} для усиления: их нужно закрыть в первых фото, инфографике и описании ожиданий."
    competitor_with_word = plural_ru(competitor_count, "конкурентом", "конкурентами", "конкурентами")
    return f"Сравнение с {competitor_count} {competitor_with_word} показывает близкий уровень; главный резерв — лучше упаковать доказательства в карточке."


def analyze_competitors(article_input: str, limit_input: str | None, competitor_input: str | None) -> dict[str, Any]:
    article = article_from_input(article_input)
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    target_count = min(max(int(competitor_input or MAX_COMPETITORS), 1), MAX_COMPETITORS)

    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    try:
        feedback_data, feedback_url = fetch_feedbacks(article, root)
    except AppError as exc:
        if exc.status != 429:
            raise
        warning = "Отзывы вашей карточки не загрузились внутри сравнения из-за временного лимита WB; использованы доступные метрики карточки."
        feedback_data = competitor_card_only_feedback_data(product, warning)
        feedback_url = ""
    your_analysis = analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)

    candidates, queries, search_url = competitor_candidates(article, product, card_meta, target_count)
    competitor_analyses = []
    competitors = []
    errors = []

    for candidate in candidates:
        if len(competitors) >= target_count:
            break
        nm_id = safe_int(candidate.get("id"))
        if not nm_id:
            continue
        include_competitor_photo = len(competitors) < 5
        if competitor_analyses:
            time.sleep(0.55)
        try:
            candidate_feedbacks, candidate_feedback_url = fetch_feedbacks(nm_id, safe_int(candidate.get("root")))
            analysis = analyze_feedbacks(
                nm_id,
                candidate,
                candidate_feedbacks,
                candidate_feedback_url,
                f"https://www.wildberries.ru/catalog/{nm_id}/detail.aspx",
                min(limit, COMPETITOR_REVIEW_LIMIT),
                include_first_photo=include_competitor_photo,
            )
            competitor_analyses.append(analysis)
            competitors.append(competitor_product_payload(candidate, analysis))
        except AppError as exc:
            errors.append({"article": nm_id, "error": exc.message})
            if exc.status == 429:
                warning = "Отзывы конкурента не загрузились из-за временного лимита WB; в сравнении использованы доступные данные карточки."
                try:
                    analysis = analyze_feedbacks(
                        nm_id,
                        candidate,
                        competitor_card_only_feedback_data(candidate, warning),
                        "",
                        f"https://www.wildberries.ru/catalog/{nm_id}/detail.aspx",
                        0,
                        include_first_photo=include_competitor_photo,
                    )
                    competitor_analyses.append(analysis)
                    competitors.append(competitor_product_payload(candidate, analysis))
                except AppError as fallback_exc:
                    errors.append({"article": nm_id, "error": fallback_exc.message})
            continue

    if not competitor_analyses:
        raise AppError(
            "Не удалось собрать отзывы конкурентов. Wildberries мог временно ограничить выдачу или у похожих товаров нет текстовых отзывов.",
            502,
        )

    benchmark = competitor_benchmark(your_analysis, competitor_analyses)
    aspect_comparison = compare_aspects(your_analysis, competitor_analyses)
    action_plan = competitor_action_plan(your_analysis, competitor_analyses, aspect_comparison, benchmark)
    visual_comparison = first_photo_comparison(your_analysis, competitor_analyses)

    return {
        "product": your_analysis["product"],
        "summary": {
            "verdict": competitor_verdict(benchmark, aspect_comparison, len(competitors)),
            "competitorCount": len(competitors),
            "requestedCompetitors": target_count,
            "searchQueries": queries,
        },
        "benchmark": benchmark,
        "aspectComparison": aspect_comparison,
        "actionPlan": action_plan,
        "visualComparison": visual_comparison,
        "competitors": competitors,
        "source": {
            "searchUrl": search_url,
            "cardMetaUrl": card_meta_url,
            "selectionMode": "title_and_characteristics_score",
            "imageAnalysisMode": "first_photo_visual_metrics",
            "fetchedAt": datetime.now(timezone.utc).isoformat(),
            "reviewLimitPerCompetitor": min(limit, COMPETITOR_REVIEW_LIMIT),
            "errors": errors[:8],
        },
    }


def analyze_feedbacks(
    article: int,
    product: dict[str, Any],
    feedback_data: dict[str, Any],
    feedback_url: str,
    card_url: str,
    limit: int,
    card_meta: dict[str, Any] | None = None,
    card_meta_url: str | None = None,
    include_first_photo: bool = True,
) -> dict[str, Any]:
    all_feedbacks = feedback_data.get("feedbacks") or []
    feedbacks = all_feedbacks[:limit]
    aspect_data: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "positive": 0,
            "negative": 0,
            "neutral": 0,
            "sentences": [],
            "positive_examples": [],
            "negative_examples": [],
        }
    )

    positive_sentences: list[str] = []
    negative_sentences: list[str] = []
    neutral_sentences: list[str] = []

    for feedback in feedbacks:
        rating = safe_int(feedback.get("productValuation"))
        for field in ("pros", "cons", "text"):
            source_text = as_text(feedback.get(field))
            for sentence in split_sentences(source_text):
                polarity = classify_sentence(field, sentence, rating)
                if polarity == "neutral":
                    neutral_sentences.append(sentence)
                elif polarity == "positive":
                    positive_sentences.append(sentence)
                else:
                    negative_sentences.append(sentence)

                for aspect in detect_aspects(sentence):
                    item = aspect_data[aspect]
                    item[polarity] += 1
                    item["sentences"].append(sentence)
                    evidence = {
                        "text": short_text(sentence),
                        "rating": rating,
                        "date": feedback_date(feedback),
                    }
                    if polarity == "positive" and len(item["positive_examples"]) < 5:
                        item["positive_examples"].append(evidence)
                    if polarity == "negative" and len(item["negative_examples"]) < 5:
                        item["negative_examples"].append(evidence)

    specific_keys = [key for key in aspect_data if key != "overall"]
    strength_candidates = specific_keys or list(aspect_data.keys())
    weakness_candidates = specific_keys or list(aspect_data.keys())

    strengths = [
        summarize_aspect(key, aspect_data[key], "positive")
        for key in strength_candidates
        if aspect_data[key]["positive"] >= 1
    ]
    strengths.sort(key=lambda item: (item["positiveMentions"], item["balance"]), reverse=True)
    strengths = strengths[:5]

    weaknesses = [
        summarize_aspect(key, aspect_data[key], "negative")
        for key in weakness_candidates
        if aspect_data[key]["negative"] >= 1
    ]
    weaknesses.sort(key=lambda item: (item["negativeMentions"], -item["positiveMentions"]), reverse=True)
    weaknesses = weaknesses[:5]

    distribution = normalize_distribution(feedback_data.get("valuationDistribution"), all_feedbacks)
    distribution_total = sum(distribution.values())
    positive_ratings = distribution["4"] + distribution["5"]
    negative_ratings = distribution["1"] + distribution["2"] + distribution["3"]
    avg_rating = safe_float(feedback_data.get("valuation")) or safe_float(product.get("reviewRating"))

    text_count = int(feedback_data.get("feedbackCountWithText") or len(feedbacks))
    total_count = int(feedback_data.get("feedbackCount") or len(all_feedbacks))
    positive_pct = round(positive_ratings * 100 / distribution_total) if distribution_total else None
    negative_pct = round(negative_ratings * 100 / distribution_total) if distribution_total else None
    matching_size = feedback_data.get("matchingSizePercentages") or {}
    recommendations = build_recommendations(
        strengths,
        weaknesses,
        negative_pct,
        matching_size,
        text_count,
        product,
        card_meta,
    )
    marketplace = product.get("_marketplace") or MARKETPLACE_WB
    if marketplace == MARKETPLACE_OZON:
        source_image_url = as_text(product.get("sourceImageUrl") or product.get("imageUrl"))
        image_fetcher = (lambda url=source_image_url, referer=as_text(product.get("url")): fetch_remote_image(url, referer, timeout=8)) if source_image_url else None
        first_photo_analysis = (
            analyze_first_photo(
                article,
                product,
                strengths,
                weaknesses,
                image_url_override=source_image_url,
                source_url_override=source_image_url,
                image_fetcher=image_fetcher,
                marketplace_label="Ozon",
            )
            if include_first_photo
            else None
        )
        product_payload = {
            "marketplace": MARKETPLACE_OZON,
            "marketplaceLabel": "Ozon",
            "article": article,
            "sku": product.get("sku"),
            "productId": product.get("product_id"),
            "offerId": product.get("offer_id"),
            "root": product.get("product_id"),
            "name": as_text(product.get("name")),
            "brand": as_text(product.get("brand")),
            "supplier": as_text(product.get("supplier")),
            "imageUrl": source_image_url,
            "imageUrls": [source_image_url] if source_image_url else [],
            "sourceImageUrl": source_image_url,
            "reviewRating": avg_rating,
            "feedbacks": total_count,
            "textFeedbacks": text_count,
            "url": as_text(product.get("url")) or f"https://www.ozon.ru/product/{article}/",
        }
    else:
        first_photo_analysis = analyze_first_photo(article, product, strengths, weaknesses) if include_first_photo else None
        product_root = safe_int(product.get("root"))
        image_count = safe_int(product.get("pics")) or 1
        product_payload = {
            "marketplace": MARKETPLACE_WB,
            "marketplaceLabel": "WB",
            "article": article,
            "root": product_root,
            "name": as_text(product.get("name")),
            "brand": as_text(product.get("brand")),
            "supplier": as_text(product.get("supplier")),
            "imageUrl": product_image_url(article),
            "imageUrls": [product_image_url(article, index) for index in range(1, min(image_count, 4) + 1)],
            "sourceImageUrl": wb_product_image_url(article),
            "reviewRating": avg_rating,
            "feedbacks": total_count,
            "textFeedbacks": text_count,
            "url": f"https://www.wildberries.ru/catalog/{article}/detail.aspx",
        }

    return {
        "product": product_payload,
        "summary": {
            "verdict": build_verdict(avg_rating, distribution, text_count, len(weaknesses)),
            "averageRating": avg_rating,
            "feedbackCount": total_count,
            "textFeedbackCount": text_count,
            "loadedReviews": len(feedbacks),
            "distribution": distribution,
            "positiveRatingPercent": positive_pct,
            "negativeRatingPercent": negative_pct,
            "matchingSizePercentages": matching_size,
        },
        "strengths": strengths,
        "weaknesses": weaknesses,
        "recommendations": recommendations,
        "firstPhotoAnalysis": first_photo_analysis,
        "terms": {
            "positive": top_terms(positive_sentences, 12),
            "negative": top_terms(negative_sentences, 12),
            "neutral": top_terms(neutral_sentences, 8),
        },
        "examples": {
            "positive": select_examples(feedbacks, "positive"),
            "negative": select_examples(feedbacks, "negative"),
        },
        "source": {
            "cardUrl": card_url,
            "cardMetaUrl": card_meta_url,
            "feedbackUrl": feedback_url,
            "fetchedAt": datetime.now(timezone.utc).isoformat(),
            "limit": limit,
            "marketplace": marketplace,
            "warning": feedback_data.get("_warning"),
            "note": "Локальный эвристический анализ отзывов карточки маркетплейса.",
        },
    }


def analyze_article(article_input: str, limit_input: str | None, marketplace_input: str | None = None) -> dict[str, Any]:
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    marketplace = marketplace_from_input(marketplace_input)
    if marketplace == MARKETPLACE_OZON:
        product, feedback_data, card_url, card_meta_url = fetch_ozon_product_and_feedbacks(article_input, limit)
        article = safe_int(product.get("article")) or safe_int(product.get("sku")) or safe_int(product.get("product_id")) or 0
        return analyze_feedbacks(article, product, feedback_data, card_url, card_url, limit, {}, card_meta_url)

    article = article_from_input(article_input)
    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    feedback_data, feedback_url = fetch_feedbacks(article, root)
    return analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)


class AnalyzerHandler(BaseHTTPRequestHandler):
    server_version = "WBReviewAnalyzer/1.0"

    def log_message(self, format: str, *args: Any) -> None:
        print(f"{self.address_string()} - {format % args}")

    def send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_xlsx(self, filename: str, body: bytes) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_docx(self, filename: str, body: bytes) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_image(self, body: bytes, content_type: str) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_static(self, path: str) -> None:
        parsed_path = path.lstrip("/") or "index.html"
        target = (BASE_DIR / parsed_path).resolve()
        if not str(target).startswith(str(BASE_DIR)) or not target.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return

        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        data = target.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_cors_headers()
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/analyze":
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            marketplace = (query.get("marketplace") or [MARKETPLACE_WB])[0]
            try:
                payload = analyze_article(article, limit, marketplace)
                self.send_json({"ok": True, "data": payload})
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит должен быть числом."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Внутренняя ошибка анализатора.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/export":
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            marketplace = (query.get("marketplace") or [MARKETPLACE_WB])[0]
            try:
                article_id, workbook, source = export_article(article, limit, marketplace)
                self.send_xlsx(f"{source}-review-analysis-{article_id}.xlsx", workbook)
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит должен быть числом."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Не удалось сформировать Excel-файл.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/brief":
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            marketplace = (query.get("marketplace") or [MARKETPLACE_WB])[0]
            try:
                article_id, document, source = brief_article(article, limit, marketplace)
                self.send_docx(f"{source}-content-brief-{article_id}.docx", document)
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит должен быть числом."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Не удалось сформировать ТЗ.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/competitors":
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            competitors = (query.get("competitors") or [str(MAX_COMPETITORS)])[0]
            marketplace = marketplace_from_input((query.get("marketplace") or [MARKETPLACE_WB])[0])
            try:
                if marketplace == MARKETPLACE_OZON:
                    raise AppError(
                        "Анализ конкурентов Ozon пока требует отдельный источник данных.",
                        501,
                        "Публичная выдача Ozon часто блокирует серверные запросы. Для конкурентов нужен Seller/Brand API или внешний парсер.",
                    )
                payload = analyze_competitors(article, limit, competitors)
                self.send_json({"ok": True, "data": payload})
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит и количество конкурентов должны быть числами."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Не удалось выполнить анализ конкурентов.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/image":
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            image_number = parse_image_number((query.get("n") or [None])[0])
            marketplace = marketplace_from_input((query.get("marketplace") or [MARKETPLACE_WB])[0])
            try:
                if marketplace == MARKETPLACE_OZON:
                    raise AppError("Для Ozon фото передается прямой ссылкой из карточки или Seller API.", 400)
                article_id = article_from_input(article)
                body, content_type, _source_url = fetch_product_image(article_id, image_number)
                self.send_image(body, content_type)
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ С„РѕС‚Рѕ С‚РѕРІР°СЂР°.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/health":
            self.send_json({"ok": True, "version": APP_VERSION})
            return

        self.send_static(parsed.path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Wildberries review analyzer")
    default_host = os.environ.get("HOST") or ("0.0.0.0" if os.environ.get("PORT") else "127.0.0.1")
    default_port = int(os.environ.get("PORT", "8765"))
    parser.add_argument("--host", default=default_host)
    parser.add_argument("--port", type=int, default=default_port)
    args = parser.parse_args()

    httpd = ThreadingHTTPServer((args.host, args.port), AnalyzerHandler)
    print(f"WB review analyzer: http://{args.host}:{args.port}")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
