from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import hmac
import json
import mimetypes
import os
import re
import time
import zipfile
import zlib
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, parse_qsl, quote, urlencode, urlparse
from urllib.request import Request, urlopen
from xml.sax.saxutils import escape as xml_escape


BASE_DIR = Path(__file__).resolve().parent
REQUEST_TIMEOUT = 20
MAX_LIMIT = 300
MAX_COMPETITORS = 10
COMPETITOR_REVIEW_LIMIT = 60
IMAGE_BASKET_LIMIT = 80
IMAGE_MAX_ATTEMPTS = 36
IMAGE_FOLDERS = ("images/big", "images/c516x688", "images/c246x328", "images/tm")
MARKETPLACE_WB = "wb"
MARKETPLACE_OZON = "ozon"
APP_VERSION = "seo-placeholder-1"
DEFAULT_TELEGRAM_BOT_USERNAME = "vorobey_vision_access_bot"
DEFAULT_TELEGRAM_REQUIRED_CHANNELS = "@Elena_opora_psy,@vorobevFM"
DEFAULT_PUBLIC_BASE_URL = "https://vorobey-vision-ai.onrender.com"
AUTH_COOKIE_NAME = "vvai_session"
AUTH_TTL_SECONDS = 60 * 60 * 24 * 7
TELEGRAM_LOGIN_MAX_AGE_SECONDS = 60 * 60 * 24
WB_SEARCH_ENDPOINTS = (
    "https://search.wb.ru/exactmatch/ru/common/v18/search",
    "https://u-search.wb.ru/exactmatch/ru/common/v18/search",
)


class AppError(Exception):
    def __init__(self, message: str, status: int = 500, details: str | None = None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.details = details


@dataclass(frozen=True)
class RemoteResult:
    url: str
    data: dict[str, Any]


STOPWORDS = {
    "а",
    "без",
    "более",
    "был",
    "была",
    "были",
    "было",
    "быть",
    "в",
    "вам",
    "вас",
    "весь",
    "во",
    "вот",
    "все",
    "всё",
    "всего",
    "вы",
    "где",
    "да",
    "даже",
    "для",
    "до",
    "его",
    "ее",
    "её",
    "если",
    "есть",
    "ещё",
    "же",
    "за",
    "и",
    "из",
    "или",
    "им",
    "их",
    "к",
    "как",
    "ко",
    "когда",
    "ли",
    "лучше",
    "мне",
    "мой",
    "мы",
    "на",
    "над",
    "нам",
    "нас",
    "не",
    "него",
    "нее",
    "ней",
    "нем",
    "нет",
    "ни",
    "но",
    "ну",
    "о",
    "об",
    "он",
    "она",
    "они",
    "оно",
    "от",
    "очень",
    "по",
    "под",
    "при",
    "про",
    "раз",
    "с",
    "со",
    "так",
    "там",
    "то",
    "тоже",
    "только",
    "у",
    "уже",
    "хотя",
    "чем",
    "что",
    "чтобы",
    "это",
    "этот",
    "эту",
    "я",
    "товар",
    "товара",
    "товару",
    "товаром",
    "wb",
    "wildberries",
    "беру",
    "брала",
    "брал",
    "заказ",
    "заказала",
    "заказал",
    "пришел",
    "пришла",
    "пришло",
    "пришли",
    "получила",
    "получил",
}


EMPTY_OPINIONS = {
    "",
    "-",
    "нет",
    "нету",
    "не нашла",
    "не нашел",
    "не нашёл",
    "не обнаружено",
    "не обнаружила",
    "не обнаружил",
    "нет недостатков",
    "без недостатков",
    "нет минусов",
    "минусов нет",
    "нет достоинств",
}


POSITIVE_PATTERNS = (
    "аккурат",
    "выгод",
    "доволь",
    "идеаль",
    "качеств",
    "класс",
    "красив",
    "крепк",
    "легк",
    "мягк",
    "нрав",
    "отлич",
    "понрав",
    "прекрас",
    "прият",
    "плотн",
    "рекоменд",
    "супер",
    "удоб",
    "хорош",
    "цена",
)

NEGATIVE_PATTERNS = (
    "брак",
    "большемер",
    "гряз",
    "дорог",
    "жмет",
    "жмёт",
    "запах",
    "колет",
    "крив",
    "маломер",
    "мят",
    "не подош",
    "не понрав",
    "не работает",
    "не соответствует",
    "нет ",
    "отвал",
    "плох",
    "порвал",
    "проблем",
    "рван",
    "скольз",
    "слом",
    "тонк",
    "ужас",
)


ASPECTS = {
    "quality": {
        "title": "Качество и материалы",
        "keywords": (
            "качеств",
            "материал",
            "ткан",
            "шов",
            "швы",
            "нитк",
            "плотн",
            "тонк",
            "прочн",
            "крепк",
            "пошив",
            "состав",
            "кожа",
            "пластик",
            "металл",
            "брак",
            "рван",
            "порвал",
        ),
    },
    "fit": {
        "title": "Размер и посадка",
        "keywords": (
            "размер",
            "маломер",
            "большемер",
            "посадк",
            "сидит",
            "сел",
            "села",
            "подош",
            "узк",
            "широк",
            "длин",
            "коротк",
            "объем",
            "объём",
            "рост",
        ),
    },
    "comfort": {
        "title": "Удобство",
        "keywords": (
            "удоб",
            "комфорт",
            "мягк",
            "прият",
            "носить",
            "жмет",
            "жмёт",
            "давит",
            "колет",
            "тяжел",
            "легк",
            "скольз",
        ),
    },
    "appearance": {
        "title": "Внешний вид",
        "keywords": (
            "красив",
            "цвет",
            "вид",
            "дизайн",
            "фото",
            "стиль",
            "выгляд",
            "ярк",
            "оттенок",
            "принт",
        ),
    },
    "price": {
        "title": "Цена и ценность",
        "keywords": (
            "цена",
            "стоим",
            "деньг",
            "дорог",
            "дешев",
            "выгод",
            "скидк",
            "ценник",
            "переплат",
        ),
    },
    "packaging": {
        "title": "Упаковка и доставка",
        "keywords": (
            "упаков",
            "достав",
            "коробк",
            "пакет",
            "мят",
            "цел",
            "быстро",
            "гряз",
            "пришел",
            "пришла",
            "пришло",
            "пришли",
        ),
    },
    "completeness": {
        "title": "Комплектация",
        "keywords": (
            "комплект",
            "набор",
            "штук",
            "пара",
            "не хватает",
            "влож",
            "насад",
            "детал",
            "инструкц",
        ),
    },
    "function": {
        "title": "Работа и функции",
        "keywords": (
            "работает",
            "работ",
            "заряд",
            "звук",
            "держит",
            "греет",
            "свет",
            "моет",
            "липнет",
            "клеит",
            "застеж",
            "замок",
            "молния",
            "кнопк",
            "аккумулятор",
            "батар",
        ),
    },
}


RECOMMENDATION_TEMPLATES = {
    "quality": {
        "content_title": "Показать качество без догадок",
        "content_action": (
            "Добавьте в первые 5 фото крупный план материала, швов и фактуры; в инфографике укажите состав, "
            "плотность, уход и что именно покупатель получает в упаковке."
        ),
        "product_title": "Усилить контроль качества партии",
        "product_action": (
            "Проверьте швы, торчащие нитки, плотность и повторяемость материала по партиям; заведите чек-лист "
            "перед отгрузкой и отдельно проверяйте товары, которые чаще попадают в негативные отзывы."
        ),
    },
    "fit": {
        "content_title": "Снять риск ошибки с размером",
        "content_action": (
            "Обновите размерную сетку фактическими замерами товара, добавьте подсказку «маломерит/большемерит», "
            "фото на модели или схему посадки с ростом и параметрами."
        ),
        "product_title": "Сверить лекала и фактические размеры",
        "product_action": (
            "Сравните реальные замеры партии с таблицей на карточке; если отклонения повторяются, скорректируйте "
            "размерный ряд или добавьте отдельный размер/посадку."
        ),
    },
    "comfort": {
        "content_title": "Объяснить комфорт в сценариях",
        "content_action": (
            "Добавьте блок «когда удобно использовать»: мягкость, вес, эластичность, посадка, сезонность и ограничения, "
            "чтобы ожидания совпадали с реальным использованием."
        ),
        "product_title": "Убрать источники дискомфорта",
        "product_action": (
            "Проверьте контактные зоны: резинки, швы, застёжки, жёсткие края, вес и скольжение; протестируйте товар "
            "в типовом сценарии использования, а не только визуально."
        ),
    },
    "appearance": {
        "content_title": "Переснять цвет и детали",
        "content_action": (
            "Сделайте фото при дневном нейтральном свете без сильной обработки, покажите оттенок рядом с белым/серым "
            "фоном и добавьте крупные кадры принта, фактуры и важных деталей."
        ),
        "product_title": "Стабилизировать внешний вид партии",
        "product_action": (
            "Сверьте фактический оттенок, принт и отделку с карточкой; если поставки отличаются, разделите варианты "
            "по цветам/партиям или обновляйте фото под текущую поставку."
        ),
    },
    "price": {
        "content_title": "Обосновать цену",
        "content_action": (
            "Вынесите в инфографику, за что платит покупатель: комплектность, материал, срок службы, гарантия, "
            "дополнительные элементы или выгоду набора."
        ),
        "product_title": "Добавить ценность без роста цены",
        "product_action": (
            "Проверьте, можно ли улучшить комплектацию, упаковку, инструкцию или гарантийную поддержку; если нельзя, "
            "пересмотрите цену, скидку или набор."
        ),
    },
    "packaging": {
        "content_title": "Показать упаковку и получение",
        "content_action": (
            "Добавьте фото комплекта в упаковке и коротко опишите, как товар защищён при доставке; отдельно покажите "
            "что должно прийти покупателю."
        ),
        "product_title": "Усилить упаковку и предпродажную проверку",
        "product_action": (
            "Добавьте защиту от помятостей, грязи и вскрытия; перед отгрузкой проверяйте целостность упаковки, "
            "маркировку и комплектность."
        ),
    },
    "completeness": {
        "content_title": "Сделать состав комплекта очевидным",
        "content_action": (
            "На отдельной инфографике перечислите все элементы комплекта, количество штук, размеры и исключения; "
            "покажите весь набор одним кадром."
        ),
        "product_title": "Ввести контроль комплектации",
        "product_action": (
            "Добавьте чек-лист сборки заказа и контроль веса/штрихкода для комплекта, чтобы не отправлять неполные "
            "наборы или другой вариант товара."
        ),
    },
    "function": {
        "content_title": "Показать работу товара в видео",
        "content_action": (
            "Добавьте короткое видео или серию кадров: включение, результат работы, важные характеристики, ограничения "
            "и простую инструкцию по использованию."
        ),
        "product_title": "Проверить функциональные узлы",
        "product_action": (
            "Проведите выборочную проверку функций, замков, кнопок, аккумулятора, креплений или расходников; отдельно "
            "фиксируйте дефекты, которые повторяются в отзывах."
        ),
    },
    "overall": {
        "content_title": "Закрыть частые сомнения в карточке",
        "content_action": (
            "Добавьте мини-FAQ по повторяющимся вопросам и замечаниям из отзывов: что входит, кому подходит, "
            "как выбрать и чего не стоит ожидать."
        ),
        "product_title": "Разобрать негативные отзывы вручную",
        "product_action": (
            "Сгруппируйте последние отзывы на 1-3 звезды, проверьте товар из спорных партий и заведите список "
            "корректирующих действий по каждой повторяющейся причине."
        ),
    },
}


def decode_body(raw: bytes, encoding: str) -> bytes:
    encoding = encoding.lower()
    if encoding == "gzip" or raw[:2] == b"\x1f\x8b":
        return gzip.decompress(raw)
    if encoding == "deflate":
        return zlib.decompress(raw)
    return raw


def remote_json(url: str, referer: str, attempts: int = 2, timeout: int = REQUEST_TIMEOUT) -> RemoteResult:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "application/json,text/plain,*/*",
        "Accept-Encoding": "gzip, deflate",
        "Origin": "https://www.wildberries.ru",
        "Referer": referer,
    }
    last_error: Exception | None = None

    for attempt in range(attempts):
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=timeout) as response:
                raw = response.read()
                encoding = response.headers.get("Content-Encoding", "")
            body = decode_body(raw, encoding).decode("utf-8", "replace")
            return RemoteResult(url=url, data=json.loads(body))
        except HTTPError as exc:
            last_error = exc
            if exc.code == 429 and attempt + 1 < attempts:
                time.sleep(1.2)
                continue
            if exc.code == 404:
                raise AppError("Wildberries не нашёл данные по этому артикулу.", 404)
            if exc.code == 429:
                raise AppError(
                    "Wildberries временно ограничил частоту запросов. Попробуйте ещё раз через минуту.",
                    429,
                )
            raise AppError(f"Wildberries вернул HTTP {exc.code}.", 502)
        except (URLError, TimeoutError) as exc:
            last_error = exc
            if attempt + 1 < attempts:
                time.sleep(0.8)
                continue
        except json.JSONDecodeError as exc:
            raise AppError("Wildberries вернул ответ в неожиданном формате.", 502, str(exc))

    raise AppError("Не удалось подключиться к Wildberries.", 502, str(last_error))


def article_from_input(value: str) -> int:
    value = value.strip()
    catalog_match = re.search(r"/catalog/(\d+)", value)
    if catalog_match:
        return int(catalog_match.group(1))
    digits = re.sub(r"\D+", "", value)
    if not digits:
        raise AppError("Введите артикул Wildberries или ссылку на товар.", 400)
    return int(digits)


def fetch_product(article: int) -> tuple[dict[str, Any], str]:
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    url = (
        "https://card.wb.ru/cards/v4/detail"
        f"?appType=1&curr=rub&dest=-1257786&hide_dtype=13&lang=ru&nm={article}&spp=30"
    )
    result = remote_json(url, referer)
    products = result.data.get("products") or result.data.get("data", {}).get("products") or []
    if not products:
        raise AppError("Карточка товара не найдена. Проверьте артикул.", 404)
    return products[0], result.url


def basket_host_candidates(article: int) -> list[int]:
    vol = article // 100000
    ranges = [
        (0, 143, 1),
        (144, 287, 2),
        (288, 431, 3),
        (432, 719, 4),
        (720, 1007, 5),
        (1008, 1061, 6),
        (1062, 1115, 7),
        (1116, 1169, 8),
        (1170, 1313, 9),
        (1314, 1601, 10),
        (1602, 1655, 11),
        (1656, 1919, 12),
        (1920, 2045, 13),
        (2046, 2189, 14),
        (2190, 2405, 15),
        (2406, 2621, 16),
        (2622, 2837, 17),
        (2838, 3053, 18),
        (3054, 3269, 19),
        (3270, 3485, 20),
        (3486, 3701, 21),
        (3702, 3917, 22),
        (3918, 4133, 23),
        (4134, 4349, 24),
        (4350, 4565, 25),
        (4566, 4781, 26),
        (4782, 4997, 27),
        (4998, 5213, 28),
        (5214, 5429, 29),
        (5430, 5645, 30),
    ]
    preferred = next((basket for start, end, basket in ranges if start <= vol <= end), None)
    if preferred is None and vol > ranges[-1][1]:
        estimated = ranges[-1][2] + ((vol - ranges[-1][1] - 1) // 216) + 1
        preferred = min(max(estimated, 1), IMAGE_BASKET_LIMIT)
    candidates = [preferred] if preferred else []
    if preferred:
        for offset in range(1, 13):
            lower = preferred - offset
            upper = preferred + offset
            if lower >= 1:
                candidates.append(lower)
            if upper <= IMAGE_BASKET_LIMIT:
                candidates.append(upper)
    candidates.extend(range(1, 31))
    candidates.extend(range(31, IMAGE_BASKET_LIMIT + 1))
    return [item for index, item in enumerate(candidates) if item and item not in candidates[:index]]


def wb_product_image_url(
    article: int,
    image_number: int = 1,
    basket: int | None = None,
    image_folder: str = "images/big",
) -> str:
    vol = article // 100000
    part = article // 1000
    basket_id = basket or basket_host_candidates(article)[0]
    return f"https://basket-{basket_id:02d}.wbbasket.ru/vol{vol}/part{part}/{article}/{image_folder}/{image_number}.webp"


def product_image_url_candidates(article: int, image_number: int = 1) -> list[str]:
    baskets = basket_host_candidates(article)
    primary_baskets = baskets[:28]
    fallback_baskets = baskets[28:58]
    candidates = [
        wb_product_image_url(article, image_number, basket, image_folder)
        for image_folder in IMAGE_FOLDERS[:2]
        for basket in primary_baskets
    ]
    candidates.extend(wb_product_image_url(article, image_number, basket) for basket in fallback_baskets)
    candidates.extend(
        wb_product_image_url(article, image_number, basket, image_folder)
        for image_folder in IMAGE_FOLDERS[2:]
        for basket in primary_baskets[:10]
    )
    return candidates


def product_image_url(article: int, image_number: int = 1) -> str:
    return f"/api/image?article={article}&n={image_number}"


def fetch_product_image(article: int, image_number: int = 1, timeout: int = 8) -> tuple[bytes, str, str]:
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": referer,
    }
    last_error: Exception | None = None
    request_timeout = min(float(timeout), 1.5)

    for url in product_image_url_candidates(article, image_number)[:IMAGE_MAX_ATTEMPTS]:
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=request_timeout) as response:
                body = response.read()
                content_type = response.headers.get("Content-Type") or "image/webp"
            if body and (content_type.startswith("image/") or body[:4] == b"RIFF"):
                return body, content_type if content_type.startswith("image/") else "image/webp", url
        except HTTPError as exc:
            last_error = exc
            if exc.code in (403, 404):
                continue
            raise AppError(f"Wildberries РІРµСЂРЅСѓР» HTTP {exc.code} РґР»СЏ С„РѕС‚Рѕ С‚РѕРІР°СЂР°.", 502)
        except (URLError, TimeoutError, OSError) as exc:
            last_error = exc
            continue

    raise AppError("Р¤РѕС‚Рѕ С‚РѕРІР°СЂР° РЅРµ РЅР°Р№РґРµРЅРѕ.", 404, str(last_error) if last_error else None)


def fetch_remote_image(url: str, referer: str = "", timeout: int = 8) -> tuple[bytes, str, str]:
    if not url:
        raise AppError("Ссылка на фото не найдена.", 404)
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    }
    if referer:
        headers["Referer"] = referer
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=timeout) as response:
            body = response.read()
            content_type = response.headers.get("Content-Type") or "image/jpeg"
        if body and (content_type.startswith("image/") or body[:4] == b"RIFF"):
            return body, content_type if content_type.startswith("image/") else "image/webp", url
    except HTTPError as exc:
        raise AppError(f"Сервер изображения вернул HTTP {exc.code}.", 502) from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise AppError("Не удалось загрузить фото товара.", 502, str(exc)) from exc
    raise AppError("Фото товара не найдено.", 404)


def parse_image_number(value: str | None) -> int:
    number = safe_int(value) or 1
    return min(max(number, 1), 12)


def fetch_card_metadata(article: int, max_hosts: int = 10, timeout: int = 3) -> tuple[dict[str, Any], str | None]:
    vol = article // 100000
    part = article // 1000
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "application/json,text/plain,*/*",
        "Accept-Encoding": "gzip, deflate",
        "Referer": referer,
    }

    for basket in basket_host_candidates(article)[:max_hosts]:
        url = f"https://basket-{basket:02d}.wbbasket.ru/vol{vol}/part{part}/{article}/info/ru/card.json"
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=timeout) as response:
                raw = response.read()
                encoding = response.headers.get("Content-Encoding", "")
            data = json.loads(decode_body(raw, encoding).decode("utf-8", "replace"))
            if isinstance(data, dict):
                return data, url
        except HTTPError as exc:
            if exc.code in (403, 404):
                continue
        except (URLError, TimeoutError, json.JSONDecodeError, OSError):
            continue
    return {}, None


def fetch_feedbacks(article: int, root: int | None) -> tuple[dict[str, Any], str]:
    referer = f"https://www.wildberries.ru/catalog/{article}/detail.aspx"
    ids = []
    for candidate in (root, article):
        if candidate and candidate not in ids:
            ids.append(candidate)

    best: tuple[dict[str, Any], str] | None = None
    for feedback_id in ids:
        for host in ("feedbacks1.wb.ru", "feedbacks2.wb.ru"):
            for version in ("v2", "v1"):
                url = f"https://{host}/feedbacks/{version}/{feedback_id}"
                try:
                    result = remote_json(url, referer)
                except AppError as exc:
                    if exc.status == 404:
                        continue
                    raise

                data = result.data
                feedbacks = data.get("feedbacks") or []
                current_score = (
                    int(data.get("feedbackCountWithText") or 0),
                    len(feedbacks),
                    int(data.get("feedbackCount") or 0),
                )
                if best is None:
                    best = (data, result.url)
                else:
                    previous = best[0]
                    previous_score = (
                        int(previous.get("feedbackCountWithText") or 0),
                        len(previous.get("feedbacks") or []),
                        int(previous.get("feedbackCount") or 0),
                    )
                    if current_score > previous_score:
                        best = (data, result.url)

                if feedbacks:
                    return data, result.url

    if best is None:
        raise AppError("Отзывы по товару не найдены.", 404)
    return best


def as_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def normalize_opinion(text: str) -> str:
    normalized = re.sub(r"\s+", " ", text.strip().lower().replace("ё", "е"))
    return normalized.strip(" .,!?:;")


def has_real_text(text: str) -> bool:
    return bool(text.strip()) and normalize_opinion(text) not in EMPTY_OPINIONS


def safe_int(value: Any) -> int | None:
    try:
        if value is None or value == "":
            return None
        return int(float(value))
    except (TypeError, ValueError):
        return None


def safe_float(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return None


def marketplace_from_input(value: str | None) -> str:
    normalized = normalize_opinion(as_text(value))
    if normalized in ("ozon", "озон", "o3"):
        return MARKETPLACE_OZON
    return MARKETPLACE_WB


def ozon_identifier_from_input(value: str) -> tuple[str, str]:
    text = as_text(value)
    if not text:
        raise AppError("Введите SKU, product_id, offer_id или ссылку на товар Ozon.", 400)
    lowered = text.lower()
    if "ozon.ru" in lowered or "/product/" in lowered:
        parsed = urlparse(text if re.match(r"^https?://", text, re.I) else "https://" + text.lstrip("/"))
        match = re.search(r"-(\d+)(?:[/?#]|$)", parsed.path)
        if not match:
            match = re.search(r"/product/[^/?#]*?(\d+)(?:[/?#]|$)", parsed.path)
        if match:
            return "sku", match.group(1)
    if re.fullmatch(r"\d{5,}", text):
        return "sku", text
    return "offer_id", text


def ozon_public_product_path(value: str) -> str:
    text = as_text(value)
    if "ozon.ru" in text.lower():
        parsed = urlparse(text if re.match(r"^https?://", text, re.I) else "https://" + text.lstrip("/"))
        path = parsed.path or ""
        if parsed.query:
            path += "?" + parsed.query
        return path
    kind, identifier = ozon_identifier_from_input(value)
    if kind == "sku":
        return f"/product/{identifier}/"
    raise AppError("Для публичного режима Ozon нужна ссылка на товар или числовой SKU.", 400)


def ozon_public_json(path: str) -> tuple[dict[str, Any], str]:
    public_path = path if path.startswith("/") else "/" + path
    url = "https://www.ozon.ru/api/composer-api.bx/page/json/v2?url=" + quote(public_path, safe="/?=&")
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
        ),
        "Accept": "application/json,text/plain,*/*",
        "Referer": "https://www.ozon.ru/",
    }
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=12) as response:
            raw = response.read()
            encoding = response.headers.get("Content-Encoding", "")
        data = json.loads(decode_body(raw, encoding).decode("utf-8", "replace"))
        if isinstance(data, dict):
            return data, url
    except HTTPError as exc:
        if exc.code == 403:
            raise AppError(
                "Ozon заблокировал публичную загрузку карточки с сервера. Для стабильного анализа Ozon добавьте Seller API ключи.",
                403,
                "Нужны переменные окружения OZON_CLIENT_ID и OZON_API_KEY.",
            ) from exc
        raise AppError(f"Ozon вернул HTTP {exc.code}.", 502) from exc
    except (URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        raise AppError("Не удалось подключиться к Ozon.", 502, str(exc)) from exc
    raise AppError("Ozon вернул ответ в неожиданном формате.", 502)


def decode_possible_json(value: Any) -> Any:
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("{") or text.startswith("["):
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return value
    return value


def walk_json_values(value: Any) -> list[Any]:
    value = decode_possible_json(value)
    result = [value]
    if isinstance(value, dict):
        for child in value.values():
            result.extend(walk_json_values(child))
    elif isinstance(value, list):
        for child in value:
            result.extend(walk_json_values(child))
    return result


def image_url_from_value(value: Any) -> str:
    if isinstance(value, str) and re.search(r"\.(?:jpg|jpeg|png|webp)(?:\?|$)", value, re.I):
        return value
    if isinstance(value, dict):
        for key in ("primary_image", "primaryImage", "coverImage", "image", "imageUrl", "url"):
            found = image_url_from_value(value.get(key))
            if found:
                return found
        for key in ("images", "pictures"):
            images = value.get(key)
            if isinstance(images, list):
                for item in images:
                    found = image_url_from_value(item)
                    if found:
                        return found
    if isinstance(value, list):
        for item in value:
            found = image_url_from_value(item)
            if found:
                return found
    return ""


def fetch_ozon_public_product(article_input: str) -> tuple[dict[str, Any], dict[str, Any], str, str | None]:
    path = ozon_public_product_path(article_input)
    data, source_url = ozon_public_json(path)
    identifier_kind, identifier = ozon_identifier_from_input(article_input)
    product_candidates = []
    for item in walk_json_values(data):
        if not isinstance(item, dict):
            continue
        name = as_text(item.get("name") or item.get("title") or item.get("productName"))
        image = image_url_from_value(item)
        rating = safe_float(item.get("rating") or item.get("reviewRating") or item.get("ratingValue"))
        reviews = safe_int(item.get("reviewsCount") or item.get("commentsCount") or item.get("feedbacks"))
        if name and (image or rating is not None or reviews is not None):
            product_candidates.append((item, name, image, rating, reviews))

    if not product_candidates:
        raise AppError("Ozon не отдал структуру карточки в публичном режиме.", 502)

    raw, name, image, rating, reviews = product_candidates[0]
    sku = safe_int(identifier) if identifier_kind == "sku" else safe_int(raw.get("sku") or raw.get("id"))
    product_id = safe_int(raw.get("product_id") or raw.get("productId"))
    article = sku or product_id or safe_int(identifier) or 0
    product = {
        "_marketplace": MARKETPLACE_OZON,
        "article": article,
        "sku": sku,
        "product_id": product_id,
        "offer_id": as_text(raw.get("offer_id") or raw.get("offerId") or (identifier if identifier_kind == "offer_id" else "")),
        "name": name,
        "brand": as_text(raw.get("brand") or raw.get("brandName")),
        "supplier": as_text(raw.get("seller") or raw.get("sellerName")),
        "imageUrl": image,
        "sourceImageUrl": image,
        "reviewRating": rating,
        "feedbacks": reviews or 0,
        "textFeedbacks": 0,
        "url": "https://www.ozon.ru" + path,
        "pics": 1 if image else 0,
    }
    feedbacks = {"feedbacks": [], "feedbackCount": reviews or 0, "feedbackCountWithText": 0, "valuation": rating}
    return product, feedbacks, source_url, None


def ozon_api_credentials() -> tuple[str, str] | None:
    client_id = os.environ.get("OZON_CLIENT_ID") or os.environ.get("OZON_SELLER_CLIENT_ID")
    api_key = os.environ.get("OZON_API_KEY") or os.environ.get("OZON_SELLER_API_KEY")
    if client_id and api_key:
        return client_id, api_key
    return None


def ozon_seller_request(path: str, payload: dict[str, Any], timeout: int = 20) -> dict[str, Any]:
    credentials = ozon_api_credentials()
    if not credentials:
        raise AppError(
            "Для стабильного анализа Ozon нужны ключи Seller API.",
            401,
            "Добавьте в Render переменные OZON_CLIENT_ID и OZON_API_KEY. Публичные страницы Ozon часто возвращают 403.",
        )
    client_id, api_key = credentials
    url = "https://api-seller.ozon.ru" + path
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Client-Id": client_id,
        "Api-Key": api_key,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        req = Request(url, data=body, headers=headers, method="POST")
        with urlopen(req, timeout=timeout) as response:
            raw = response.read()
            encoding = response.headers.get("Content-Encoding", "")
        data = json.loads(decode_body(raw, encoding).decode("utf-8", "replace"))
        if isinstance(data, dict):
            return data
    except HTTPError as exc:
        details = ""
        try:
            details = exc.read().decode("utf-8", "replace")
        except OSError:
            details = str(exc)
        raise AppError(f"Ozon Seller API вернул HTTP {exc.code}.", 502, details) from exc
    except (URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        raise AppError("Не удалось подключиться к Ozon Seller API.", 502, str(exc)) from exc
    raise AppError("Ozon Seller API вернул ответ в неожиданном формате.", 502)


def fetch_ozon_seller_product(article_input: str) -> tuple[dict[str, Any], dict[str, Any], str, str | None]:
    kind, identifier = ozon_identifier_from_input(article_input)
    product_query = {kind: [identifier]}
    info = ozon_seller_request("/v3/product/info/list", product_query)
    items = info.get("items") or info.get("result", {}).get("items") or []
    if not items and kind == "sku":
        info = ozon_seller_request("/v3/product/info/list", {"product_id": [identifier]})
        items = info.get("items") or info.get("result", {}).get("items") or []
    if not items:
        raise AppError("Товар Ozon не найден в Seller API. Проверьте SKU/product_id/offer_id.", 404)
    raw = items[0]
    product_id = safe_int(raw.get("product_id") or raw.get("id"))
    sku = safe_int(raw.get("sku") or (identifier if kind == "sku" else None))
    offer_id = as_text(raw.get("offer_id") or (identifier if kind == "offer_id" else ""))
    image = image_url_from_value(raw)
    card_url = f"https://www.ozon.ru/product/{sku or product_id}/"
    product = {
        "_marketplace": MARKETPLACE_OZON,
        "article": sku or product_id or safe_int(identifier) or 0,
        "sku": sku,
        "product_id": product_id,
        "offer_id": offer_id,
        "name": as_text(raw.get("name")),
        "brand": as_text(raw.get("brand") or raw.get("brand_name")),
        "supplier": as_text(raw.get("seller_name")),
        "imageUrl": image,
        "sourceImageUrl": image,
        "reviewRating": safe_float(raw.get("rating") or raw.get("rating_value")),
        "feedbacks": safe_int(raw.get("reviews_count") or raw.get("review_count")) or 0,
        "textFeedbacks": 0,
        "url": card_url,
        "pics": len(raw.get("images") or []) or (1 if image else 0),
    }

    attributes_meta: dict[str, Any] = {}
    attributes_url = None
    try:
        attr_filter: dict[str, Any] = {"visibility": "ALL"}
        if product_id:
            attr_filter["product_id"] = [str(product_id)]
        elif offer_id:
            attr_filter["offer_id"] = [offer_id]
        attr_payload = {"filter": attr_filter, "limit": 100, "sort_dir": "ASC"}
        attributes_meta = ozon_seller_request("/v3/products/info/attributes", attr_payload)
        attributes_url = "https://api-seller.ozon.ru/v3/products/info/attributes"
    except AppError:
        attributes_meta = {}

    try:
        feedbacks = fetch_ozon_seller_feedbacks(product, 120)
    except AppError as exc:
        feedbacks = {
            "feedbacks": [],
            "feedbackCount": product.get("feedbacks") or 0,
            "feedbackCountWithText": 0,
            "valuation": product.get("reviewRating"),
            "valuationDistribution": None,
            "matchingSizePercentages": {},
            "_warning": f"Отзывы Ozon не загружены: {exc.message}",
        }
    return product, feedbacks, "https://api-seller.ozon.ru/v3/product/info/list", attributes_url


def map_ozon_review(review: dict[str, Any]) -> dict[str, Any]:
    text = as_text(review.get("text") or review.get("review_text") or review.get("comment"))
    pros = as_text(review.get("pros") or review.get("positive") or review.get("advantages"))
    cons = as_text(review.get("cons") or review.get("negative") or review.get("disadvantages"))
    return {
        "id": review.get("id") or review.get("review_id"),
        "createdDate": review.get("published_at") or review.get("created_at") or review.get("date"),
        "productValuation": safe_int(review.get("rating")) or safe_int(review.get("valuation")),
        "pros": pros,
        "cons": cons,
        "text": text,
        "color": "",
        "size": "",
        "matchingSize": "",
        "sku": review.get("sku"),
        "product_id": review.get("product_id"),
    }


def fetch_ozon_seller_feedbacks(product: dict[str, Any], limit: int) -> dict[str, Any]:
    sku = safe_int(product.get("sku"))
    product_id = safe_int(product.get("product_id"))
    collected: list[dict[str, Any]] = []
    offset = 0
    page_limit = min(max(limit, 20), 100)
    while len(collected) < limit and offset < 500:
        payload = {"status": "ALL", "limit": page_limit, "offset": offset}
        data = ozon_seller_request("/v1/review/list", payload)
        raw_reviews = data.get("reviews") or data.get("result", {}).get("reviews") or data.get("items") or []
        if not raw_reviews:
            break
        for raw in raw_reviews:
            if not isinstance(raw, dict):
                continue
            raw_sku = safe_int(raw.get("sku"))
            raw_product_id = safe_int(raw.get("product_id"))
            if sku and raw_sku and raw_sku != sku:
                continue
            if product_id and raw_product_id and raw_product_id != product_id:
                continue
            collected.append(map_ozon_review(raw))
            if len(collected) >= limit:
                break
        if len(raw_reviews) < page_limit:
            break
        offset += page_limit

    distribution = normalize_distribution(None, collected)
    ratings = [safe_int(item.get("productValuation")) for item in collected if safe_int(item.get("productValuation"))]
    average = round(sum(ratings) / len(ratings), 2) if ratings else product.get("reviewRating")
    return {
        "feedbacks": collected,
        "feedbackCount": len(collected) or product.get("feedbacks") or 0,
        "feedbackCountWithText": sum(1 for item in collected if any(as_text(item.get(field)) for field in ("pros", "cons", "text"))),
        "valuation": average,
        "valuationDistribution": distribution,
        "matchingSizePercentages": {},
    }


def fetch_ozon_product_and_feedbacks(article_input: str, limit: int) -> tuple[dict[str, Any], dict[str, Any], str, str | None]:
    if ozon_api_credentials():
        return fetch_ozon_seller_product(article_input)
    try:
        return fetch_ozon_public_product(article_input)
    except AppError as public_error:
        if public_error.status == 403:
            raise public_error
        return fetch_ozon_seller_product(article_input)


def split_sentences(text: str) -> list[str]:
    clean = re.sub(r"\s+", " ", text).strip()
    if not clean:
        return []
    parts = re.split(r"(?<=[.!?…])\s+|[\n\r]+", clean)
    if len(parts) == 1 and len(clean) > 180:
        parts = re.split(r"\s*[;•]\s*|\s+-\s+", clean)
    return [part.strip(" \t.,;:") for part in parts if has_real_text(part)]


def token_list(text: str) -> list[str]:
    words = re.findall(r"[a-zа-яё0-9]+", text.lower().replace("ё", "е"))
    return [word for word in words if len(word) > 2 and word not in STOPWORDS and not word.isdigit()]


def sentiment_from_text(text: str) -> tuple[int, int]:
    lower = normalize_opinion(text)
    positive = sum(1 for pattern in POSITIVE_PATTERNS if pattern in lower)
    negative = sum(1 for pattern in NEGATIVE_PATTERNS if pattern in lower)
    if "не " in lower:
        for pattern in ("подош", "понрав", "работ", "соответств"):
            if f"не {pattern}" in lower:
                negative += 2
    return positive, negative


def classify_sentence(field: str, sentence: str, rating: int | None) -> str:
    positive, negative = sentiment_from_text(sentence)
    normalized = normalize_opinion(sentence)
    if normalized in EMPTY_OPINIONS:
        return "neutral"
    if field == "pros":
        if negative > positive and positive == 0:
            return "negative"
        return "positive"
    if field == "cons":
        if normalized in EMPTY_OPINIONS or normalized.startswith("нет "):
            return "neutral"
        return "negative"
    if negative > positive:
        return "negative"
    if positive > negative:
        return "positive"
    if rating is not None and rating <= 3:
        return "negative"
    if rating is not None and rating >= 4:
        return "positive"
    return "neutral"


def detect_aspects(sentence: str) -> list[str]:
    lower = normalize_opinion(sentence)
    matches = []
    for key, meta in ASPECTS.items():
        if any(keyword in lower for keyword in meta["keywords"]):
            matches.append(key)
    return matches or ["overall"]


def short_text(text: str, max_len: int = 180) -> str:
    clean = re.sub(r"\s+", " ", text).strip()
    if len(clean) <= max_len:
        return clean
    return clean[: max_len - 1].rstrip() + "…"


def feedback_date(feedback: dict[str, Any]) -> str:
    raw = as_text(feedback.get("createdDate") or feedback.get("updatedDate"))
    return raw[:10] if raw else ""


def review_text(feedback: dict[str, Any], preferred: str | None = None) -> str:
    fields = []
    if preferred == "positive":
        fields = [as_text(feedback.get("pros")), as_text(feedback.get("text"))]
    elif preferred == "negative":
        fields = [as_text(feedback.get("cons")), as_text(feedback.get("text"))]
    else:
        fields = [
            as_text(feedback.get("pros")),
            as_text(feedback.get("cons")),
            as_text(feedback.get("text")),
        ]
    return short_text(" ".join(part for part in fields if has_real_text(part)), 220)


def top_terms(sentences: list[str], max_items: int = 10) -> list[dict[str, Any]]:
    counter: Counter[str] = Counter()
    for sentence in sentences:
        words = token_list(sentence)
        counter.update(words)
        for first, second in zip(words, words[1:]):
            if first != second and first not in STOPWORDS and second not in STOPWORDS:
                counter[f"{first} {second}"] += 1

    items = []
    for term, count in counter.most_common(max_items * 3):
        if " " in term and count < 2:
            continue
        items.append({"term": term, "count": count})
        if len(items) >= max_items:
            break
    return items


def normalize_distribution(raw: Any, feedbacks: list[dict[str, Any]]) -> dict[str, int]:
    distribution = {str(star): 0 for star in range(1, 6)}
    if isinstance(raw, dict):
        for key, value in raw.items():
            if str(key) in distribution:
                distribution[str(key)] = int(value or 0)
    elif isinstance(raw, list):
        for item in raw:
            if isinstance(item, dict):
                star = str(item.get("valuation") or item.get("rating") or item.get("star") or "")
                if star in distribution:
                    distribution[star] = int(item.get("count") or item.get("value") or 0)

    if not any(distribution.values()):
        for feedback in feedbacks:
            rating = safe_int(feedback.get("productValuation"))
            if rating and 1 <= rating <= 5:
                distribution[str(rating)] += 1
    return distribution


def summarize_aspect(
    key: str,
    data: dict[str, Any],
    polarity: str,
) -> dict[str, Any]:
    title = "Общее впечатление" if key == "overall" else ASPECTS[key]["title"]
    pos_count = data["positive"]
    neg_count = data["negative"]
    terms = [item["term"] for item in top_terms(data["sentences"], 4)]
    evidence_key = "positive_examples" if polarity == "positive" else "negative_examples"
    evidence = data[evidence_key][:3]

    if polarity == "positive":
        summary = f"{pos_count} положительных упоминаний"
        if neg_count:
            summary += f", есть {neg_count} проблемных"
    else:
        summary = f"{neg_count} проблемных упоминаний"
        if pos_count:
            summary += f", при этом {pos_count} положительных"
    if terms:
        summary += ". Часто встречается: " + ", ".join(terms)
    summary += "."

    return {
        "key": key,
        "title": title,
        "summary": summary,
        "positiveMentions": pos_count,
        "negativeMentions": neg_count,
        "mentions": pos_count if polarity == "positive" else neg_count,
        "balance": pos_count - neg_count,
        "terms": terms,
        "evidence": evidence,
    }


def select_examples(feedbacks: list[dict[str, Any]], polarity: str, limit: int = 4) -> list[dict[str, Any]]:
    examples = []
    for feedback in feedbacks:
        rating = safe_int(feedback.get("productValuation"))
        text = review_text(feedback, polarity)
        if not text:
            continue
        if polarity == "positive" and rating is not None and rating < 4:
            continue
        if polarity == "negative" and rating is not None and rating > 3 and not has_real_text(as_text(feedback.get("cons"))):
            continue
        examples.append(
            {
                "rating": rating,
                "date": feedback_date(feedback),
                "text": text,
                "color": as_text(feedback.get("color")),
                "size": as_text(feedback.get("size")),
            }
        )
        if len(examples) >= limit:
            break
    return examples


def build_verdict(
    avg_rating: float | None,
    distribution: dict[str, int],
    text_count: int,
    weak_count: int,
) -> str:
    total = sum(distribution.values())
    positive = distribution["4"] + distribution["5"]
    negative = distribution["1"] + distribution["2"] + distribution["3"]
    positive_pct = round(positive * 100 / total) if total else 0
    negative_pct = round(negative * 100 / total) if total else 0

    if text_count == 0:
        return "У товара пока нет доступных текстовых отзывов, поэтому выводы ограничены рейтингом."
    if avg_rating and avg_rating >= 4.6 and negative_pct <= 15:
        return f"Покупатели в целом довольны: {positive_pct}% оценок на 4-5 звёзд, явных проблем немного."
    if weak_count >= 3 or negative_pct >= 30:
        return f"Отзывы смешанные: {negative_pct}% оценок на 1-3 звезды, слабые места стоит проверить перед закупкой."
    return f"Картина скорее положительная: {positive_pct}% оценок на 4-5 звёзд, но в отзывах есть повторяющиеся замечания."


def recommendation_priority(mentions: int, negative_pct: int | None) -> str:
    if mentions >= 4 or (negative_pct is not None and negative_pct >= 25):
        return "high"
    if mentions >= 2 or (negative_pct is not None and negative_pct >= 12):
        return "medium"
    return "low"


def priority_label(priority: str) -> str:
    return {
        "critical": "Критично",
        "high": "Высокий",
        "medium": "Средний",
        "low": "Низкий",
    }.get(priority, "Средний")


def clamp_photo_value(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def photo_recommendation(priority: str, title: str, action: str, reason: str) -> dict[str, Any]:
    return {
        "priority": priority,
        "priorityLabel": priority_label(priority),
        "title": title,
        "action": action,
        "reason": reason,
    }


def photo_score_label(score: float | int | None) -> str:
    if score is None:
        return "Нет оценки"
    if score >= 82:
        return "Сильное первое фото"
    if score >= 66:
        return "Хорошая база"
    if score >= 50:
        return "Нужно усилить"
    return "Слабое первое фото"


def photo_metric_payload(label: str, value: float | int | None, unit: str, verdict: str) -> dict[str, Any]:
    return {
        "label": label,
        "value": None if value is None else round(float(value), 1),
        "unit": unit,
        "verdict": verdict,
    }


def photo_criterion_status(score: float | int | None) -> str:
    if score is None:
        return "нет оценки"
    if score >= 82:
        return "сильно"
    if score >= 66:
        return "норма"
    if score >= 50:
        return "усилить"
    return "критично"


def photo_criterion_payload(
    key: str,
    label: str,
    score: float | int | None,
    summary: str,
    action: str,
    evidence: list[str] | None = None,
) -> dict[str, Any]:
    clean_score = None if score is None else round(clamp_photo_value(float(score)))
    return {
        "key": key,
        "label": label,
        "score": clean_score,
        "status": photo_criterion_status(clean_score),
        "summary": summary,
        "action": action,
        "evidence": [item for item in (evidence or []) if item][:3],
    }


def short_photo_meaning(product: dict[str, Any] | None, fallback_title: str) -> str:
    product = product or {}
    source = as_text(product.get("entity") or product.get("subjectName") or product.get("name") or fallback_title)
    words = re.split(r"\s+", source.strip())
    return " ".join(words[:7]) or "товар и его главная выгода"


def analyze_first_photo(
    article: int,
    product: dict[str, Any] | None = None,
    strengths: list[dict[str, Any]] | None = None,
    weaknesses: list[dict[str, Any]] | None = None,
    image_number: int = 1,
    image_url_override: str | None = None,
    source_url_override: str | None = None,
    image_fetcher: Any | None = None,
    marketplace_label: str = "WB",
) -> dict[str, Any]:
    image_url = image_url_override or product_image_url(article, image_number)
    fallback_source_url = source_url_override or wb_product_image_url(article, image_number)
    title = as_text((product or {}).get("name")) or f"Артикул {article}"

    try:
        from PIL import Image, ImageFilter
    except ImportError as exc:
        return {
            "ok": False,
            "status": "library_missing",
            "imageUrl": image_url,
            "sourceUrl": fallback_source_url,
            "summary": "Серверу нужна библиотека Pillow, чтобы анализировать первое фото.",
            "recommendations": [
                photo_recommendation(
                    "medium",
                    "Проверить сборку сервиса",
                    "Добавить Pillow в зависимости и заново развернуть сервис на Render.",
                    str(exc),
                )
            ],
        }

    try:
        if image_fetcher:
            body, content_type, source_url = image_fetcher()
        else:
            body, content_type, source_url = fetch_product_image(article, image_number, timeout=6)
        with Image.open(BytesIO(body)) as original_image:
            original_image.load()
            width, height = original_image.size
            rgb = original_image.convert("RGB")

        sample = rgb.copy()
        sample.thumbnail((360, 360))
        sample_width, sample_height = sample.size
        pixels = list(sample.getdata())
        pixel_count = max(len(pixels), 1)

        luminance_values: list[float] = []
        saturation_values: list[float] = []
        light_background_pixels = 0
        dark_pixels = 0

        for red, green, blue in pixels:
            luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue
            max_channel = max(red, green, blue)
            min_channel = min(red, green, blue)
            saturation = 0.0 if max_channel == 0 else (max_channel - min_channel) * 100 / max_channel
            luminance_values.append(luminance)
            saturation_values.append(saturation)
            if luminance >= 235 and saturation <= 18:
                light_background_pixels += 1
            if luminance <= 48:
                dark_pixels += 1

        brightness = sum(luminance_values) * 100 / (pixel_count * 255)
        average_luminance = sum(luminance_values) / pixel_count
        luminance_std = (sum((value - average_luminance) ** 2 for value in luminance_values) / pixel_count) ** 0.5
        contrast = clamp_photo_value(luminance_std * 100 / 64)
        saturation = sum(saturation_values) / pixel_count
        light_background_share = light_background_pixels * 100 / pixel_count
        dark_share = dark_pixels * 100 / pixel_count

        corner_width = max(1, sample_width // 8)
        corner_height = max(1, sample_height // 8)
        corner_pixels: list[tuple[int, int, int]] = []
        for y in range(sample_height):
            y_is_corner = y < corner_height or y >= sample_height - corner_height
            if not y_is_corner:
                continue
            row_offset = y * sample_width
            for x in range(sample_width):
                if x < corner_width or x >= sample_width - corner_width:
                    corner_pixels.append(pixels[row_offset + x])
        if corner_pixels:
            background_color = tuple(
                sum(pixel[channel] for pixel in corner_pixels) / len(corner_pixels)
                for channel in range(3)
            )
        else:
            background_color = (255.0, 255.0, 255.0)

        subject_pixels = 0
        foreground_mask: list[bool] = []
        for red, green, blue in pixels:
            color_distance = (
                (red - background_color[0]) ** 2
                + (green - background_color[1]) ** 2
                + (blue - background_color[2]) ** 2
            ) ** 0.5
            is_foreground = color_distance >= 38
            foreground_mask.append(is_foreground)
            if is_foreground:
                subject_pixels += 1
        subject_share = subject_pixels * 100 / pixel_count

        gray = sample.convert("L")
        edge_image = gray.filter(ImageFilter.FIND_EDGES)
        edge_values = list(edge_image.getdata())
        edge_mean = (sum(edge_values) / max(len(edge_values), 1)) * 100 / 255
        detail_score = clamp_photo_value(edge_mean * 7.5)
        aspect_ratio = width / height if height else 0
        megapixels = width * height / 1_000_000

        brightness_score = clamp_photo_value(100 - abs(brightness - 68) * 2.1)
        saturation_score = clamp_photo_value(100 - abs(saturation - 24) * 1.7)
        if subject_share < 34:
            subject_score = clamp_photo_value(42 + subject_share * 1.35)
        elif subject_share > 78:
            subject_score = clamp_photo_value(100 - (subject_share - 78) * 2.2)
        else:
            subject_score = 100.0
        background_score = 90.0 if light_background_share >= 45 else 76.0 if light_background_share >= 25 else 62.0
        ratio_score = 100.0 if 0.68 <= aspect_ratio <= 0.84 else 78.0 if 0.84 < aspect_ratio <= 1.05 else 64.0
        active_count = max(sum(1 for active in foreground_mask if active), 1)
        x_sum = 0
        y_sum = 0
        for index, active in enumerate(foreground_mask):
            if not active:
                continue
            y, x = divmod(index, sample_width)
            x_sum += x
            y_sum += y
        subject_center_x = (x_sum / active_count) / max(sample_width - 1, 1)
        subject_center_y = (y_sum / active_count) / max(sample_height - 1, 1)
        center_offset = ((subject_center_x - 0.5) ** 2 + (subject_center_y - 0.5) ** 2) ** 0.5 * 100
        center_score = clamp_photo_value(100 - center_offset * 2.6)

        def zone_edge_score(x1: float, y1: float, x2: float, y2: float) -> float:
            left = max(0, min(sample_width - 1, int(sample_width * x1)))
            top = max(0, min(sample_height - 1, int(sample_height * y1)))
            right = max(left + 1, min(sample_width, int(sample_width * x2)))
            bottom = max(top + 1, min(sample_height, int(sample_height * y2)))
            total = 0
            edge_total = 0
            for y in range(top, bottom):
                offset = y * sample_width
                for x in range(left, right):
                    total += 1
                    edge_total += edge_values[offset + x]
            return clamp_photo_value((edge_total / max(total, 1)) * 100 / 255 * 7.5)

        top_left_activity = zone_edge_score(0.0, 0.0, 0.25, 0.18)
        top_right_activity = zone_edge_score(0.75, 0.0, 1.0, 0.18)
        bottom_activity = zone_edge_score(0.0, 0.78, 1.0, 1.0)
        marketplace_zone_activity = max(top_left_activity, top_right_activity, bottom_activity)
        visual_load = clamp_photo_value(
            subject_share * 0.32 + detail_score * 0.38 + saturation * 0.42 + max(contrast - 45, 0) * 0.15
        )
        offer_overload_score = clamp_photo_value(
            100 - max(0, visual_load - 64) * 2.3 - max(0, 24 - visual_load) * 1.2
        )
        mobile_text_score = clamp_photo_value(
            0.34 * contrast + 0.28 * brightness_score + 0.22 * background_score + 0.16 * offer_overload_score
        )
        composition_score = clamp_photo_value(
            0.30 * center_score + 0.25 * contrast + 0.20 * saturation_score + 0.15 * background_score + 0.10 * subject_score
        )
        standout_score = clamp_photo_value(0.35 * contrast + 0.25 * saturation_score + 0.20 * detail_score + 0.20 * subject_score)
        safe_zone_score = clamp_photo_value(100 - max(0, marketplace_zone_activity - 30) * 2.0)
        base_visual_score = round(
            0.24 * subject_score
            + 0.20 * contrast
            + 0.16 * brightness_score
            + 0.14 * saturation_score
            + 0.14 * detail_score
            + 0.07 * background_score
            + 0.05 * ratio_score
        )

        metrics = {
            "brightnessPercent": round(brightness, 1),
            "contrastScore": round(contrast, 1),
            "saturationPercent": round(saturation, 1),
            "productSharePercent": round(subject_share, 1),
            "lightBackgroundPercent": round(light_background_share, 1),
            "darkPercent": round(dark_share, 1),
            "detailScore": round(detail_score, 1),
            "aspectRatio": round(aspect_ratio, 3),
            "width": width,
            "height": height,
            "megapixels": round(megapixels, 2),
            "fileSizeKb": round(len(body) / 1024, 1),
            "baseVisualScore": base_visual_score,
            "visualLoadPercent": round(visual_load, 1),
            "marketplaceZoneActivityPercent": round(marketplace_zone_activity, 1),
            "centerOffsetPercent": round(center_offset, 1),
        }

        strengths_found: list[str] = []
        risks: list[str] = []
        recommendations: list[dict[str, Any]] = []
        designer_brief: list[str] = []
        best_strength = next((item.get("title") for item in strengths or [] if item.get("title")), "")
        main_weakness = next((item.get("title") for item in weaknesses or [] if item.get("title")), "")
        one_second_meaning = short_photo_meaning(product, title)
        primary_offer = best_strength or main_weakness or one_second_meaning
        needs_action = (
            f"Закрыть главное возражение покупателей: «{main_weakness}»."
            if main_weakness
            else f"Усилить на первом экране доказанную сильную сторону: «{best_strength}»."
            if best_strength
            else "Добавить на первый экран одну конкретную выгоду, а не общий рекламный лозунг."
        )
        needs_score = 82 if best_strength and main_weakness else 74 if (best_strength or main_weakness) else 58
        meaning_score = clamp_photo_value(0.62 * subject_score + 0.23 * contrast + 0.15 * detail_score)

        criteria = [
            photo_criterion_payload(
                "one_second_meaning",
                "Смысл за 1 секунду",
                meaning_score,
                f"Должно мгновенно считываться: «{one_second_meaning}».",
                f"Собрать обложку вокруг одной мысли: товар + выгода «{primary_offer}».",
                [
                    f"Товар в кадре: {round(subject_share)}%.",
                    f"Контраст: {round(contrast)}/100.",
                ],
            ),
            photo_criterion_payload(
                "product_scale",
                "Товар крупно и понятно",
                subject_score,
                "Оцениваем, насколько главный объект заметен в миниатюре и не зажат краями.",
                "Перекадрировать так, чтобы товар был главным объектом, а ключевая деталь читалась без приближения.",
                [f"Оценочная доля товара/объекта в кадре: {round(subject_share)}%."],
            ),
            photo_criterion_payload(
                "offers_load",
                "Офферы и перегруз",
                offer_overload_score,
                "На обложке должна быть одна главная выгода; перегруз текстом и акцентами снижает скорость выбора.",
                "Оставить один оффер на первом фото, второстепенные преимущества перенести на 2-3 слайд.",
                [f"Индекс визуальной загруженности: {round(visual_load)}%."],
            ),
            photo_criterion_payload(
                "mobile_readability",
                "Текст читается с телефона",
                mobile_text_score,
                "Если на обложке есть текст, он должен читаться в маленькой карточке выдачи.",
                "Проверить макет в размере 120-160 px: максимум 3-5 слов крупным кеглем, высокий контраст с фоном.",
                [
                    f"Контраст: {round(contrast)}/100.",
                    f"Перегруз: {round(visual_load)}%.",
                ],
            ),
            photo_criterion_payload(
                "composition_hierarchy",
                "Композиция и иерархия",
                composition_score,
                "Проверяем центр композиции, контраст, цветовую гамму и понятный главный акцент.",
                "Выстроить иерархию: сначала товар, затем короткая выгода, затем доказательство/деталь.",
                [
                    f"Смещение главного объекта от центра: {round(center_offset)}%.",
                    f"Цветовой акцент: {round(saturation)}%.",
                ],
            ),
            photo_criterion_payload(
                "competitive_standout",
                "Выделение среди конкурентов",
                standout_score,
                "Фото должно отличаться в выдаче за счет чистого силуэта, контраста, цвета или понятного результата.",
                "Добавить управляемый отличительный элемент: фирменный цвет, результат применения или сильную выгоду без шума.",
                [
                    f"Контраст: {round(contrast)}/100.",
                    f"Детальность: {round(detail_score)}/100.",
                ],
            ),
            photo_criterion_payload(
                "needs_objections",
                "Потребности и возражения",
                needs_score,
                "Обложка должна отвечать на главный мотив покупки и заранее снижать самое частое сомнение.",
                needs_action,
                [item for item in [f"Сила из отзывов: {best_strength}" if best_strength else "", f"Возражение: {main_weakness}" if main_weakness else ""] if item],
            ),
            photo_criterion_payload(
                "marketplace_safe_zones",
                f"Зоны плашек {marketplace_label}",
                safe_zone_score,
                f"Важный текст, лицо товара и ключевые детали не должны попадать в зоны бейджей, скидок и нижних плашек {marketplace_label}.",
                f"Освободить верхние углы и нижние 20-22% кадра от важного текста и ключевых деталей товара под плашки {marketplace_label}.",
                [
                    f"Активность в риск-зонах: {round(marketplace_zone_activity)}%.",
                    f"Верх слева: {round(top_left_activity)}%, верх справа: {round(top_right_activity)}%, низ: {round(bottom_activity)}%.",
                ],
            ),
        ]
        weighted_criteria = {
            "one_second_meaning": 0.17,
            "product_scale": 0.16,
            "offers_load": 0.12,
            "mobile_readability": 0.12,
            "composition_hierarchy": 0.16,
            "competitive_standout": 0.12,
            "needs_objections": 0.10,
            "marketplace_safe_zones": 0.05,
        }
        score = round(
            sum((item.get("score") or 0) * weighted_criteria.get(item.get("key"), 0.1) for item in criteria)
            / max(sum(weighted_criteria.values()), 1)
        )
        low_criteria = [item for item in criteria if (item.get("score") or 0) < 58]
        for item in low_criteria[:2]:
            recommendations.append(
                photo_recommendation(
                    "high" if (item.get("score") or 0) < 50 else "medium",
                    f"Усилить критерий: {item.get('label')}",
                    item.get("action") or "Переделать первый экран по этому критерию.",
                    item.get("summary") or "",
                )
            )
        designer_brief.append(f"Главный смысл первого фото: «{one_second_meaning}» + одна выгода «{primary_offer}».")

        if 48 <= brightness <= 82:
            strengths_found.append("Фото достаточно светлое: товар легче воспринимается в выдаче.")
        if contrast >= 52:
            strengths_found.append("Контраст выше среднего: контуры товара и элементы должны считываться увереннее.")
        if 34 <= subject_share <= 78:
            strengths_found.append("Товар занимает заметную часть кадра, но у изображения остаётся визуальный воздух.")
        if light_background_share >= 45:
            strengths_found.append("Светлый фон подходит для маркетплейса и не спорит с товаром.")

        if subject_share < 34:
            risks.append("Товар выглядит мелко: в поисковой выдаче его будет сложнее быстро распознать.")
            recommendations.append(
                photo_recommendation(
                    "high",
                    "Укрупнить товар в кадре",
                    "Перекадрировать первое фото так, чтобы товар занимал больше площади, а ключевая деталь была видна без приближения.",
                    f"Сейчас товар занимает примерно {round(subject_share)}% изображения.",
                )
            )
            designer_brief.append(f"Сделать товар крупнее: главный объект должен читаться в миниатюре {marketplace_label} без увеличения.")
        elif subject_share > 78:
            risks.append("Кадр может быть перегружен: товару и текстовым выгодам может не хватать свободного пространства.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Добавить воздуха вокруг товара",
                    "Чуть отдалить объект или переразложить композицию, чтобы оставить место под 1 сильную выгоду и не зажимать края.",
                    f"Оценочная заполненность кадра: {round(subject_share)}%.",
                )
            )

        if contrast < 45:
            risks.append("Низкий контраст: товар, тени или текстовые элементы могут сливаться с фоном.")
            recommendations.append(
                photo_recommendation(
                    "high",
                    "Усилить контраст и границы",
                    "Добавить мягкую тень, локальное затемнение/осветление и проверить читаемость на маленькой превью-карточке.",
                    f"Контраст первого фото: {round(contrast)}/100.",
                )
            )
            designer_brief.append("Проверить превью 120-160 px: товар и главная выгода должны читаться сразу.")

        if brightness < 46:
            risks.append("Фото темновато: товар может выглядеть дешевле и терять детали.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Осветлить первое фото",
                    "Поднять экспозицию и фон, но сохранить объём товара через тени и контур.",
                    f"Яркость первого фото: {round(brightness)}%.",
                )
            )
        elif brightness > 86:
            risks.append("Фото слишком светлое: светлые детали товара могут пропадать на фоне.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Вернуть объём светлым зонам",
                    "Снизить пересвет, добавить аккуратную тень или контур, чтобы края товара не растворялись.",
                    f"Яркость первого фото: {round(brightness)}%.",
                )
            )

        if saturation < 10:
            risks.append("Мало цветового акцента: карточка может теряться рядом с более выразительными конкурентами.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Добавить фирменный акцент",
                    "Использовать 1-2 цвета бренда для плашки, стрелки или короткой выгоды, не перекрывая сам товар.",
                    f"Средняя насыщенность: {round(saturation)}%.",
                )
            )
        elif saturation > 48:
            risks.append("Цвета очень насыщенные: есть риск ощущения дешёвой или перегруженной инфографики.")
            recommendations.append(
                photo_recommendation(
                    "low",
                    "Упростить цветовые акценты",
                    "Оставить один главный акцентный цвет и убрать второстепенный визуальный шум.",
                    f"Средняя насыщенность: {round(saturation)}%.",
                )
            )

        if detail_score < 26:
            risks.append("Мало визуальных деталей: покупателю может быть трудно понять материал, фактуру или комплектацию.")
            recommendations.append(
                photo_recommendation(
                    "medium",
                    "Показать важную деталь крупнее",
                    "Добавить рядом увеличенный фрагмент, фактуру, комплектацию или главный элемент, который влияет на выбор.",
                    f"Детальность первого фото: {round(detail_score)}/100.",
                )
            )

        if not (0.68 <= aspect_ratio <= 0.84):
            recommendations.append(
                photo_recommendation(
                    "low",
                    "Проверить вертикальное кадрирование",
                    "Подготовить первый слайд под витринный вертикальный формат: товар по центру, без обрезанных краёв.",
                    f"Текущее соотношение сторон: {width}×{height}.",
                )
            )

        best_strength = next((item.get("title") for item in strengths or [] if item.get("title")), "")
        main_weakness = next((item.get("title") for item in weaknesses or [] if item.get("title")), "")
        if best_strength:
            designer_brief.append(f"Вынести на первый экран выгоду по сильной стороне из отзывов: «{best_strength}».")
        if main_weakness:
            designer_brief.append(f"Закрыть возражение в первом или втором слайде: «{main_weakness}».")
        designer_brief.append("Собрать первый экран по схеме: товар крупно + одна главная выгода + короткое доказательство.")

        if not strengths_found:
            strengths_found.append("Фото загружено и пригодно для базового визуального аудита.")
        if not recommendations:
            recommendations.append(
                photo_recommendation(
                    "low",
                    "Закрепить сильный первый экран",
                    "Оставить текущую базовую композицию, но протестировать вариант с одной короткой выгодой на первом фото.",
                    "По базовым метрикам критичных визуальных проблем не найдено.",
                )
            )

        summary = (
            f"{photo_score_label(score)}: визуальная оценка {score}/100. "
            f"Для товара «{title}» главный резерв — {recommendations[0]['title'].lower()}."
        )

        return {
            "ok": True,
            "status": "analyzed",
            "imageNumber": image_number,
            "imageUrl": image_url,
            "sourceUrl": source_url,
            "contentType": content_type,
            "score": score,
            "scoreLabel": photo_score_label(score),
            "summary": summary,
            "metrics": metrics,
            "metricCards": [
                photo_metric_payload("Яркость", brightness, "%", "норма" if 48 <= brightness <= 82 else "проверить"),
                photo_metric_payload("Контраст", contrast, "/100", "норма" if contrast >= 52 else "усилить"),
                photo_metric_payload("Цветовой акцент", saturation, "%", "норма" if 10 <= saturation <= 48 else "проверить"),
                photo_metric_payload("Товар в кадре", subject_share, "%", "норма" if 34 <= subject_share <= 78 else "перекадрировать"),
                photo_metric_payload("Светлый фон", light_background_share, "%", "норма" if light_background_share >= 45 else "проверить"),
                photo_metric_payload("Детальность", detail_score, "/100", "норма" if detail_score >= 26 else "усилить"),
                photo_metric_payload("Перегруз", visual_load, "%", "норма" if 24 <= visual_load <= 64 else "проверить"),
                photo_metric_payload(f"Зоны {marketplace_label}", marketplace_zone_activity, "%", "чисто" if marketplace_zone_activity < 18 else "проверить"),
            ],
            "criteria": criteria,
            "strengths": strengths_found[:4],
            "risks": risks[:5],
            "recommendations": recommendations[:5],
            "designerBrief": designer_brief[:5],
        }
    except AppError as exc:
        return {
            "ok": False,
            "status": "image_unavailable",
            "imageUrl": image_url,
            "sourceUrl": fallback_source_url,
            "summary": "Не удалось загрузить первое фото товара для визуального анализа.",
            "error": exc.message,
            "recommendations": [
                photo_recommendation(
                    "medium",
                    "Проверить первое фото карточки",
                    f"Открыть товар на {marketplace_label} и убедиться, что первое изображение загружается и не скрыто ограничениями площадки.",
                    exc.message,
                )
            ],
        }
    except Exception as exc:
        return {
            "ok": False,
            "status": "analysis_error",
            "imageUrl": image_url,
            "sourceUrl": fallback_source_url,
            "summary": "Первое фото найдено, но визуальный анализ временно не выполнен.",
            "error": str(exc),
            "recommendations": [
                photo_recommendation(
                    "low",
                    "Повторить анализ позже",
                    "Если фото в карточке открывается, повторите анализ после обновления сервиса или уменьшите нагрузку.",
                    str(exc),
                )
            ],
        }


def recommendation_reason(aspect: dict[str, Any], negative_pct: int | None) -> str:
    mentions = aspect.get("negativeMentions") or aspect.get("mentions") or 0
    title = aspect.get("title") or "Общее впечатление"
    terms = aspect.get("terms") or []
    reason = f"В теме «{title}» найдено {mentions} проблемных упоминаний."
    if terms:
        reason += " Частые слова: " + ", ".join(terms[:4]) + "."
    if negative_pct is not None and negative_pct >= 12:
        reason += f" Доля оценок 1-3★: {negative_pct}%."
    return reason


def make_recommendation(area: str, aspect: dict[str, Any], negative_pct: int | None) -> dict[str, Any]:
    key = aspect.get("key") or "overall"
    template = RECOMMENDATION_TEMPLATES.get(key, RECOMMENDATION_TEMPLATES["overall"])
    priority = recommendation_priority(int(aspect.get("negativeMentions") or aspect.get("mentions") or 0), negative_pct)
    title_key = "content_title" if area == "content" else "product_title"
    action_key = "content_action" if area == "content" else "product_action"

    return {
        "id": f"{area}-{key}",
        "area": area,
        "aspect": aspect.get("title") or "Общее впечатление",
        "priority": priority,
        "priorityLabel": priority_label(priority),
        "title": template[title_key],
        "action": template[action_key],
        "reason": recommendation_reason(aspect, negative_pct),
        "evidence": (aspect.get("evidence") or [])[:2],
    }


def make_strength_recommendation(strength: dict[str, Any]) -> dict[str, Any]:
    key = strength.get("key") or "overall"
    aspect_title = strength.get("title") or "сильную сторону"
    terms = strength.get("terms") or []
    reason = f"Эту тему уже хвалят: {strength.get('positiveMentions') or strength.get('mentions') or 0} положительных упоминаний."
    if terms:
        reason += " Формулировки покупателей: " + ", ".join(terms[:4]) + "."

    return {
        "id": f"content-amplify-{key}",
        "area": "content",
        "aspect": aspect_title,
        "priority": "medium",
        "priorityLabel": priority_label("medium"),
        "title": "Усилить то, что уже продаёт",
        "action": (
            f"Вынесите «{aspect_title.lower()}» в главное фото, инфографику или первые строки описания; "
            "используйте реальные слова покупателей и подкрепите их фото/видео доказательством."
        ),
        "reason": reason,
        "evidence": (strength.get("evidence") or [])[:2],
    }


def add_unique_recommendation(items: list[dict[str, Any]], item: dict[str, Any], limit: int) -> None:
    if len(items) >= limit:
        return
    if any(existing["id"] == item["id"] for existing in items):
        return
    items.append(item)


def option_value_text(option: dict[str, Any]) -> str:
    values = option.get("variable_values")
    if isinstance(values, list) and values:
        return "; ".join(as_text(value) for value in values if as_text(value))
    value = option.get("value")
    if isinstance(value, list):
        return "; ".join(as_text(item) for item in value if as_text(item))
    return as_text(value)


def card_option_items(card_meta: dict[str, Any]) -> list[dict[str, str]]:
    items: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()

    def add_option(option: dict[str, Any], source: str) -> None:
        name = as_text(option.get("name"))
        value = option_value_text(option)
        if not name or not value:
            return
        key = (name.lower(), value.lower())
        if key in seen:
            return
        seen.add(key)
        items.append({"name": name, "value": value, "source": source})

    for group in card_meta.get("grouped_options") or []:
        if not isinstance(group, dict):
            continue
        source = as_text(group.get("group_name")) or "Характеристики карточки"
        for option in group.get("options") or []:
            if isinstance(option, dict):
                add_option(option, source)

    for option in card_meta.get("options") or []:
        if isinstance(option, dict):
            add_option(option, "Характеристики карточки")

    return items


def product_characteristic_items(product: dict[str, Any], card_meta: dict[str, Any]) -> list[dict[str, str]]:
    items = card_option_items(card_meta)
    seen = {(item["name"].lower(), item["value"].lower()) for item in items}

    def add(name: str, value: str, source: str) -> None:
        value = short_text(value, 120)
        if not name or not value:
            return
        key = (name.lower(), value.lower())
        if key in seen:
            return
        seen.add(key)
        items.append({"name": name, "value": value, "source": source})

    colors = product.get("colors")
    if isinstance(colors, list):
        color_names = [as_text(item.get("name")) for item in colors if isinstance(item, dict) and as_text(item.get("name"))]
        if color_names:
            add("Цвет", "; ".join(color_names[:4]), "Карточка товара")

    sizes = product.get("sizes")
    if isinstance(sizes, list):
        size_names = []
        for item in sizes[:8]:
            if not isinstance(item, dict):
                continue
            size = as_text(item.get("origName") or item.get("name"))
            if size and size not in size_names:
                size_names.append(size)
        if size_names:
            add("Размерный ряд", "; ".join(size_names), "Карточка товара")

    volume = safe_float(product.get("volume"))
    if volume:
        add("Объем упаковки", f"{volume:g}", "Карточка товара")
    weight = safe_float(product.get("weight"))
    if weight:
        add("Вес", f"{weight:g}", "Карточка товара")

    description = as_text(card_meta.get("description"))
    if description and len(items) < 4:
        for sentence in split_sentences(description):
            if len(sentence) < 28:
                continue
            add("Описание", sentence, "Описание карточки")
            if len(items) >= 5:
                break

    return items


def hpv_related_key(name: str, value: str) -> str:
    text = normalize_opinion(f"{name} {value}")
    if any(word in text for word in ("состав", "материал", "ткан", "хлоп", "шерст", "полиэстер", "эластан", "кожа")):
        return "quality"
    if any(word in text for word in ("размер", "рост", "длина", "ширина", "посад", "обхват")):
        return "fit"
    if any(word in text for word in ("цвет", "оттен", "принт", "рисунок", "дизайн")):
        return "appearance"
    if any(word in text for word in ("назнач", "сезон", "повсед", "спорт", "дом", "школ", "работ")):
        return "comfort"
    if any(word in text for word in ("комплект", "набор", "штук", "пара", "колич")):
        return "completeness"
    if any(word in text for word in ("вес", "объем", "размер упаков", "габарит")):
        return "packaging"
    if any(word in text for word in ("уход", "стир", "мыть", "чист")):
        return "quality"
    return "overall"


def hpv_copy(name: str, value: str, product_title: str, category: str, key: str) -> dict[str, str]:
    subject = category or product_title or "товар"
    characteristic = f"{name}: {value}"
    if key == "quality":
        return {
            "advantage": "Покупатель видит не сухой состав, а причину доверять качеству, фактуре и сроку службы.",
            "benefit": f"{subject}: материал и исполнение подобраны так, чтобы товар был приятен в использовании и выглядел аккуратно после покупки.",
            "cardText": f"Заменить сухое «{characteristic}» на выгоду: «Комфортный материал для ежедневного использования: приятен к телу, держит форму и не выглядит дешево».",
            "infographicText": "Слайд: «Материал = комфорт каждый день» + крупный план фактуры/шва/детали.",
        }
    if key == "fit":
        return {
            "advantage": "Размерная информация снижает риск ошибки и возврата.",
            "benefit": "Покупатель быстрее понимает, подойдет ли товар именно ему, и увереннее добавляет его в корзину.",
            "cardText": f"Заменить «{characteristic}» на: «Легко выбрать размер: ориентируйтесь на фактические параметры и посадку, чтобы не заказывать наугад».",
            "infographicText": "Слайд: «Как выбрать размер» + схема замеров, посадка, подсказка маломерит/в размер/большемерит.",
        }
    if key == "appearance":
        return {
            "advantage": "Визуальная характеристика превращается в обещание понятного внешнего вида без сюрпризов.",
            "benefit": "Покупатель заранее понимает оттенок, стиль и сочетание товара с другими вещами.",
            "cardText": f"Заменить «{characteristic}» на: «Цвет и внешний вид легко сочетать в базовых образах; оттенок показан на фото без лишней обработки».",
            "infographicText": "Слайд: «Реальный цвет» + фото при дневном свете и крупный план детали.",
        }
    if key == "comfort":
        return {
            "advantage": "Назначение объясняет сценарий использования, а не просто перечисляет категорию.",
            "benefit": f"Покупатель понимает, когда и зачем брать этот {subject.lower()}, и быстрее соотносит товар со своей задачей.",
            "cardText": f"Заменить «{characteristic}» на: «Подходит для конкретного сценария: каждый день, дорога, дом, работа или подарок — без лишних сомнений при выборе».",
            "infographicText": "Слайд: «Когда использовать» + 3 сценария применения и понятные пиктограммы.",
        }
    if key == "completeness":
        return {
            "advantage": "Комплектация показывает экономию, удобство и отсутствие сюрпризов при получении.",
            "benefit": "Покупатель сразу понимает, что входит в заказ и почему набор выгоднее одиночной покупки.",
            "cardText": f"Заменить «{characteristic}» на: «Все нужное сразу в одном заказе: понятная комплектация, удобно для себя, семьи или запаса».",
            "infographicText": "Слайд: «Что входит в набор» + разложить комплект по элементам/количеству.",
        }
    if key == "packaging":
        return {
            "advantage": "Габариты и упаковка становятся аргументом про доставку, хранение и получение товара без повреждений.",
            "benefit": "Покупатель понимает, как товар придет, сколько места займет и что защищено при доставке.",
            "cardText": f"Заменить «{characteristic}» на: «Удобно получить и хранить: упаковка защищает товар и не занимает лишнее место».",
            "infographicText": "Слайд: «Получаете аккуратно упакованный товар» + фото упаковки и состава заказа.",
        }
    return {
        "advantage": "Характеристика становится понятным аргументом выбора.",
        "benefit": "Покупатель видит не параметр ради параметра, а личную пользу: проще выбрать, меньше сомнений, понятнее ожидания.",
        "cardText": f"Заменить «{characteristic}» на: «Эта характеристика дает понятную пользу при использовании: товар проще выбрать и легче оценить до покупки».",
        "infographicText": "Слайд: «Почему это важно» + параметр, простая выгода и визуальное доказательство.",
    }


def hpv_reason(key: str, strengths: list[dict[str, Any]], weaknesses: list[dict[str, Any]]) -> str:
    weak = next((item for item in weaknesses if item.get("key") == key), None)
    strong = next((item for item in strengths if item.get("key") == key), None)
    if weak:
        terms = weak.get("terms") or []
        reason = f"В отзывах есть риск по теме «{weak.get('title')}»: {weak.get('negativeMentions') or weak.get('mentions')} проблемных упоминаний."
        if terms:
            reason += " Частые слова: " + ", ".join(terms[:3]) + "."
        return reason
    if strong:
        terms = strong.get("terms") or []
        reason = f"Эту тему уже хвалят: {strong.get('positiveMentions') or strong.get('mentions')} положительных упоминаний."
        if terms:
            reason += " Можно использовать слова покупателей: " + ", ".join(terms[:3]) + "."
        return reason
    return "В карточке есть характеристика, но ее лучше раскрыть как выгоду в первом экране и инфографике."


def build_hpv_recommendations(
    product: dict[str, Any],
    card_meta: dict[str, Any] | None,
    strengths: list[dict[str, Any]],
    weaknesses: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    card_meta = card_meta or {}
    product_title = as_text(card_meta.get("imt_name") or product.get("name"))
    category = as_text(card_meta.get("subj_name") or product.get("entity"))
    source_items = product_characteristic_items(product, card_meta)

    if not source_items:
        source_items = [
            {
                "name": "Сильная сторона из отзывов",
                "value": strengths[0].get("title") if strengths else product_title or "товар",
                "source": "Отзывы покупателей",
            }
        ]

    priority_order = {
        "quality": 0,
        "fit": 1,
        "comfort": 2,
        "appearance": 3,
        "completeness": 4,
        "packaging": 5,
        "overall": 6,
    }
    prepared = []
    for item in source_items:
        key = hpv_related_key(item["name"], item["value"])
        prepared.append((priority_order.get(key, 6), key, item))
    prepared.sort(key=lambda item: (item[0], len(item[2]["value"])))

    rows = []
    seen_keys: set[str] = set()
    for _, key, item in prepared:
        identity = f"{item['name'].lower()}:{item['value'].lower()}"
        if identity in seen_keys:
            continue
        seen_keys.add(identity)
        copy = hpv_copy(item["name"], item["value"], product_title, category, key)
        priority = "high" if any(weak.get("key") == key for weak in weaknesses) else "medium"
        if key == "overall":
            priority = "low"
        rows.append(
            {
                "id": f"hpv-{len(rows) + 1}-{key}",
                "priority": priority,
                "priorityLabel": priority_label(priority),
                "source": item["source"],
                "aspect": ASPECTS.get(key, {}).get("title", "Общее впечатление"),
                "characteristic": f"{item['name']}: {item['value']}",
                "advantage": copy["advantage"],
                "benefit": copy["benefit"],
                "cardText": copy["cardText"],
                "infographicText": copy["infographicText"],
                "why": hpv_reason(key, strengths, weaknesses),
            }
        )
        if len(rows) >= 6:
            break
    return rows


def build_recommendations(
    strengths: list[dict[str, Any]],
    weaknesses: list[dict[str, Any]],
    negative_pct: int | None,
    matching_size: dict[str, Any],
    text_count: int,
    product_card: dict[str, Any] | None = None,
    card_meta: dict[str, Any] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    content: list[dict[str, Any]] = []
    product_recs: list[dict[str, Any]] = []

    for weakness in weaknesses[:4]:
        add_unique_recommendation(content, make_recommendation("content", weakness, negative_pct), 5)
        add_unique_recommendation(product_recs, make_recommendation("product", weakness, negative_pct), 5)

    if matching_size:
        smaller = int(matching_size.get("smaller") or 0)
        bigger = int(matching_size.get("bigger") or 0)
        if max(smaller, bigger) >= 8 and not any(item["id"] == "content-fit" for item in content):
            fit_aspect = {
                "key": "fit",
                "title": ASPECTS["fit"]["title"],
                "mentions": max(smaller, bigger),
                "negativeMentions": max(smaller, bigger),
                "terms": ["маломерит" if smaller >= bigger else "большемерит"],
                "evidence": [],
            }
            add_unique_recommendation(content, make_recommendation("content", fit_aspect, negative_pct), 5)
            add_unique_recommendation(product_recs, make_recommendation("product", fit_aspect, negative_pct), 5)

    for strength in strengths[:3]:
        add_unique_recommendation(content, make_strength_recommendation(strength), 5)

    if text_count < 20:
        add_unique_recommendation(
            content,
            {
                "id": "content-more-proof",
                "area": "content",
                "aspect": "Доверие к карточке",
                "priority": "medium",
                "priorityLabel": priority_label("medium"),
                "title": "Добавить больше доказательств в карточку",
                "action": (
                    "Так как текстовых отзывов мало, компенсируйте неопределённость: больше реальных фото, видео, "
                    "замеры, комплектация, честные ограничения и ответы на типовые вопросы."
                ),
                "reason": f"Доступно только {text_count} текстовых отзывов, выводы по ним менее устойчивы.",
                "evidence": [],
            },
            5,
        )

    if not product_recs:
        add_unique_recommendation(
            product_recs,
            {
                "id": "product-maintain-quality",
                "area": "product",
                "aspect": "Контроль качества",
                "priority": "low",
                "priorityLabel": priority_label("low"),
                "title": "Сохранить текущий уровень товара",
                "action": (
                    "Повторяющихся проблем мало: закрепите чек-лист качества для поставщика и отслеживайте новые "
                    "отзывы на 1-3★, чтобы быстро ловить просадку партии."
                ),
                "reason": "В текстах нет сильного повторяющегося негативного сигнала.",
                "evidence": [],
            },
            5,
        )

    priority_order = {"high": 0, "medium": 1, "low": 2}
    priority_actions = sorted(
        content[:2] + product_recs[:3],
        key=lambda item: (priority_order.get(item["priority"], 1), item["area"]),
    )[:4]

    return {
        "content": content,
        "product": product_recs,
        "priorityActions": priority_actions,
        "hpv": build_hpv_recommendations(product_card or {}, card_meta or {}, strengths, weaknesses),
    }


SEO_PRIORITY_CHARACTERISTICS = (
    ("Тип/категория", ("тип", "категор", "вид", "модель", "предмет")),
    ("Материал/состав", ("материал", "состав", "ткан", "сырье", "покрытие", "наполнитель")),
    ("Посадка", ("посад", "талия")),
    ("Крой/силуэт", ("крой", "силуэт", "фасон")),
    ("Назначение", ("назнач", "примен", "использ", "для кого", "пол", "возраст", "сценар")),
    ("Размер/объем", ("размер", "длина", "ширина", "высота", "объем", "вес", "рост", "обхват")),
    ("Цвет/дизайн", ("цвет", "оттен", "принт", "рисунок", "дизайн")),
    ("Комплектация", ("комплект", "набор", "количество", "штук", "пара")),
    ("Сезонность", ("сезон", "погод", "температур")),
)


SEO_MODULE_WEIGHTS = (
    {"id": "semantics", "label": "Семантика", "weight": 15},
    {"id": "clusters", "label": "Кластеры", "weight": 10},
    {"id": "title", "label": "Название", "weight": 8},
    {"id": "attributes", "label": "Характеристики", "weight": 12},
    {"id": "description", "label": "Описание", "weight": 5},
    {"id": "ctr", "label": "CTR", "weight": 12},
    {"id": "conversion", "label": "Конверсия", "weight": 15},
    {"id": "query_sales", "label": "Продажи по запросам", "weight": 13},
    {"id": "ads", "label": "Реклама", "weight": 5},
    {"id": "logistics", "label": "Логистика", "weight": 5},
)
SEO_MODULE_LABELS = {item["id"]: item["label"] for item in SEO_MODULE_WEIGHTS}

SEO_CARD_CONFIG = {
    "weights": {
        "title": 0.30,
        "attributes": 0.40,
        "description": 0.30,
    },
    "title": {
        "maxSuggestedKeywords": 3,
        "minComfortableChars": 35,
        "maxComfortableChars": 150,
    },
    "thresholds": {
        "excellent": 90,
        "good": 80,
        "improve": 65,
        "weak": 50,
    },
}

SEO_MARKETING_HINTS = (
    "модный",
    "модная",
    "лучший",
    "лучшая",
    "тренд",
    "хит",
    "премиум",
    "топ",
    "стильный",
    "стильная",
    "идеальный",
    "идеальная",
)

SEO_QUERY_ATTRIBUTE_RULES = (
    ("Цвет/дизайн", ("черн", "бел", "красн", "син", "зелен", "сер", "беж", "роз", "голуб", "корич", "фиолет", "желт", "цвет", "оттен")),
    ("Материал/состав", ("хлоп", "лен", "льн", "кож", "экокож", "полиэстер", "вискоз", "шерст", "акрил", "нейлон", "эластан", "шелк", "трикотаж", "материал", "состав")),
    ("Посадка", ("посад", "талия", "талии")),
    ("Крой/силуэт", ("крой", "силуэт", "фасон", "широк", "свободн", "палаццо", "зауж", "прям")),
    ("Размер/объем", ("размер", "рост", "длина", "ширина", "высота", "объем", "вес", "обхват")),
    ("Назначение", ("офис", "работ", "делов", "повседнев", "спорт", "школ", "дом", "праздн", "вечер")),
    ("Комплектация", ("комплект", "набор", "штук", "пара", "упаков")),
    ("Сезонность", ("зим", "лет", "демисез", "сезон", "тепл", "легк")),
)

SEO_TEXT_MARKERS = {
    "Цвет/дизайн": {
        "черный": ("черн",),
        "белый": ("бел",),
        "красный": ("красн",),
        "синий": ("син",),
        "зеленый": ("зелен",),
        "серый": ("сер",),
        "бежевый": ("беж",),
        "розовый": ("роз",),
        "голубой": ("голуб",),
        "коричневый": ("корич",),
        "фиолетовый": ("фиолет",),
        "желтый": ("желт",),
    },
    "Посадка": {
        "высокая": ("высок",),
        "средняя": ("средн",),
        "низкая": ("низк",),
    },
    "Материал/состав": {
        "хлопок": ("хлоп",),
        "лен": ("лен", "льн"),
        "кожа": ("кож",),
        "экокожа": ("экокож",),
        "полиэстер": ("полиэстер",),
        "вискоза": ("вискоз",),
        "шерсть": ("шерст",),
        "акрил": ("акрил",),
        "нейлон": ("нейлон",),
        "эластан": ("эластан",),
        "шелк": ("шелк",),
        "трикотаж": ("трикотаж",),
    },
    "Крой/силуэт": {
        "широкий": ("широк", "палаццо"),
        "свободный": ("свободн",),
        "прямой": ("прям",),
        "зауженный": ("зауж",),
    },
}

SEO_CLUSTER_RULES = (
    ("Основной товар", ("брюк", "плать", "юбк", "кофт", "рубаш", "футбол", "куртк", "пальт", "кроссов", "сумк", "рюкзак", "товар")),
    ("Форма / крой", ("широк", "палаццо", "свободн", "крой", "силуэт", "прям", "зауж")),
    ("Посадка", ("посад", "талия")),
    ("Сценарий использования", ("офис", "работ", "делов", "повседнев", "дом", "спорт", "школ")),
    ("Материал", ("хлоп", "лен", "льн", "кож", "полиэстер", "вискоз", "шерст", "акрил", "нейлон", "эластан", "шелк")),
    ("Цвет", ("черн", "бел", "красн", "син", "зелен", "сер", "беж", "роз", "голуб", "корич", "фиолет", "желт")),
    ("Размер / объем", ("размер", "рост", "длина", "ширина", "высота", "объем", "вес")),
    ("Комплектация", ("комплект", "набор", "штук", "пара", "упаков")),
)


def seo_score_label(score: int | float | None) -> str:
    value = safe_float(score)
    if value is None:
        return "Нет оценки"
    if value >= 82:
        return "Сильное SEO"
    if value >= 64:
        return "Нужно усилить"
    if value >= 45:
        return "Много пробелов"
    return "Слабая карточка"


def seo_status(score: int | float | None) -> str:
    value = safe_float(score)
    if value is None:
        return "нет данных"
    if value >= 78:
        return "норма"
    if value >= 55:
        return "проверить"
    return "срочно"


def seo_status_label(score: int | float | None) -> str:
    value = safe_float(score)
    if value is None:
        return "Недостаточно данных"
    if value >= 85:
        return "Отлично"
    if value >= 70:
        return "Норма"
    if value >= 50:
        return "Требует внимания"
    return "Критично"


def seo_priority_from_status(score: int | float | None, data_required: bool = False) -> str:
    if data_required:
        return "high"
    value = safe_float(score)
    if value is None:
        return "medium"
    if value < 45:
        return "critical"
    if value < 65:
        return "high"
    if value < 80:
        return "medium"
    return "low"


def effort_label(value: str | None) -> str:
    return {
        "low": "Низкая",
        "medium": "Средняя",
        "high": "Высокая",
    }.get(value or "medium", "Средняя")


def confidence_label(value: str | None) -> str:
    return {
        "low": "Низкая",
        "medium": "Средняя",
        "high": "Высокая",
    }.get(value or "medium", "Средняя")


def term_present(term: str, *texts: str) -> bool:
    tokens = token_list(term)
    if not tokens:
        return False
    for text in texts:
        normalized = normalize_opinion(text)
        if normalize_opinion(term) and normalize_opinion(term) in normalized:
            return True
        text_tokens = set(token_list(text))
        if all(token in text_tokens for token in tokens):
            return True
    return False


def seo_characteristic_group(name: str) -> str:
    normalized = normalize_opinion(name)
    for label, patterns in SEO_PRIORITY_CHARACTERISTICS:
        if any(pattern in normalized for pattern in patterns):
            return label
    return "Прочее"


def seo_metric_from_sources(product: dict[str, Any], card_meta: dict[str, Any], *keys: str) -> float | None:
    sources: list[dict[str, Any]] = []
    for value in (
        product.get("seo"),
        product.get("analytics"),
        product.get("stats"),
        card_meta.get("seo"),
        card_meta.get("analytics"),
        card_meta.get("stats"),
        product,
        card_meta,
    ):
        if isinstance(value, dict):
            sources.append(value)

    for source in sources:
        for key in keys:
            value: Any = source
            for part in key.split("."):
                if isinstance(value, dict) and part in value:
                    value = value.get(part)
                else:
                    value = None
                    break
            number = safe_float(value)
            if number is not None:
                return number
    return None


def seo_percent(numerator: float | int | None, denominator: float | int | None) -> float | None:
    num = safe_float(numerator)
    den = safe_float(denominator)
    if num is None or den is None or den <= 0:
        return None
    return round(num * 100 / den, 2)


def seo_score_from_percent(value: float | None, weak: float, normal: float, strong: float) -> int | None:
    number = safe_float(value)
    if number is None:
        return None
    if number >= strong:
        return 95
    if number >= normal:
        return 78
    if number >= weak:
        return 58
    return 35


def seo_estimated_stock(product: dict[str, Any]) -> int | None:
    for key in ("totalQuantity", "totalQty", "quantity", "qty", "stock", "stocks"):
        value = safe_int(product.get(key))
        if value is not None:
            return value

    total = 0
    found = False
    sizes = product.get("sizes")
    if isinstance(sizes, list):
        for size in sizes:
            if not isinstance(size, dict):
                continue
            for key in ("qty", "quantity", "stock", "stocks"):
                value = safe_int(size.get(key))
                if value is not None:
                    total += value
                    found = True
            stocks = size.get("stocks")
            if isinstance(stocks, list):
                for stock in stocks:
                    if not isinstance(stock, dict):
                        continue
                    value = safe_int(stock.get("qty") or stock.get("quantity") or stock.get("stock"))
                    if value is not None:
                        total += value
                        found = True
    return total if found else None


def seo_module_item(
    module_id: str,
    score: int | float | None,
    reason: str,
    action: str,
    expected_impact: str,
    data_required: list[str] | None = None,
    priority: str | None = None,
    confidence: str = "medium",
) -> dict[str, Any]:
    clean_score = None if score is None else int(round(clamp_photo_value(float(score))))
    module_meta = next((item for item in SEO_MODULE_WEIGHTS if item["id"] == module_id), None)
    label = module_meta["label"] if module_meta else module_id
    weight = module_meta["weight"] if module_meta else 0
    missing = data_required or []
    item_priority = priority or seo_priority_from_status(clean_score, bool(missing))
    return {
        "id": module_id,
        "label": label,
        "weight": weight,
        "score": clean_score,
        "status": seo_status_label(clean_score),
        "priority": item_priority,
        "priorityLabel": priority_label(item_priority),
        "reason": reason,
        "action": action,
        "expectedImpact": expected_impact,
        "dataRequired": missing,
        "confidence": confidence,
        "confidenceLabel": confidence_label(confidence),
    }


def seo_recommendation(
    rec_id: str,
    priority: str,
    module: str,
    problem: str,
    evidence: str,
    recommendation: str,
    expected_impact: str,
    effort: str = "medium",
    confidence: str = "medium",
    check_after: str = "",
) -> dict[str, Any]:
    module_label = SEO_MODULE_LABELS.get(module, module)
    confidence_score = {"low": 0.45, "medium": 0.7, "high": 0.9}.get(confidence, 0.7)
    return {
        "id": rec_id,
        "priority": priority,
        "priorityLabel": priority_label(priority),
        "module": module,
        "moduleLabel": module_label,
        "problem": problem,
        "evidence": evidence,
        "recommendation": recommendation,
        "expectedImpact": expected_impact,
        "effort": effort,
        "effortLabel": effort_label(effort),
        "confidence": confidence,
        "confidenceScore": confidence_score,
        "confidenceLabel": confidence_label(confidence),
        "checkAfter": check_after or "Через 7-14 дней сравнить позиции, CTR, корзины и заказы по выбранному кластеру.",
        "title": problem,
        "action": recommendation,
        "reason": evidence,
    }


def seo_priority_sort_key(item: dict[str, Any]) -> tuple[int, str]:
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    return order.get(as_text(item.get("priority")), 2), as_text(item.get("moduleLabel"))


def seo_cluster_id(label: str) -> str:
    normalized = normalize_opinion(label)
    slug = re.sub(r"[^a-zа-я0-9]+", "-", normalized).strip("-")
    return slug or "cluster"


def seo_heuristic_opportunity(item: dict[str, Any]) -> int:
    base = safe_float(item.get("weight")) or 50
    if item.get("inTitle"):
        base += 8
    if item.get("inCard"):
        base += 7
    count = safe_int(item.get("count")) or 0
    base += min(count * 3, 12)
    return int(round(clamp_photo_value(base)))


def build_seo_clusters(semantic_core: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for item in semantic_core:
        label = as_text(item.get("intent")) or "Семантика"
        cluster = grouped.setdefault(
            label,
            {
                "id": seo_cluster_id(label),
                "name": label,
                "mainQuery": as_text(item.get("term")),
                "queries": [],
                "frequency": None,
                "averagePosition": None,
                "impressions": None,
                "ctr": None,
                "orders": None,
                "revenue": None,
                "conversion": None,
                "status": "secondary",
                "statusLabel": "Дополнительный",
                "opportunityScore": None,
                "sourceNote": "Кластер собран из публичных данных карточки и отзывов; частотность и позиции нужны из кабинета продавца.",
            },
        )
        query = {
            "query": as_text(item.get("term")),
            "clusterId": cluster["id"],
            "clusterName": label,
            "frequency": None,
            "currentPosition": None,
            "impressions": None,
            "clicks": None,
            "ctr": None,
            "addToCart": None,
            "orders": None,
            "conversionToCart": None,
            "conversionToOrder": None,
            "revenue": None,
            "adSpend": None,
            "source": item.get("source"),
            "relevanceScore": item.get("weight"),
            "opportunityScore": seo_heuristic_opportunity(item),
            "priority": item.get("priority") or "medium",
            "priorityLabel": item.get("priorityLabel") or priority_label(item.get("priority") or "medium"),
            "status": "Гипотеза",
            "inTitle": item.get("inTitle"),
            "inCard": item.get("inCard"),
        }
        cluster["queries"].append(query)

    clusters = []
    for cluster in grouped.values():
        cluster["queries"].sort(key=lambda item: (item.get("opportunityScore") or 0, item.get("relevanceScore") or 0), reverse=True)
        if cluster["queries"]:
            cluster["mainQuery"] = cluster["queries"][0]["query"]
            cluster["opportunityScore"] = int(
                round(sum(item.get("opportunityScore") or 0 for item in cluster["queries"]) / len(cluster["queries"]))
            )
        if cluster["name"] == "Базовый товарный запрос":
            cluster["status"] = "primary"
            cluster["statusLabel"] = "Основной"
        elif any(item.get("source") == "Отзывы покупателей" for item in cluster["queries"]):
            cluster["status"] = "test"
            cluster["statusLabel"] = "Тестовый"
        clusters.append(cluster)

    clusters.sort(key=lambda item: (item["status"] == "primary", item.get("opportunityScore") or 0), reverse=True)
    return clusters[:8]


def seo_repeated_terms(text: str, min_count: int = 3, limit: int = 6) -> list[dict[str, Any]]:
    counter: Counter[str] = Counter(token_list(text))
    return [
        {"term": term, "count": count}
        for term, count in counter.most_common(limit)
        if count >= min_count
    ]


def seo_clean_query_text(value: Any) -> str:
    clean = normalize_opinion(as_text(value))
    clean = re.sub(r"https?://\S+|www\.\S+", " ", clean)
    clean = re.sub(r"\b(?:sku|id|арт|артикул)\s*[:№#-]?\s*\d+\b", " ", clean)
    clean = re.sub(r"[^a-zа-яё0-9\s-]+", " ", clean)
    return re.sub(r"\s+", " ", clean).strip(" -")


def seo_query_signature(query: str) -> str:
    tokens = token_list(query)
    return " ".join(sorted(tokens)) or normalize_opinion(query)


def seo_token_coverage(source: str, target: str) -> int:
    source_tokens = set(token_list(source))
    if not source_tokens:
        return 0
    target_tokens = set(token_list(target))
    return round(len(source_tokens & target_tokens) * 100 / len(source_tokens))


def seo_matches_any_token(text: str, patterns: tuple[str, ...]) -> bool:
    tokens = token_list(text)
    return any(any(pattern in token for pattern in patterns) for token in tokens)


def seo_query_attribute_group(query: str) -> str | None:
    normalized = normalize_opinion(query)
    for label, patterns in SEO_QUERY_ATTRIBUTE_RULES:
        if any(pattern in normalized for pattern in patterns):
            return label
    return None


def seo_cluster_name_for_query(query: str, fallback: str = "") -> str:
    normalized = normalize_opinion(" ".join([query, fallback]))
    for label, patterns in SEO_CLUSTER_RULES:
        if any(pattern in normalized for pattern in patterns):
            return label
    if fallback and fallback != "Прочее":
        return fallback
    return "Дополнительный смысл"


def seo_field_value(option: dict[str, Any]) -> str:
    value = option.get("value")
    if isinstance(value, list):
        return "; ".join(as_text(item) for item in value if as_text(item))
    if isinstance(value, bool):
        return "да" if value else "нет"
    values = option.get("variable_values")
    if isinstance(values, list) and values:
        return "; ".join(as_text(item) for item in values if as_text(item))
    return as_text(value)


def seo_all_attribute_items(product: dict[str, Any], card_meta: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    by_name: dict[str, int] = {}

    def add(name: str, value: Any, source: str, required: bool = False, filter_relevant: bool = False) -> None:
        clean_name = as_text(name)
        raw_value = value if isinstance(value, str) else seo_field_value({"value": value})
        clean_value = short_text(as_text(raw_value), 160)
        if not clean_name:
            return
        group = seo_characteristic_group(clean_name)
        if group == "Прочее":
            detected = seo_query_attribute_group(clean_name)
            group = detected or "Прочее"
        key = normalize_opinion(clean_name)
        record = {
            "name": clean_name,
            "value": clean_value,
            "source": source,
            "required": bool(required),
            "filterRelevant": bool(filter_relevant) or group != "Прочее",
            "group": group,
            "filled": bool(clean_value),
        }
        if key in by_name:
            index = by_name[key]
            existing = items[index]
            if not existing.get("filled") and record["filled"]:
                items[index] = record
            else:
                existing["required"] = bool(existing.get("required") or required)
                existing["filterRelevant"] = bool(existing.get("filterRelevant") or record["filterRelevant"])
            return
        by_name[key] = len(items)
        items.append(record)

    for item in product_characteristic_items(product, card_meta):
        add(item.get("name", ""), item.get("value", ""), item.get("source", "Карточка товара"))

    for group in card_meta.get("grouped_options") or []:
        if not isinstance(group, dict):
            continue
        source = as_text(group.get("group_name")) or "Характеристики карточки"
        for option in group.get("options") or []:
            if isinstance(option, dict):
                add(
                    option.get("name", ""),
                    seo_field_value(option),
                    source,
                    bool(option.get("required")),
                    bool(option.get("filterRelevant")),
                )

    for container, source in ((product, "Товар"), (card_meta, "Карточка товара")):
        for key in ("attributes", "attrs", "characteristics"):
            raw_items = container.get(key)
            if not isinstance(raw_items, list):
                continue
            for item in raw_items:
                if not isinstance(item, dict):
                    continue
                add(
                    item.get("name") or item.get("attributeName") or item.get("title") or item.get("id"),
                    seo_field_value(item),
                    source,
                    bool(item.get("required")),
                    bool(item.get("filterRelevant") or item.get("filter_relevant")),
                )

    return items


def seo_marker_hits(text: str, group: str) -> set[str]:
    markers = SEO_TEXT_MARKERS.get(group) or {}
    tokens = token_list(text)
    hits = set()
    for label, stems in markers.items():
        if any(any(token.startswith(stem) for stem in stems) for token in tokens):
            hits.add(label)
    return hits


def seo_issue_p0(
    issue_id: str,
    area: str,
    severity: str,
    title: str,
    description: str,
    evidence: list[str] | None = None,
    recommendation: str = "",
    confidence: float = 0.7,
) -> dict[str, Any]:
    clean_confidence = round(clamp_photo_value(confidence, 0, 1), 2)
    return {
        "id": issue_id,
        "area": area,
        "severity": severity,
        "severityLabel": priority_label(severity),
        "title": title,
        "description": description,
        "evidence": evidence or [],
        "recommendation": recommendation,
        "confidence": clean_confidence,
    }


def check_seo_consistency(title: str, description: str, attributes: list[dict[str, Any]]) -> dict[str, Any]:
    conflicts: list[dict[str, Any]] = []
    text_fields = (("Наименование", title), ("Описание", description))

    for attribute in attributes:
        group = attribute.get("group")
        value = as_text(attribute.get("value"))
        if not group or not value or group not in SEO_TEXT_MARKERS:
            continue
        attribute_hits = seo_marker_hits(value, group)
        if not attribute_hits:
            continue
        for field_name, field_text in text_fields:
            field_hits = seo_marker_hits(field_text, group)
            if not field_hits or attribute_hits & field_hits:
                continue
            conflicts.append(
                {
                    "fieldA": attribute.get("name") or group,
                    "valueA": value,
                    "fieldB": field_name,
                    "valueB": ", ".join(sorted(field_hits)),
                    "group": group,
                    "confidence": 0.78 if field_name == "Наименование" else 0.68,
                    "severity": "high" if field_name == "Наименование" else "medium",
                    "description": (
                        f"Характеристика «{attribute.get('name') or group}» содержит «{value}», "
                        f"а поле «{field_name}» считывается как «{', '.join(sorted(field_hits))}»."
                    ),
                }
            )

    by_group: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for attribute in attributes:
        group = attribute.get("group")
        value = as_text(attribute.get("value"))
        if group in ("Посадка", "Крой/силуэт") and value:
            hits = seo_marker_hits(value, group)
            if hits:
                by_group[group].append({"attribute": attribute, "hits": hits})
    for group, group_items in by_group.items():
        all_hits = set().union(*(item["hits"] for item in group_items))
        if len(all_hits) <= 1:
            continue
        names = ", ".join(item["attribute"].get("name", group) for item in group_items)
        conflicts.append(
            {
                "fieldA": "Характеристики",
                "valueA": names,
                "fieldB": "Характеристики",
                "valueB": ", ".join(sorted(all_hits)),
                "group": group,
                "confidence": 0.72,
                "severity": "high",
                "description": f"В характеристиках по группе «{group}» одновременно встречаются разные значения: {', '.join(sorted(all_hits))}.",
            }
        )

    issues = [
        seo_issue_p0(
            f"consistency-{index}",
            "consistency",
            item.get("severity", "high"),
            "Противоречие между полями карточки",
            item.get("description", ""),
            [f"{item.get('fieldA')}: {item.get('valueA')}", f"{item.get('fieldB')}: {item.get('valueB')}"],
            "Проверить фактическое свойство товара и исправить поле, где значение указано неверно. Не маскировать противоречие повтором ключа.",
            item.get("confidence", 0.7),
        )
        for index, item in enumerate(conflicts, start=1)
    ]
    score = int(clamp_photo_value(100 - len(conflicts) * 28))
    return {"score": score, "conflicts": conflicts[:8], "issues": issues, "ok": not conflicts}


def semantic_candidate_records(
    semantic_core: list[dict[str, Any]],
    product: dict[str, Any],
    card_meta: dict[str, Any],
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []

    def add(query: Any, source: str, weight: int = 60, count: int | None = None, raw: dict[str, Any] | None = None) -> None:
        clean = seo_clean_query_text(query)
        if len(clean) < 3:
            return
        records.append(
            {
                "query": clean,
                "source": source,
                "weight": weight,
                "count": count,
                "raw": raw or {},
                "signature": seo_query_signature(clean),
            }
        )

    for item in semantic_core:
        add(
            item.get("term"),
            as_text(item.get("source")) or "Семантическое ядро",
            safe_int(item.get("weight")) or 60,
            safe_int(item.get("count")),
            item,
        )

    for container, source in ((product, "Внешняя семантика товара"), (card_meta, "Внешняя семантика карточки")):
        for key in ("searchQueries", "queries", "semanticQueries", "semantics"):
            raw_items = container.get(key)
            if not isinstance(raw_items, list):
                continue
            for item in raw_items:
                if isinstance(item, dict):
                    add(
                        item.get("query") or item.get("term") or item.get("keyword"),
                        source,
                        safe_int(item.get("relevanceScore")) or 72,
                        safe_int(item.get("frequency")),
                        item,
                    )
                else:
                    add(item, source, 72)

    merged: dict[str, dict[str, Any]] = {}
    for record in records:
        signature = record["signature"]
        current = merged.get(signature)
        if current is None:
            merged[signature] = record
            continue
        current["weight"] = max(current.get("weight") or 0, record.get("weight") or 0)
        current["count"] = max(current.get("count") or 0, record.get("count") or 0) or None
        sources = unique_texts([current.get("source", ""), record.get("source", "")])
        current["source"] = "; ".join(sources)
        if len(token_list(record["query"])) > len(token_list(current["query"])):
            current["query"] = record["query"]

    return sorted(merged.values(), key=lambda item: (item.get("weight") or 0, item.get("count") or 0), reverse=True)[:30]


class SemanticPlacementEngine:
    def __init__(
        self,
        title: str,
        category: str,
        description: str,
        attributes: list[dict[str, Any]],
        semantic_core: list[dict[str, Any]],
        product: dict[str, Any],
        card_meta: dict[str, Any],
    ) -> None:
        self.title = title
        self.category = category
        self.description = description
        self.attributes = attributes
        self.card_text = " ".join(
            part
            for part in [
                title,
                category,
                description,
                " ".join(f"{item.get('name')} {item.get('value')}" for item in attributes if item.get("filled")),
            ]
            if part
        )
        self.card_tokens = set(token_list(self.card_text))
        self.attribute_groups = {
            item.get("group")
            for item in attributes
            if item.get("group") and item.get("group") != "Прочее" and item.get("filled")
        }
        self.attribute_text_by_group: dict[str, str] = defaultdict(str)
        for item in attributes:
            if item.get("group") and item.get("filled"):
                self.attribute_text_by_group[item["group"]] += f" {item.get('name')} {item.get('value')}"
        self.records = semantic_candidate_records(semantic_core, product, card_meta)

    def relevance(self, query: str, source: str) -> tuple[str, int, str]:
        query_tokens = set(token_list(query))
        if not query_tokens:
            return "unknown", 35, "Недостаточно значимых слов в запросе."
        if term_present(query, self.card_text):
            return "high", 92, "Запрос подтвержден публичными полями карточки."
        category_coverage = seo_token_coverage(self.category, query) if self.category else 0
        query_coverage = round(len(query_tokens & self.card_tokens) * 100 / len(query_tokens)) if query_tokens else 0
        if category_coverage >= 70 or query_coverage >= 70:
            return "medium", 74, "Запрос частично совпадает с типом товара или характеристиками."
        if "Отзывы покупателей" in source and query_tokens & self.card_tokens:
            return "medium", 68, "Смысл встречается в языке покупателей, но не полностью закреплен в карточке."
        if query_tokens & self.card_tokens:
            return "low", 48, "Есть слабое пересечение с карточкой, требуется проверка релевантности."
        return "unknown", 36, "В публичных данных карточки нет подтверждения этому запросу."

    def placement_for(self, query: str, relevance: str, source: str, cluster_name: str) -> tuple[str, str]:
        attribute_group = seo_query_attribute_group(query)
        if relevance in ("irrelevant", "unknown") and attribute_group is None:
            return "exclude", "Нет подтверждения в товаре, поэтому запрос нельзя использовать ради SEO."
        if attribute_group and attribute_group != "Назначение":
            normalized = normalize_opinion(query)
            kroy_title_subtype = (
                attribute_group == "Крой/силуэт"
                and "палаццо" in normalized
                and not any(pattern in normalized for pattern in ("широк", "свободн", "прям", "зауж", "крой", "силуэт", "фасон"))
            )
            if not kroy_title_subtype:
                return "attribute", f"Смысл лучше подтверждать структурированной характеристикой «{attribute_group}»."
        if attribute_group == "Назначение":
            if "Назначение" in self.attribute_groups:
                return "attribute", "Назначение уже является структурированной характеристикой карточки."
            return "description", "Сценарий использования лучше раскрывать естественным описанием и инфографикой."
        if cluster_name == "Основной товар":
            return "title", "Главный товарный смысл должен считываться в наименовании."
        if "Отзывы покупателей" in source or cluster_name == "Сценарий использования":
            return "description", "Сценарий или язык покупателей лучше раскрыть естественным описанием и инфографикой."
        if relevance == "high":
            return "description", "Смысл подтвержден карточкой, но не является главным запросом для наименования."
        return "exclude", "Смысл спорный; сначала подтвердите фактическое соответствие товару."

    def placement_status(self, query: str, placement: str) -> str:
        attribute_group = seo_query_attribute_group(query)
        if placement == "title":
            return "Используется" if term_present(query, self.title) else "Не используется"
        if placement == "attribute":
            attribute_text = self.attribute_text_by_group.get(attribute_group or "", "")
            if attribute_text and term_present(query, attribute_text):
                return "Используется"
            if attribute_text and attribute_group:
                query_markers = seo_marker_hits(query, attribute_group)
                attribute_markers = seo_marker_hits(attribute_text, attribute_group)
                if query_markers and query_markers & attribute_markers:
                    return "Используется"
                query_tokens = set(token_list(query)) - set(token_list(self.category))
                attribute_tokens = set(token_list(attribute_text))
                if query_tokens and query_tokens & attribute_tokens:
                    return "Используется"
            if attribute_group and attribute_group in self.attribute_groups:
                return "Требует проверки"
            return "Не заполнено"
        if placement == "description":
            return "Используется" if term_present(query, self.description) else "Не раскрыто"
        return "Исключить"

    def run(self) -> dict[str, Any]:
        placements: list[dict[str, Any]] = []
        for record in self.records:
            query = record["query"]
            cluster_name = seo_cluster_name_for_query(query, as_text(record.get("raw", {}).get("intent")))
            relevance, relevance_score, relevance_reason = self.relevance(query, record.get("source", ""))
            placement, placement_reason = self.placement_for(query, relevance, record.get("source", ""), cluster_name)
            status = self.placement_status(query, placement)
            confidence = 0.86 if relevance == "high" and status == "Используется" else 0.68 if relevance in ("medium", "low") else 0.45
            placements.append(
                {
                    "cluster": cluster_name,
                    "query": query,
                    "exampleQuery": query,
                    "source": record.get("source"),
                    "frequency": record.get("raw", {}).get("frequency"),
                    "relevance": relevance,
                    "relevanceLabel": {
                        "high": "Высокая",
                        "medium": "Средняя",
                        "low": "Низкая",
                        "irrelevant": "Нерелевантно",
                        "unknown": "Недостаточно данных",
                    }.get(relevance, "Недостаточно данных"),
                    "relevanceScore": relevance_score,
                    "placement": placement,
                    "placementLabel": {
                        "title": "Наименование",
                        "attribute": "Характеристики",
                        "description": "Описание",
                        "exclude": "Исключить",
                    }.get(placement, placement),
                    "status": status,
                    "reason": placement_reason,
                    "relevanceReason": relevance_reason,
                    "attributeGroup": seo_query_attribute_group(query),
                    "confidence": confidence,
                    "opportunityScore": seo_heuristic_opportunity({"weight": relevance_score, "count": record.get("count"), "inCard": status == "Используется"}),
                }
            )

        cluster_map: dict[str, dict[str, Any]] = {}
        for item in placements:
            cluster = cluster_map.setdefault(
                item["cluster"],
                {
                    "id": seo_cluster_id(item["cluster"]),
                    "name": item["cluster"],
                    "mainQuery": item["query"],
                    "queries": [],
                    "frequency": None,
                    "averagePosition": None,
                    "impressions": None,
                    "ctr": None,
                    "orders": None,
                    "revenue": None,
                    "conversion": None,
                    "status": "secondary",
                    "statusLabel": "Дополнительный",
                    "opportunityScore": None,
                    "sourceNote": "Кластер собран из публичной карточки, характеристик, отзывов и загруженной семантики, если она есть.",
                },
            )
            cluster["queries"].append(item)
        clusters = []
        for cluster in cluster_map.values():
            cluster["queries"].sort(key=lambda item: (item.get("relevanceScore") or 0, item.get("opportunityScore") or 0), reverse=True)
            cluster["mainQuery"] = cluster["queries"][0]["query"]
            cluster["opportunityScore"] = round(sum(item.get("opportunityScore") or 0 for item in cluster["queries"]) / len(cluster["queries"]))
            if cluster["name"] == "Основной товар" or term_present(cluster["mainQuery"], self.category):
                cluster["status"] = "primary"
                cluster["statusLabel"] = "Основной"
            elif any(item.get("placement") == "exclude" for item in cluster["queries"]):
                cluster["status"] = "test"
                cluster["statusLabel"] = "Требует проверки"
            clusters.append(cluster)
        clusters.sort(key=lambda item: (item["status"] == "primary", item.get("opportunityScore") or 0), reverse=True)

        used = sum(1 for item in placements if item["status"] == "Используется")
        excluded = sum(1 for item in placements if item["placement"] == "exclude")
        return {
            "items": placements[:24],
            "clusters": clusters[:8],
            "summary": {
                "totalQueries": len(placements),
                "used": used,
                "needsWork": sum(1 for item in placements if item["status"] in ("Не используется", "Не заполнено", "Не раскрыто")),
                "excluded": excluded,
            },
        }


def seo_spam_analysis(text: str, semantic_items: list[dict[str, Any]], min_repeat: int = 3) -> dict[str, Any]:
    tokens = token_list(text)
    if not tokens:
        return {"score": 0, "level": "none", "overusedTerms": [], "keywordDensity": 0, "listLike": False}
    overused = seo_repeated_terms(text, min_count=min_repeat, limit=8)
    semantic_tokens = set()
    for item in semantic_items[:18]:
        semantic_tokens.update(token_list(item.get("query") or item.get("term") or ""))
    keyword_hits = sum(1 for token in tokens if token in semantic_tokens)
    density = round(keyword_hits * 100 / len(tokens), 1) if tokens else 0
    fragments = [part.strip() for part in re.split(r"[,;.\n]+", text) if len(token_list(part)) >= 2]
    shared_heads = Counter()
    for fragment in fragments:
        words = token_list(fragment)
        if words:
            shared_heads[words[0]] += 1
    list_like = len(fragments) >= 4 and any(count >= 3 for count in shared_heads.values())
    if len(tokens) <= 5:
        density_threshold = 88
        density_weight = 0.6
    elif len(tokens) <= 10:
        density_threshold = 56
        density_weight = 1.2
    else:
        density_threshold = 42
        density_weight = 1.5
    penalty = len(overused) * 12 + max(0, density - density_threshold) * density_weight + (24 if list_like else 0)
    score = int(clamp_photo_value(100 - penalty))
    level = "none" if score >= 88 else "low" if score >= 72 else "medium" if score >= 50 else "high"
    return {"score": score, "level": level, "overusedTerms": overused, "keywordDensity": density, "listLike": list_like}


def seo_readability_score(text: str, min_chars: int, max_chars: int) -> int:
    clean = as_text(text)
    if not clean:
        return 0
    score = 100
    char_count = len(clean)
    word_count = len(token_list(clean))
    if char_count < min_chars:
        score -= min(38, (min_chars - char_count) // 2)
    if char_count > max_chars:
        score -= min(36, (char_count - max_chars) // 6)
    if clean.count(",") + clean.count(";") >= 6:
        score -= 14
    if word_count > 16 and clean.count(" ") > 0 and not re.search(r"[.,;:]", clean):
        score -= 12
    marketing_hits = [word for word in SEO_MARKETING_HINTS if term_present(word, clean)]
    score -= min(len(marketing_hits) * 5, 18)
    return int(clamp_photo_value(score))


def seo_title_structure_score(title: str) -> int:
    clean = normalize_opinion(title)
    tokens = token_list(title)
    if not tokens:
        return 0
    score = 100
    connector_count = len(re.findall(r"\b(?:с|со|для|из|на|в|во|без|под|после|до)\b", clean))
    if len(tokens) >= 7 and connector_count == 0 and not re.search(r"[,;/]", clean):
        score -= 30
    if len(tokens) >= 9:
        score -= 12
    repeat_count = sum(count - 1 for count in Counter(tokens).values() if count > 1)
    score -= min(repeat_count * 12, 24)
    attribute_signals = sum(1 for label, _patterns in SEO_QUERY_ATTRIBUTE_RULES if seo_query_attribute_group(" ".join(tokens)) == label)
    if len(tokens) >= 7 and attribute_signals >= 1:
        score -= 6
    marketing_hits = [word for word in SEO_MARKETING_HINTS if term_present(word, clean)]
    score -= min(len(marketing_hits) * 6, 18)
    return int(clamp_photo_value(score))


def generate_optimized_title(title: str, category: str, placement: dict[str, Any]) -> str:
    max_terms = SEO_CARD_CONFIG["title"]["maxSuggestedKeywords"]
    clusters = placement.get("clusters") or []
    primary = next((item for item in clusters if item.get("status") == "primary"), clusters[0] if clusters else {})
    base = as_text(category or primary.get("mainQuery") or title)
    parts = [base]
    for item in placement.get("items") or []:
        if len(parts) >= max_terms + 1:
            break
        query = as_text(item.get("query"))
        if not query or item.get("placement") not in ("title", "attribute"):
            continue
        if item.get("relevance") not in ("high", "medium"):
            continue
        if item.get("status") not in ("Используется", "Требует проверки"):
            continue
        if term_present(query, " ".join(parts)):
            continue
        if len(token_list(query)) > 3:
            continue
        parts.append(query)
    suggestion = short_text(" ".join(unique_texts(parts, max_terms + 1)), 150)
    return suggestion or title


def evaluate_title(title: str, category: str, placement: dict[str, Any], card_text: str) -> dict[str, Any]:
    clusters = placement.get("clusters") or []
    primary = next((item for item in clusters if item.get("status") == "primary"), None)
    fallback_cluster = clusters[0] if clusters else {}
    main_query = as_text((primary or {}).get("mainQuery") or category or fallback_cluster.get("mainQuery"))
    product_type_score = 100 if category and term_present(category, title) else 72 if main_query and seo_token_coverage(main_query, title) >= 65 else 35
    main_cluster_coverage = seo_token_coverage(main_query, title) if main_query else 0
    main_cluster_score = main_cluster_coverage
    title_tokens = token_list(title)
    semantic_tokens = set(token_list(card_text)) | set(token_list(category))
    relevant_title_tokens = [token for token in title_tokens if token in semantic_tokens]
    relevance_score = round(len(relevant_title_tokens) * 100 / len(title_tokens)) if title_tokens else 0
    readability_score = seo_readability_score(
        title,
        SEO_CARD_CONFIG["title"]["minComfortableChars"],
        SEO_CARD_CONFIG["title"]["maxComfortableChars"],
    )
    readability_score = min(readability_score, seo_title_structure_score(title))
    spam = seo_spam_analysis(title, placement.get("items") or [], min_repeat=2)
    if readability_score < 60 and len(title_tokens) >= 7:
        spam = {**spam, "score": min(spam["score"], 60), "level": "medium" if spam["score"] >= 50 else "high", "listLike": True}
    anti_spam_score = spam["score"]
    score = round(
        product_type_score * 0.25
        + main_cluster_score * 0.30
        + relevance_score * 0.20
        + readability_score * 0.15
        + anti_spam_score * 0.10
    )
    score = int(clamp_photo_value(score))
    issues: list[dict[str, Any]] = []
    strengths = []
    if product_type_score < 70:
        issues.append(
            seo_issue_p0(
                "title-product-type",
                "title",
                "high",
                "Тип товара плохо считывается",
                "Наименование должно сразу объяснять, что продается.",
                [f"Категория: {category or 'не определена'}", f"Наименование: {title or 'пусто'}"],
                "Поставить точный тип товара в начало наименования.",
                0.82,
            )
        )
    else:
        strengths.append("Тип товара считывается в наименовании.")
    if main_cluster_score < 70:
        issues.append(
            seo_issue_p0(
                "title-main-cluster",
                "title",
                "high",
                "Главный кластер покрыт не полностью",
                "Название должно закрывать основной поисковый смысл, а не общий набор слов.",
                [f"Главный запрос: {main_query}", f"Покрытие: {main_cluster_coverage}%"],
                "Пересобрать наименование вокруг главного кластера и 1-2 фактических признаков.",
                0.76,
            )
        )
    else:
        strengths.append("Главный кластер покрыт в наименовании.")
    if spam["level"] in ("medium", "high"):
        issues.append(
            seo_issue_p0(
                "title-keyword-spam",
                "title",
                "high" if spam["level"] == "high" else "medium",
                "Наименование похоже на SEO-список",
                "Есть риск искусственного накопления ключей или повторов.",
                [f"Уровень переспама: {spam['level']}", "Повторы: " + ", ".join(item["term"] for item in spam["overusedTerms"])],
                "Убрать повторы, синонимические списки и оценочные слова без фактической пользы.",
                0.74,
            )
        )
    else:
        strengths.append("Явного SEO-переспама в наименовании не найдено.")
    if readability_score < 65:
        issues.append(
            seo_issue_p0(
                "title-readability",
                "title",
                "medium",
                "Наименование тяжело читается",
                "Покупатель должен понять товар за 1-2 секунды.",
                [f"Читаемость: {readability_score}/100"],
                "Сократить фразу до нормального названия товара без длинного перечисления признаков.",
                0.67,
            )
        )
    if spam["level"] == "high" or (spam["level"] == "medium" and readability_score < 72):
        action = "rewrite"
    else:
        action = "keep" if score >= 85 and not issues else "minor_edit" if score >= 65 else "rewrite"
    suggested = generate_optimized_title(title, category, placement)
    return {
        "score": score,
        "components": {
            "productTypeScore": product_type_score,
            "mainClusterScore": main_cluster_score,
            "relevanceScore": relevance_score,
            "readabilityScore": readability_score,
            "antiSpamScore": anti_spam_score,
        },
        "issues": issues,
        "strengths": strengths[:4],
        "mainClusterCoverage": main_cluster_coverage,
        "keywordSpamLevel": spam["level"],
        "recommendedAction": action,
        "recommendedActionLabel": {"keep": "Оставить", "minor_edit": "Точечно поправить", "rewrite": "Переписать"}.get(action, action),
        "suggestedTitle": suggested if suggested and normalize_opinion(suggested) != normalize_opinion(title) else "",
    }


def seo_required_attribute_groups(category: str, placement_items: list[dict[str, Any]]) -> list[str]:
    groups = ["Материал/состав", "Цвет/дизайн", "Размер/объем", "Комплектация"]
    normalized_category = normalize_opinion(category)
    if any(pattern in normalized_category for pattern in ("брюк", "одеж", "плать", "юбк", "рубаш", "кофт", "куртк", "пальт")):
        groups.extend(["Посадка", "Крой/силуэт", "Назначение"])
    for item in placement_items:
        group = item.get("attributeGroup")
        if item.get("placement") == "attribute" and group:
            groups.append(group)
    return unique_texts(groups)


def evaluate_attributes(
    attributes: list[dict[str, Any]],
    placement: dict[str, Any],
    consistency: dict[str, Any],
    category: str,
) -> dict[str, Any]:
    placement_items = placement.get("items") or []
    expected_groups = seo_required_attribute_groups(category, placement_items)
    filled_groups = {item.get("group") for item in attributes if item.get("filled") and item.get("group") != "Прочее"}
    filled_important = len([group for group in expected_groups if group in filled_groups])
    total_important = len(expected_groups)
    missing = [
        {
            "attributeName": group,
            "name": group,
            "value": "",
            "seoImportance": "Высокая",
            "status": "Не заполнено",
            "recommendation": f"Проверить и заполнить характеристику «{group}», если она фактически применима к товару.",
            "priority": "high",
            "priorityLabel": priority_label("high"),
        }
        for group in expected_groups
        if group not in filled_groups
    ]
    attribute_placements = [item for item in placement_items if item.get("placement") == "attribute"]
    used_attribute_placements = [item for item in attribute_placements if item.get("status") == "Используется"]
    missing_seo_relevant = [
        {
            "cluster": item.get("cluster"),
            "query": item.get("query"),
            "attributeGroup": item.get("attributeGroup"),
            "status": item.get("status"),
            "recommendation": f"Не добавлять «{item.get('query')}» в описание повтором; сначала подтвердить смысл характеристикой «{item.get('attributeGroup')}», если это правда.",
        }
        for item in attribute_placements
        if item.get("status") != "Используется"
    ][:8]
    suspicious = [
        item
        for item in attributes
        if item.get("required") and not item.get("filled")
        or normalize_opinion(as_text(item.get("value"))) in ("нет", "не указано", "none", "null")
    ][:8]

    attr_rows = []
    conflict_groups = {item.get("group") for item in consistency.get("conflicts") or []}
    for item in attributes:
        group = item.get("group") or "Прочее"
        value = as_text(item.get("value"))
        if group in conflict_groups:
            status = "Противоречие"
            recommendation = "Проверить фактическое значение и исправить конфликт между полями."
        elif not value:
            status = "Не заполнено"
            recommendation = f"Заполнить «{item.get('name')}», если это применимо к товару."
        elif group in expected_groups:
            status = "Заполнено корректно"
            recommendation = "Сохранить значение; использовать его как факт для названия, описания и инфографики."
        elif group != "Прочее":
            status = "Требует проверки"
            recommendation = "Оставить, если характеристика действительно помогает покупателю выбрать товар."
        else:
            status = "Недостаточно данных"
            recommendation = "Проверить, относится ли характеристика к важным фильтрам категории."
        attr_rows.append(
            {
                "attributeName": item.get("name"),
                "value": value,
                "group": group,
                "seoImportance": "Высокая" if group in expected_groups else "Средняя" if group != "Прочее" else "Низкая",
                "status": status,
                "recommendation": recommendation,
            }
        )

    completeness_score = round(filled_important * 100 / total_important) if total_important else 0
    seo_coverage_score = round(len(used_attribute_placements) * 100 / len(attribute_placements)) if attribute_placements else (80 if filled_groups else 0)
    filter_groups = [group for group in ("Материал/состав", "Цвет/дизайн", "Размер/объем", "Комплектация") if group in expected_groups]
    filter_coverage_score = round(len([group for group in filter_groups if group in filled_groups]) * 100 / len(filter_groups)) if filter_groups else 100
    consistency_score = consistency.get("score", 100)
    score = round(
        completeness_score * 0.30
        + seo_coverage_score * 0.30
        + filter_coverage_score * 0.20
        + consistency_score * 0.20
    )
    issues: list[dict[str, Any]] = []
    if not attributes:
        issues.append(
            seo_issue_p0(
                "attributes-missing-all",
                "attributes",
                "critical",
                "Характеристики не найдены",
                "Невозможно корректно оценить структурную релевантность карточки.",
                [],
                "Подключить/проверить характеристики карточки и заполнить обязательные фактические поля.",
                0.9,
            )
        )
    for item in missing[:5]:
        issues.append(
            seo_issue_p0(
                f"attributes-missing-{seo_cluster_id(item['attributeName'])}",
                "attributes",
                "high",
                f"Не заполнена SEO-релевантная характеристика «{item['attributeName']}»",
                "Если поисковый смысл можно подтвердить характеристикой, не стоит компенсировать его повтором в описании.",
                [item["attributeName"]],
                item["recommendation"],
                0.72,
            )
        )
    for issue in consistency.get("issues") or []:
        issues.append(issue)
    return {
        "score": int(clamp_photo_value(score)),
        "filledImportant": filled_important,
        "totalImportant": total_important,
        "missingImportant": missing[:8],
        "missingSeoRelevant": missing_seo_relevant,
        "contradictions": consistency.get("conflicts") or [],
        "suspiciousValues": suspicious,
        "rows": attr_rows[:18],
        "issues": issues[:10],
        "recommendations": [
            {
                "attributeName": item["attributeName"],
                "currentValue": item.get("value"),
                "action": "fill",
                "reason": item["recommendation"],
                "relatedClusters": [
                    gap.get("cluster")
                    for gap in missing_seo_relevant
                    if gap.get("attributeGroup") == item["attributeName"]
                ],
            }
            for item in missing[:6]
        ],
        "components": {
            "completenessScore": completeness_score,
            "seoCoverageScore": seo_coverage_score,
            "filterCoverageScore": filter_coverage_score,
            "consistencyScore": consistency_score,
        },
    }


def generate_optimized_description(
    title: str,
    category: str,
    attributes: list[dict[str, Any]],
    placement: dict[str, Any],
) -> str:
    facts = []
    for group in ("Материал/состав", "Цвет/дизайн", "Размер/объем", "Комплектация", "Посадка", "Крой/силуэт", "Назначение"):
        values = [as_text(item.get("value")) for item in attributes if item.get("group") == group and item.get("filled")]
        if values:
            facts.append(f"{group.lower()}: {', '.join(unique_texts(values, 2))}")
    scenarios = [
        item.get("query")
        for item in placement.get("items") or []
        if item.get("placement") == "description" and item.get("relevance") in ("high", "medium") and item.get("status") == "Используется"
    ]
    first = f"{category or title} — товар с понятными фактическими характеристиками." if category or title else "Опишите товар через фактические свойства."
    second = f"В карточке подтверждены: {'; '.join(facts[:5])}." if facts else "Добавьте в описание только те свойства, которые подтверждены характеристиками и фото товара."
    third = f"Дополнительные сценарии: {', '.join(unique_texts(scenarios, 3))}." if scenarios else "Кратко раскройте назначение, сценарий использования, комплектацию и ограничения без повторения ключевых фраз."
    return short_text(" ".join([first, second, third]), 520)


def evaluate_description(
    description: str,
    placement: dict[str, Any],
    consistency: dict[str, Any],
    title: str,
    category: str,
    attributes: list[dict[str, Any]],
) -> dict[str, Any]:
    description_items = [item for item in placement.get("items") or [] if item.get("placement") == "description"]
    used_items = [item for item in description_items if item.get("status") == "Используется"]
    semantic_coverage = round(len(used_items) * 100 / len(description_items)) if description_items else (100 if description else 0)
    readability_score = seo_readability_score(description, 80, 1100)
    spam = seo_spam_analysis(description, placement.get("items") or [], min_repeat=3)
    consistency_score = consistency.get("score", 100)
    relevance_score = round((semantic_coverage * 0.65) + (min(len(token_list(description)), 60) * 100 / 60 * 0.35)) if description else 0
    score = round(
        semantic_coverage * 0.25
        + readability_score * 0.25
        + relevance_score * 0.20
        + spam["score"] * 0.20
        + consistency_score * 0.10
    )
    if not description:
        score = 0
    missing_clusters = [
        {"name": item.get("cluster"), "mainQuery": item.get("query"), "status": item.get("status")}
        for item in description_items
        if item.get("status") != "Используется" and item.get("relevance") in ("high", "medium")
    ][:8]
    irrelevant_terms = [
        item.get("query")
        for item in placement.get("items") or []
        if item.get("placement") == "exclude" and term_present(item.get("query"), description)
    ][:8]
    issues: list[dict[str, Any]] = []
    if not description:
        issues.append(
            seo_issue_p0(
                "description-empty",
                "description",
                "high",
                "Описание отсутствует",
                "Описание не главный SEO-фактор, но оно помогает раскрыть свойства, сценарии и ограничения товара.",
                [],
                "Добавить естественное описание на языке покупателя без списка ключей.",
                0.88,
            )
        )
    if spam["level"] in ("medium", "high"):
        issues.append(
            seo_issue_p0(
                "description-spam",
                "description",
                "high" if spam["level"] == "high" else "medium",
                "Описание похоже на SEO-список",
                "Высокое покрытие ключей не является преимуществом, если текст выглядит искусственным.",
                [f"Уровень переспама: {spam['level']}", f"Плотность ключевых слов: {spam['keywordDensity']}%"],
                "Переписать описание нормальным русским текстом: товар, свойства, польза, сценарии, комплектация.",
                0.78,
            )
        )
    if missing_clusters:
        issues.append(
            seo_issue_p0(
                "description-missing-clusters",
                "description",
                "medium",
                "Не раскрыты дополнительные релевантные смыслы",
                "Описание можно использовать для длинного хвоста, но только когда смысл соответствует товару.",
                [", ".join(unique_texts([item["mainQuery"] for item in missing_clusters], 4))],
                "Добавить 1-2 коротких предложения по этим сценариям, если они подтверждены товаром.",
                0.64,
            )
        )
    if irrelevant_terms:
        issues.append(
            seo_issue_p0(
                "description-irrelevant-terms",
                "description",
                "high",
                "В описании есть неподтвержденные SEO-смыслы",
                "Нерелевантные запросы ухудшают ожидания покупателя и могут снижать конверсию.",
                irrelevant_terms,
                "Удалить спорные запросы или подтвердить их фактическими характеристиками.",
                0.72,
            )
        )
    return {
        "score": int(clamp_photo_value(score)),
        "semanticCoverage": semantic_coverage,
        "readabilityScore": readability_score,
        "relevanceScore": int(clamp_photo_value(relevance_score)),
        "spamScore": spam["score"],
        "keywordSpamLevel": spam["level"],
        "consistencyScore": consistency_score,
        "missingClusters": missing_clusters,
        "overusedTerms": spam["overusedTerms"],
        "irrelevantTerms": irrelevant_terms,
        "issues": issues,
        "suggestedDescription": generate_optimized_description(title, category, attributes, placement),
    }


def card_seo_score_label(score: int | float | None) -> str:
    value = safe_float(score)
    if value is None:
        return "Нет оценки"
    thresholds = SEO_CARD_CONFIG["thresholds"]
    if value >= thresholds["excellent"]:
        return "Отлично"
    if value >= thresholds["good"]:
        return "Хорошо"
    if value >= thresholds["improve"]:
        return "Требует улучшения"
    if value >= thresholds["weak"]:
        return "Слабая оптимизация"
    return "Критические проблемы"


def confidence_bucket(value: float | int | None) -> str:
    number = safe_float(value)
    if number is None:
        return "medium"
    if number >= 0.78:
        return "high"
    if number >= 0.58:
        return "medium"
    return "low"


def seo_p0_issue_sort_key(item: dict[str, Any]) -> tuple[int, int, str]:
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    area_order = {"consistency": 0, "semantics": 1, "title": 2, "attributes": 3, "description": 4}
    return (
        severity_order.get(item.get("severity"), 2),
        area_order.get(item.get("area"), 5),
        as_text(item.get("title")),
    )


def build_p0_recommendations(p0_issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    recommendations = []
    for issue in sorted(p0_issues, key=seo_p0_issue_sort_key)[:5]:
        area = issue.get("area") or "semantics"
        module = "attributes" if area == "consistency" else area
        if module not in SEO_MODULE_LABELS:
            module = "semantics"
        rec = seo_recommendation(
            issue.get("id", "seo-p0-recommendation"),
            issue.get("severity", "medium"),
            module,
            issue.get("title", "SEO-рекомендация"),
            " ".join(issue.get("evidence") or [issue.get("description", "")]),
            issue.get("recommendation") or "Проверить карточку и исправить проблему по фактическим данным товара.",
            "Карточка станет лучше подтверждать релевантность товара без набивки ключей.",
            effort="medium",
            confidence=confidence_bucket(issue.get("confidence")),
            check_after="После изменения сравнить внутренний SEO Score, отсутствие переспама и корректность заполнения полей.",
        )
        rec["confidenceScore"] = issue.get("confidence", rec.get("confidenceScore", 0.7))
        recommendations.append(rec)
    return recommendations


def build_card_seo_p0(
    product: dict[str, Any],
    card_meta: dict[str, Any],
    semantic_core: list[dict[str, Any]],
    title: str,
    category: str,
    description: str,
) -> dict[str, Any]:
    attributes = seo_all_attribute_items(product, card_meta)
    placement = SemanticPlacementEngine(title, category, description, attributes, semantic_core, product, card_meta).run()
    consistency = check_seo_consistency(title, description, attributes)
    card_fact_text = " ".join([category, description, " ".join(f"{item.get('name')} {item.get('value')}" for item in attributes if item.get("filled"))])
    title_eval = evaluate_title(title, category, placement, card_fact_text)
    attributes_eval = evaluate_attributes(attributes, placement, consistency, category)
    description_eval = evaluate_description(description, placement, consistency, title, category, attributes)
    weights = SEO_CARD_CONFIG["weights"]
    score = round(
        title_eval["score"] * weights["title"]
        + attributes_eval["score"] * weights["attributes"]
        + description_eval["score"] * weights["description"]
    )
    issues = (
        title_eval.get("issues", [])
        + attributes_eval.get("issues", [])
        + description_eval.get("issues", [])
        + [
            seo_issue_p0(
                "semantics-missing",
                "semantics",
                "medium",
                "Семантическое ядро ограничено",
                "Оценка работает по публичной карточке, отзывам и загруженной семантике, если она есть.",
                [],
                "Для более точного аудита загрузить реальные поисковые запросы из кабинета WB.",
                0.56,
            )
        ]
        if not placement.get("items")
        else title_eval.get("issues", []) + attributes_eval.get("issues", []) + description_eval.get("issues", [])
    )
    issues = sorted(issues, key=seo_p0_issue_sort_key)
    recommendations = build_p0_recommendations(issues)
    if not recommendations:
        recommendations = [
            seo_recommendation(
                "seo-p0-keep",
                "low",
                "semantics",
                "Критичных P0-проблем не найдено",
                "Наименование, характеристики и описание выглядят согласованными по доступным данным.",
                "Сохранить текущую структуру и проверить ее на реальных поисковых запросах, CTR и заказах.",
                "Подтверждение, что карточка оптимизирована не количеством ключей, а релевантностью.",
                effort="low",
                confidence="medium",
            )
        ]
    main_problem = issues[0]["title"] if issues else "Критичных P0-проблем по карточке не найдено."
    main_opportunity = (
        recommendations[0].get("recommendation")
        if recommendations
        else "Проверить карточку на реальных поисковых запросах WB."
    )
    return {
        "ok": True,
        "config": SEO_CARD_CONFIG,
        "score": int(clamp_photo_value(score)),
        "scoreLabel": card_seo_score_label(score),
        "weights": weights,
        "titleEvaluation": title_eval,
        "attributesEvaluation": attributes_eval,
        "descriptionEvaluation": description_eval,
        "consistency": consistency,
        "semanticPlacement": placement,
        "issues": issues[:14],
        "recommendations": recommendations[:5],
        "mainProblem": main_problem,
        "mainOpportunity": main_opportunity,
        "summary": (
            f"Наименование {title_eval['score']}/100, характеристики {attributes_eval['score']}/100, "
            f"описание {description_eval['score']}/100."
        ),
    }


def build_seo_card_audit(
    title: str,
    category: str,
    characteristics: list[dict[str, str]],
    characteristic_gaps: list[dict[str, Any]],
    description: str,
    semantic_core: list[dict[str, Any]],
    clusters: list[dict[str, Any]],
) -> dict[str, Any]:
    main_cluster = next((item for item in clusters if item.get("status") == "primary"), clusters[0] if clusters else {})
    main_query = as_text(main_cluster.get("mainQuery") or category)
    title_problems = []
    if category and not term_present(category, title):
        title_problems.append("тип товара не стоит явным главным запросом")
    repeated_title = seo_repeated_terms(title, min_count=2, limit=4)
    if repeated_title:
        title_problems.append("есть повторы слов: " + ", ".join(item["term"] for item in repeated_title))
    if len(title) < 35:
        title_problems.append("название слишком короткое для раскрытия главного смысла")
    if len(title) > 170:
        title_problems.append("название перегружено и может хуже считываться")

    title_terms = []
    for item in semantic_core:
        term = as_text(item.get("term"))
        if not term or term_present(term, " ".join(title_terms), title):
            continue
        if item.get("weight", 0) >= 74:
            title_terms.append(term)
        if len(title_terms) >= 3:
            break
    title_example_parts = unique_texts([main_query or category] + title_terms, 4)
    title_example = " ".join(title_example_parts) if title_example_parts else title

    grouped_characteristics: dict[str, list[str]] = {}
    for item in characteristics:
        group = seo_characteristic_group(item.get("name", ""))
        if group == "Прочее":
            continue
        grouped_characteristics.setdefault(group, []).append(f"{item.get('name')}: {item.get('value')}")

    description_word_count = len(token_list(description))
    repeated_description = seo_repeated_terms(description, min_count=3, limit=6)
    missing_description_clusters = []
    for cluster in clusters:
        query = as_text(cluster.get("mainQuery"))
        if query and not term_present(query, description):
            missing_description_clusters.append(query)
        if len(missing_description_clusters) >= 5:
            break
    description_problems = []
    if not description:
        description_problems.append("описание не найдено")
    elif description_word_count < 25:
        description_problems.append("описание короткое и слабо раскрывает сценарии использования")
    if repeated_description:
        description_problems.append("есть риск повторов: " + ", ".join(item["term"] for item in repeated_description[:4]))
    if missing_description_clusters:
        description_problems.append("не раскрыты близкие смыслы: " + ", ".join(missing_description_clusters[:3]))

    return {
        "title": {
            "current": title,
            "primaryCluster": as_text(main_cluster.get("name") or category or "не определен"),
            "mainQuery": main_query,
            "problems": title_problems or ["критичных проблем по публичным данным не найдено"],
            "recommendation": "Собрать название по формуле: тип товара + назначение/пол + 1-2 ключевые фактические особенности.",
            "example": title_example,
        },
        "attributes": {
            "filledCount": len(characteristics),
            "filledGroups": [
                {"group": group, "items": values[:4]}
                for group, values in grouped_characteristics.items()
            ],
            "missing": characteristic_gaps[:6],
            "filterRelated": list(grouped_characteristics.keys()),
            "conflicts": [],
            "recommendation": "Заполнять только фактические характеристики, которые подтверждают фильтры и поисковый смысл карточки.",
        },
        "description": {
            "wordCount": description_word_count,
            "problems": description_problems or ["описание закрывает базовый смысл, но его стоит сверить с продажами по запросам"],
            "repeatedTerms": repeated_description,
            "missingClusters": missing_description_clusters[:5],
            "recommendation": "Писать для покупателя: назначение, свойства, сценарии, ограничения и выгоды без списка ключевых слов.",
        },
    }


def build_seo_funnel(product: dict[str, Any], card_meta: dict[str, Any], relevance_score: int, text_count: int) -> dict[str, Any]:
    impressions = seo_metric_from_sources(product, card_meta, "impressions", "searchImpressions", "funnel.impressions")
    clicks = seo_metric_from_sources(product, card_meta, "clicks", "searchClicks", "funnel.clicks")
    product_views = seo_metric_from_sources(product, card_meta, "productViews", "views", "cardViews", "funnel.productViews")
    add_to_cart = seo_metric_from_sources(product, card_meta, "addToCart", "cartAdds", "baskets", "funnel.addToCart")
    orders = seo_metric_from_sources(product, card_meta, "orders", "searchOrders", "funnel.orders")
    buyouts = seo_metric_from_sources(product, card_meta, "buyouts", "redemptions", "funnel.buyouts")
    revenue = seo_metric_from_sources(product, card_meta, "revenue", "searchRevenue", "funnel.revenue")
    ad_spend = seo_metric_from_sources(product, card_meta, "adSpend", "adsSpend", "advertisingSpend", "funnel.adSpend")
    position = seo_metric_from_sources(product, card_meta, "position", "currentPosition", "organicPosition", "funnel.position")
    ctr = seo_metric_from_sources(product, card_meta, "ctr", "searchCtr", "funnel.ctr") or seo_percent(clicks, impressions)
    cart_conversion = (
        seo_metric_from_sources(product, card_meta, "conversionToCart", "cartConversion", "funnel.conversionToCart")
        or seo_percent(add_to_cart, product_views)
    )
    order_conversion = (
        seo_metric_from_sources(product, card_meta, "conversionToOrder", "orderConversion", "funnel.conversionToOrder")
        or seo_percent(orders, product_views)
    )
    stock = seo_estimated_stock(product)

    stages = [
        {
            "id": "relevance",
            "label": "Запрос → релевантность",
            "metric": "Покрытие карточки",
            "value": f"{relevance_score}%",
            "score": relevance_score,
            "status": seo_status_label(relevance_score),
            "interpretation": "Показывает, насколько публичные тексты карточки подтверждают собранную семантику.",
            "action": "Сверить основной кластер с названием, характеристиками и описанием.",
        },
        {
            "id": "impressions",
            "label": "Релевантность → показы",
            "metric": "Показы / позиция",
            "value": None if impressions is None else f"{int(impressions)} показов",
            "score": None,
            "status": "Недостаточно данных" if impressions is None else "Есть данные",
            "interpretation": "Без показов и позиции нельзя понять, видит ли алгоритм карточку по нужным запросам.",
            "action": "Подключить выгрузку поисковых запросов: запрос, позиция, показы, частотность.",
        },
        {
            "id": "ctr",
            "label": "Показы → клики",
            "metric": "CTR",
            "value": None if ctr is None else f"{ctr}%",
            "score": seo_score_from_percent(ctr, 1.5, 3.0, 6.0),
            "status": seo_status_label(seo_score_from_percent(ctr, 1.5, 3.0, 6.0)),
            "interpretation": "CTR показывает, выбирают ли карточку в выдаче при текущей позиции.",
            "action": "Если позиция есть, но CTR слабый, тестировать первую фотографию, оффер, цену и отличие от конкурентов.",
        },
        {
            "id": "card",
            "label": "Клик → карточка",
            "metric": "Контент и отзывы",
            "value": f"{text_count} текстовых отзывов",
            "score": 82 if text_count >= 50 else 62 if text_count >= 15 else 45,
            "status": seo_status_label(82 if text_count >= 50 else 62 if text_count >= 15 else 45),
            "interpretation": "Отзывы и контент помогают понять, совпадает ли ожидание после клика с реальным товаром.",
            "action": "Закрыть частые возражения в инфографике, описании и характеристиках.",
        },
        {
            "id": "cart",
            "label": "Карточка → корзина",
            "metric": "Конверсия в корзину",
            "value": None if cart_conversion is None else f"{cart_conversion}%",
            "score": seo_score_from_percent(cart_conversion, 2.0, 5.0, 9.0),
            "status": seo_status_label(seo_score_from_percent(cart_conversion, 2.0, 5.0, 9.0)),
            "interpretation": "Если клики есть, но корзин мало, проблема может быть в цене, контенте, характеристиках или доверии.",
            "action": "Подключить просмотры карточки и добавления в корзину по поисковым кластерам.",
        },
        {
            "id": "orders",
            "label": "Корзина → заказ → выкуп",
            "metric": "Заказы / выкупы",
            "value": None if orders is None else f"{int(orders)} заказов",
            "score": seo_score_from_percent(order_conversion, 1.0, 2.5, 5.0),
            "status": seo_status_label(seo_score_from_percent(order_conversion, 1.0, 2.5, 5.0)),
            "interpretation": "SEO нужно масштабировать только после проверки заказов, выкупа и экономики.",
            "action": "Добавить заказы, выручку, выкуп, возвраты и период сравнения.",
        },
    ]

    if impressions is None:
        bottleneck = "Недостаточно данных для определения узкого места воронки: нет показов и позиций по запросам."
    elif clicks is not None and impressions > 0 and (ctr or 0) < 3:
        bottleneck = "Вероятное узкое место: CTR выдачи. Карточка показывается, но получает мало кликов."
    elif product_views is not None and add_to_cart is not None and (cart_conversion or 0) < 5:
        bottleneck = "Вероятное узкое место: конверсия карточки в корзину."
    elif orders is not None and add_to_cart is not None and add_to_cart > 0 and orders / add_to_cart < 0.35:
        bottleneck = "Вероятное узкое место: переход из корзины в заказ."
    else:
        bottleneck = "По доступным данным критичное узкое место не выявлено; нужна детализация по запросам."

    return {
        "metrics": {
            "impressions": impressions,
            "clicks": clicks,
            "productViews": product_views,
            "addToCart": add_to_cart,
            "orders": orders,
            "buyouts": buyouts,
            "revenue": revenue,
            "adSpend": ad_spend,
            "position": position,
            "ctr": ctr,
            "conversionToCart": cart_conversion,
            "conversionToOrder": order_conversion,
            "stock": stock,
        },
        "stages": stages,
        "bottleneck": bottleneck,
    }


def build_seo_module_scores(
    core_count: int,
    card_coverage: int,
    clusters: list[dict[str, Any]],
    title_score: int,
    characteristic_score: int,
    description_score: int,
    funnel: dict[str, Any],
) -> list[dict[str, Any]]:
    has_primary_cluster = any(item.get("status") == "primary" for item in clusters)
    cluster_count = len(clusters)
    semantic_score = round(0.65 * card_coverage + 0.35 * (100 if core_count >= 6 else 70 if core_count >= 3 else 45))
    cluster_score = 84 if has_primary_cluster and 2 <= cluster_count <= 6 else 68 if clusters else 35
    if cluster_count > 7:
        cluster_score = min(cluster_score, 62)

    metrics = funnel.get("metrics") or {}
    ctr_score = seo_score_from_percent(metrics.get("ctr"), 1.5, 3.0, 6.0)
    cart_score = seo_score_from_percent(metrics.get("conversionToCart"), 2.0, 5.0, 9.0)
    order_score = seo_score_from_percent(metrics.get("conversionToOrder"), 1.0, 2.5, 5.0)
    conversion_score = None
    if cart_score is not None or order_score is not None:
        available = [item for item in (cart_score, order_score) if item is not None]
        conversion_score = round(sum(available) / len(available))

    stock = metrics.get("stock")
    logistics_score = None
    if stock is not None:
        logistics_score = 88 if stock >= 30 else 62 if stock > 0 else 25

    return [
        seo_module_item(
            "semantics",
            semantic_score,
            f"Собрано {core_count} поисковых сигналов из категории, характеристик и отзывов; покрытие карточки {card_coverage}%.",
            "Сверить ядро с реальными поисковыми фразами из кабинета WB и убрать нерелевантные запросы.",
            "Рост релевантности по целевым запросам без SEO-спама.",
            confidence="medium",
        ),
        seo_module_item(
            "clusters",
            cluster_score,
            f"Сформировано {cluster_count} кластера(ов); основной кластер {'найден' if has_primary_cluster else 'не определен'} публично.",
            "Выбрать 1 основной кластер и 2-4 близких дополнительных, не смешивать несвязанные намерения.",
            "Более точное название, инфографика и рекламные тесты по одному поисковому смыслу.",
            confidence="medium",
        ),
        seo_module_item(
            "title",
            title_score,
            "Название проверено на главный запрос, длину, повторы и покрытие важных сигналов.",
            "Оставить в начале тип товара и добавить только фактические уточнения без набивки синонимов.",
            "Улучшение считывания товара алгоритмом и покупателем.",
            confidence="medium",
        ),
        seo_module_item(
            "attributes",
            characteristic_score,
            "Характеристики оценены как источник релевантности и попадания в фильтры.",
            "Дозаполнить материал, назначение, размер, цвет, комплектацию и сезонность, если это соответствует товару.",
            "Больше попаданий в фильтры и меньше лишних вопросов у покупателя.",
            confidence="medium",
        ),
        seo_module_item(
            "description",
            description_score,
            "Описание оценено по объему, повторам и раскрытию смыслов.",
            "Раскрыть сценарии использования и выгоды естественным текстом, не списком ключей.",
            "Лучшее совпадение ожиданий после клика и поддержка длинного хвоста запросов.",
            confidence="medium",
        ),
        seo_module_item(
            "ctr",
            ctr_score,
            "CTR нельзя оценить по публичной карточке без показов и кликов.",
            "Подключить поисковую аналитику; при низком CTR тестировать первое фото, оффер, цену и рейтинг относительно TOP-10.",
            "Рост кликов из уже существующей видимости.",
            data_required=[] if ctr_score is not None else ["Показы", "Клики", "Позиция", "Запрос/кластер"],
            confidence="high" if ctr_score is not None else "low",
        ),
        seo_module_item(
            "conversion",
            conversion_score,
            "Конверсию нельзя подтвердить без просмотров, корзин и заказов.",
            "До масштабирования SEO проверить конверсию карточки, цену, отзывы, характеристики, доставку и варианты.",
            "Не тратить трафик на карточку, которая пока плохо продает.",
            data_required=[] if conversion_score is not None else ["Просмотры карточки", "Добавления в корзину", "Заказы", "Выкупы"],
            confidence="high" if conversion_score is not None else "low",
        ),
        seo_module_item(
            "query_sales",
            None,
            "Продажи по конкретным поисковым запросам недоступны из публичной карточки.",
            "Загрузить отчет, где по каждому запросу видны позиции, CTR, корзины, заказы, выручка и конверсия.",
            "Выбор запросов, которые не только дают показы, но реально продают.",
            data_required=["Запрос", "Позиция", "CTR", "Корзины", "Заказы", "Выручка"],
            confidence="low",
        ),
        seo_module_item(
            "ads",
            None,
            "Реклама не анализируется без расходов, ставок, кликов, заказов и органической динамики.",
            "Связать рекламные кампании с выбранными SEO-кластерами и не запускать рекламу только по частотности.",
            "Понимание, усиливает ли реклама органический рост или просто расходует бюджет.",
            data_required=["Расходы", "Ставки", "Клики", "Заказы", "ДРР/ROAS", "Динамика позиции"],
            confidence="low",
        ),
        seo_module_item(
            "logistics",
            logistics_score,
            "Логистика оценена только если публичные данные содержат остатки; сроки доставки по регионам нужны из кабинета.",
            "Проверить остатки по складам, размерам и регионам перед масштабированием продвижения.",
            "SEO-рост не будет упираться в отсутствие товара или долгую доставку.",
            data_required=[] if logistics_score is not None else ["Остатки", "Склады", "Срок доставки", "Out-of-stock", "Размеры/варианты"],
            confidence="medium" if logistics_score is not None else "low",
        ),
    ]


def weighted_seo_score(module_scores: list[dict[str, Any]]) -> tuple[int, int]:
    scored = [item for item in module_scores if item.get("score") is not None]
    total_weight = sum(item.get("weight") or 0 for item in module_scores)
    scored_weight = sum(item.get("weight") or 0 for item in scored)
    if not scored or scored_weight <= 0:
        return 0, 0
    score = round(sum((item.get("score") or 0) * (item.get("weight") or 0) for item in scored) / scored_weight)
    coverage = round(scored_weight * 100 / total_weight) if total_weight else 0
    return int(clamp_photo_value(score)), int(clamp_photo_value(coverage))


def seo_main_problem(module_scores: list[dict[str, Any]], title_audit: list[dict[str, Any]]) -> str:
    critical = [item for item in module_scores if item.get("score") is not None and item.get("score", 100) < 55]
    if critical:
        worst = sorted(critical, key=lambda item: item.get("score") or 0)[0]
        return f"{worst.get('label')}: {worst.get('reason')}"
    missing = [item for item in module_scores if item.get("dataRequired")]
    if missing:
        return f"Для полной SEO-воронки не хватает данных: {', '.join(item.get('label') for item in missing[:3])}."
    audit = [item for item in title_audit if item.get("priority") in ("critical", "high")]
    if audit:
        return audit[0].get("summary") or audit[0].get("label")
    return "Критичных проблем по доступным публичным данным не найдено."


def seo_main_opportunity(clusters: list[dict[str, Any]], missing_keywords: list[dict[str, Any]]) -> str:
    promising = next((item for item in clusters if (item.get("opportunityScore") or 0) >= 75), None)
    if promising:
        return f"Усилить кластер «{promising.get('mainQuery')}» и проверить его по реальным показам, CTR и заказам."
    if missing_keywords:
        return f"Аккуратно добавить релевантный сигнал «{missing_keywords[0].get('term')}» в {as_text(missing_keywords[0].get('where')).lower()}."
    return "Подключить реальные поисковые запросы и найти кластеры с позициями 10-50 и подтвержденными заказами."


def build_seo_data_needs(marketplace_label: str, module_scores: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for item in module_scores:
        required = item.get("dataRequired") or []
        if not required:
            continue
        result.append(
            {
                "module": item.get("label"),
                "fields": required,
                "why": item.get("expectedImpact"),
                "source": f"Кабинет продавца {marketplace_label} / API / ручная выгрузка",
            }
        )
    return result


def build_seo_priority_recommendations(
    marketplace_label: str,
    module_scores: list[dict[str, Any]],
    title_score: int,
    characteristic_gaps: list[dict[str, Any]],
    description_score: int,
    missing_keywords: list[dict[str, Any]],
    negative_terms: list[dict[str, Any]],
    clusters: list[dict[str, Any]],
    score_coverage: int,
) -> list[dict[str, Any]]:
    recommendations: list[dict[str, Any]] = []
    if score_coverage < 75:
        recommendations.append(
            seo_recommendation(
                "seo-data-connect",
                "high",
                "semantics",
                "Подключить реальные данные поисковой воронки",
                f"Сейчас SEO Score рассчитан по публичным данным примерно на {score_coverage}% модели; нет части показов, кликов, заказов, рекламы или логистики.",
                f"Выгрузить из кабинета {marketplace_label}: запросы, частотность, позиции, показы, клики, корзины, заказы, выручку, рекламу и остатки.",
                "Сервис сможет отличать проблему видимости от проблемы CTR или конверсии.",
                effort="medium",
                confidence="high",
                check_after="После загрузки данных проверить главную проблему: показы, CTR, конверсия или логистика.",
            )
        )
    if title_score < 70:
        recommendations.append(
            seo_recommendation(
                "seo-title-rebuild",
                "high",
                "title",
                "Пересобрать название под основной кластер",
                f"Оценка модуля «Название» — {title_score}/100; есть риск слабого считывания главного товарного запроса.",
                "Поставить тип товара в начало и оставить 1-3 фактических уточнения: назначение, материал, размер/объем, цвет или комплектация.",
                "Алгоритм и покупатель быстрее понимают релевантность карточки.",
                effort="low",
                confidence="medium",
            )
        )
    if characteristic_gaps:
        missing_labels = ", ".join(item.get("label", "") for item in characteristic_gaps[:4])
        recommendations.append(
            seo_recommendation(
                "seo-attributes-fill",
                "medium",
                "attributes",
                "Дозаполнить характеристики, влияющие на фильтры",
                f"Не найдены важные группы характеристик: {missing_labels}.",
                "Проверить карточку в кабинете и заполнить только реальные параметры товара, особенно материал, назначение, размер, цвет, комплектацию и сезон.",
                "Больше релевантных попаданий в фильтры и меньше возражений до покупки.",
                effort="medium",
                confidence="medium",
            )
        )
    if description_score < 70:
        recommendations.append(
            seo_recommendation(
                "seo-description-rewrite",
                "medium",
                "description",
                "Усилить описание без SEO-спама",
                f"Оценка описания — {description_score}/100; оно не должно быть списком ключей, но должно раскрывать покупательские сценарии.",
                "Добавить короткие абзацы: для кого товар, где использовать, какие свойства важны, что входит в заказ, какие ограничения важно знать.",
                "Описание поддержит длинный хвост запросов и снизит разрыв ожиданий после клика.",
                effort="low",
                confidence="medium",
            )
        )
    if missing_keywords:
        item = missing_keywords[0]
        recommendations.append(
            seo_recommendation(
                "seo-key-signal",
                "medium",
                "semantics",
                f"Проверить ключевой сигнал «{item.get('term')}»",
                item.get("reason") or "Сигнал найден в семантике, но не полностью закреплен в карточке.",
                item.get("action") or "Добавить сигнал только если он соответствует фактическим свойствам товара.",
                "Карточка лучше закрепляет релевантный поисковый смысл.",
                effort="low",
                confidence="medium",
            )
        )
    if negative_terms:
        term = as_text(negative_terms[0].get("term"))
        recommendations.append(
            seo_recommendation(
                "seo-objection-content",
                "medium",
                "conversion",
                f"Закрыть возражение из отзывов: «{term}»",
                f"Тема повторяется в негативных отзывах {negative_terms[0].get('count')} раз(а). Это может снижать конверсию после клика.",
                "Сделать честный слайд/FAQ-блок: объяснить размер, материал, комплектацию, ограничение или способ использования.",
                "Меньше разочарованных кликов и выше шанс добавления в корзину.",
                effort="medium",
                confidence="medium",
            )
        )
    if clusters:
        cluster = clusters[0]
        recommendations.append(
            seo_recommendation(
                "seo-cluster-test",
                "low",
                "clusters",
                f"Проверить перспективность кластера «{cluster.get('mainQuery')}»",
                "Кластер выделен эвристически из карточки и отзывов, но без частотности и заказов это гипотеза.",
                "Сравнить кластер с отчетом по поисковым запросам: позиции 10-50, CTR не ниже среднего, есть корзины/заказы.",
                "Можно найти точку роста, где карточка уже релевантна и способна расти.",
                effort="medium",
                confidence="low",
            )
        )
    return sorted(recommendations, key=seo_priority_sort_key)[:6]


def seo_priority_from_score(score: int | float | None) -> str:
    value = safe_float(score)
    if value is None:
        return "medium"
    if value < 55:
        return "high"
    if value < 78:
        return "medium"
    return "low"


def seo_issue(
    issue_id: str,
    label: str,
    score: int | float,
    summary: str,
    action: str,
    priority: str | None = None,
) -> dict[str, Any]:
    clean_score = int(round(clamp_photo_value(float(score))))
    item_priority = priority or seo_priority_from_score(clean_score)
    return {
        "id": issue_id,
        "label": label,
        "score": clean_score,
        "status": seo_status(clean_score),
        "priority": item_priority,
        "priorityLabel": priority_label(item_priority),
        "summary": summary,
        "action": action,
    }


def seo_add_candidate(
    items: list[dict[str, Any]],
    seen: set[str],
    phrase: str,
    source: str,
    weight: int,
    title_text: str,
    card_text: str,
    intent: str,
    count: int | None = None,
) -> None:
    clean = short_text(as_text(phrase), 64).strip(" -–—,.;:")
    if len(clean) < 3:
        return
    tokens = token_list(clean)
    if not tokens:
        return
    key = normalize_opinion(clean)
    if key in seen:
        return
    seen.add(key)
    in_title = term_present(clean, title_text)
    in_card = term_present(clean, card_text)
    priority = "high" if weight >= 90 and not in_title else "medium" if not in_card else "low"
    items.append(
        {
            "term": clean,
            "source": source,
            "intent": intent,
            "weight": weight,
            "count": count,
            "inTitle": in_title,
            "inCard": in_card,
            "priority": priority,
            "priorityLabel": priority_label(priority),
        }
    )


def seo_characteristic_terms(characteristics: list[dict[str, str]], category: str) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for item in characteristics:
        group = seo_characteristic_group(item.get("name", ""))
        if group == "Прочее":
            continue
        raw_value = as_text(item.get("value"))
        parts = re.split(r"\s*[;,/]\s*|\s+и\s+", raw_value)
        for part in parts[:4]:
            text = short_text(part, 42).strip(" -–—,.;:")
            if len(token_list(text)) == 0:
                continue
            result.append(
                {
                    "term": text,
                    "group": group,
                    "source": f"{item.get('name')}: {item.get('source')}",
                }
            )
            if category and len(token_list(text)) <= 2:
                result.append(
                    {
                        "term": f"{text} {category}",
                        "group": group,
                        "source": f"{item.get('name')}: {item.get('source')}",
                    }
                )
    return result


def build_seo_analysis(
    product: dict[str, Any],
    card_meta: dict[str, Any] | None,
    positive_sentences: list[str],
    negative_sentences: list[str],
    neutral_sentences: list[str],
    text_count: int,
) -> dict[str, Any]:
    card_meta = card_meta or {}
    title = as_text(card_meta.get("imt_name") or product.get("name"))
    category = as_text(product.get("entity") or card_meta.get("subj_name"))
    brand = as_text(product.get("brand"))
    description = as_text(card_meta.get("description"))
    marketplace = product.get("_marketplace") or MARKETPLACE_WB
    marketplace_label = "Ozon" if marketplace == MARKETPLACE_OZON else "WB"
    characteristics = product_characteristic_items(product, card_meta)
    characteristic_text = " ".join(f"{item.get('name')} {item.get('value')}" for item in characteristics)
    card_text = " ".join(part for part in (title, category, brand, description, characteristic_text) if part)

    semantic_core: list[dict[str, Any]] = []
    seen_terms: set[str] = set()
    if category:
        seo_add_candidate(semantic_core, seen_terms, category, "Категория карточки", 100, title, card_text, "Базовый товарный запрос")

    for item in seo_characteristic_terms(characteristics, category)[:12]:
        weight = 88 if item["group"] in ("Тип/категория", "Материал/состав", "Назначение") else 74
        seo_add_candidate(
            semantic_core,
            seen_terms,
            item["term"],
            item["source"],
            weight,
            title,
            card_text,
            item["group"],
        )

    for item in top_terms(positive_sentences + neutral_sentences, 10):
        term = as_text(item.get("term"))
        if len(token_list(term)) > 3:
            continue
        seo_add_candidate(
            semantic_core,
            seen_terms,
            term,
            "Отзывы покупателей",
            66,
            title,
            card_text,
            "Слова покупателей",
            safe_int(item.get("count")),
        )

    semantic_core.sort(key=lambda item: (item.get("weight", 0), item.get("count") or 0), reverse=True)
    semantic_core = semantic_core[:18]
    core_count = len(semantic_core)
    in_title_count = sum(1 for item in semantic_core if item.get("inTitle"))
    in_card_count = sum(1 for item in semantic_core if item.get("inCard"))
    title_coverage = round(in_title_count * 100 / core_count) if core_count else 0
    card_coverage = round(in_card_count * 100 / core_count) if core_count else 0

    title_len = len(title)
    if 55 <= title_len <= 135:
        title_length_score = 100
        title_length_summary = "Название достаточно информативное и не выглядит чрезмерно длинным."
    elif 35 <= title_len < 55 or 135 < title_len <= 170:
        title_length_score = 68
        title_length_summary = "Название можно уплотнить: оставить ключевой товарный запрос и самые важные уточнения."
    else:
        title_length_score = 42
        title_length_summary = "Название выглядит слишком коротким или перегруженным для уверенного считывания."

    category_score = 100 if category and term_present(category, title) else 45 if category else 58
    title_semantic_score = title_coverage
    characteristic_score = 100 if len(characteristics) >= 8 else 78 if len(characteristics) >= 5 else 48
    buyer_language_score = 100
    review_terms = top_terms(positive_sentences + negative_sentences + neutral_sentences, 8)
    if review_terms:
        used_review_terms = sum(1 for item in review_terms if term_present(as_text(item.get("term")), card_text))
        buyer_language_score = round(used_review_terms * 100 / len(review_terms))
    description_score = 92 if len(token_list(description)) >= 25 else 68 if description else 42
    title_repeats = seo_repeated_terms(title, min_count=2, limit=4)
    title_repeat_score = 100 if not title_repeats else 62 if len(title_repeats) <= 2 else 42
    description_repeats = seo_repeated_terms(description, min_count=3, limit=6)
    if description_repeats:
        description_score = min(description_score, 64)
    title_score = round(
        0.32 * category_score
        + 0.24 * title_length_score
        + 0.28 * title_semantic_score
        + 0.16 * title_repeat_score
    )

    title_audit = [
        seo_issue(
            "title-category",
            "Главный товарный запрос",
            category_score,
            f"Категория: {category or 'не определена'}.",
            "Поставить тип товара ближе к началу названия, чтобы алгоритм и покупатель сразу считывали, что продается.",
        ),
        seo_issue(
            "title-length",
            "Длина названия",
            title_length_score,
            title_length_summary,
            "Собрать название по формуле: тип товара + важный параметр + материал/состав + назначение/сценарий.",
        ),
        seo_issue(
            "title-semantic",
            "Покрытие семантики в названии",
            title_semantic_score,
            f"В названии есть {in_title_count} из {core_count} важных SEO-сигналов.",
            "Добавить 2-4 недостающих ключевых уточнения без повторов и рекламного шума.",
        ),
        seo_issue(
            "title-repeats",
            "Повторы в названии",
            title_repeat_score,
            "Повторов значимых слов не найдено." if not title_repeats else "Есть повторы: " + ", ".join(item["term"] for item in title_repeats),
            "Убрать лишние повторы и синонимы, оставить читаемую формулу: тип товара + назначение + ключевая особенность.",
        ),
        seo_issue(
            "characteristics",
            "Заполненность характеристик",
            characteristic_score,
            f"Найдено {len(characteristics)} характеристик, пригодных для SEO и ХПВ.",
            "Заполнить характеристики, которые помогают фильтрам и поиску: материал, назначение, размер, цвет, комплектация, сезон.",
        ),
        seo_issue(
            "buyer-language",
            "Слова покупателей",
            buyer_language_score,
            f"Проверено {len(review_terms)} частых слов из отзывов.",
            "Использовать повторяющиеся слова покупателей в инфографике, описании и ответах на вопросы.",
        ),
        seo_issue(
            "description",
            "Описание",
            description_score,
            "Описание помогает закрепить смысл карточки, но не заменяет название и характеристики.",
            "В описании дать 3-5 коротких выгод: для кого товар, какой сценарий, какие ограничения и что входит в заказ.",
        ),
    ]

    missing_keywords = []
    for item in semantic_core:
        if item.get("inTitle") and item.get("inCard"):
            continue
        where = "Название" if not item.get("inTitle") and item.get("weight", 0) >= 74 else "Характеристики/описание"
        if not item.get("inCard"):
            where = "Название и характеристики"
        reason = "Есть в карточке, но не усилено в названии." if item.get("inCard") else "Не найдено в основных текстах карточки."
        missing_keywords.append(
            {
                "term": item.get("term"),
                "source": item.get("source"),
                "intent": item.get("intent"),
                "where": where,
                "priority": item.get("priority") or "medium",
                "priorityLabel": priority_label(item.get("priority") or "medium"),
                "reason": reason,
                "action": f"Аккуратно добавить «{item.get('term')}» в {where.lower()}, если это точно соответствует товару.",
            }
        )
        if len(missing_keywords) >= 8:
            break

    present_groups = {seo_characteristic_group(item.get("name", "")) for item in characteristics}
    characteristic_gaps = []
    for label, _patterns in SEO_PRIORITY_CHARACTERISTICS:
        if label in present_groups:
            continue
        characteristic_gaps.append(
            {
                "label": label,
                "priority": "high" if label in ("Материал/состав", "Назначение", "Размер/объем") else "medium",
                "priorityLabel": priority_label("high" if label in ("Материал/состав", "Назначение", "Размер/объем") else "medium"),
                "action": f"Проверить, можно ли заполнить характеристику «{label}» в карточке. Она помогает фильтрам и снижает лишние вопросы.",
            }
        )

    negative_terms = top_terms(negative_sentences, 6)
    content_tasks = []
    for item in missing_keywords[:5]:
        content_tasks.append(
            {
                "title": f"Добавить ключ «{item.get('term')}»",
                "priority": item.get("priority") or "medium",
                "priorityLabel": item.get("priorityLabel") or "Средний",
                "block": item.get("where"),
                "action": item.get("action"),
                "reason": item.get("reason"),
            }
        )
    for item in negative_terms[:3]:
        term = as_text(item.get("term"))
        if not term:
            continue
        content_tasks.append(
            {
                "title": f"Закрыть возражение «{term}»",
                "priority": "high",
                "priorityLabel": priority_label("high"),
                "block": "Инфографика/FAQ",
                "action": f"Добавить слайд или короткий блок, который честно объясняет тему «{term}»: размер, материал, комплектацию или ограничение.",
                "reason": f"Это повторяется в негативных отзывах {item.get('count')} раз(а), значит влияет на ожидания и конверсию.",
            }
        )

    query_ideas = []
    for item in semantic_core:
        term = as_text(item.get("term"))
        if not term:
            continue
        if category and normalize_opinion(term) != normalize_opinion(category) and len(token_list(term)) <= 2:
            query_ideas.append(f"{category} {term}")
        else:
            query_ideas.append(term)
    query_ideas = unique_texts(query_ideas, 10)

    p0_audit = build_card_seo_p0(product, card_meta, semantic_core, title, category, description)
    title_score = p0_audit["titleEvaluation"]["score"]
    characteristic_score = p0_audit["attributesEvaluation"]["score"]
    description_score = p0_audit["descriptionEvaluation"]["score"]
    clusters = (p0_audit.get("semanticPlacement") or {}).get("clusters") or build_seo_clusters(semantic_core)
    card_audit = build_seo_card_audit(
        title,
        category,
        characteristics,
        characteristic_gaps,
        description,
        semantic_core,
        clusters,
    )
    funnel = build_seo_funnel(product, card_meta, card_coverage, text_count)
    module_scores = build_seo_module_scores(
        core_count,
        card_coverage,
        clusters,
        title_score,
        characteristic_score,
        description_score,
        funnel,
    )
    funnel_score, score_coverage = weighted_seo_score(module_scores)
    score = p0_audit["score"]
    data_needs = build_seo_data_needs(marketplace_label, module_scores)
    funnel_recommendations = build_seo_priority_recommendations(
        marketplace_label,
        module_scores,
        title_score,
        characteristic_gaps,
        description_score,
        missing_keywords,
        negative_terms,
        clusters,
        score_coverage,
    )
    priority_recommendations = []
    seen_recommendations: set[str] = set()
    for item in (p0_audit.get("recommendations") or []) + funnel_recommendations:
        rec_id = as_text(item.get("id") or item.get("problem"))
        if rec_id and rec_id in seen_recommendations:
            continue
        if rec_id:
            seen_recommendations.add(rec_id)
        priority_recommendations.append(item)
        if len(priority_recommendations) >= 8:
            break
    recommendations = priority_recommendations[:4]

    return {
        "ok": True,
        "score": score,
        "scoreLabel": card_seo_score_label(score),
        "summary": (
            f"{card_seo_score_label(score)}: {p0_audit.get('summary')} "
            f"Полнота расширенной SEO-модели {score_coverage}%."
        ),
        "marketplaceLabel": marketplace_label,
        "title": title,
        "category": category,
        "titleLength": title_len,
        "cardSeoScore": score,
        "cardSeoScoreLabel": card_seo_score_label(score),
        "funnelScore": funnel_score,
        "scoreCoverage": score_coverage,
        "semanticCoverageTitle": title_coverage,
        "semanticCoverageCard": card_coverage,
        "characteristicsCount": len(characteristics),
        "reviewTextCount": text_count,
        "mainProblem": p0_audit.get("mainProblem") or seo_main_problem(module_scores, title_audit),
        "mainOpportunity": p0_audit.get("mainOpportunity") or seo_main_opportunity(clusters, missing_keywords),
        "p0Audit": p0_audit,
        "titleEvaluation": p0_audit.get("titleEvaluation"),
        "attributesEvaluation": p0_audit.get("attributesEvaluation"),
        "descriptionEvaluation": p0_audit.get("descriptionEvaluation"),
        "consistency": p0_audit.get("consistency"),
        "semanticPlacement": p0_audit.get("semanticPlacement"),
        "moduleScores": module_scores,
        "funnel": funnel,
        "clusters": clusters,
        "cardAudit": card_audit,
        "dataNeeds": data_needs,
        "priorityRecommendations": priority_recommendations,
        "titleAudit": title_audit,
        "semanticCore": semantic_core,
        "missingKeywords": missing_keywords,
        "characteristicGaps": characteristic_gaps[:6],
        "queryIdeas": query_ideas,
        "contentTasks": content_tasks[:8],
        "recommendations": recommendations[:4],
        "sourceNote": (
            "SEO-анализ строится по публичной карточке и отзывам. "
            f"Для полной воронки нужны поисковые запросы, показы, клики, заказы, реклама и логистика из аналитики {marketplace_label}."
        ),
    }


def xlsx_col(index: int) -> str:
    result = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        result = chr(65 + remainder) + result
    return result


def xlsx_ref(row_count: int, col_count: int) -> str:
    if row_count <= 0 or col_count <= 0:
        return "A1"
    return f"A1:{xlsx_col(col_count)}{row_count}"


def xlsx_text(value: Any, style: int | None = None) -> dict[str, Any]:
    return {"value": "" if value is None else str(value), "type": "text", "style": style}


def xlsx_number(value: Any, style: int | None = None) -> dict[str, Any]:
    number = safe_float(value)
    return {"value": "" if number is None else number, "type": "number", "style": style}


def xlsx_date(value: Any, style: int | None = None) -> dict[str, Any]:
    text = as_text(value)
    if not text:
        return xlsx_text("", style)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        try:
            parsed = datetime.fromisoformat(text[:10])
        except ValueError:
            return xlsx_text(text[:10], style)
    base = datetime(1899, 12, 30, tzinfo=timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    serial = (parsed.astimezone(timezone.utc) - base).total_seconds() / 86400
    return {"value": serial, "type": "number", "style": style or 5}


def xlsx_percent(value: Any, style: int | None = None) -> dict[str, Any]:
    number = safe_float(value)
    if number is None:
        return xlsx_text("", style)
    if number > 1:
        number = number / 100
    return {"value": number, "type": "number", "style": style or 6}


def xlsx_header_row(headers: list[str]) -> list[dict[str, Any]]:
    return [xlsx_text(header, 1) for header in headers]


def xlsx_cell_xml(cell: dict[str, Any], cell_ref: str) -> str:
    value = cell.get("value", "")
    style = cell.get("style")
    style_attr = f' s="{style}"' if style is not None else ""
    if value == "":
        return f'<c r="{cell_ref}"{style_attr}/>'
    if cell.get("type") == "number":
        return f'<c r="{cell_ref}"{style_attr}><v>{value}</v></c>'
    escaped = xml_escape(str(value))
    return f'<c r="{cell_ref}" t="inlineStr"{style_attr}><is><t>{escaped}</t></is></c>'


def xlsx_worksheet_xml(
    rows: list[list[dict[str, Any]]],
    widths: list[float] | None = None,
    freeze_header: bool = True,
    auto_filter: bool = True,
) -> str:
    row_count = len(rows)
    col_count = max((len(row) for row in rows), default=1)
    dimension = xlsx_ref(row_count, col_count)
    cols_xml = ""
    if widths:
        cols = []
        for index, width in enumerate(widths, start=1):
            cols.append(f'<col min="{index}" max="{index}" width="{width}" customWidth="1"/>')
        cols_xml = "<cols>" + "".join(cols) + "</cols>"

    sheet_views = ""
    if freeze_header and row_count > 1:
        sheet_views = (
            '<sheetViews><sheetView workbookViewId="0">'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            "</sheetView></sheetViews>"
        )
    else:
        sheet_views = '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'

    sheet_rows = []
    for row_index, row in enumerate(rows, start=1):
        cells = []
        for col_index in range(1, col_count + 1):
            cell = row[col_index - 1] if col_index <= len(row) else xlsx_text("")
            cells.append(xlsx_cell_xml(cell, f"{xlsx_col(col_index)}{row_index}"))
        sheet_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')

    filter_xml = f'<autoFilter ref="{dimension}"/>' if auto_filter and row_count > 1 and col_count > 1 else ""
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        f'<dimension ref="{dimension}"/>'
        f"{sheet_views}"
        '<sheetFormatPr defaultRowHeight="15"/>'
        f"{cols_xml}"
        f'<sheetData>{"".join(sheet_rows)}</sheetData>'
        f"{filter_xml}"
        "</worksheet>"
    )


def xlsx_styles_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="2">
    <numFmt numFmtId="164" formatCode="yyyy-mm-dd"/>
    <numFmt numFmtId="165" formatCode="0.0%"/>
  </numFmts>
  <fonts count="3">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font>
    <font><b/><sz val="14"/><name val="Calibri"/></font>
  </fonts>
  <fills count="4">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF245F73"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFEFF4F0"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFD9DFD8"/></left><right style="thin"><color rgb="FFD9DFD8"/></right><top style="thin"><color rgb="FFD9DFD8"/></top><bottom style="thin"><color rgb="FFD9DFD8"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="8">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
    <xf numFmtId="2" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
    <xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def workbook_xml(sheet_names: list[str]) -> str:
    sheets_xml = []
    for index, name in enumerate(sheet_names, start=1):
        sheets_xml.append(
            f'<sheet name="{xml_escape(name)}" sheetId="{index}" r:id="rId{index}"/>'
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheets>{"".join(sheets_xml)}</sheets>'
        "</workbook>"
    )


def workbook_rels_xml(sheet_count: int) -> str:
    rels = []
    for index in range(1, sheet_count + 1):
        rels.append(
            f'<Relationship Id="rId{index}" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
            f'Target="worksheets/sheet{index}.xml"/>'
        )
    rels.append(
        f'<Relationship Id="rId{sheet_count + 1}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/>'
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'{"".join(rels)}'
        "</Relationships>"
    )


def content_types_xml(sheet_count: int) -> str:
    overrides = [
        '<Override PartName="/xl/workbook.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
        '<Override PartName="/docProps/core.xml" '
        'ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
        '<Override PartName="/docProps/app.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
    ]
    for index in range(1, sheet_count + 1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{index}.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        f'{"".join(overrides)}'
        "</Types>"
    )


def root_rels_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" '
        'Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" '
        'Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" '
        'Target="docProps/app.xml"/>'
        "</Relationships>"
    )


def core_props_xml() -> str:
    created = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        "<dc:creator>WB Review Analyzer</dc:creator>"
        "<cp:lastModifiedBy>WB Review Analyzer</cp:lastModifiedBy>"
        f'<dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created>'
        f'<dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified>'
        "</cp:coreProperties>"
    )


def app_props_xml(sheet_names: list[str]) -> str:
    titles = "".join(f'<vt:lpstr>{xml_escape(name)}</vt:lpstr>' for name in sheet_names)
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        "<Application>WB Review Analyzer</Application>"
        f"<Worksheets>{len(sheet_names)}</Worksheets>"
        '<TitlesOfParts><vt:vector size="'
        f'{len(sheet_names)}" baseType="lpstr">{titles}</vt:vector></TitlesOfParts>'
        "</Properties>"
    )


def evidence_to_text(evidence: list[dict[str, Any]]) -> str:
    parts = []
    for item in evidence[:3]:
        rating = f"{item.get('rating')}★" if item.get("rating") else "без оценки"
        date = f", {item.get('date')}" if item.get("date") else ""
        parts.append(f"{rating}{date}: {item.get('text')}")
    return " | ".join(parts)


def terms_to_text(terms: list[Any]) -> str:
    if not terms:
        return ""
    if isinstance(terms[0], dict):
        return ", ".join(f"{item.get('term')} ({item.get('count')})" for item in terms)
    return ", ".join(str(term) for term in terms)


def recommendation_rows(recommendations: dict[str, list[dict[str, Any]]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "Раздел",
                "Приоритет",
                "Блок",
                "Аспект",
                "Рекомендация",
                "Что сделать",
                "Почему",
                "Примеры из отзывов",
            ]
        )
    ]
    sections = [
        ("Что сделать сначала", recommendations.get("priorityActions") or []),
        ("Контент карточки", recommendations.get("content") or []),
        ("Товар и поставка", recommendations.get("product") or []),
    ]
    for section, items in sections:
        for item in items:
            rows.append(
                [
                    xlsx_text(section, 2),
                    xlsx_text(item.get("priorityLabel"), 2),
                    xlsx_text("Товар" if item.get("area") == "product" else "Контент", 2),
                    xlsx_text(item.get("aspect"), 2),
                    xlsx_text(item.get("title"), 2),
                    xlsx_text(item.get("action"), 2),
                    xlsx_text(item.get("reason"), 2),
                    xlsx_text(evidence_to_text(item.get("evidence") or []), 2),
                ]
            )
    return rows


def hpv_rows(items: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "Источник",
                "Приоритет",
                "Аспект",
                "Характеристика",
                "Преимущество",
                "Выгода",
                "Текст для карточки",
                "Текст для инфографики",
                "Почему",
            ]
        )
    ]
    for item in items:
        rows.append(
            [
                xlsx_text(item.get("source"), 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("aspect"), 2),
                xlsx_text(item.get("characteristic"), 2),
                xlsx_text(item.get("advantage"), 2),
                xlsx_text(item.get("benefit"), 2),
                xlsx_text(item.get("cardText"), 2),
                xlsx_text(item.get("infographicText"), 2),
                xlsx_text(item.get("why"), 2),
            ]
        )
    if len(rows) == 1:
        rows.append([xlsx_text("Нет данных для ХПВ-рекомендаций.", 2)])
    return rows


def photo_rows(photo: dict[str, Any] | None) -> list[list[dict[str, Any]]]:
    photo = photo or {}
    rows = [
        xlsx_header_row(["Тип", "Показатель", "Балл/значение", "Статус", "Диагноз", "Что сделать", "Доказательства"]),
    ]
    if not photo:
        rows.append([xlsx_text("Нет данных по первому фото.", 2)])
        return rows

    rows.append(
        [
            xlsx_text("Итог", 2),
            xlsx_text(photo.get("scoreLabel"), 2),
            xlsx_number(photo.get("score"), 4),
            xlsx_text(photo.get("status"), 2),
            xlsx_text(photo.get("summary"), 2),
            xlsx_text("", 2),
            xlsx_text(photo.get("sourceUrl"), 2),
        ]
    )
    for item in photo.get("criteria") or []:
        rows.append(
            [
                xlsx_text("Критерий", 2),
                xlsx_text(item.get("label"), 2),
                xlsx_number(item.get("score"), 4),
                xlsx_text(item.get("status"), 2),
                xlsx_text(item.get("summary"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text("; ".join(item.get("evidence") or []), 2),
            ]
        )
    for item in photo.get("metricCards") or []:
        value = item.get("value")
        unit = item.get("unit") or ""
        rows.append(
            [
                xlsx_text("Метрика", 2),
                xlsx_text(item.get("label"), 2),
                xlsx_text(f"{value}{unit}" if value is not None else "", 2),
                xlsx_text(item.get("verdict"), 2),
                xlsx_text("", 2),
                xlsx_text("", 2),
                xlsx_text("", 2),
            ]
        )
    for item in photo.get("recommendations") or []:
        rows.append(
            [
                xlsx_text("Рекомендация", 2),
                xlsx_text(item.get("title"), 2),
                xlsx_text("", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("reason"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text("", 2),
            ]
        )
    return rows


def seo_rows(seo: dict[str, Any] | None) -> list[list[dict[str, Any]]]:
    return [
        xlsx_header_row(["Раздел", "Статус", "Комментарий"]),
        [
            xlsx_text("SEO", 2),
            xlsx_text("На доработке", 2),
            xlsx_text("Блок SEO на доработке.", 2),
        ],
    ]
    seo = seo or {}
    rows = [
        xlsx_header_row(["Тип", "Приоритет", "Элемент", "Балл/статус", "Что сделать", "Почему", "Источник"]),
    ]
    if not seo:
        rows.append([xlsx_text("Нет данных по SEO.", 2)])
        return rows

    rows.append(
        [
            xlsx_text("Итог", 2),
            xlsx_text(seo.get("scoreLabel"), 2),
            xlsx_text("SEO карточки", 2),
            xlsx_number(seo.get("score"), 4),
            xlsx_text(seo.get("summary"), 2),
            xlsx_text(seo.get("sourceNote"), 2),
            xlsx_text(seo.get("marketplaceLabel"), 2),
        ]
    )
    rows.append(
        [
            xlsx_text("Главная проблема", 2),
            xlsx_text("", 2),
            xlsx_text("SEO-воронка", 2),
            xlsx_text(f"полнота {seo.get('scoreCoverage')}%", 2),
            xlsx_text(seo.get("mainOpportunity"), 2),
            xlsx_text(seo.get("mainProblem"), 2),
            xlsx_text("Модульная диагностика", 2),
        ]
    )
    p0 = seo.get("p0Audit") or {}
    if p0:
        title_eval = p0.get("titleEvaluation") or {}
        attributes_eval = p0.get("attributesEvaluation") or {}
        description_eval = p0.get("descriptionEvaluation") or {}
        rows.append(
            [
                xlsx_text("P0 Score", 2),
                xlsx_text(p0.get("scoreLabel"), 2),
                xlsx_text("Наименование / характеристики / описание", 2),
                xlsx_number(p0.get("score"), 4),
                xlsx_text(p0.get("mainOpportunity"), 2),
                xlsx_text(p0.get("mainProblem"), 2),
                xlsx_text("Формула 30/40/30", 2),
            ]
        )
        for label, evaluation in (
            ("Наименование", title_eval),
            ("Характеристики", attributes_eval),
            ("Описание", description_eval),
        ):
            rows.append(
                [
                    xlsx_text("P0 модуль", 2),
                    xlsx_text(card_seo_score_label(evaluation.get("score")), 2),
                    xlsx_text(label, 2),
                    xlsx_number(evaluation.get("score"), 4),
                    xlsx_text(evaluation.get("recommendedActionLabel") or evaluation.get("suggestedTitle") or evaluation.get("suggestedDescription"), 2),
                    xlsx_text("; ".join(item.get("title", "") for item in evaluation.get("issues") or []) or "Критичных замечаний нет", 2),
                    xlsx_text("P0 SEO-аудит", 2),
                ]
            )
        for item in (p0.get("semanticPlacement") or {}).get("items") or []:
            rows.append(
                [
                    xlsx_text("Размещение семантики", 2),
                    xlsx_text(item.get("relevanceLabel"), 2),
                    xlsx_text(item.get("query"), 2),
                    xlsx_text(item.get("placementLabel"), 2),
                    xlsx_text(item.get("status"), 2),
                    xlsx_text(item.get("reason"), 2),
                    xlsx_text(item.get("cluster"), 2),
                ]
            )
        for item in attributes_eval.get("rows") or []:
            rows.append(
                [
                    xlsx_text("P0 характеристика", 2),
                    xlsx_text(item.get("seoImportance"), 2),
                    xlsx_text(item.get("attributeName"), 2),
                    xlsx_text(item.get("status"), 2),
                    xlsx_text(item.get("recommendation"), 2),
                    xlsx_text(item.get("value"), 2),
                    xlsx_text(item.get("group"), 2),
                ]
            )
        for item in (p0.get("consistency") or {}).get("conflicts") or []:
            rows.append(
                [
                    xlsx_text("Противоречие", 2),
                    xlsx_text(item.get("severity"), 2),
                    xlsx_text(item.get("group"), 2),
                    xlsx_text(f"confidence {item.get('confidence')}", 2),
                    xlsx_text("Исправить поле, где значение указано неверно.", 2),
                    xlsx_text(item.get("description"), 2),
                    xlsx_text(f"{item.get('fieldA')} / {item.get('fieldB')}", 2),
                ]
            )
    for item in seo.get("moduleScores") or []:
        score = item.get("score")
        rows.append(
            [
                xlsx_text("Модуль", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("label"), 2),
                xlsx_text(f"{score}/100, {item.get('status')}" if score is not None else item.get("status"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text(item.get("reason"), 2),
                xlsx_text("; ".join(item.get("dataRequired") or []) or f"вес {item.get('weight')}%", 2),
            ]
        )
    for item in (seo.get("funnel") or {}).get("stages") or []:
        rows.append(
            [
                xlsx_text("Воронка", 2),
                xlsx_text(item.get("status"), 2),
                xlsx_text(item.get("label"), 2),
                xlsx_text(item.get("value") or "нет данных", 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text(item.get("interpretation"), 2),
                xlsx_text(item.get("metric"), 2),
            ]
        )
    for item in seo.get("clusters") or []:
        rows.append(
            [
                xlsx_text("Кластер", 2),
                xlsx_text(item.get("statusLabel"), 2),
                xlsx_text(item.get("name"), 2),
                xlsx_text(f"Opportunity {item.get('opportunityScore')}/100", 2),
                xlsx_text(f"Проверить главный запрос: {item.get('mainQuery')}", 2),
                xlsx_text(f"Запросов в кластере: {len(item.get('queries') or [])}", 2),
                xlsx_text(item.get("sourceNote"), 2),
            ]
        )
    for item in seo.get("priorityRecommendations") or []:
        rows.append(
            [
                xlsx_text("Рекомендация", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("moduleLabel"), 2),
                xlsx_text(item.get("confidenceLabel"), 2),
                xlsx_text(item.get("recommendation"), 2),
                xlsx_text(f"{item.get('problem')} | {item.get('evidence')}", 2),
                xlsx_text(f"Эффект: {item.get('expectedImpact')} | Проверить: {item.get('checkAfter')}", 2),
            ]
        )
    for item in seo.get("dataNeeds") or []:
        rows.append(
            [
                xlsx_text("Нужны данные", 2),
                xlsx_text("Высокий", 2),
                xlsx_text(item.get("module"), 2),
                xlsx_text("; ".join(item.get("fields") or []), 2),
                xlsx_text("Подключить API или ручную выгрузку из кабинета продавца.", 2),
                xlsx_text(item.get("why"), 2),
                xlsx_text(item.get("source"), 2),
            ]
        )
    for item in seo.get("titleAudit") or []:
        rows.append(
            [
                xlsx_text("Аудит", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("label"), 2),
                xlsx_text(f"{item.get('score')}/100, {item.get('status')}", 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text(item.get("summary"), 2),
                xlsx_text("Название/карточка", 2),
            ]
        )
    for item in seo.get("missingKeywords") or []:
        rows.append(
            [
                xlsx_text("Ключ", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("term"), 2),
                xlsx_text(item.get("where"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text(item.get("reason"), 2),
                xlsx_text(item.get("source"), 2),
            ]
        )
    for item in seo.get("characteristicGaps") or []:
        rows.append(
            [
                xlsx_text("Характеристика", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("label"), 2),
                xlsx_text("не найдена", 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text("Параметр может помогать фильтрам и поиску.", 2),
                xlsx_text("Карточка товара", 2),
            ]
        )
    for item in seo.get("contentTasks") or []:
        rows.append(
            [
                xlsx_text("Задача", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("title"), 2),
                xlsx_text(item.get("block"), 2),
                xlsx_text(item.get("action"), 2),
                xlsx_text(item.get("reason"), 2),
                xlsx_text("SEO-рекомендация", 2),
            ]
        )
    for item in seo.get("semanticCore") or []:
        rows.append(
            [
                xlsx_text("Семантика", 2),
                xlsx_text(item.get("priorityLabel"), 2),
                xlsx_text(item.get("term"), 2),
                xlsx_text("в названии" if item.get("inTitle") else "нет в названии", 2),
                xlsx_text("Использовать только если термин точно соответствует товару.", 2),
                xlsx_text(item.get("intent"), 2),
                xlsx_text(item.get("source"), 2),
            ]
        )
    return rows


def aspect_rows(title: str, items: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "Аспект",
                "Упоминания",
                "Позитивные",
                "Негативные",
                "Баланс",
                "Частые слова",
                "Кратко",
                "Примеры из отзывов",
            ]
        )
    ]
    for item in items:
        rows.append(
            [
                xlsx_text(item.get("title"), 2),
                xlsx_number(item.get("mentions"), 4),
                xlsx_number(item.get("positiveMentions"), 4),
                xlsx_number(item.get("negativeMentions"), 4),
                xlsx_number(item.get("balance"), 4),
                xlsx_text(terms_to_text(item.get("terms") or []), 2),
                xlsx_text(item.get("summary"), 2),
                xlsx_text(evidence_to_text(item.get("evidence") or []), 2),
            ]
        )
    if len(rows) == 1:
        rows.append([xlsx_text(f"Нет данных для листа «{title}».", 2)])
    return rows


def topics_rows(terms: dict[str, list[dict[str, Any]]]) -> list[list[dict[str, Any]]]:
    rows = [xlsx_header_row(["Тип", "Тема", "Количество"])]
    labels = {"positive": "Часто хвалят", "negative": "Часто критикуют", "neutral": "Нейтральные темы"}
    for key in ("positive", "negative", "neutral"):
        for item in terms.get(key) or []:
            rows.append([xlsx_text(labels[key], 2), xlsx_text(item.get("term"), 2), xlsx_number(item.get("count"), 4)])
    return rows


def examples_rows(examples: dict[str, list[dict[str, Any]]]) -> list[list[dict[str, Any]]]:
    rows = [xlsx_header_row(["Тип", "Оценка", "Дата", "Цвет", "Размер", "Текст"])]
    labels = {"positive": "Плюс", "negative": "Минус"}
    for key in ("positive", "negative"):
        for item in examples.get(key) or []:
            rows.append(
                [
                    xlsx_text(labels[key], 2),
                    xlsx_number(item.get("rating"), 4),
                    xlsx_date(item.get("date")),
                    xlsx_text(item.get("color"), 2),
                    xlsx_text(item.get("size"), 2),
                    xlsx_text(item.get("text"), 2),
                ]
            )
    return rows


def feedback_rows(feedbacks: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    rows = [
        xlsx_header_row(
            [
                "ID отзыва",
                "Дата",
                "Оценка",
                "Цвет",
                "Размер",
                "Соответствие размеру",
                "Достоинства",
                "Недостатки",
                "Комментарий",
                "Теги",
            ]
        )
    ]
    for feedback in feedbacks:
        tags = feedback.get("tags") or []
        tag_text = ", ".join(str(tag.get("status") or tag.get("id")) for tag in tags if isinstance(tag, dict))
        rows.append(
            [
                xlsx_text(feedback.get("id"), 2),
                xlsx_date(feedback.get("createdDate")),
                xlsx_number(feedback.get("productValuation"), 4),
                xlsx_text(feedback.get("color"), 2),
                xlsx_text(feedback.get("size"), 2),
                xlsx_text(feedback.get("matchingSize") or feedback.get("matchingDescription"), 2),
                xlsx_text(feedback.get("pros"), 2),
                xlsx_text(feedback.get("cons"), 2),
                xlsx_text(feedback.get("text"), 2),
                xlsx_text(tag_text, 2),
            ]
        )
    return rows


def summary_rows(analysis: dict[str, Any]) -> list[list[dict[str, Any]]]:
    product = analysis["product"]
    summary = analysis["summary"]
    size = summary.get("matchingSizePercentages") or {}
    marketplace_label = product.get("marketplaceLabel") or "WB"
    rows = [
        [xlsx_text(f"Анализ отзывов {marketplace_label}", 3), xlsx_text("", 3)],
        [xlsx_text("Показатель", 1), xlsx_text("Значение", 1)],
        [xlsx_text("Артикул", 2), xlsx_text(product.get("article"), 2)],
        [xlsx_text("ID / root / product_id", 2), xlsx_text(product.get("root"), 2)],
        [xlsx_text("Бренд", 2), xlsx_text(product.get("brand"), 2)],
        [xlsx_text("Название", 2), xlsx_text(product.get("name"), 2)],
        [xlsx_text("Поставщик", 2), xlsx_text(product.get("supplier"), 2)],
        [xlsx_text("Средняя оценка", 2), xlsx_number(summary.get("averageRating"), 4)],
        [xlsx_text("Всего отзывов", 2), xlsx_number(summary.get("feedbackCount"), 4)],
        [xlsx_text("Текстовых отзывов", 2), xlsx_number(summary.get("textFeedbackCount"), 4)],
        [xlsx_text("Загружено в анализ", 2), xlsx_number(summary.get("loadedReviews"), 4)],
        [xlsx_text("Оценки 4-5★", 2), xlsx_percent(summary.get("positiveRatingPercent"))],
        [xlsx_text("Оценки 1-3★", 2), xlsx_percent(summary.get("negativeRatingPercent"))],
        [xlsx_text("Размер в размер", 2), xlsx_percent(size.get("ok"))],
        [xlsx_text("Маломерит", 2), xlsx_percent(size.get("smaller"))],
        [xlsx_text("Большемерит", 2), xlsx_percent(size.get("bigger"))],
        [xlsx_text("Вердикт", 2), xlsx_text(summary.get("verdict"), 2)],
        [xlsx_text("Ссылка на товар", 2), xlsx_text(product.get("url"), 2)],
        [xlsx_text("Дата выгрузки", 2), xlsx_date(datetime.now(timezone.utc).isoformat())],
    ]

    distribution = summary.get("distribution") or {}
    rows.extend(
        [
            [xlsx_text("", 2), xlsx_text("", 2)],
            [xlsx_text("Распределение оценок", 1), xlsx_text("Количество", 1)],
        ]
    )
    for star in ("5", "4", "3", "2", "1"):
        rows.append([xlsx_text(f"{star}★", 2), xlsx_number(distribution.get(star), 4)])
    return rows


def build_xlsx(sheets: list[dict[str, Any]]) -> bytes:
    sheet_names = [sheet["name"] for sheet in sheets]
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types_xml(len(sheets)))
        archive.writestr("_rels/.rels", root_rels_xml())
        archive.writestr("docProps/core.xml", core_props_xml())
        archive.writestr("docProps/app.xml", app_props_xml(sheet_names))
        archive.writestr("xl/workbook.xml", workbook_xml(sheet_names))
        archive.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml(len(sheets)))
        archive.writestr("xl/styles.xml", xlsx_styles_xml())
        for index, sheet in enumerate(sheets, start=1):
            archive.writestr(
                f"xl/worksheets/sheet{index}.xml",
                xlsx_worksheet_xml(
                    sheet["rows"],
                    widths=sheet.get("widths"),
                    freeze_header=sheet.get("freeze_header", True),
                    auto_filter=sheet.get("auto_filter", True),
                ),
            )
    return buffer.getvalue()


def build_export_workbook(analysis: dict[str, Any], feedback_data: dict[str, Any], limit: int) -> bytes:
    feedbacks = (feedback_data.get("feedbacks") or [])[:limit]
    sheets = [
        {
            "name": "Сводка",
            "rows": summary_rows(analysis),
            "widths": [28, 80],
            "freeze_header": False,
            "auto_filter": False,
        },
        {
            "name": "Рекомендации",
            "rows": recommendation_rows(analysis.get("recommendations") or {}),
            "widths": [22, 14, 14, 24, 34, 70, 70, 70],
        },
        {
            "name": "SEO",
            "rows": seo_rows(analysis.get("seoAnalysis") or {}),
            "widths": [18, 16, 30, 18, 70, 60, 36],
        },
        {
            "name": "ХПВ",
            "rows": hpv_rows((analysis.get("recommendations") or {}).get("hpv") or []),
            "widths": [22, 14, 22, 42, 52, 58, 72, 62, 58],
        },
        {
            "name": "Первое фото",
            "rows": photo_rows(analysis.get("firstPhotoAnalysis") or {}),
            "widths": [18, 28, 16, 16, 60, 70, 60],
        },
        {
            "name": "Сильные",
            "rows": aspect_rows("Сильные", analysis.get("strengths") or []),
            "widths": [24, 14, 14, 14, 12, 38, 70, 70],
        },
        {
            "name": "Слабые",
            "rows": aspect_rows("Слабые", analysis.get("weaknesses") or []),
            "widths": [24, 14, 14, 14, 12, 38, 70, 70],
        },
        {
            "name": "Темы",
            "rows": topics_rows(analysis.get("terms") or {}),
            "widths": [22, 36, 14],
        },
        {
            "name": "Примеры",
            "rows": examples_rows(analysis.get("examples") or {}),
            "widths": [14, 10, 14, 18, 18, 90],
        },
        {
            "name": "Отзывы",
            "rows": feedback_rows(feedbacks),
            "widths": [28, 14, 10, 18, 16, 24, 60, 60, 90, 20],
        },
    ]
    return build_xlsx(sheets)


def export_article(article_input: str, limit_input: str | None, marketplace_input: str | None = None) -> tuple[int, bytes, str]:
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    marketplace = marketplace_from_input(marketplace_input)
    if marketplace == MARKETPLACE_OZON:
        product, feedback_data, card_url, card_meta_url = fetch_ozon_product_and_feedbacks(article_input, limit)
        article = safe_int(product.get("article")) or safe_int(product.get("sku")) or safe_int(product.get("product_id")) or 0
        analysis = analyze_feedbacks(article, product, feedback_data, card_url, card_url, limit, {}, card_meta_url)
        return article, build_export_workbook(analysis, feedback_data, limit), MARKETPLACE_OZON

    article = article_from_input(article_input)
    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    feedback_data, feedback_url = fetch_feedbacks(article, root)
    analysis = analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)
    return article, build_export_workbook(analysis, feedback_data, limit), MARKETPLACE_WB


def priority_rank(priority: str) -> int:
    return {"high": 0, "medium": 1, "low": 2}.get(priority, 1)


def docx_rgb(value: str) -> Any:
    from docx.shared import RGBColor

    value = value.lstrip("#")
    return RGBColor(int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def docx_set_run(run: Any, size: float | None = None, bold: bool | None = None, color: str | None = None) -> None:
    from docx.oxml.ns import qn
    from docx.shared import Pt

    run.font.name = "Calibri"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = docx_rgb(color)


def docx_set_paragraph(paragraph: Any, before: int = 0, after: int = 6, line: float = 1.25) -> None:
    from docx.shared import Pt

    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = line


def docx_add_heading(doc: Any, text: str, level: int = 1) -> Any:
    sizes = {1: 16, 2: 13, 3: 12}
    colors = {1: "2E74B5", 2: "2E74B5", 3: "1F4D78"}
    before = {1: 18, 2: 14, 3: 10}
    after = {1: 10, 2: 7, 3: 5}
    paragraph = doc.add_paragraph()
    docx_set_paragraph(paragraph, before=before[level], after=after[level])
    run = paragraph.add_run(text)
    docx_set_run(run, size=sizes[level], bold=True, color=colors[level])
    return paragraph


def docx_add_para(doc: Any, text: str, bold_label: str | None = None, after: int = 6) -> Any:
    paragraph = doc.add_paragraph()
    docx_set_paragraph(paragraph, after=after)
    if bold_label:
        label_run = paragraph.add_run(f"{bold_label}: ")
        docx_set_run(label_run, size=11, bold=True)
    run = paragraph.add_run(text)
    docx_set_run(run, size=11)
    return paragraph


def docx_element(tag: str) -> Any:
    from docx.oxml import OxmlElement

    return OxmlElement(tag)


def docx_set_cell_shading(cell: Any, fill: str) -> None:
    from docx.oxml.ns import qn

    tc_pr = cell._tc.get_or_add_tcPr()
    shading = docx_element("w:shd")
    shading.set(qn("w:fill"), fill)
    tc_pr.append(shading)


def docx_set_cell_margins(table: Any, top: int = 80, bottom: int = 80, start: int = 120, end: int = 120) -> None:
    from docx.oxml.ns import qn

    tbl_pr = table._tbl.tblPr
    cell_mar = tbl_pr.find(qn("w:tblCellMar"))
    if cell_mar is None:
        cell_mar = docx_element("w:tblCellMar")
        tbl_pr.append(cell_mar)
    for side, value in (("top", top), ("bottom", bottom), ("start", start), ("end", end)):
        node = cell_mar.find(qn(f"w:{side}"))
        if node is None:
            node = docx_element(f"w:{side}")
            cell_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def docx_set_table_geometry(table: Any, widths_dxa: list[int], indent_dxa: int = 120) -> None:
    from docx.oxml.ns import qn

    table.autofit = False
    tbl = table._tbl
    tbl_pr = tbl.tblPr

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = docx_element("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_dxa)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = docx_element("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent_dxa))
    tbl_ind.set(qn("w:type"), "dxa")

    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = docx_element("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    old_grid = tbl.find(qn("w:tblGrid"))
    if old_grid is not None:
        tbl.remove(old_grid)
    grid = docx_element("w:tblGrid")
    for width in widths_dxa:
        grid_col = docx_element("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)
    tbl.insert(1, grid)

    for row in table.rows:
        for index, cell in enumerate(row.cells):
            width = widths_dxa[min(index, len(widths_dxa) - 1)]
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = docx_element("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")


def docx_fill_cell(cell: Any, text: str, bold: bool = False, fill: str | None = None) -> None:
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if fill:
        docx_set_cell_shading(cell, fill)
    paragraph = cell.paragraphs[0]
    docx_set_paragraph(paragraph, after=0)
    run = paragraph.add_run(as_text(text))
    docx_set_run(run, size=10.5, bold=bold, color="000000")


def docx_add_table(
    doc: Any,
    headers: list[str],
    rows: list[list[Any]],
    widths_dxa: list[int],
    header_fill: str = "E8EEF5",
) -> Any:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    docx_set_table_geometry(table, widths_dxa)
    docx_set_cell_margins(table)

    header_cells = table.rows[0].cells
    for index, header in enumerate(headers):
        docx_fill_cell(header_cells[index], header, bold=True, fill=header_fill)

    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            docx_fill_cell(cells[index], as_text(value))
    return table


def docx_add_callout(doc: Any, title: str, body: str) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    docx_set_table_geometry(table, [9360], indent_dxa=120)
    docx_set_cell_margins(table, top=120, bottom=120, start=160, end=160)
    cell = table.rows[0].cells[0]
    docx_set_cell_shading(cell, "F4F6F9")
    paragraph = cell.paragraphs[0]
    docx_set_paragraph(paragraph, after=3)
    title_run = paragraph.add_run(title)
    docx_set_run(title_run, size=11, bold=True, color="1F3A5F")
    paragraph.add_run("\n")
    body_run = paragraph.add_run(body)
    docx_set_run(body_run, size=10.5)


def docx_style_document(doc: Any) -> None:
    from docx.shared import Inches, Pt

    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25


def docx_product_title(product: dict[str, Any]) -> str:
    title = " · ".join(part for part in [as_text(product.get("brand")), as_text(product.get("name"))] if part)
    return title or f"Артикул {product.get('article')}"


def brief_goal(analysis: dict[str, Any]) -> str:
    summary = analysis["summary"]
    weaknesses = analysis.get("weaknesses") or []
    strengths = analysis.get("strengths") or []
    weak_names = ", ".join(item.get("title", "").lower() for item in weaknesses[:3]) or "повторяющиеся возражения"
    strong_names = ", ".join(item.get("title", "").lower() for item in strengths[:2]) or "сильные стороны товара"
    return (
        f"Обновить визуальный контент карточки так, чтобы усилить {strong_names} и закрыть {weak_names}. "
        f"Текущий ориентир по отзывам: {summary.get('averageRating') or 'нет оценки'}★, "
        f"{summary.get('textFeedbackCount')} текстовых отзывов."
    )


def brief_slide_plan(analysis: dict[str, Any]) -> list[list[str]]:
    content_recs = analysis.get("recommendations", {}).get("content") or []
    strengths = analysis.get("strengths") or []
    weaknesses = analysis.get("weaknesses") or []
    weakness_keys = {item.get("key") for item in weaknesses}

    rows = [
        [
            "1",
            "Главное фото",
            "Чистый кадр товара без перегруза текстом; товар должен быть крупным, резким и понятным с первого взгляда.",
            "Покупатель за 1-2 секунды понимает, что продаётся, какой вариант/цвет выбран и почему товар выглядит аккуратно.",
        ],
        [
            "2",
            "Слайд с главным УТП",
            "Вынести 1-2 сильные стороны из отзывов: " + terms_to_text([item.get("title") for item in strengths[:2] if item.get("title")]),
            "Формулировки опираются на реальные отзывы, без неподтверждённых обещаний.",
        ],
    ]

    if "fit" in weakness_keys or (analysis["summary"].get("matchingSizePercentages") or {}):
        rows.append(
            [
                str(len(rows) + 1),
                "Размеры и посадка",
                "Сделать инфографику с фактическими замерами, подсказкой по выбору размера и визуальной схемой посадки.",
                "Покупатель понимает, брать свой размер, больше или меньше; нет противоречий с отзывами.",
            ]
        )

    if "quality" in weakness_keys or any(item.get("key") == "quality" for item in strengths):
        rows.append(
            [
                str(len(rows) + 1),
                "Материал и детали",
                "Показать крупные планы материала, швов, фактуры, креплений или критичных деталей.",
                "На макете видны детали, о которых пишут покупатели; ретушь не скрывает фактуру и возможные ограничения.",
            ]
        )

    if "appearance" in weakness_keys:
        rows.append(
            [
                str(len(rows) + 1),
                "Цвет и внешний вид",
                "Переснять цвет при нейтральном свете, добавить кадр без фильтров и крупный план оттенка/принта.",
                "Цвет на фото не конфликтует с реальным товаром и снижает риск жалоб «не тот цвет».",
            ]
        )

    if "packaging" in weakness_keys or "completeness" in weakness_keys:
        rows.append(
            [
                str(len(rows) + 1),
                "Комплектация и упаковка",
                "Показать полный комплект одним кадром, упаковку, количество штук и что именно приходит покупателю.",
                "Состав заказа понятен без чтения длинного описания.",
            ]
        )

    rows.append(
        [
            str(len(rows) + 1),
            "Финальный слайд доверия",
            "Короткий блок с уходом, ограничениями, гарантией/возвратом или честным FAQ по повторяющимся вопросам.",
            "Закрывает типовые сомнения и не обещает того, что товар не подтверждает отзывами.",
        ]
    )
    return rows


def brief_priority_rows(analysis: dict[str, Any]) -> list[list[str]]:
    actions = sorted(
        analysis.get("recommendations", {}).get("priorityActions") or [],
        key=lambda item: priority_rank(item.get("priority", "medium")),
    )
    rows = []
    for index, item in enumerate(actions[:6], start=1):
        rows.append(
            [
                str(index),
                item.get("priorityLabel", ""),
                "Товар" if item.get("area") == "product" else "Контент",
                item.get("title", ""),
                item.get("action", ""),
                item.get("reason", ""),
            ]
        )
    return rows


def brief_content_rows(analysis: dict[str, Any]) -> list[list[str]]:
    rows = []
    for item in analysis.get("recommendations", {}).get("content") or []:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("aspect", ""),
                item.get("title", ""),
                item.get("action", ""),
                item.get("reason", ""),
                evidence_to_text(item.get("evidence") or []),
            ]
        )
    return rows


def brief_seo_rows(analysis: dict[str, Any]) -> list[list[str]]:
    seo = analysis.get("seoAnalysis") or {}
    rows: list[list[str]] = []
    for item in (seo.get("priorityRecommendations") or [])[:5]:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("moduleLabel", ""),
                f"{item.get('problem', '')} {item.get('evidence', '')}".strip(),
                f"{item.get('recommendation', '')} Проверить: {item.get('checkAfter', '')}".strip(),
            ]
        )
    if rows:
        return rows[:8]
    for item in (seo.get("titleAudit") or [])[:4]:
        if item.get("priority") == "low" and item.get("score", 100) >= 78:
            continue
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("label", ""),
                item.get("summary", ""),
                item.get("action", ""),
            ]
        )
    for item in (seo.get("missingKeywords") or [])[:4]:
        rows.append(
            [
                item.get("priorityLabel", ""),
                f"Ключ: {item.get('term', '')}",
                item.get("reason", ""),
                item.get("action", ""),
            ]
        )
    return rows[:8]


def brief_hpv_rows(analysis: dict[str, Any]) -> list[list[str]]:
    rows = []
    for item in (analysis.get("recommendations", {}).get("hpv") or [])[:6]:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("characteristic", ""),
                item.get("advantage", ""),
                item.get("benefit", ""),
                item.get("cardText", ""),
                item.get("infographicText", ""),
            ]
        )
    return rows


def brief_product_signal_rows(analysis: dict[str, Any]) -> list[list[str]]:
    rows = []
    for item in analysis.get("recommendations", {}).get("product") or []:
        rows.append(
            [
                item.get("priorityLabel", ""),
                item.get("aspect", ""),
                item.get("title", ""),
                item.get("action", ""),
                item.get("reason", ""),
            ]
        )
    return rows


def brief_photo_criteria_rows(analysis: dict[str, Any]) -> list[list[str]]:
    photo = analysis.get("firstPhotoAnalysis") or {}
    rows = []
    for item in photo.get("criteria") or []:
        score = item.get("score")
        rows.append(
            [
                item.get("label", ""),
                f"{score}/100" if score is not None else item.get("status", ""),
                item.get("summary", ""),
                item.get("action", ""),
            ]
        )
    return rows


def brief_acceptance_rows(marketplace_label: str = "WB") -> list[list[str]]:
    return [
        ["☐", "Главное фото ясно показывает товар, вариант и масштаб без визуального шума."],
        ["☐", f"Важный текст и ключевые детали не попадают в верхние углы и нижнюю зону плашек {marketplace_label}."],
        ["☐", "Первые 5 изображений закрывают главные возражения из отзывов."],
        ["☐", "Цвет, материал, размер, комплектация и ограничения показаны честно и без сильной ретуши."],
        ["☐", "Каждый инфографический слайд содержит одну мысль и читается на мобильном экране."],
        ["☐", "Тексты на макетах короткие, проверяемые и не обещают неподтверждённых свойств."],
        ["☐", f"Исходники и экспорт подготовлены под актуальные требования {marketplace_label}."],
    ]


def build_brief_docx(analysis: dict[str, Any]) -> bytes:
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt
    except ImportError as exc:
        raise AppError("Не удалось сформировать DOCX: не установлен python-docx.", 500, str(exc))

    product = analysis["product"]
    summary = analysis["summary"]
    marketplace_label = product.get("marketplaceLabel") or "WB"
    doc = Document()
    docx_style_document(doc)

    header = doc.sections[0].header.paragraphs[0]
    docx_set_paragraph(header, after=0)
    run = header.add_run(f"ТЗ по контенту {marketplace_label}")
    docx_set_run(run, size=9, color="5C655E")

    footer = doc.sections[0].footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    docx_set_paragraph(footer, after=0)
    footer_run = footer.add_run("Сформировано анализатором отзывов")
    docx_set_run(footer_run, size=9, color="5C655E")

    title = doc.add_paragraph()
    docx_set_paragraph(title, after=4)
    title_run = title.add_run("Техническое задание дизайнеру")
    docx_set_run(title_run, size=24, bold=True, color="000000")

    subtitle = doc.add_paragraph()
    docx_set_paragraph(subtitle, after=12)
    sub_run = subtitle.add_run(docx_product_title(product))
    docx_set_run(sub_run, size=13, color="5C655E")

    metadata_rows = [
        ["Артикул", product.get("article")],
        ["Средняя оценка", f"{summary.get('averageRating') or 'нет данных'}★"],
        ["Отзывы / текстовые", f"{summary.get('feedbackCount')} / {summary.get('textFeedbackCount')}"],
        ["Ссылка", product.get("url")],
    ]
    docx_add_table(doc, ["Параметр", "Значение"], metadata_rows, [1800, 7560])

    docx_add_callout(doc, "Цель обновления контента", brief_goal(analysis))

    docx_add_heading(doc, "1. Что сделать в первую очередь", 1)
    priority_rows = brief_priority_rows(analysis) or [["1", "Средний", "Контент", "Подготовить базовое обновление", "Обновить первые изображения карточки по выводам из отзывов.", "Данных мало, используйте сводку и примеры отзывов как ориентир."]]
    docx_add_table(
        doc,
        ["№", "Приоритет", "Блок", "Задача", "Действие", "Основание"],
        priority_rows,
        [420, 900, 900, 1700, 3000, 2440],
    )

    docx_add_heading(doc, "2. Структура визуального контента", 1)
    docx_add_table(
        doc,
        ["№", "Элемент", "Что подготовить", "Критерий приемки"],
        brief_slide_plan(analysis),
        [420, 1500, 3900, 3540],
    )

    docx_add_heading(doc, "3. Анализ первого фото", 1)
    photo_criteria_rows = brief_photo_criteria_rows(analysis)
    if photo_criteria_rows:
        docx_add_table(
            doc,
            ["Критерий", "Оценка", "Диагноз", "Что сделать"],
            photo_criteria_rows,
            [1700, 900, 3100, 3660],
        )
    else:
        docx_add_para(doc, f"Первое фото не удалось загрузить для визуального анализа. Проверьте доступность изображения на {marketplace_label}.")

    docx_add_heading(doc, "4. Контентные задачи из отзывов", 1)
    content_rows = brief_content_rows(analysis)
    if content_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Аспект", "Рекомендация", "Что сделать", "Почему", "Отзывы"],
            content_rows,
            [900, 1300, 1600, 2900, 1700, 960],
        )
    else:
        docx_add_para(doc, "Повторяющихся контентных задач не найдено. Сфокусируйтесь на чистой пересъёмке и понятной структуре карточки.")

    docx_add_heading(doc, "5. SEO карточки", 1)
    seo_brief_rows = brief_seo_rows(analysis)
    if seo_brief_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Элемент", "Диагноз", "Что сделать"],
            seo_brief_rows,
            [900, 1800, 3300, 3360],
        )
    else:
        docx_add_para(doc, "SEO-критичных замечаний не найдено. Сохраните понятный товарный запрос в названии и не перегружайте инфографику ключами.")

    docx_add_heading(doc, "6. ХПВ: характеристики в выгоды", 1)
    hpv_brief_rows = brief_hpv_rows(analysis)
    if hpv_brief_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Характеристика", "Преимущество", "Выгода", "Текст карточки", "Инфографика"],
            hpv_brief_rows,
            [820, 1500, 1900, 1900, 1900, 1340],
        )
    else:
        docx_add_para(doc, "Расширенные характеристики карточки не найдены. Используйте сильные стороны из отзывов как основу для ХПВ.")

    docx_add_heading(doc, "7. Сигналы, которые нельзя маскировать дизайном", 1)
    docx_add_para(
        doc,
        "Если отзыв указывает на реальную проблему товара или партии, контент должен честно объяснить ограничение либо задача должна уйти поставщику на исправление.",
    )
    product_rows = brief_product_signal_rows(analysis)
    if product_rows:
        docx_add_table(
            doc,
            ["Приоритет", "Аспект", "Сигнал", "Что проверить", "Почему"],
            product_rows,
            [900, 1400, 1700, 3300, 2060],
        )

    docx_add_heading(doc, "8. Чек-лист приемки макетов", 1)
    docx_add_table(doc, ["Готово", "Критерий"], brief_acceptance_rows(marketplace_label), [720, 8640])

    docx_add_heading(doc, "9. Рабочие правила для дизайнера", 1)
    rules = [
        ("Мобильная читаемость", "Проверить каждый слайд в маленьком размере: текст должен читаться без увеличения."),
        ("Одна мысль на слайд", "Не смешивать размер, материал, преимущества и комплектацию в одном перегруженном макете."),
        ("Честность визуала", "Не менять оттенок, фактуру и пропорции товара так, чтобы это усиливало расхождение с отзывами."),
        ("Исходники", "Передать редактируемые исходники, финальные экспорты и список использованных текстовых формулировок."),
    ]
    docx_add_table(doc, ["Правило", "Требование"], rules, [1800, 7560])

    docx_add_heading(doc, "10. Доказательная база из отзывов", 1)
    examples = []
    for label, items in (("Плюс", analysis.get("examples", {}).get("positive") or []), ("Минус", analysis.get("examples", {}).get("negative") or [])):
        for item in items[:4]:
            examples.append([label, f"{item.get('rating') or ''}★", item.get("date", ""), item.get("text", "")])
    if examples:
        docx_add_table(doc, ["Тип", "Оценка", "Дата", "Фрагмент"], examples, [800, 700, 1000, 6860])

    buffer = BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def brief_article(article_input: str, limit_input: str | None, marketplace_input: str | None = None) -> tuple[int, bytes, str]:
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    marketplace = marketplace_from_input(marketplace_input)
    if marketplace == MARKETPLACE_OZON:
        analysis = analyze_article(article_input, str(limit), MARKETPLACE_OZON)
        article = safe_int((analysis.get("product") or {}).get("article")) or 0
        return article, build_brief_docx(analysis), MARKETPLACE_OZON

    article = article_from_input(article_input)
    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    feedback_data, feedback_url = fetch_feedbacks(article, root)
    analysis = analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)
    return article, build_brief_docx(analysis), MARKETPLACE_WB


def unique_texts(values: list[str], limit: int | None = None) -> list[str]:
    result = []
    seen = set()
    for value in values:
        cleaned = re.sub(r"\s+", " ", as_text(value)).strip()
        key = cleaned.lower()
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(cleaned)
        if limit and len(result) >= limit:
            break
    return result


def product_variant_tokens(product: dict[str, Any]) -> tuple[set[str], set[str]]:
    color_tokens: set[str] = set()
    size_tokens: set[str] = set()

    colors = product.get("colors")
    if isinstance(colors, list):
        for color in colors:
            if isinstance(color, dict):
                color_tokens.update(token_list(as_text(color.get("name"))))

    sizes = product.get("sizes")
    if isinstance(sizes, list):
        for size in sizes:
            if isinstance(size, dict):
                size_tokens.update(token_list(" ".join([as_text(size.get("name")), as_text(size.get("origName"))])))

    return color_tokens, size_tokens


def competitor_text(product: dict[str, Any]) -> str:
    parts = [
        as_text(product.get("name")),
        as_text(product.get("entity")),
        as_text(product.get("brand")),
        as_text(product.get("supplier")),
    ]
    color_tokens, size_tokens = product_variant_tokens(product)
    parts.extend(sorted(color_tokens))
    parts.extend(sorted(size_tokens))
    return " ".join(part for part in parts if part)


def competitor_profile(product: dict[str, Any], card_meta: dict[str, Any] | None) -> dict[str, Any]:
    card_meta = card_meta or {}
    title_text = " ".join(
        part
        for part in [
            as_text(product.get("name")),
            as_text(product.get("entity")),
            as_text(card_meta.get("imt_name")),
            as_text(card_meta.get("subj_name")),
        ]
        if part
    )
    characteristic_items = product_characteristic_items(product, card_meta)
    characteristic_text = " ".join(f"{item['name']} {item['value']}" for item in characteristic_items)
    color_tokens, size_tokens = product_variant_tokens(product)

    title_tokens = set(token_list(title_text))
    characteristic_tokens = set(token_list(characteristic_text)) - title_tokens

    return {
        "subjectId": safe_int(product.get("subjectId")),
        "subjectParentId": safe_int(product.get("subjectParentId")),
        "entity": normalize_opinion(as_text(product.get("entity") or card_meta.get("subj_name"))),
        "titleTokens": title_tokens,
        "characteristicTokens": characteristic_tokens,
        "colorTokens": color_tokens,
        "sizeTokens": size_tokens,
        "characteristics": characteristic_items,
    }


def characteristic_query_terms(product: dict[str, Any], card_meta: dict[str, Any] | None) -> list[str]:
    terms = []
    priority_names = ("пол", "назнач", "комплект", "набор", "цвет", "сезон")
    for item in product_characteristic_items(product, card_meta or {}):
        name = normalize_opinion(item["name"])
        if not any(priority in name for priority in priority_names):
            continue
        for token in token_list(item["value"]):
            if len(token) >= 4:
                terms.append(token)
    return unique_texts(terms, 4)


def search_query_candidates(product: dict[str, Any], card_meta: dict[str, Any] | None = None) -> list[str]:
    candidates = []
    entity = as_text(product.get("entity") or (card_meta or {}).get("subj_name"))
    name = as_text((card_meta or {}).get("imt_name") or product.get("name"))
    combined = " ".join(part for part in [name, entity] if part)

    for raw in (name, combined):
        text = as_text(raw)
        if len(text) >= 3:
            candidates.append(text)

    for term in characteristic_query_terms(product, card_meta)[:2]:
        if entity:
            candidates.append(f"{term} {entity}")

    if combined and normalize_opinion(name) != normalize_opinion(entity):
        candidates.append(combined)

    if len(entity) >= 3:
        candidates.append(entity)

    return unique_texts(candidates, 3) or [as_text(product.get("name")) or str(product.get("id"))]


def fetch_search_products(query: str, page: int = 1) -> tuple[list[dict[str, Any]], str]:
    encoded = quote(query, safe="")
    referer = f"https://www.wildberries.ru/catalog/0/search.aspx?search={encoded}"
    errors = []
    for endpoint in WB_SEARCH_ENDPOINTS:
        url = (
            endpoint
            + "?ab_testid=new_benefit_sort&appType=1&curr=rub&dest=-1257786"
            + "&inheritFilters=false&lang=ru"
            + f"&page={page}&query={encoded}&resultset=catalog&sort=popular&spp=30"
            + "&suppressSpellcheck=false"
        )
        try:
            result = remote_json(url, referer, attempts=2, timeout=8)
        except AppError as exc:
            errors.append(f"{endpoint}: {exc.message}")
            if exc.status == 429:
                time.sleep(0.7)
                continue
            continue

        products = result.data.get("products") or result.data.get("data", {}).get("products") or []
        return [product for product in products if isinstance(product, dict)], result.url

    details = "; ".join(errors) if errors else None
    if any("ограничил частоту" in error.lower() for error in errors):
        raise AppError(
            "Wildberries временно ограничил поиск конкурентов. Пробую другие источники и более мягкий режим.",
            429,
            details,
        )
    raise AppError("Не удалось получить поисковую выдачу Wildberries для подбора конкурентов.", 502, details)


def candidate_similarity_score(candidate: dict[str, Any], profile: dict[str, Any]) -> tuple[float, list[str]]:
    score = 0.0
    reasons = []
    candidate_subject = safe_int(candidate.get("subjectId"))
    candidate_parent = safe_int(candidate.get("subjectParentId"))
    candidate_entity = normalize_opinion(as_text(candidate.get("entity")))
    candidate_tokens = set(token_list(competitor_text(candidate)))

    if profile["subjectId"] and candidate_subject == profile["subjectId"]:
        score += 55
        reasons.append("та же категория")
    elif profile["subjectParentId"] and candidate_parent == profile["subjectParentId"]:
        score += 20
        reasons.append("родственная категория")
    else:
        score -= 25

    if profile["entity"] and candidate_entity == profile["entity"]:
        score += 12
        reasons.append("совпадает тип товара")

    title_tokens = profile["titleTokens"]
    title_matches = title_tokens & candidate_tokens
    if title_matches:
        score += min(len(title_matches) * 8, 36)
        reasons.append("похожий заголовок: " + ", ".join(sorted(title_matches)[:4]))
        union = title_tokens | candidate_tokens
        if union:
            score += round(len(title_matches) * 24 / len(union), 2)
    else:
        score -= 12

    characteristic_matches = profile["characteristicTokens"] & candidate_tokens
    if characteristic_matches:
        score += min(len(characteristic_matches) * 7, 35)
        reasons.append("совпали характеристики: " + ", ".join(sorted(characteristic_matches)[:4]))

    candidate_colors, candidate_sizes = product_variant_tokens(candidate)
    color_matches = profile["colorTokens"] & candidate_colors
    if color_matches:
        score += 8
        reasons.append("совпадает цвет")
    size_matches = profile["sizeTokens"] & candidate_sizes
    if size_matches:
        score += 6
        reasons.append("пересекаются размеры")

    feedbacks = int(candidate.get("feedbacks") or candidate.get("nmFeedbacks") or 0)
    if feedbacks >= 1000:
        score += 5
    elif feedbacks >= 100:
        score += 3

    return round(score, 2), reasons[:5]


def competitor_candidates(
    article: int,
    product: dict[str, Any],
    card_meta: dict[str, Any] | None,
    target_count: int,
) -> tuple[list[dict[str, Any]], list[str], str | None]:
    profile = competitor_profile(product, card_meta)
    collected: dict[int, dict[str, Any]] = {}
    seen: set[int] = {article}
    used_queries = []
    first_url = None

    queries = search_query_candidates(product, card_meta)
    for query_index, query in enumerate(queries):
        used_queries.append(query)
        for page in (1, 2):
            try:
                products, source_url = fetch_search_products(query, page)
                first_url = first_url or source_url
            except AppError as exc:
                if exc.status == 429:
                    time.sleep(0.9 + query_index * 0.25)
                continue

            for candidate in products:
                nm_id = safe_int(candidate.get("id"))
                if not nm_id or nm_id in seen:
                    continue
                seen.add(nm_id)
                if int(candidate.get("feedbacks") or candidate.get("nmFeedbacks") or 0) <= 0:
                    continue
                if safe_float(candidate.get("reviewRating") or candidate.get("nmReviewRating")) is None:
                    continue

                score, reasons = candidate_similarity_score(candidate, profile)
                if score < 30 and not (profile["subjectId"] and safe_int(candidate.get("subjectId")) == profile["subjectId"]):
                    continue

                payload = dict(candidate)
                payload["_matchScore"] = score
                payload["_matchReasons"] = reasons
                payload["_searchQuery"] = query
                collected[nm_id] = payload

            if len(collected) >= max(target_count * 4, target_count + 8):
                break
            if query_index == 0 and page == 1 and len(collected) >= target_count:
                break
        if len(collected) >= max(target_count * 4, target_count + 8):
            break
        if query_index == 0 and len(collected) >= target_count:
            break

    candidates = sorted(
        collected.values(),
        key=lambda item: (
            float(item.get("_matchScore") or 0),
            int(item.get("feedbacks") or item.get("nmFeedbacks") or 0),
        ),
        reverse=True,
    )
    return candidates[: max(target_count * 4, target_count)], used_queries, first_url


def competitor_product_payload(product: dict[str, Any], analysis: dict[str, Any]) -> dict[str, Any]:
    summary = analysis["summary"]
    return {
        "article": product.get("id") or analysis["product"].get("article"),
        "root": product.get("root") or analysis["product"].get("root"),
        "name": as_text(product.get("name") or analysis["product"].get("name")),
        "brand": as_text(product.get("brand") or analysis["product"].get("brand")),
        "supplier": as_text(product.get("supplier") or analysis["product"].get("supplier")),
        "reviewRating": summary.get("averageRating"),
        "feedbacks": summary.get("feedbackCount"),
        "textFeedbacks": summary.get("textFeedbackCount"),
        "loadedReviews": summary.get("loadedReviews"),
        "positiveRatingPercent": summary.get("positiveRatingPercent"),
        "negativeRatingPercent": summary.get("negativeRatingPercent"),
        "matchScore": product.get("_matchScore"),
        "matchReasons": product.get("_matchReasons") or [],
        "searchQuery": product.get("_searchQuery"),
        "url": f"https://www.wildberries.ru/catalog/{product.get('id')}/detail.aspx",
        "imageUrl": analysis["product"].get("imageUrl"),
        "firstPhotoAnalysis": analysis.get("firstPhotoAnalysis"),
        "topStrengths": [item.get("title") for item in (analysis.get("strengths") or [])[:3]],
        "topWeaknesses": [item.get("title") for item in (analysis.get("weaknesses") or [])[:3]],
    }


def competitor_card_only_feedback_data(product: dict[str, Any], warning: str) -> dict[str, Any]:
    return {
        "feedbacks": [],
        "feedbackCount": safe_int(product.get("feedbacks") or product.get("nmFeedbacks")) or 0,
        "feedbackCountWithText": 0,
        "valuation": safe_float(product.get("reviewRating") or product.get("nmReviewRating")),
        "valuationDistribution": {},
        "matchingSizePercentages": {},
        "_warning": warning,
    }


def aspect_totals(analysis: dict[str, Any]) -> dict[str, dict[str, float]]:
    totals: dict[str, dict[str, float]] = {}
    for item in (analysis.get("strengths") or []) + (analysis.get("weaknesses") or []):
        key = item.get("key") or "overall"
        current = totals.setdefault(key, {"positive": 0.0, "negative": 0.0, "mentions": 0.0})
        current["positive"] = max(current["positive"], float(item.get("positiveMentions") or 0))
        current["negative"] = max(current["negative"], float(item.get("negativeMentions") or 0))
        current["mentions"] = max(current["mentions"], float(item.get("mentions") or 0))
    return totals


def rate_per_100(value: float, loaded_reviews: int | None) -> float:
    denominator = max(int(loaded_reviews or 0), 1)
    return round(value * 100 / denominator, 1)


def competitor_benchmark(your_analysis: dict[str, Any], competitor_analyses: list[dict[str, Any]]) -> dict[str, Any]:
    def avg(values: list[float | int | None]) -> float | None:
        clean = [float(value) for value in values if value is not None]
        if not clean:
            return None
        return round(sum(clean) / len(clean), 2)

    your_summary = your_analysis["summary"]
    competitor_summaries = [analysis["summary"] for analysis in competitor_analyses]
    return {
        "your": {
            "averageRating": your_summary.get("averageRating"),
            "feedbackCount": your_summary.get("feedbackCount"),
            "textFeedbackCount": your_summary.get("textFeedbackCount"),
            "positiveRatingPercent": your_summary.get("positiveRatingPercent"),
            "negativeRatingPercent": your_summary.get("negativeRatingPercent"),
        },
        "competitorsAvg": {
            "averageRating": avg([item.get("averageRating") for item in competitor_summaries]),
            "feedbackCount": avg([item.get("feedbackCount") for item in competitor_summaries]),
            "textFeedbackCount": avg([item.get("textFeedbackCount") for item in competitor_summaries]),
            "positiveRatingPercent": avg([item.get("positiveRatingPercent") for item in competitor_summaries]),
            "negativeRatingPercent": avg([item.get("negativeRatingPercent") for item in competitor_summaries]),
        },
    }


def average_photo_metric(photo_items: list[dict[str, Any]], key: str) -> float | None:
    values = [
        safe_float((item.get("metrics") or {}).get(key))
        for item in photo_items
        if item.get("ok") and (item.get("metrics") or {}).get(key) is not None
    ]
    clean = [value for value in values if value is not None]
    if not clean:
        return None
    return round(sum(clean) / len(clean), 1)


def photo_competitor_item(analysis: dict[str, Any]) -> dict[str, Any] | None:
    photo = analysis.get("firstPhotoAnalysis") or {}
    product = analysis.get("product") or {}
    score = safe_float(photo.get("score"))
    if not photo.get("ok") or score is None:
        return None
    title = [product.get("brand"), product.get("name")]
    return {
        "article": product.get("article"),
        "title": " · ".join(as_text(part) for part in title if as_text(part)) or f"Артикул {product.get('article')}",
        "url": product.get("url"),
        "imageUrl": product.get("imageUrl") or photo.get("imageUrl"),
        "sourceUrl": photo.get("sourceUrl") or product.get("sourceImageUrl"),
        "score": round(score),
        "scoreLabel": photo.get("scoreLabel"),
        "metrics": photo.get("metrics") or {},
        "criteria": photo.get("criteria") or [],
    }


def photo_criteria_map(photo: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        as_text(item.get("key")): item
        for item in (photo.get("criteria") or [])
        if isinstance(item, dict) and item.get("key")
    }


def photo_criterion_score(photo: dict[str, Any], key: str) -> float | None:
    item = photo_criteria_map(photo).get(key)
    return safe_float((item or {}).get("score"))


def competitor_criterion_avg(photo_items: list[dict[str, Any]], key: str) -> float | None:
    values = [safe_float(photo_criteria_map(item).get(key, {}).get("score")) for item in photo_items]
    clean = [value for value in values if value is not None]
    if not clean:
        return None
    return round(sum(clean) / len(clean), 1)


def comparison_phrase(your_value: float | None, competitor_value: float | None, label: str, unit: str = "") -> str:
    if your_value is None or competitor_value is None:
        return ""
    return f"{label}: у вас {round(your_value)}{unit}, у конкурентов в среднем {round(competitor_value)}{unit}."


def build_market_photo_patterns(competitor_photos: list[dict[str, Any]], avg_value: Any) -> list[str]:
    patterns: list[str] = []
    comp_subject = avg_value("productSharePercent")
    comp_contrast = avg_value("contrastScore")
    comp_saturation = avg_value("saturationPercent")
    comp_load = avg_value("visualLoadPercent")
    comp_safe_zones = avg_value("marketplaceZoneActivityPercent")
    comp_readability = competitor_criterion_avg(competitor_photos, "mobile_readability")
    comp_standout = competitor_criterion_avg(competitor_photos, "competitive_standout")

    if comp_subject is not None:
        if comp_subject >= 62:
            patterns.append(f"Конкуренты делают товар главным объектом: в среднем он занимает около {round(comp_subject)}% кадра.")
        elif comp_subject <= 42:
            patterns.append(f"В нише часто оставляют много воздуха вокруг товара: средняя заполненность кадра около {round(comp_subject)}%.")
        else:
            patterns.append(f"Средний паттерн ниши — умеренно крупный товар без плотной обрезки: около {round(comp_subject)}% кадра.")
    if comp_contrast is not None:
        if comp_contrast >= 62:
            patterns.append(f"Обложки конкурентов заметны за счет контраста: средний контраст {round(comp_contrast)}/100.")
        elif comp_contrast <= 46:
            patterns.append(f"У конкурентов слабый контраст, поэтому можно выделиться более чистым силуэтом и фоном.")
    if comp_saturation is not None:
        if comp_saturation <= 12:
            patterns.append("Цветовые акценты в нише используются сдержанно: есть шанс выделиться одним фирменным цветом без перегруза.")
        elif comp_saturation >= 34:
            patterns.append("Конкуренты активно используют цвет, поэтому важна строгая иерархия: один главный акцент, а не несколько спорящих элементов.")
    if comp_load is not None and comp_load >= 58:
        patterns.append(f"Многие обложки выглядят насыщенно: средний индекс визуальной загруженности {round(comp_load)}%.")
    elif comp_load is not None and comp_load <= 34:
        patterns.append("Конкуренты чаще используют чистые обложки без большого количества элементов.")
    if comp_readability is not None and comp_readability >= 70:
        patterns.append("У сильных конкурентов первый экран, вероятно, читается с телефона: высокая мобильная читаемость обложки.")
    if comp_standout is not None and comp_standout < 66:
        patterns.append("В нише нет сильного визуального стандарта выделения, поэтому можно выиграть за счет ясной выгоды и аккуратного контраста.")
    if comp_safe_zones is not None and comp_safe_zones >= 52:
        patterns.append("У части конкурентов важные элементы находятся близко к зонам плашек WB, это можно использовать как преимущество чистой компоновкой.")

    return unique_texts(patterns, 5)


def build_your_cover_points(
    your_photo: dict[str, Any],
    competitor_photos: list[dict[str, Any]],
    avg_value: Any,
) -> tuple[list[str], list[str]]:
    strengths: list[str] = []
    weaknesses: list[str] = []
    your_metrics = your_photo.get("metrics") or {}

    comparisons = [
        ("one_second_meaning", "Понятность за 1 секунду", "/100"),
        ("product_scale", "Крупность и понятность товара", "/100"),
        ("mobile_readability", "Читаемость с телефона", "/100"),
        ("composition_hierarchy", "Композиция и визуальная иерархия", "/100"),
        ("competitive_standout", "Выделение в выдаче", "/100"),
        ("needs_objections", "Мотивация открыть карточку", "/100"),
        ("marketplace_safe_zones", "Чистота зон WB", "/100"),
    ]
    for key, label, unit in comparisons:
        your_score = photo_criterion_score(your_photo, key)
        comp_score = competitor_criterion_avg(competitor_photos, key)
        phrase = comparison_phrase(your_score, comp_score, label, unit)
        if your_score is None:
            continue
        if comp_score is not None and your_score >= comp_score + 7:
            strengths.append(phrase)
        elif your_score < 62 or (comp_score is not None and your_score + 7 < comp_score):
            weaknesses.append(phrase or f"{label}: критерий требует усиления, текущая оценка {round(your_score)}/100.")

    metric_checks = [
        ("productSharePercent", "Товар в кадре", "%", 8),
        ("contrastScore", "Контраст", "/100", 8),
        ("visualLoadPercent", "Визуальная загруженность", "%", 12),
    ]
    for key, label, unit, threshold in metric_checks:
        your_value = safe_float(your_metrics.get(key))
        comp_value = avg_value(key)
        if your_value is None or comp_value is None:
            continue
        phrase = comparison_phrase(your_value, comp_value, label, unit)
        if key == "visualLoadPercent":
            if your_value + threshold < comp_value:
                strengths.append(f"{phrase} Обложка чище и должна быстрее считываться.")
            elif your_value > comp_value + threshold:
                weaknesses.append(f"{phrase} Есть риск перегруза первого экрана.")
        elif your_value >= comp_value + threshold:
            strengths.append(phrase)
        elif your_value + threshold < comp_value:
            weaknesses.append(phrase)

    if not strengths:
        score = safe_float(your_photo.get("score"))
        if score is not None:
            strengths.append(f"Базовая оценка обложки {round(score)}/100: есть рабочая основа для тестов.")
    if not weaknesses:
        weaknesses.append("Сильного отставания по базовым метрикам не видно; главный резерв — протестировать смысл и оффер на первом фото.")

    return unique_texts(strengths, 4), unique_texts(weaknesses, 4)


def build_ab_test_hypotheses(
    your_photo: dict[str, Any],
    competitor_photos: list[dict[str, Any]],
    avg_value: Any,
    actions: list[dict[str, Any]],
) -> list[dict[str, str]]:
    your_metrics = your_photo.get("metrics") or {}
    hypotheses: list[dict[str, str]] = []

    def add(title: str, variant_a: str, variant_b: str, reason: str, metric: str) -> None:
        if len(hypotheses) >= 3:
            return
        hypotheses.append(
            {
                "title": title,
                "variantA": variant_a,
                "variantB": variant_b,
                "reason": reason,
                "successMetric": metric,
            }
        )

    one_second = photo_criterion_score(your_photo, "one_second_meaning")
    needs = photo_criterion_score(your_photo, "needs_objections")
    if (one_second is not None and one_second < 72) or (needs is not None and needs < 76):
        add(
            "Проверить главный смысл обложки",
            "Товар крупно + короткий нейтральный оффер о типе товара.",
            "Товар крупно + выгода, закрывающая главное возражение покупателей.",
            "Если покупатель быстрее понимает пользу, CTR карточки должен вырасти.",
            "CTR из выдачи WB и добавления в корзину после открытия.",
        )

    your_subject = safe_float(your_metrics.get("productSharePercent"))
    comp_subject = avg_value("productSharePercent")
    if your_subject is not None and comp_subject is not None and (your_subject + 8 < comp_subject or your_subject > 78):
        add(
            "Протестировать масштаб товара",
            "Текущий масштаб и композиция.",
            "Перекадрирование: товар крупнее/чище, ключевая деталь видна в миниатюре.",
            comparison_phrase(your_subject, comp_subject, "Товар в кадре", "%") or "Масштаб влияет на скорость распознавания товара.",
            "CTR карточки и глубина просмотра фото.",
        )

    standout = photo_criterion_score(your_photo, "competitive_standout")
    your_contrast = safe_float(your_metrics.get("contrastScore"))
    comp_contrast = avg_value("contrastScore")
    if (standout is not None and standout < 70) or (
        your_contrast is not None and comp_contrast is not None and your_contrast + 8 < comp_contrast
    ):
        add(
            "Усилить заметность в выдаче",
            "Чистая обложка без дополнительного акцента.",
            "Один управляемый акцент: контрастный фон/плашка/стрелка + 2-4 слова выгоды.",
            comparison_phrase(your_contrast, comp_contrast, "Контраст", "/100") or "Нужно проверить, что обложка выделяется рядом с конкурентами.",
            "CTR из поисковой выдачи и доля переходов из рекомендаций.",
        )

    readability = photo_criterion_score(your_photo, "mobile_readability")
    load = safe_float(your_metrics.get("visualLoadPercent"))
    if (readability is not None and readability < 72) or (load is not None and load > 60):
        add(
            "Проверить читаемость оффера с телефона",
            "Оффер как сейчас, без сокращения.",
            "Один крупный тезис до 3-5 слов, остальное перенести на второй слайд.",
            "Перегруженная обложка может быть понятной в редакторе, но теряться в мобильной выдаче WB.",
            "CTR на мобильном трафике и досмотры второго/третьего фото.",
        )

    if len(hypotheses) < 2:
        add(
            "Сравнить смысловые акценты",
            "Первое фото с акцентом на внешний вид товара.",
            "Первое фото с акцентом на результат/выгоду использования.",
            "По базовым метрикам сильного провала нет, значит тестировать нужно смысл, который мотивирует открыть карточку.",
            "CTR карточки и конверсия в корзину.",
        )
    if len(hypotheses) < 3:
        action_title = (actions[0] or {}).get("title") if actions else ""
        add(
            "Проверить версию против лучшего конкурента",
            "Текущая обложка.",
            "Вариант с визуальным паттерном лучшего конкурента, но с вашей выгодой и фирменным цветом.",
            action_title or "Лучший конкурент показывает ориентир по первому фото, но его можно адаптировать без копирования.",
            "CTR относительно текущей версии и изменение позиции по поведенческим сигналам.",
        )

    return hypotheses[:3]


def first_photo_comparison(your_analysis: dict[str, Any], competitor_analyses: list[dict[str, Any]]) -> dict[str, Any]:
    your_photo = your_analysis.get("firstPhotoAnalysis") or {}
    competitor_photos = [
        item
        for item in (photo_competitor_item(analysis) for analysis in competitor_analyses)
        if item is not None
    ]
    if not competitor_photos:
        return {
            "available": False,
            "verdict": "Первые фото конкурентов не удалось загрузить для сравнения.",
            "clickVerdict": "Сравнить понятность, заметность и мотивацию к клику пока нельзя: фото конкурентов недоступны.",
            "marketPatterns": [],
            "yourCoverStrengths": [],
            "yourCoverWeaknesses": ["Нужно повторить сравнение, чтобы понять, как наша обложка выглядит рядом с конкурентами."],
            "abTestHypotheses": [
                {
                    "title": "Проверить главный смысл первого фото",
                    "variantA": "Текущая обложка.",
                    "variantB": "Товар крупно + одна конкретная выгода, закрывающая главное возражение.",
                    "reason": "Даже без конкурентов можно проверить, понятнее ли новая обложка мотивирует открыть карточку.",
                    "successMetric": "CTR карточки и конверсия в корзину.",
                }
            ],
            "actions": [
                photo_recommendation(
                    "low",
                    "Повторить сравнение позже",
                    "Запустить анализ конкурентов ещё раз: иногда Wildberries временно не отдаёт изображения.",
                    "Визуальная часть сравнения зависит от доступности первых фото WB.",
                )
            ],
        }

    def avg_value(key: str) -> float | None:
        values = [safe_float((item.get("metrics") or {}).get(key)) for item in competitor_photos]
        clean = [value for value in values if value is not None]
        if not clean:
            return None
        return round(sum(clean) / len(clean), 1)

    comp_score = round(sum(float(item["score"]) for item in competitor_photos) / len(competitor_photos), 1)
    best = max(competitor_photos, key=lambda item: float(item["score"]))
    your_score = safe_float(your_photo.get("score"))
    your_metrics = your_photo.get("metrics") or {}
    actions: list[dict[str, Any]] = []
    market_patterns = build_market_photo_patterns(competitor_photos, avg_value)

    if not your_photo.get("ok") or your_score is None:
        verdict = "Ваше первое фото не удалось оценить, но фото конкурентов доступны для ориентира."
        actions.append(
            photo_recommendation(
                "high",
                "Проверить доступность первого фото",
                "Убедиться, что первое изображение карточки открывается на WB и не заменено пустым/ошибочным файлом.",
                your_photo.get("error") or "Сервис не получил изображение для анализа.",
            )
        )
    else:
        delta = round(your_score - comp_score, 1)
        if delta >= 7:
            verdict = f"Первое фото сильнее среднего уровня конкурентов: {round(your_score)}/100 против {round(comp_score)}/100."
        elif delta <= -7:
            verdict = f"Первое фото слабее среднего уровня конкурентов: {round(your_score)}/100 против {round(comp_score)}/100."
        else:
            verdict = f"Первое фото близко к конкурентам: {round(your_score)}/100 против {round(comp_score)}/100."

        comp_subject = avg_value("productSharePercent")
        your_subject = safe_float(your_metrics.get("productSharePercent"))
        if comp_subject is not None and your_subject is not None and your_subject + 8 < comp_subject:
            actions.append(
                photo_recommendation(
                    "high",
                    "Сделать товар заметнее конкурентов",
                    "Увеличить товар в первом кадре или показать главный элемент крупнее, чтобы карточка быстрее считывалась в выдаче.",
                    f"У вас товар занимает около {round(your_subject)}%, у конкурентов в среднем {round(comp_subject)}%.",
                )
            )

        comp_contrast = avg_value("contrastScore")
        your_contrast = safe_float(your_metrics.get("contrastScore"))
        if comp_contrast is not None and your_contrast is not None and your_contrast + 8 < comp_contrast:
            actions.append(
                photo_recommendation(
                    "medium",
                    "Поднять контраст до уровня рынка",
                    "Добавить аккуратные тени, контуры или более чистое разделение товара и фона.",
                    f"Контраст у вас {round(your_contrast)}/100, у конкурентов в среднем {round(comp_contrast)}/100.",
                )
            )

        comp_saturation = avg_value("saturationPercent")
        your_saturation = safe_float(your_metrics.get("saturationPercent"))
        if comp_saturation is not None and your_saturation is not None and your_saturation + 8 < comp_saturation:
            actions.append(
                photo_recommendation(
                    "medium",
                    "Добавить управляемый цветовой акцент",
                    "Использовать цвет бренда или короткую плашку с выгодой, чтобы первое фото выделялось без визуального шума.",
                    f"Цветовой акцент у вас {round(your_saturation)}%, у конкурентов в среднем {round(comp_saturation)}%.",
                )
            )

        comp_detail = avg_value("detailScore")
        your_detail = safe_float(your_metrics.get("detailScore"))
        if comp_detail is not None and your_detail is not None and your_detail + 8 < comp_detail:
            actions.append(
                photo_recommendation(
                    "medium",
                    "Показать больше доказательных деталей",
                    "Добавить крупный фрагмент материала, комплектации или важной функции на первый/второй слайд.",
                    f"Детальность у вас {round(your_detail)}/100, у конкурентов в среднем {round(comp_detail)}/100.",
                )
            )

        if not actions:
            actions.append(
                photo_recommendation(
                    "low",
                    "Тестировать смысл, а не только картинку",
                    "Сделать A/B-вариант первого фото с другой главной выгодой: акцент на результате, комплектации или снятии возражения.",
                    "По базовым визуальным метрикам сильного отставания от конкурентов не найдено.",
                )
            )

    if your_photo.get("ok") and your_score is not None:
        your_strengths, your_weaknesses = build_your_cover_points(your_photo, competitor_photos, avg_value)
        ab_hypotheses = build_ab_test_hypotheses(your_photo, competitor_photos, avg_value, actions)
        clarity = photo_criterion_score(your_photo, "one_second_meaning")
        visibility = photo_criterion_score(your_photo, "competitive_standout")
        motivation = photo_criterion_score(your_photo, "needs_objections")
        comp_clarity = competitor_criterion_avg(competitor_photos, "one_second_meaning")
        comp_visibility = competitor_criterion_avg(competitor_photos, "competitive_standout")
        comp_motivation = competitor_criterion_avg(competitor_photos, "needs_objections")
        click_verdict_parts = [
            comparison_phrase(clarity, comp_clarity, "понятность", "/100"),
            comparison_phrase(visibility, comp_visibility, "заметность", "/100"),
            comparison_phrase(motivation, comp_motivation, "мотивация открыть карточку", "/100"),
        ]
        click_verdict = " ".join(part for part in click_verdict_parts if part) or (
            "Оцениваем обложку по трем задачам: быстро понять товар, заметить его в выдаче и захотеть открыть карточку."
        )
    else:
        your_strengths = []
        your_weaknesses = ["Наше первое фото не удалось загрузить, поэтому нельзя честно оценить понятность, заметность и мотивацию к клику."]
        ab_hypotheses = [
            {
                "title": "Проверить доступную версию первого фото",
                "variantA": "Текущее первое фото после восстановления загрузки.",
                "variantB": "Пересобранная обложка: товар крупно + одна выгода + чистые зоны WB.",
                "reason": "Без стабильной загрузки фото карточка теряет визуальную конкурентность в выдаче.",
                "successMetric": "CTR карточки и отсутствие ошибок загрузки первого изображения.",
            }
        ]
        click_verdict = "Наше фото не оценено: сначала нужно восстановить загрузку, затем сравнить понятность, заметность и мотивацию к клику."

    return {
        "available": True,
        "verdict": verdict,
        "clickVerdict": click_verdict,
        "marketPatterns": market_patterns,
        "yourCoverStrengths": your_strengths,
        "yourCoverWeaknesses": your_weaknesses,
        "abTestHypotheses": ab_hypotheses,
        "your": {
            "score": None if your_score is None else round(your_score),
            "scoreLabel": your_photo.get("scoreLabel"),
            "imageUrl": your_photo.get("imageUrl"),
            "metrics": your_metrics,
            "criteria": your_photo.get("criteria") or [],
        },
        "competitorsAvg": {
            "score": comp_score,
            "brightnessPercent": avg_value("brightnessPercent"),
            "contrastScore": avg_value("contrastScore"),
            "saturationPercent": avg_value("saturationPercent"),
            "productSharePercent": avg_value("productSharePercent"),
            "lightBackgroundPercent": avg_value("lightBackgroundPercent"),
            "detailScore": avg_value("detailScore"),
            "visualLoadPercent": avg_value("visualLoadPercent"),
            "marketplaceZoneActivityPercent": avg_value("marketplaceZoneActivityPercent"),
            "oneSecondMeaningScore": competitor_criterion_avg(competitor_photos, "one_second_meaning"),
            "mobileReadabilityScore": competitor_criterion_avg(competitor_photos, "mobile_readability"),
            "competitiveStandoutScore": competitor_criterion_avg(competitor_photos, "competitive_standout"),
            "needsObjectionsScore": competitor_criterion_avg(competitor_photos, "needs_objections"),
        },
        "bestCompetitor": best,
        "actions": actions[:5],
        "competitors": competitor_photos[:10],
    }


def compare_aspects(your_analysis: dict[str, Any], competitor_analyses: list[dict[str, Any]]) -> list[dict[str, Any]]:
    your_totals = aspect_totals(your_analysis)
    competitor_totals: dict[str, dict[str, float]] = {}
    competitor_loaded = sum(int(analysis["summary"].get("loadedReviews") or 0) for analysis in competitor_analyses)

    for analysis in competitor_analyses:
        for key, values in aspect_totals(analysis).items():
            current = competitor_totals.setdefault(key, {"positive": 0.0, "negative": 0.0})
            current["positive"] += values["positive"]
            current["negative"] += values["negative"]

    your_loaded = int(your_analysis["summary"].get("loadedReviews") or 0)
    keys = set(your_totals) | set(competitor_totals)
    rows = []
    for key in keys:
        your_values = your_totals.get(key, {"positive": 0.0, "negative": 0.0})
        comp_values = competitor_totals.get(key, {"positive": 0.0, "negative": 0.0})
        your_pos = rate_per_100(your_values["positive"], your_loaded)
        your_neg = rate_per_100(your_values["negative"], your_loaded)
        comp_pos = rate_per_100(comp_values["positive"], competitor_loaded)
        comp_neg = rate_per_100(comp_values["negative"], competitor_loaded)

        if your_neg > comp_neg + 2:
            status = "У нас слабее"
            recommendation = RECOMMENDATION_TEMPLATES.get(key, RECOMMENDATION_TEMPLATES["overall"])["content_action"]
            priority = "high"
        elif comp_pos > your_pos + 3:
            status = "Конкуренты сильнее"
            title = "Общее впечатление" if key == "overall" else ASPECTS.get(key, {}).get("title", key)
            recommendation = f"Показать и доказать «{title.lower()}» сильнее: вынести аргумент в первые изображения и подкрепить фото/видео."
            priority = "medium"
        elif your_pos > comp_pos + 3 and your_neg <= comp_neg + 1:
            status = "Наше преимущество"
            title = "Общее впечатление" if key == "overall" else ASPECTS.get(key, {}).get("title", key)
            recommendation = f"Закрепить преимущество по теме «{title.lower()}» в главном фото, инфографике и ТЗ дизайнеру."
            priority = "medium"
        else:
            status = "Паритет"
            recommendation = "Поддерживать текущий уровень и отслеживать новые негативные отзывы."
            priority = "low"

        rows.append(
            {
                "key": key,
                "title": "Общее впечатление" if key == "overall" else ASPECTS.get(key, {}).get("title", key),
                "status": status,
                "priority": priority,
                "priorityLabel": priority_label(priority),
                "yourPositivePer100": your_pos,
                "yourNegativePer100": your_neg,
                "competitorPositivePer100": comp_pos,
                "competitorNegativePer100": comp_neg,
                "recommendation": recommendation,
            }
        )

    rows.sort(
        key=lambda row: (
            {"У нас слабее": 0, "Конкуренты сильнее": 1, "Наше преимущество": 2, "Паритет": 3}.get(row["status"], 4),
            -abs(row["yourNegativePer100"] - row["competitorNegativePer100"]),
        )
    )
    return rows[:8]


def competitor_action_plan(
    your_analysis: dict[str, Any],
    competitor_analyses: list[dict[str, Any]],
    aspect_comparison: list[dict[str, Any]],
    benchmark: dict[str, Any],
) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    for row in aspect_comparison:
        if row["status"] in ("У нас слабее", "Конкуренты сильнее"):
            actions.append(
                {
                    "priority": row["priority"],
                    "priorityLabel": row["priorityLabel"],
                    "area": "Контент",
                    "title": f"Усилить: {row['title']}",
                    "action": row["recommendation"],
                    "why": (
                        f"У нас: +{row['yourPositivePer100']} / -{row['yourNegativePer100']} упоминаний на 100 отзывов; "
                        f"у конкурентов: +{row['competitorPositivePer100']} / -{row['competitorNegativePer100']}."
                    ),
                }
            )

    your = benchmark["your"]
    comp = benchmark["competitorsAvg"]
    if comp.get("feedbackCount") and your.get("feedbackCount") and comp["feedbackCount"] > your["feedbackCount"] * 2:
        actions.append(
            {
                "priority": "medium",
                "priorityLabel": priority_label("medium"),
                "area": "Контент",
                "title": "Усилить доверие к карточке",
                "action": "Добавить больше доказательств: реальные фото, видео, крупные планы, FAQ и ответы на частые сомнения.",
                "why": f"У конкурентов в среднем больше отзывов: {round(comp['feedbackCount'])} против {your['feedbackCount']} у нас.",
            }
        )

    if comp.get("averageRating") and your.get("averageRating") and comp["averageRating"] > your["averageRating"] + 0.15:
        actions.append(
            {
                "priority": "high",
                "priorityLabel": priority_label("high"),
                "area": "Товар",
                "title": "Разобрать разрыв в рейтинге",
                "action": "Сравнить слабые стороны товара с конкурентами и проверить, не связаны ли претензии с партией, упаковкой или ожиданиями из карточки.",
                "why": f"Средняя оценка конкурентов выше: {comp['averageRating']} против {your['averageRating']} у нас.",
            }
        )

    if not actions:
        for row in aspect_comparison[:3]:
            if row["status"] == "Наше преимущество":
                actions.append(
                    {
                        "priority": "medium",
                        "priorityLabel": priority_label("medium"),
                        "area": "Контент",
                        "title": f"Закрепить преимущество: {row['title']}",
                        "action": row["recommendation"],
                        "why": "По этой теме наш товар выглядит сильнее конкурентов в отзывах.",
                    }
                )

    priority_order = {"high": 0, "medium": 1, "low": 2}
    unique = []
    seen = set()
    for action in sorted(actions, key=lambda item: priority_order.get(item["priority"], 1)):
        key = (action["title"], action["area"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(action)
        if len(unique) >= 6:
            break
    return unique


def plural_ru(value: int, one: str, few: str, many: str) -> str:
    number = abs(int(value))
    if 11 <= number % 100 <= 14:
        return many
    last = number % 10
    if last == 1:
        return one
    if 2 <= last <= 4:
        return few
    return many


def competitor_verdict(benchmark: dict[str, Any], aspect_comparison: list[dict[str, Any]], competitor_count: int) -> str:
    weak = sum(1 for row in aspect_comparison if row["status"] in ("У нас слабее", "Конкуренты сильнее"))
    strong = sum(1 for row in aspect_comparison if row["status"] == "Наше преимущество")
    your_rating = benchmark["your"].get("averageRating")
    comp_rating = benchmark["competitorsAvg"].get("averageRating")
    if competitor_count == 0:
        return "Не удалось собрать достаточно конкурентов для сравнения."
    competitor_word = plural_ru(competitor_count, "конкурента", "конкурентов", "конкурентов")
    if comp_rating and your_rating and your_rating >= comp_rating and strong >= weak:
        return f"На фоне {competitor_count} {competitor_word} товар выглядит устойчиво: рейтинг не ниже рынка, сильные стороны стоит активнее вынести в контент."
    if weak:
        zone_word = plural_ru(weak, "зона", "зоны", "зон")
        return f"На фоне {competitor_count} {competitor_word} есть {weak} {zone_word} для усиления: их нужно закрыть в первых фото, инфографике и описании ожиданий."
    competitor_with_word = plural_ru(competitor_count, "конкурентом", "конкурентами", "конкурентами")
    return f"Сравнение с {competitor_count} {competitor_with_word} показывает близкий уровень; главный резерв — лучше упаковать доказательства в карточке."


def analyze_competitors(article_input: str, limit_input: str | None, competitor_input: str | None) -> dict[str, Any]:
    article = article_from_input(article_input)
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    target_count = min(max(int(competitor_input or MAX_COMPETITORS), 1), MAX_COMPETITORS)

    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    try:
        feedback_data, feedback_url = fetch_feedbacks(article, root)
    except AppError as exc:
        if exc.status != 429:
            raise
        warning = "Отзывы вашей карточки не загрузились внутри сравнения из-за временного лимита WB; использованы доступные метрики карточки."
        feedback_data = competitor_card_only_feedback_data(product, warning)
        feedback_url = ""
    your_analysis = analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)

    candidates, queries, search_url = competitor_candidates(article, product, card_meta, target_count)
    competitor_analyses = []
    competitors = []
    errors = []

    for candidate in candidates:
        if len(competitors) >= target_count:
            break
        nm_id = safe_int(candidate.get("id"))
        if not nm_id:
            continue
        include_competitor_photo = len(competitors) < 5
        if competitor_analyses:
            time.sleep(0.55)
        try:
            candidate_feedbacks, candidate_feedback_url = fetch_feedbacks(nm_id, safe_int(candidate.get("root")))
            analysis = analyze_feedbacks(
                nm_id,
                candidate,
                candidate_feedbacks,
                candidate_feedback_url,
                f"https://www.wildberries.ru/catalog/{nm_id}/detail.aspx",
                min(limit, COMPETITOR_REVIEW_LIMIT),
                include_first_photo=include_competitor_photo,
            )
            competitor_analyses.append(analysis)
            competitors.append(competitor_product_payload(candidate, analysis))
        except AppError as exc:
            errors.append({"article": nm_id, "error": exc.message})
            if exc.status == 429:
                warning = "Отзывы конкурента не загрузились из-за временного лимита WB; в сравнении использованы доступные данные карточки."
                try:
                    analysis = analyze_feedbacks(
                        nm_id,
                        candidate,
                        competitor_card_only_feedback_data(candidate, warning),
                        "",
                        f"https://www.wildberries.ru/catalog/{nm_id}/detail.aspx",
                        0,
                        include_first_photo=include_competitor_photo,
                    )
                    competitor_analyses.append(analysis)
                    competitors.append(competitor_product_payload(candidate, analysis))
                except AppError as fallback_exc:
                    errors.append({"article": nm_id, "error": fallback_exc.message})
            continue

    if not competitor_analyses:
        raise AppError(
            "Не удалось собрать отзывы конкурентов. Wildberries мог временно ограничить выдачу или у похожих товаров нет текстовых отзывов.",
            502,
        )

    benchmark = competitor_benchmark(your_analysis, competitor_analyses)
    aspect_comparison = compare_aspects(your_analysis, competitor_analyses)
    action_plan = competitor_action_plan(your_analysis, competitor_analyses, aspect_comparison, benchmark)
    visual_comparison = first_photo_comparison(your_analysis, competitor_analyses)

    return {
        "product": your_analysis["product"],
        "summary": {
            "verdict": competitor_verdict(benchmark, aspect_comparison, len(competitors)),
            "competitorCount": len(competitors),
            "requestedCompetitors": target_count,
            "searchQueries": queries,
        },
        "benchmark": benchmark,
        "aspectComparison": aspect_comparison,
        "actionPlan": action_plan,
        "visualComparison": visual_comparison,
        "competitors": competitors,
        "source": {
            "searchUrl": search_url,
            "cardMetaUrl": card_meta_url,
            "selectionMode": "title_and_characteristics_score",
            "imageAnalysisMode": "first_photo_visual_metrics",
            "fetchedAt": datetime.now(timezone.utc).isoformat(),
            "reviewLimitPerCompetitor": min(limit, COMPETITOR_REVIEW_LIMIT),
            "errors": errors[:8],
        },
    }


def analyze_feedbacks(
    article: int,
    product: dict[str, Any],
    feedback_data: dict[str, Any],
    feedback_url: str,
    card_url: str,
    limit: int,
    card_meta: dict[str, Any] | None = None,
    card_meta_url: str | None = None,
    include_first_photo: bool = True,
) -> dict[str, Any]:
    all_feedbacks = feedback_data.get("feedbacks") or []
    feedbacks = all_feedbacks[:limit]
    aspect_data: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "positive": 0,
            "negative": 0,
            "neutral": 0,
            "sentences": [],
            "positive_examples": [],
            "negative_examples": [],
        }
    )

    positive_sentences: list[str] = []
    negative_sentences: list[str] = []
    neutral_sentences: list[str] = []

    for feedback in feedbacks:
        rating = safe_int(feedback.get("productValuation"))
        for field in ("pros", "cons", "text"):
            source_text = as_text(feedback.get(field))
            for sentence in split_sentences(source_text):
                polarity = classify_sentence(field, sentence, rating)
                if polarity == "neutral":
                    neutral_sentences.append(sentence)
                elif polarity == "positive":
                    positive_sentences.append(sentence)
                else:
                    negative_sentences.append(sentence)

                for aspect in detect_aspects(sentence):
                    item = aspect_data[aspect]
                    item[polarity] += 1
                    item["sentences"].append(sentence)
                    evidence = {
                        "text": short_text(sentence),
                        "rating": rating,
                        "date": feedback_date(feedback),
                    }
                    if polarity == "positive" and len(item["positive_examples"]) < 5:
                        item["positive_examples"].append(evidence)
                    if polarity == "negative" and len(item["negative_examples"]) < 5:
                        item["negative_examples"].append(evidence)

    specific_keys = [key for key in aspect_data if key != "overall"]
    strength_candidates = specific_keys or list(aspect_data.keys())
    weakness_candidates = specific_keys or list(aspect_data.keys())

    strengths = [
        summarize_aspect(key, aspect_data[key], "positive")
        for key in strength_candidates
        if aspect_data[key]["positive"] >= 1
    ]
    strengths.sort(key=lambda item: (item["positiveMentions"], item["balance"]), reverse=True)
    strengths = strengths[:5]

    weaknesses = [
        summarize_aspect(key, aspect_data[key], "negative")
        for key in weakness_candidates
        if aspect_data[key]["negative"] >= 1
    ]
    weaknesses.sort(key=lambda item: (item["negativeMentions"], -item["positiveMentions"]), reverse=True)
    weaknesses = weaknesses[:5]

    distribution = normalize_distribution(feedback_data.get("valuationDistribution"), all_feedbacks)
    distribution_total = sum(distribution.values())
    positive_ratings = distribution["4"] + distribution["5"]
    negative_ratings = distribution["1"] + distribution["2"] + distribution["3"]
    avg_rating = safe_float(feedback_data.get("valuation")) or safe_float(product.get("reviewRating"))

    text_count = int(feedback_data.get("feedbackCountWithText") or len(feedbacks))
    total_count = int(feedback_data.get("feedbackCount") or len(all_feedbacks))
    positive_pct = round(positive_ratings * 100 / distribution_total) if distribution_total else None
    negative_pct = round(negative_ratings * 100 / distribution_total) if distribution_total else None
    matching_size = feedback_data.get("matchingSizePercentages") or {}
    recommendations = build_recommendations(
        strengths,
        weaknesses,
        negative_pct,
        matching_size,
        text_count,
        product,
        card_meta,
    )
    marketplace = product.get("_marketplace") or MARKETPLACE_WB
    seo_analysis = build_seo_analysis(
        product,
        card_meta,
        positive_sentences,
        negative_sentences,
        neutral_sentences,
        text_count,
    )
    if marketplace == MARKETPLACE_OZON:
        source_image_url = as_text(product.get("sourceImageUrl") or product.get("imageUrl"))
        image_fetcher = (lambda url=source_image_url, referer=as_text(product.get("url")): fetch_remote_image(url, referer, timeout=8)) if source_image_url else None
        first_photo_analysis = (
            analyze_first_photo(
                article,
                product,
                strengths,
                weaknesses,
                image_url_override=source_image_url,
                source_url_override=source_image_url,
                image_fetcher=image_fetcher,
                marketplace_label="Ozon",
            )
            if include_first_photo
            else None
        )
        product_payload = {
            "marketplace": MARKETPLACE_OZON,
            "marketplaceLabel": "Ozon",
            "article": article,
            "sku": product.get("sku"),
            "productId": product.get("product_id"),
            "offerId": product.get("offer_id"),
            "root": product.get("product_id"),
            "name": as_text(product.get("name")),
            "brand": as_text(product.get("brand")),
            "supplier": as_text(product.get("supplier")),
            "imageUrl": source_image_url,
            "imageUrls": [source_image_url] if source_image_url else [],
            "sourceImageUrl": source_image_url,
            "reviewRating": avg_rating,
            "feedbacks": total_count,
            "textFeedbacks": text_count,
            "url": as_text(product.get("url")) or f"https://www.ozon.ru/product/{article}/",
        }
    else:
        first_photo_analysis = analyze_first_photo(article, product, strengths, weaknesses) if include_first_photo else None
        product_root = safe_int(product.get("root"))
        image_count = safe_int(product.get("pics")) or 1
        product_payload = {
            "marketplace": MARKETPLACE_WB,
            "marketplaceLabel": "WB",
            "article": article,
            "root": product_root,
            "name": as_text(product.get("name")),
            "brand": as_text(product.get("brand")),
            "supplier": as_text(product.get("supplier")),
            "imageUrl": product_image_url(article),
            "imageUrls": [product_image_url(article, index) for index in range(1, min(image_count, 4) + 1)],
            "sourceImageUrl": wb_product_image_url(article),
            "reviewRating": avg_rating,
            "feedbacks": total_count,
            "textFeedbacks": text_count,
            "url": f"https://www.wildberries.ru/catalog/{article}/detail.aspx",
        }

    return {
        "product": product_payload,
        "summary": {
            "verdict": build_verdict(avg_rating, distribution, text_count, len(weaknesses)),
            "averageRating": avg_rating,
            "feedbackCount": total_count,
            "textFeedbackCount": text_count,
            "loadedReviews": len(feedbacks),
            "distribution": distribution,
            "positiveRatingPercent": positive_pct,
            "negativeRatingPercent": negative_pct,
            "matchingSizePercentages": matching_size,
        },
        "strengths": strengths,
        "weaknesses": weaknesses,
        "recommendations": recommendations,
        "firstPhotoAnalysis": first_photo_analysis,
        "seoAnalysis": seo_analysis,
        "terms": {
            "positive": top_terms(positive_sentences, 12),
            "negative": top_terms(negative_sentences, 12),
            "neutral": top_terms(neutral_sentences, 8),
        },
        "examples": {
            "positive": select_examples(feedbacks, "positive"),
            "negative": select_examples(feedbacks, "negative"),
        },
        "source": {
            "cardUrl": card_url,
            "cardMetaUrl": card_meta_url,
            "feedbackUrl": feedback_url,
            "fetchedAt": datetime.now(timezone.utc).isoformat(),
            "limit": limit,
            "marketplace": marketplace,
            "warning": feedback_data.get("_warning"),
            "note": "Локальный эвристический анализ отзывов карточки маркетплейса.",
        },
    }


def analyze_article(article_input: str, limit_input: str | None, marketplace_input: str | None = None) -> dict[str, Any]:
    limit = min(max(int(limit_input or 120), 1), MAX_LIMIT)
    marketplace = marketplace_from_input(marketplace_input)
    if marketplace == MARKETPLACE_OZON:
        product, feedback_data, card_url, card_meta_url = fetch_ozon_product_and_feedbacks(article_input, limit)
        article = safe_int(product.get("article")) or safe_int(product.get("sku")) or safe_int(product.get("product_id")) or 0
        return analyze_feedbacks(article, product, feedback_data, card_url, card_url, limit, {}, card_meta_url)

    article = article_from_input(article_input)
    product, card_url = fetch_product(article)
    card_meta, card_meta_url = fetch_card_metadata(article)
    root = safe_int(product.get("root"))
    feedback_data, feedback_url = fetch_feedbacks(article, root)
    return analyze_feedbacks(article, product, feedback_data, feedback_url, card_url, limit, card_meta, card_meta_url)


def telegram_bot_token() -> str:
    return os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()


def telegram_bot_username() -> str:
    return (os.environ.get("TELEGRAM_BOT_USERNAME") or DEFAULT_TELEGRAM_BOT_USERNAME).strip().lstrip("@")


def telegram_required_channels() -> list[str]:
    raw = os.environ.get("TELEGRAM_REQUIRED_CHANNELS") or DEFAULT_TELEGRAM_REQUIRED_CHANNELS
    channels = []
    for item in raw.split(","):
        channel = item.strip()
        if not channel:
            continue
        if not channel.startswith("@") and not channel.startswith("-"):
            channel = f"@{channel}"
        channels.append(channel)
    return channels


def telegram_access_mode() -> str:
    return (os.environ.get("TELEGRAM_ACCESS_MODE") or "all").strip().lower()


def truthy_env(name: str) -> bool:
    return (os.environ.get(name) or "").strip().lower() in {"1", "true", "yes", "on"}


def public_base_url() -> str:
    return (os.environ.get("PUBLIC_BASE_URL") or DEFAULT_PUBLIC_BASE_URL).strip().rstrip("/")


def telegram_bot_url() -> str:
    return f"https://t.me/{telegram_bot_username()}"


def telegram_webapp_url() -> str:
    return (os.environ.get("TELEGRAM_WEBAPP_URL") or public_base_url()).strip()


def telegram_auto_setup_enabled() -> bool:
    return truthy_env("TELEGRAM_AUTO_SETUP")


def telegram_auth_enabled() -> bool:
    return bool(telegram_bot_token())


def auth_secret_bytes() -> bytes:
    secret = os.environ.get("AUTH_SESSION_SECRET", "").strip()
    if not secret:
        secret = f"{telegram_bot_token()}:{APP_VERSION}:fallback-session-secret"
    return hashlib.sha256(secret.encode("utf-8")).digest()


def telegram_webhook_secret() -> str:
    explicit = os.environ.get("TELEGRAM_WEBHOOK_SECRET", "").strip()
    if explicit:
        return explicit
    return hmac.new(auth_secret_bytes(), b"telegram-webhook", hashlib.sha256).hexdigest()


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def public_auth_user(session: dict[str, Any] | None) -> dict[str, Any] | None:
    if not session:
        return None
    return {
        "id": session.get("id"),
        "first_name": session.get("first_name") or "",
        "last_name": session.get("last_name") or "",
        "username": session.get("username") or "",
        "photo_url": session.get("photo_url") or "",
    }


def signed_session_token(session: dict[str, Any]) -> str:
    payload = dict(session)
    payload.setdefault("iat", int(time.time()))
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    encoded = b64url_encode(raw)
    signature = hmac.new(auth_secret_bytes(), encoded.encode("ascii"), hashlib.sha256).hexdigest()
    return f"{encoded}.{signature}"


def parse_session_token(token: str) -> dict[str, Any] | None:
    try:
        encoded, signature = token.split(".", 1)
    except ValueError:
        return None
    expected = hmac.new(auth_secret_bytes(), encoded.encode("ascii"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        return None
    try:
        session = json.loads(b64url_decode(encoded).decode("utf-8"))
    except (ValueError, json.JSONDecodeError):
        return None
    issued_at = safe_int(session.get("iat")) or 0
    if issued_at + AUTH_TTL_SECONDS < int(time.time()):
        return None
    user_id = safe_int(session.get("id"))
    if not user_id:
        return None
    session["id"] = user_id
    return session


def session_from_cookie(cookie_header: str | None) -> dict[str, Any] | None:
    if not cookie_header:
        return None
    cookie = SimpleCookie()
    try:
        cookie.load(cookie_header)
    except Exception:
        return None
    morsel = cookie.get(AUTH_COOKIE_NAME)
    if not morsel:
        return None
    return parse_session_token(morsel.value)


def verify_telegram_login(auth_data: dict[str, Any]) -> dict[str, Any]:
    token = telegram_bot_token()
    if not token:
        raise AppError("Telegram-доступ не настроен: нет TELEGRAM_BOT_TOKEN.", 503)
    received_hash = as_text(auth_data.get("hash"))
    if not received_hash:
        raise AppError("Telegram не передал подпись авторизации.", 400)

    clean: dict[str, str] = {}
    for key, value in auth_data.items():
        if key == "hash" or value is None:
            continue
        text = as_text(value)
        if text:
            clean[key] = text

    auth_date = safe_int(clean.get("auth_date"))
    if not auth_date:
        raise AppError("Telegram не передал дату авторизации.", 400)
    if auth_date + TELEGRAM_LOGIN_MAX_AGE_SECONDS < int(time.time()):
        raise AppError("Авторизация Telegram устарела. Войдите ещё раз.", 401)

    data_check_string = "\n".join(f"{key}={clean[key]}" for key in sorted(clean))
    secret_key = hashlib.sha256(token.encode("utf-8")).digest()
    expected_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected_hash, received_hash):
        raise AppError("Не удалось проверить подпись Telegram.", 401)

    user_id = safe_int(clean.get("id"))
    if not user_id:
        raise AppError("Telegram не передал ID пользователя.", 400)
    return {
        "id": user_id,
        "first_name": clean.get("first_name", ""),
        "last_name": clean.get("last_name", ""),
        "username": clean.get("username", ""),
        "photo_url": clean.get("photo_url", ""),
        "auth_date": auth_date,
        "iat": int(time.time()),
    }


def verify_telegram_webapp(init_data: str) -> dict[str, Any]:
    token = telegram_bot_token()
    if not token:
        raise AppError("Telegram-доступ не настроен: нет TELEGRAM_BOT_TOKEN.", 503)
    if not init_data:
        raise AppError("Telegram не передал данные Mini App.", 400)

    pairs = parse_qsl(init_data, keep_blank_values=True, strict_parsing=False)
    data: dict[str, str] = {}
    received_hash = ""
    for key, value in pairs:
        if key == "hash":
            received_hash = value
        else:
            data[key] = value
    if not received_hash:
        raise AppError("Telegram Mini App не передал подпись.", 400)

    auth_date = safe_int(data.get("auth_date"))
    if not auth_date:
        raise AppError("Telegram Mini App не передал дату авторизации.", 400)
    if auth_date + TELEGRAM_LOGIN_MAX_AGE_SECONDS < int(time.time()):
        raise AppError("Авторизация Telegram устарела. Откройте сервис из бота ещё раз.", 401)

    data_check_string = "\n".join(f"{key}={data[key]}" for key in sorted(data))
    secret_key = hmac.new(b"WebAppData", token.encode("utf-8"), hashlib.sha256).digest()
    expected_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected_hash, received_hash):
        raise AppError("Не удалось проверить подпись Telegram Mini App.", 401)

    try:
        user = json.loads(data.get("user") or "{}")
    except json.JSONDecodeError as exc:
        raise AppError("Telegram Mini App передал некорректные данные пользователя.", 400, str(exc)) from exc
    if not isinstance(user, dict):
        raise AppError("Telegram Mini App не передал пользователя.", 400)

    user_id = safe_int(user.get("id"))
    if not user_id:
        raise AppError("Telegram Mini App не передал ID пользователя.", 400)
    return {
        "id": user_id,
        "first_name": as_text(user.get("first_name")),
        "last_name": as_text(user.get("last_name")),
        "username": as_text(user.get("username")),
        "photo_url": as_text(user.get("photo_url")),
        "auth_date": auth_date,
        "source": "telegram-mini-app",
        "iat": int(time.time()),
    }


def telegram_api_json(method: str, params: dict[str, Any], timeout: int = 10) -> dict[str, Any]:
    token = telegram_bot_token()
    if not token:
        raise AppError("Telegram-доступ не настроен: нет TELEGRAM_BOT_TOKEN.", 503)
    url = f"https://api.telegram.org/bot{token}/{method}?{urlencode(params)}"
    req = Request(url, headers={"Accept": "application/json"})
    try:
        with urlopen(req, timeout=timeout) as response:
            body = response.read().decode("utf-8", "replace")
    except HTTPError as exc:
        details = ""
        try:
            details = exc.read().decode("utf-8", "replace")
        except Exception:
            details = str(exc)
        raise AppError("Telegram API не подтвердил доступ.", 502, details) from exc
    except (URLError, TimeoutError) as exc:
        raise AppError("Не удалось подключиться к Telegram API.", 502, str(exc)) from exc

    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise AppError("Telegram API вернул неожиданный ответ.", 502, str(exc)) from exc
    return data


def telegram_api_post_json(method: str, payload: dict[str, Any], timeout: int = 10) -> dict[str, Any]:
    token = telegram_bot_token()
    if not token:
        raise AppError("Telegram-доступ не настроен: нет TELEGRAM_BOT_TOKEN.", 503)
    url = f"https://api.telegram.org/bot{token}/{method}"
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = Request(
        url,
        data=body,
        headers={"Accept": "application/json", "Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urlopen(req, timeout=timeout) as response:
            raw = response.read().decode("utf-8", "replace")
    except HTTPError as exc:
        details = ""
        try:
            details = exc.read().decode("utf-8", "replace")
        except Exception:
            details = str(exc)
        raise AppError("Telegram API не принял запрос.", 502, details) from exc
    except (URLError, TimeoutError) as exc:
        raise AppError("Не удалось подключиться к Telegram API.", 502, str(exc)) from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise AppError("Telegram API вернул неожиданный ответ.", 502, str(exc)) from exc
    if not data.get("ok"):
        raise AppError("Telegram API вернул ошибку.", 502, as_text(data.get("description")))
    return data


def channel_subscription_status(user_id: int, channel: str) -> tuple[bool, str, str]:
    try:
        data = telegram_api_json("getChatMember", {"chat_id": channel, "user_id": user_id})
    except AppError as exc:
        details = exc.details or exc.message
        lower = details.lower()
        if "user not found" in lower or "member not found" in lower or "participant_id_invalid" in lower:
            return False, "left", details
        return False, "error", details

    if not data.get("ok"):
        description = as_text(data.get("description"))
        lower = description.lower()
        if "user not found" in lower or "member not found" in lower:
            return False, "left", description
        return False, "error", description or "Telegram не вернул статус подписки."

    member = data.get("result") or {}
    status = as_text(member.get("status"))
    allowed = status in {"creator", "administrator", "member"} or (
        status == "restricted" and bool(member.get("is_member"))
    )
    return allowed, status, ""


def check_telegram_access(user_id: int) -> dict[str, Any]:
    channels = telegram_required_channels()
    mode = telegram_access_mode()
    checks = []
    for channel in channels:
        ok, status, error = channel_subscription_status(user_id, channel)
        checks.append({"channel": channel, "ok": ok, "status": status, "error": error})

    if not checks:
        allowed = True
    elif mode == "any":
        allowed = any(item["ok"] for item in checks)
    else:
        allowed = all(item["ok"] for item in checks)

    missing = [item["channel"] for item in checks if not item["ok"]]
    errors = [item for item in checks if item.get("status") == "error"]
    return {
        "allowed": allowed,
        "mode": "any" if mode == "any" else "all",
        "channels": channels,
        "missing": missing,
        "checks": checks,
        "errors": errors,
    }


def telegram_webapp_keyboard() -> dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {
                    "text": "Открыть анализатор",
                    "web_app": {"url": telegram_webapp_url()},
                }
            ]
        ]
    }


def handle_telegram_update(update: dict[str, Any]) -> None:
    message = update.get("message") or update.get("edited_message") or {}
    if not isinstance(message, dict):
        return
    chat = message.get("chat") or {}
    if not isinstance(chat, dict):
        return
    chat_id = safe_int(chat.get("id"))
    if not chat_id:
        return

    channels = ", ".join(telegram_required_channels())
    telegram_api_post_json(
        "sendMessage",
        {
            "chat_id": chat_id,
            "text": (
                "Откройте VOROBEY VISION AI кнопкой ниже. "
                f"Доступ работает для подписчиков каналов: {channels}."
            ),
            "reply_markup": telegram_webapp_keyboard(),
            "disable_web_page_preview": True,
        },
    )


def configure_telegram_bot_if_enabled() -> None:
    if not telegram_auto_setup_enabled() or not telegram_auth_enabled():
        return
    webapp_url = telegram_webapp_url()
    telegram_api_post_json(
        "setChatMenuButton",
        {
            "menu_button": {
                "type": "web_app",
                "text": "Открыть сервис",
                "web_app": {"url": webapp_url},
            }
        },
    )
    telegram_api_post_json(
        "setWebhook",
        {
            "url": f"{public_base_url()}/api/telegram/webhook",
            "allowed_updates": ["message"],
            "secret_token": telegram_webhook_secret(),
        },
    )
    print(f"Telegram bot menu and webhook configured for {webapp_url}", flush=True)


def telegram_diagnostics() -> dict[str, Any]:
    payload: dict[str, Any] = {
        "enabled": telegram_auth_enabled(),
        "autoSetup": telegram_auto_setup_enabled(),
        "botUsername": telegram_bot_username(),
        "botUrl": telegram_bot_url(),
        "webAppUrl": telegram_webapp_url(),
        "channels": telegram_required_channels(),
    }
    if not telegram_auth_enabled():
        return payload
    bot = telegram_api_json("getMe", {}).get("result") or {}
    bot_id = safe_int(bot.get("id"))
    webhook = telegram_api_json("getWebhookInfo", {})
    menu = telegram_api_json("getChatMenuButton", {})
    channel_checks = []
    for channel in telegram_required_channels():
        check: dict[str, Any] = {"channel": channel}
        if bot_id:
            ok, status, error = channel_subscription_status(bot_id, channel)
            check.update({"botCanCheck": status in {"creator", "administrator"}, "botMemberStatus": status, "error": error})
        else:
            check.update({"botCanCheck": False, "botMemberStatus": "unknown", "error": "Не удалось получить ID бота."})
        channel_checks.append(check)
    payload["bot"] = {
        "id": bot_id,
        "username": as_text(bot.get("username")),
        "firstName": as_text(bot.get("first_name")),
    }
    payload["webhook"] = webhook.get("result") or {}
    payload["menuButton"] = menu.get("result") or {}
    payload["channelChecks"] = channel_checks
    return payload


class AnalyzerHandler(BaseHTTPRequestHandler):
    server_version = "WBReviewAnalyzer/1.0"

    def log_message(self, format: str, *args: Any) -> None:
        print(f"{self.address_string()} - {format % args}", flush=True)

    def send_cors_headers(self) -> None:
        origin = self.headers.get("Origin")
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Credentials", "true")
        else:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def cookie_is_secure(self) -> bool:
        host = (self.headers.get("Host") or "").lower()
        return not (host.startswith("127.0.0.1") or host.startswith("localhost"))

    def session_cookie_header(self, session: dict[str, Any]) -> str:
        parts = [
            f"{AUTH_COOKIE_NAME}={signed_session_token(session)}",
            "Path=/",
            f"Max-Age={AUTH_TTL_SECONDS}",
            "HttpOnly",
            "SameSite=Lax",
        ]
        if self.cookie_is_secure():
            parts.append("Secure")
        return "; ".join(parts)

    def clear_session_cookie_header(self) -> str:
        parts = [
            f"{AUTH_COOKIE_NAME}=",
            "Path=/",
            "Max-Age=0",
            "HttpOnly",
            "SameSite=Lax",
        ]
        if self.cookie_is_secure():
            parts.append("Secure")
        return "; ".join(parts)

    def current_session(self) -> dict[str, Any] | None:
        return session_from_cookie(self.headers.get("Cookie"))

    def read_json_body(self) -> dict[str, Any]:
        length = safe_int(self.headers.get("Content-Length")) or 0
        if length <= 0:
            return {}
        if length > 65536:
            raise AppError("Слишком большой запрос авторизации.", 413)
        body = self.rfile.read(length).decode("utf-8", "replace")
        try:
            data = json.loads(body)
        except json.JSONDecodeError as exc:
            raise AppError("Запрос должен быть JSON.", 400, str(exc)) from exc
        if not isinstance(data, dict):
            raise AppError("Запрос должен быть JSON-объектом.", 400)
        return data

    def auth_payload(self, session: dict[str, Any] | None = None) -> dict[str, Any]:
        enabled = telegram_auth_enabled()
        payload = {
            "enabled": enabled,
            "botUsername": telegram_bot_username(),
            "botUrl": telegram_bot_url(),
            "webAppUrl": telegram_webapp_url(),
            "channels": telegram_required_channels(),
            "accessMode": telegram_access_mode(),
            "user": public_auth_user(session),
            "allowed": not enabled,
            "missing": [],
            "checks": [],
        }
        if not enabled:
            return payload
        if not session:
            payload["allowed"] = False
            return payload

        access = check_telegram_access(int(session["id"]))
        payload.update(access)
        payload["user"] = public_auth_user(session)
        return payload

    def require_access(self) -> bool:
        if not telegram_auth_enabled():
            return True
        session = self.current_session()
        if not session:
            self.send_json(
                {
                    "ok": False,
                    "code": "AUTH_REQUIRED",
                    "error": "Войдите через Telegram, чтобы пользоваться сервисом.",
                    "auth": self.auth_payload(None),
                },
                status=401,
            )
            return False
        try:
            auth = self.auth_payload(session)
        except AppError as exc:
            self.send_json(
                {"ok": False, "code": "AUTH_CHECK_FAILED", "error": exc.message, "details": exc.details},
                status=exc.status,
            )
            return False
        if not auth.get("allowed"):
            self.send_json(
                {
                    "ok": False,
                    "code": "SUBSCRIPTION_REQUIRED",
                    "error": "Доступ открыт только подписчикам Telegram-каналов.",
                    "auth": auth,
                },
                status=403,
            )
            return False
        return True

    def send_json(
        self,
        payload: dict[str, Any],
        status: int = 200,
        extra_headers: list[tuple[str, str]] | None = None,
    ) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_cors_headers()
        for name, value in extra_headers or []:
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def send_xlsx(self, filename: str, body: bytes) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_docx(self, filename: str, body: bytes) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_image(self, body: bytes, content_type: str) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_static(self, path: str) -> None:
        parsed_path = path.lstrip("/") or "index.html"
        target = (BASE_DIR / parsed_path).resolve()
        if not str(target).startswith(str(BASE_DIR)) or not target.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return

        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        data = target.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_cors_headers()
        self.end_headers()

    def do_HEAD(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_cors_headers()
            self.end_headers()
            return

        parsed_path = parsed.path.lstrip("/") or "index.html"
        target = (BASE_DIR / parsed_path).resolve()
        if not str(target).startswith(str(BASE_DIR)) or not target.is_file():
            self.send_response(HTTPStatus.NOT_FOUND)
            self.end_headers()
            return

        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(target.stat().st_size))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/telegram/webhook":
            expected_secret = telegram_webhook_secret()
            received_secret = self.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
            if expected_secret and not hmac.compare_digest(expected_secret, received_secret):
                self.send_json({"ok": False, "error": "Forbidden"}, status=403)
                return
            try:
                handle_telegram_update(self.read_json_body())
                self.send_json({"ok": True})
            except AppError as exc:
                self.send_json({"ok": False, "error": exc.message, "details": exc.details}, status=exc.status)
            except Exception as exc:
                self.send_json({"ok": False, "error": "Не удалось обработать сообщение Telegram.", "details": str(exc)}, status=500)
            return

        if parsed.path == "/api/auth/telegram":
            try:
                session = verify_telegram_login(self.read_json_body())
                auth = self.auth_payload(session)
                self.send_json(
                    {"ok": True, "auth": auth},
                    extra_headers=[("Set-Cookie", self.session_cookie_header(session))],
                )
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except Exception as exc:
                self.send_json(
                    {"ok": False, "error": "Не удалось выполнить вход через Telegram.", "details": str(exc)},
                    status=500,
                )
            return

        if parsed.path == "/api/auth/telegram-webapp":
            try:
                body = self.read_json_body()
                session = verify_telegram_webapp(as_text(body.get("initData")))
                auth = self.auth_payload(session)
                self.send_json(
                    {"ok": True, "auth": auth},
                    extra_headers=[("Set-Cookie", self.session_cookie_header(session))],
                )
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except Exception as exc:
                self.send_json(
                    {"ok": False, "error": "Не удалось выполнить вход из Telegram.", "details": str(exc)},
                    status=500,
                )
            return

        if parsed.path == "/api/auth/logout":
            self.send_json(
                {"ok": True},
                extra_headers=[("Set-Cookie", self.clear_session_cookie_header())],
            )
            return

        self.send_json({"ok": False, "error": "Метод не найден."}, status=404)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/auth/config":
            self.send_json({"ok": True, "auth": self.auth_payload(None)})
            return

        if parsed.path == "/api/auth/status":
            try:
                self.send_json({"ok": True, "auth": self.auth_payload(self.current_session())})
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            return

        if parsed.path == "/api/telegram/diagnostics":
            try:
                self.send_json({"ok": True, "diagnostics": telegram_diagnostics()})
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except Exception as exc:
                self.send_json(
                    {"ok": False, "error": "Не удалось проверить настройки Telegram.", "details": str(exc)},
                    status=500,
                )
            return

        if parsed.path == "/api/analyze":
            if not self.require_access():
                return
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            marketplace = (query.get("marketplace") or [MARKETPLACE_WB])[0]
            try:
                payload = analyze_article(article, limit, marketplace)
                self.send_json({"ok": True, "data": payload})
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит должен быть числом."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Внутренняя ошибка анализатора.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/export":
            if not self.require_access():
                return
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            marketplace = (query.get("marketplace") or [MARKETPLACE_WB])[0]
            try:
                article_id, workbook, source = export_article(article, limit, marketplace)
                self.send_xlsx(f"{source}-review-analysis-{article_id}.xlsx", workbook)
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит должен быть числом."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Не удалось сформировать Excel-файл.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/brief":
            if not self.require_access():
                return
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            marketplace = (query.get("marketplace") or [MARKETPLACE_WB])[0]
            try:
                article_id, document, source = brief_article(article, limit, marketplace)
                self.send_docx(f"{source}-content-brief-{article_id}.docx", document)
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит должен быть числом."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Не удалось сформировать ТЗ.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/competitors":
            if not self.require_access():
                return
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            limit = (query.get("limit") or [None])[0]
            competitors = (query.get("competitors") or [str(MAX_COMPETITORS)])[0]
            marketplace = marketplace_from_input((query.get("marketplace") or [MARKETPLACE_WB])[0])
            try:
                if marketplace == MARKETPLACE_OZON:
                    raise AppError(
                        "Анализ конкурентов Ozon пока требует отдельный источник данных.",
                        501,
                        "Публичная выдача Ozon часто блокирует серверные запросы. Для конкурентов нужен Seller/Brand API или внешний парсер.",
                    )
                payload = analyze_competitors(article, limit, competitors)
                self.send_json({"ok": True, "data": payload})
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except ValueError:
                self.send_json({"ok": False, "error": "Лимит и количество конкурентов должны быть числами."}, status=400)
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "Не удалось выполнить анализ конкурентов.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/api/image":
            if not self.require_access():
                return
            query = parse_qs(parsed.query)
            article = (query.get("article") or [""])[0]
            image_number = parse_image_number((query.get("n") or [None])[0])
            marketplace = marketplace_from_input((query.get("marketplace") or [MARKETPLACE_WB])[0])
            try:
                if marketplace == MARKETPLACE_OZON:
                    raise AppError("Для Ozon фото передается прямой ссылкой из карточки или Seller API.", 400)
                article_id = article_from_input(article)
                body, content_type, _source_url = fetch_product_image(article_id, image_number)
                self.send_image(body, content_type)
            except AppError as exc:
                self.send_json(
                    {"ok": False, "error": exc.message, "details": exc.details},
                    status=exc.status,
                )
            except Exception as exc:
                self.send_json(
                    {
                        "ok": False,
                        "error": "РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ С„РѕС‚Рѕ С‚РѕРІР°СЂР°.",
                        "details": str(exc),
                    },
                    status=500,
                )
            return

        if parsed.path == "/health":
            self.send_json({"ok": True, "version": APP_VERSION})
            return

        self.send_static(parsed.path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Wildberries review analyzer")
    default_host = os.environ.get("HOST") or ("0.0.0.0" if os.environ.get("PORT") else "127.0.0.1")
    default_port = int(os.environ.get("PORT", "8765"))
    parser.add_argument("--host", default=default_host)
    parser.add_argument("--port", type=int, default=default_port)
    args = parser.parse_args()

    try:
        configure_telegram_bot_if_enabled()
    except Exception as exc:
        print(f"Telegram bot auto setup failed: {exc}", flush=True)

    httpd = ThreadingHTTPServer((args.host, args.port), AnalyzerHandler)
    print(f"WB review analyzer: http://{args.host}:{args.port}", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
