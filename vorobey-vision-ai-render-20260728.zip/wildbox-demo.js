/* Independent read-only demo: never receives a Wildbox credential. */
(() => {
  const form = document.getElementById("ai-search-form");
  const input = document.getElementById("ai-search-input");
  const button = document.getElementById("ai-search-button");
  const output = document.getElementById("ai-search-results");
  const message = document.getElementById("ai-search-message");
  const format = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const num = (value, suffix = "") => typeof value === "number" && Number.isFinite(value) ? format.format(value) + suffix : "Нет данных";
  let loading = false;
  let cooldown = 0;
  let timer;

  function date(value) {
    if (!value) return "не указана";
    const parsed = new Date(value);
    return Number.isNaN(parsed.valueOf()) ? "не указана" : parsed.toLocaleDateString("ru-RU", {timeZone:"Europe/Moscow"});
  }
  function sync() {
    const remaining = Math.max(0, Math.ceil((cooldown - Date.now()) / 1000));
    button.disabled = loading || remaining > 0;
    button.textContent = loading ? "Ищем…" : remaining ? `Повтор через ${remaining} с` : "Найти";
    input.disabled = loading;
    form.setAttribute("aria-busy", String(loading));
    if (!remaining && timer) { clearInterval(timer); timer = null; }
  }
  function chart(series, key, label, suffix) {
    const values = series.map(p => p[key]).filter(v => typeof v === "number" && Number.isFinite(v));
    if (!values.length) return "";
    const low = Math.min(...values), high = Math.max(...values);
    const points = [];
    let segment = [];
    series.forEach((p, i) => {
      if (typeof p[key] !== "number" || !Number.isFinite(p[key])) {
        if (segment.length) points.push(segment.join(" ")); segment = []; return;
      }
      const x = 8 + i / Math.max(1, series.length - 1) * 304;
      const y = high === low ? 50 : 85 - (p[key] - low) / (high - low) * 65;
      segment.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    });
    if (segment.length) points.push(segment.join(" "));
    return `<figure class="ai-chart"><figcaption>${esc(label)} <strong>${num(low, suffix)} — ${num(high, suffix)}</strong></figcaption>
      <svg viewBox="0 0 320 100" role="img" aria-label="${esc(label)}: ${esc(num(low, suffix))} — ${esc(num(high, suffix))}">
      <path d="M8 86H312" stroke="#d7deea" fill="none"/>
      ${points.map(p => `<polyline points="${p}" fill="none" stroke="#6154c7" stroke-width="2.5" stroke-linejoin="round"/>`).join("")}</svg>
      <div class="ai-chart-dates"><span>${date(series[0].date)}</span><span>${date(series.at(-1).date)}</span></div></figure>`;
  }
  function render(data) {
    const rows = data.rows || [], series = data.series || [];
    const period = `${date(data.period.from)} — ${date(data.period.to)}`;
    const empty = data.mode === "article" ? "За этот период Wildbox не вернул данные по артикулу. Это не означает, что товара нет на WB." : "Wildbox не вернул товары. Уточните название: пустой ответ также возможен при недоступности выдачи WB.";
    const header = `<div class="ai-result-heading"><h3>${data.mode === "article" ? "Динамика товара" : "Товары по запросу"}</h3><span class="ai-demo-badge">DEMO</span></div>
      <p class="ai-result-meta">${esc(data.query)} · Запрошено: ${period}<br>Получено: ${date(data.fetchedAt)}${data.cached ? " · Сохранённый результат, обновление раз в час" : ""}${data.actualTo ? `<br>Период данных: ${date(data.actualFrom)} — ${date(data.actualTo)}` : "<br>Точную дату последнего среза источник не указал."}</p>`;
    const table = rows.length ? `<div class="ai-table-scroll"><table class="ai-table"><caption>Источник: Wildbox. Цены — средние за период; заказы и выручка — расчётные.</caption><thead><tr><th scope="col">Товар WB</th><th scope="col">Средняя цена</th><th scope="col">Заказы, оценка</th><th scope="col">Выручка, оценка</th><th scope="col">Остаток</th></tr></thead><tbody>${rows.map(row => `<tr><td><a href="https://www.wildberries.ru/catalog/${encodeURIComponent(row.id)}/detail.aspx" target="_blank" rel="noopener noreferrer">${esc(row.name)}</a><small>${esc(row.id)}</small></td><td>${num(row.price," ₽")}</td><td>${num(row.orders)}</td><td>${num(row.proceeds," ₽")}</td><td>${num(row.quantity," шт.")}</td></tr>`).join("")}</tbody></table></div>` : `<p>${empty}</p>`;
    const charts = series.length ? `<div class="ai-charts">${chart(series,"price","Цена по дням"," ₽")}${chart(series,"orders","Заказы по дням, оценка","")}${chart(series,"quantity","Остаток по дням"," шт.")}</div>
      <details><summary>Данные по дням</summary><div class="ai-table-scroll"><table class="ai-table"><thead><tr><th>Дата</th><th>Цена</th><th>Заказы, оценка</th><th>Остаток</th></tr></thead><tbody>${series.map(p => `<tr><td>${date(p.date)}</td><td>${num(p.price," ₽")}</td><td>${num(p.orders)}</td><td>${num(p.quantity)}</td></tr>`).join("")}</tbody></table></div></details>` : "";
    const notes = `<details class="ai-notes" open><summary>Как читать результат</summary><ul>${(data.notes || []).map(n => `<li>${esc(n)}</li>`).join("")}</ul></details>`;
    const kw = data.keywords;
    const keywordTable = !kw ? "" : `<section class="ai-keywords"><h3>Поисковые фразы и позиции карточки</h3>
      <p class="ai-result-meta">Источник: Wildbox. Частотность — текущая за 30 дней, обновляется раз в неделю. Позиции — за ${date(kw.period?.date_from || data.period.from)} — ${date(kw.period?.date_to || data.period.to)}. Запросы с органическим показом; отметка рекламы означает, что за период также был рекламный показ.</p>
      ${kw.error ? `<p role="status">Не удалось загрузить поисковые фразы: ${esc(kw.error)} Повторите поиск.</p>` : `<p>Показано ${num(kw.rows.length)}${typeof kw.total === "number" ? ` из ${num(kw.total)}` : ""} запросов${kw.partial ? " — часть списка, по убыванию частотности" : ""}.</p>
      ${kw.rows.length ? `<div class="ai-table-scroll"><table class="ai-table"><thead><tr><th scope="col">Поисковая фраза</th><th scope="col">Частотность за 30 дней</th><th scope="col">Позиция в начале ряда</th><th scope="col">Позиция в конце ряда</th><th scope="col">Лучшая позиция</th><th scope="col">Дней в выдаче</th><th scope="col">Была реклама</th></tr></thead><tbody>${kw.rows.map(row => `<tr><td>${esc(row.query)}</td><td>${num(row.query_frequency_30d)}</td><td>${num(row.position_start)}</td><td>${num(row.position_end)}</td><td>${num(row.best_position)}</td><td>${num(row.days_in_serp)}</td><td>${row.advert === true ? "Да" : row.advert === false ? "Нет" : "Нет данных"}</td></tr>`).join("")}</tbody></table></div>` : "<p>Wildbox не вернул поисковые фразы за этот период. Это не доказывает отсутствие карточки в поиске.</p>"}`}
      <p class="ai-result-meta">Нет данных о позиции не означает нулевое место. Частотность относится ко всему запросу WB, а не к показам вашей карточки.</p></section>`;
    output.innerHTML = header + keywordTable + table + charts + notes;
    output.hidden = false;
  }
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (loading || cooldown > Date.now()) return;
    if (typeof authState !== "undefined" && authState.enabled && !authState.allowed) {
      message.textContent = "Войдите через Telegram, чтобы воспользоваться поиском."; return;
    }
    const query = input.value.trim();
    if (!query) { input.focus(); return; }
    loading = true; sync(); output.hidden = true;
    message.textContent = "Запрашиваем данные Wildbox. Это может занять до минуты…";
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 140000);
    try {
      const response = await fetch(apiUrl("/api/ai-search"), {method:"POST", credentials:"include", headers:{"Content-Type":"application/json"}, body:JSON.stringify({query}), signal:controller.signal});
      const payload = await response.json();
      if (!response.ok || !payload.ok) {
        if (response.status === 429) {
          cooldown = Date.now() + Math.max(1, Math.min(86400, Number(payload.retryAfter) || 60)) * 1000;
          timer = setInterval(sync, 1000);
        }
        if ((response.status === 401 || response.status === 403) && payload.auth) applyAuthState(payload.auth);
        throw new Error(payload.error || "Не удалось получить данные. Повторите позже.");
      }
      render(payload.data);
      message.textContent = payload.data.keywords?.error ? "Данные товара получены; поисковые фразы пока недоступны." : payload.data.rows.length || payload.data.keywords?.rows?.length ? "Данные получены." : "По запросу нет доступных данных.";
    } catch (error) {
      message.textContent = error.name === "AbortError" ? "Источник не ответил вовремя. Повторите запрос позже." : error.message;
    } finally { clearTimeout(timeout); loading = false; sync(); }
  });
  document.querySelectorAll("[data-ai-example]").forEach(button => button.addEventListener("click", () => {
    if (!loading) { input.value = button.dataset.aiExample; input.focus(); }
  }));
})();
