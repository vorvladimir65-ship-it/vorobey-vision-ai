function buildCardRating(data, comparison) {
  const valid = (value, max) => Number.isFinite(value) && value >= 0 && value <= max;
  const review = data.summary || {};
  const seo = data.seoAnalysis || {};
  const title = seo.titleEvaluation;
  const audit = seo.descriptionAudit;
  const attrs = seo.attributesEvaluation;
  const photo = data.firstPhotoAnalysis || data.product?.firstPhotoAnalysis;
  const ozon = (data.product?.marketplace || data.source?.marketplace) === "ozon";
  const missingWbAudit = ozon ? "Для Ozon эта проверка пока недоступна." : "Аудит карточки WB не дал оценки.";
  const display = (value) => value.toLocaleString("ru-RU", { maximumFractionDigits: 2 });
  const firstFix = (issues) => issues?.find((item) => item.fix)?.fix;
  const rated = valid(review.averageRating, 5) && review.averageRating > 0 && review.feedbackCount > 0;
  const photoScore = photo?.ok && valid(photo.score, 100) ? photo.score : null;
  const titleScore = !ozon && data.product?.name?.trim() && valid(title?.score, 100) ? title.score : null;
  const seoScore = !ozon && audit?.ok && valid(audit.qualityScore, 100) ? audit.qualityScore : null;
  const attrsAvailable = !ozon && attrs?.totalImportant > 0 && valid(attrs.filledImportant, attrs.totalImportant)
    && !attrs.issues?.some((issue) => issue.id === "attributes-missing-all");
  const competitorCount = comparison?.summary?.competitorCount;
  const your = comparison?.benchmark?.your?.averageRating;
  const peer = comparison?.benchmark?.competitorsAvg?.averageRating;
  const compared = !ozon && competitorCount > 0 && valid(your, 5) && your > 0 && valid(peer, 5) && peer > 0;
  const criteria = [
    {
      key: "title", title: "Контент: название", score: titleScore,
      reason: titleScore === null ? missingWbAudit : "Балл аудита названия WB: структура, понятность и замечания к формулировке. Описание и фото оцениваются отдельно.",
      detail: titleScore === null ? "" : title.issues?.[0]?.description,
      action: titleScore === null ? "" : title.issues?.find((issue) => issue.recommendation)?.recommendation,
    },
    {
      key: "reviews", title: "Отзывы и репутация", score: rated ? review.averageRating * 20 : null,
      reason: rated ? `Средняя оценка ${display(review.averageRating)} из 5, умноженная на 20.` : "Нет подтверждённой средней оценки по отзывам.",
      detail: rated ? data.weaknesses?.[0]?.label : "",
      action: rated && data.weaknesses?.length ? "Начните с наиболее частой жалобы в блоке «Сильные и слабые стороны»." : "",
    },
    {
      key: "seo", title: "SEO: описание", score: seoScore,
      reason: seoScore === null ? missingWbAudit : `Балл качества из аудита описания WB. Проверяются только доступные критерии.${valid(audit.completeness, 100) ? ` Полнота SEO-аудита: ${audit.completeness}%.` : ""}`,
      detail: seoScore === null ? "" : (audit.criticalContradictions?.[0] || audit.issues?.[0])?.explanation,
      action: seoScore === null ? "" : firstFix(audit.criticalContradictions) || firstFix(audit.issues),
    },
    {
      key: "photo", title: "Первое фото", score: photoScore,
      reason: photoScore === null ? "Нет результата визуальной проверки. Это не означает, что фото плохое." : "Балл визуального аудита обложки: заметность товара, композиция, контраст и читаемость.",
      detail: photoScore === null ? "" : photo.summary,
      action: photoScore === null ? "" : photo.designerBrief?.[0],
    },
    {
      key: "attributes", title: "Характеристики", score: attrsAvailable ? attrs.filledImportant * 100 / attrs.totalImportant : null,
      reason: attrsAvailable ? `Заполнено ${attrs.filledImportant} из ${attrs.totalImportant} важных полей по чек-листу сервиса. Балл равен проценту заполнения.` : missingWbAudit,
      action: attrsAvailable && attrs.missingImportant?.[0]?.attributeName ? `Заполните поле «${attrs.missingImportant[0].attributeName}», если значение подтверждено.` : "",
    },
    {
      key: "peers", title: "Конкурентоспособность по отзывам",
      score: compared ? Math.min(100, Math.max(0, 50 + 50 * (your - peer))) : null,
      reason: compared
        ? `Ваша оценка: ${display(your)} из 5. Средняя оценка найденных конкурентов: ${display(peer)} из 5. Паритет даёт 50 баллов; разница в одну звезду добавляет или снимает 50 баллов, пределы 0–100.`
        : ozon ? "Для Ozon сравнение с конкурентами пока недоступно."
          : comparison ? "По найденным карточкам не удалось сопоставить средние оценки."
            : "Запустите «Анализировать конкурентов», чтобы получить сравнительный балл.",
      action: compared && your < peer ? "Откройте «Что усилить» в сравнении с конкурентами и проверьте повторяющиеся жалобы." : "",
    },
  ].map((item) => ({ ...item, score: item.score === null ? null : Math.round(item.score) }));
  const measured = criteria.filter((item) => item.score !== null);
  return {
    criteria,
    measured: measured.length,
    score: measured.length ? Math.round(measured.reduce((sum, item) => sum + item.score, 0) / measured.length) : null,
    critical: ozon ? [] : audit?.criticalContradictions || [],
  };
}
