"""Read-only Wildbox demo. Credentials stay on the application server."""
from __future__ import annotations

import copy
import json
import math
import os
import re
import time
from datetime import datetime, timedelta, timezone
from threading import Lock
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

ENDPOINT = "https://wildbox.ru/mcp/v2"
MOSCOW = timezone(timedelta(hours=3))
LOCK = Lock()
CACHE = {}
SESSION = None
NEXT_CALL = 0.0
TTL = 3600


class DemoError(Exception):
    def __init__(self, message, status=503, retry_after=None):
        super().__init__(message)
        self.status = status
        self.retry_after = retry_after


class SessionExpired(DemoError):
    pass


def parse_query(value):
    query = " ".join(str(value or "").split())
    if not query or len(query) > 200:
        raise DemoError("Введите артикул, ссылку WB или название товара — до 200 символов.", 400)
    if query.isascii() and query.isdigit():
        if not 0 < int(query) <= 9223372036854775807:
            raise DemoError("Проверьте артикул WB.", 400)
        return "article", str(int(query))
    if "://" in query or query.lower().startswith(("www.", "wildberries.ru/")):
        url = urlparse(query if "://" in query else "https://" + query)
        host = (url.hostname or "").lower()
        match = re.fullmatch(r"/catalog/(\d+)/detail\.aspx/?", url.path)
        if host not in {"wildberries.ru", "www.wildberries.ru"} or not match:
            raise DemoError("Для DEMO нужна ссылка на карточку wildberries.ru/catalog/…/detail.aspx или артикул.", 400)
        return parse_query(match.group(1))
    return "search", query.lower().replace("ё", "е")


def parse_rpc(raw):
    text = raw.decode("utf-8")
    data = [line[6:].rstrip("\r") for line in text.split("\n") if line.startswith("data: ")]
    return json.loads("\n".join(data) if data else text) if text else {}


def rpc(method, params, token, notify=False):
    global SESSION
    body = {"jsonrpc": "2.0", "method": method, "params": params}
    if not notify:
        body["id"] = 1
    headers = {"X-Wildbox-Token": token, "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json", "MCP-Protocol-Version": "2025-06-18"}
    if SESSION:
        headers["Mcp-Session-Id"] = SESSION
    request = Request(ENDPOINT, json.dumps(body).encode("utf-8"), headers, method="POST")
    try:
        with urlopen(request, timeout=40) as response:
            SESSION = response.headers.get("mcp-session-id") or SESSION
            raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise DemoError("Ответ Wildbox слишком большой. Уточните запрос.", 502)
            result = parse_rpc(raw)
    except HTTPError as exc:
        if exc.code in (400, 404):
            had_session = bool(SESSION)
            SESSION = None
            if had_session and method != "initialize":
                raise SessionExpired("Сессия Wildbox завершилась. Переподключаемся.", 502) from None
        if exc.code in (401, 403):
            raise DemoError("Wildbox не подтвердил доступ. Администратору нужно проверить токен и подписку.") from None
        if exc.code == 429:
            raise DemoError("Wildbox ограничил частоту запросов. Повторите позже.", 429, 60) from None
        raise DemoError("Wildbox временно недоступен. Повторите запрос позже.", 502) from None
    except (URLError, TimeoutError, OSError, ValueError):
        SESSION = None
        raise DemoError("Wildbox не ответил вовремя. Повторите запрос позже.", 502) from None
    if result.get("error"):
        raise DemoError("Wildbox не смог обработать запрос. Попробуйте другой артикул или название.", 502)
    return result.get("result", {})


def tool_call(name, arguments, token, reconnect=True):
    global NEXT_CALL
    if not SESSION:
        rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
            "clientInfo": {"name": "vorobey-vision-demo", "version": "1.0"}}, token)
        rpc("notifications/initialized", {}, token, notify=True)
    # All users share this token and one process-wide lane. Rejected calls also count.
    NEXT_CALL = time.monotonic() + 10
    try:
        result = rpc("tools/call", {"name": name, "arguments": arguments}, token)
    except SessionExpired:
        if not reconnect:
            raise DemoError("Wildbox не смог восстановить соединение. Повторите запрос позже.", 502) from None
        time.sleep(max(0, NEXT_CALL - time.monotonic()))
        return tool_call(name, arguments, token, reconnect=False)
    if result.get("isError"):
        text = " ".join(str(c.get("text", "")) for c in result.get("content", []))
        if re.search(r"/mcp/v\d|отключаются|deprecated|migration", text, re.I):
            raise DemoError("Wildbox обновил подключение. Требуется обновление интеграции анализатора.", 502)
        if re.search(r"rate|quota|concurrent|too many|лимит", text, re.I):
            match = re.search(r"(?:retry after|повтор[^\d]{0,30})\s*(\d+(?:\.\d+)?)", text, re.I)
            wait = max(10, math.ceil(float(match.group(1)))) if match else 60
            NEXT_CALL = time.monotonic() + wait
            raise DemoError("Достигнут лимит Wildbox. Повторите запрос позже.", 429, wait)
        if re.search(r"subscription|plan|tariff|тариф|подписк|access|unauthorized", text, re.I):
            raise DemoError("Этот запрос недоступен по текущей подписке Wildbox.", 403)
        raise DemoError("Wildbox не вернул данные. Попробуйте другой запрос.", 502)
    if isinstance(result.get("structuredContent"), dict):
        return result["structuredContent"]
    for content in result.get("content", []):
        if content.get("type") == "text":
            try:
                return json.loads(content["text"])
            except (ValueError, TypeError):
                pass
    raise DemoError("Не удалось прочитать ответ Wildbox.", 502)


def number(value):
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) else None


def product_row(row):
    identifier = str(row.get("wb_article", row.get("id", "")))
    if not identifier.isdigit():
        return None
    return {"id": identifier, "name": str(row.get("product_name") or row.get("name") or "Товар WB"),
            "url": f"https://www.wildberries.ru/catalog/{identifier}/detail.aspx",
            **{key: number(row.get(key)) for key in ("orders", "proceeds", "price", "quantity")}}


def normalize(data, mode, query, start, end):
    raw_rows = data.get("rows", data.get("results", []))
    if not isinstance(raw_rows, list):
        raw_rows = []
    rows = [clean for raw in raw_rows if isinstance(raw, dict) and (clean := product_row(raw))]
    if mode == "search":
        terms = [word[:3] for word in re.findall(r"[а-яa-z]+", query.lower()) if len(word) > 3]
        def relevance(row):
            words = re.findall(r"[а-яa-z]+", row["name"].lower().replace("ё", "е"))
            return sum(any(word.startswith(term) for word in words) for term in terms) / max(1, len(terms))
        if terms:
            rows = [row for row in rows if relevance(row) >= 0.75]
            rows.sort(key=lambda row: (relevance(row), row.get("orders") or 0), reverse=True)
    series = []
    if mode == "article" and raw_rows:
        for point in raw_rows[0].get("daily", raw_rows[0].get("dynamic", [])):
            date = str(point.get("date", ""))
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
                series.append({"date": date, **{k: number(point.get(k)) for k in ("orders", "proceeds", "price", "quantity")}})
        series.sort(key=lambda point: point["date"])
        if rows and series and "daily" in raw_rows[0]:
            # V2 daily rows replace period totals; aggregate only a complete page.
            complete = not data.get("next_cursor")
            for key in ("orders", "proceeds"):
                values = [point[key] for point in series]
                rows[0][key] = sum(values) if complete and all(v is not None for v in values) else None
            prices = [point["price"] for point in series]
            rows[0]["price"] = round(sum(prices) / len(prices), 2) if complete and all(v is not None for v in prices) else None
            rows[0]["quantity"] = series[-1]["quantity"] if complete else None
    notes = ["Заказы и выручка — расчётные данные Wildbox, не фактический отчёт продавца."]
    for key in ("notes", "_note"):
        value = data.get(key)
        values = [value] if isinstance(value, str) else value if isinstance(value, list) else []
        for item in values[:5]:
            text = str(item)
            if re.search(r"\d{4}-\d{2}-\d{2}|тариф|подписк|недоступ|нет данных|занижены|Точность заказов не определена", text, re.I):
                notes.append(text[:800])
    if data.get("diagnosis"):
        notes.append("Источник не нашёл данные по этому запросу за выбранный период. Попробуйте другой артикул или название.")
    if data.get("guidance") or data.get("sample", {}).get("truncated"):
        notes.append("Показана часть доступной выборки. Для более точного результата уточните название или введите артикул.")
    if mode == "search":
        notes.append("До пяти товаров из ограниченной выборки по названию. Это не рейтинг всей ниши; состав и объём товаров могут отличаться.")
    if mode == "article" and data.get("next_cursor"):
        notes.append("Источник вернул только часть периода. Показаны доступные дни; итоги за весь период не рассчитаны.")
    dates = [p["date"] for p in series]
    actual = data.get("period") or {}
    return {"demo": True, "source": "Wildbox", "mode": mode, "query": query,
            "period": {"from": start, "to": end}, "actualFrom": min(dates) if dates else actual.get("date_from"),
            "actualTo": max(dates) if dates else actual.get("date_to"), "rows": rows[:5], "series": series,
            "notes": notes, "sample": data.get("sample", {}),
            "fetchedAt": datetime.now(MOSCOW).isoformat(timespec="seconds"), "cached": False}


def search(query):
    mode, value = parse_query(query)
    token = os.environ.get("WILDBOX_TOKEN", "").strip()
    if not token or os.environ.get("WILDBOX_DEMO_ENABLED", "true").lower() == "false":
        raise DemoError("ИИ поиск DEMO готовится к запуску. Попробуйте позже.")
    today = datetime.now(MOSCOW).date()
    start, end = (today - timedelta(days=30)).isoformat(), (today - timedelta(days=1)).isoformat()
    cache_key = (mode, value, start, end)
    if not LOCK.acquire(timeout=0.1):
        raise DemoError("ИИ поиск обрабатывает другой запрос. Повторите через несколько секунд.", 429, 10)
    try:
        cached = CACHE.get(cache_key)
        if cached and time.monotonic() - cached[0] < TTL:
            result = copy.deepcopy(cached[1])
            result["cached"] = True
            return result
        if time.monotonic() < NEXT_CALL:
            raise DemoError("Слишком частые запросы. Попробуйте немного позже.", 429,
                            max(1, math.ceil(NEXT_CALL - time.monotonic())))
        arguments = {"date_from": start, "date_to": end, "fields": ["orders", "proceeds", "price", "quantity"],
                     "breakdown": "product"}
        if mode == "article":
            arguments.update(wb_articles=[int(value)], daily=True, limit=1)
        else:
            arguments.update(search_query=value, saved_serp=True, limit=20)
        data = tool_call("get_market_sales", arguments, token)
        if mode == "search" and not data.get("rows"):
            # Missing saved SERP is not absence of products: try the current WB SERP once.
            time.sleep(max(0, NEXT_CALL - time.monotonic()))
            arguments["saved_serp"] = False
            data = tool_call("get_market_sales", arguments, token)
            data.setdefault("notes", []).append("Сохранённая выдача недоступна; использована текущая выдача WB.")
        result = normalize(data, mode, value, start, end)
        # Bounded cache, shared by all users; never stores the credential.
        for key in list(CACHE):
            if time.monotonic() - CACHE[key][0] >= TTL:
                del CACHE[key]
        if len(CACHE) >= 256:
            del CACHE[next(iter(CACHE))]
        CACHE[cache_key] = (time.monotonic(), copy.deepcopy(result))
        return result
    finally:
        LOCK.release()
