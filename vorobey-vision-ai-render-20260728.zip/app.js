const form = document.getElementById("analyze-form");
const articleInput = document.getElementById("article-input");
const limitSelect = document.getElementById("limit-select");
const submitButton = document.getElementById("submit-button");
const statusBox = document.getElementById("status");
const resultsBox = document.getElementById("results");

const PUBLIC_API_ORIGIN = "https://vorobey-vision-ai.onrender.com";
const API_ORIGIN = window.location.protocol === "file:" ? PUBLIC_API_ORIGIN : "";
const numberFormat = new Intl.NumberFormat("ru-RU");

function apiUrl(path) {
  return `${API_ORIGIN}${path}`;
}

function mediaUrl(value) {
  if (!value) return "";
  if (API_ORIGIN && String(value).startsWith("/")) return `${API_ORIGIN}${value}`;
  return value;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatNumber(value) {
  if (value === null || value === undefined || value === "") return "—";
  return numberFormat.format(value);
}

function formatRating(value) {
  if (!value) return "—";
  return Number(value).toLocaleString("ru-RU", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  });
}

function handleImageError(img) {
  const fallbackSrc = img.dataset.fallbackSrc;
  if (fallbackSrc && img.src !== fallbackSrc) {
    img.dataset.fallbackSrc = "";
    img.src = fallbackSrc;
    return;
  }

  const card = img.closest(".product-photo-card, .photo-preview-card, .photo-best-card, .photo-competitor-tile");
  if (card) card.classList.add("is-broken");
  img.remove();
}

function setLoading(isLoading) {
  submitButton.disabled = isLoading;
  articleInput.disabled = isLoading;
  limitSelect.disabled = isLoading;
  submitButton.innerHTML = isLoading
    ? '<span class="button-icon" aria-hidden="true">…</span> Анализирую'
    : '<span class="button-icon" aria-hidden="true">↗</span> Анализировать';
}

function showStatus(type, message, details = "") {
  resultsBox.hidden = true;
  statusBox.hidden = false;
  statusBox.className = `status is-${type}`;
  const mark = type === "error" ? "!" : type === "loading" ? "…" : "WB";
  const klass = type === "error" ? "error" : type === "loading" ? "loading" : "empty";
  statusBox.innerHTML = `
    <div class="${klass}-state">
      <div class="${klass}-mark" aria-hidden="true">${mark}</div>
      <p>${escapeHtml(message)}${details ? `<br><span class="muted">${escapeHtml(details)}</span>` : ""}</p>
    </div>
  `;
}

function metric(label, value, context = "") {
  return `
    <article class="metric-card">
      <div class="metric-label">${escapeHtml(label)}</div>
      <div class="metric-value">${value}</div>
      ${context ? `<div class="metric-context">${escapeHtml(context)}</div>` : ""}
    </article>
  `;
}

function renderDistribution(distribution = {}) {
  const stars = [5, 4, 3, 2, 1];
  const max = Math.max(...stars.map((star) => Number(distribution[String(star)] || 0)), 1);
  return `
    <div class="rating-bars" role="img" aria-label="Распределение оценок">
      ${stars
        .map((star) => {
          const count = Number(distribution[String(star)] || 0);
          const width = Math.round((count / max) * 100);
          return `
            <div class="rating-row">
              <span>${star}★</span>
              <div class="bar"><span style="width:${width}%"></span></div>
              <span>${formatNumber(count)}</span>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderSizeFit(sizeFit = {}) {
  const items = [
    ["ok", "В размер"],
    ["smaller", "Маломерит"],
    ["bigger", "Большемерит"],
  ].filter(([key]) => sizeFit[key] !== undefined && sizeFit[key] !== null);

  if (!items.length) {
    return '<p class="muted">Нет данных по соответствию размеру.</p>';
  }

  return `
    <div class="rating-bars" role="img" aria-label="Соответствие размеру">
      ${items
        .map(([key, label]) => {
          const value = Math.max(0, Math.min(100, Number(sizeFit[key] || 0)));
          return `
            <div class="rating-row size-row">
              <span>${escapeHtml(label)}</span>
              <div class="bar"><span style="width:${value}%"></span></div>
              <span>${value}%</span>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderAspects(items, kind) {
  if (!items.length) {
    return `<p class="muted">${kind === "good" ? "Сильные стороны пока не выделились." : "Повторяющихся слабых сторон в текстах не найдено."}</p>`;
  }
  return `
    <div class="aspect-list">
      ${items
        .map(
          (item) => `
            <article class="aspect-card">
              <div class="aspect-top">
                <div>
                  <h3 class="aspect-title">${escapeHtml(item.title)}</h3>
                  <p class="aspect-summary">${escapeHtml(item.summary)}</p>
                </div>
                <span class="aspect-badge ${kind}">${formatNumber(item.mentions)}</span>
              </div>
              ${renderEvidence(item.evidence)}
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderEvidence(evidence = []) {
  if (!evidence.length) return "";
  return `
    <ul class="evidence-list">
      ${evidence
        .slice(0, 2)
        .map(
          (item) => `
            <li>
              “${escapeHtml(item.text)}”
              <small>${item.rating ? `${item.rating}★` : "без оценки"}${item.date ? ` · ${escapeHtml(item.date)}` : ""}</small>
            </li>
          `,
        )
        .join("")}
    </ul>
  `;
}

function renderTopics(terms = [], kind) {
  if (!terms.length) return '<p class="muted">Недостаточно повторяющихся слов.</p>';
  return `
    <div class="topic-cloud">
      ${terms
        .map(
          (item) => `
            <span class="topic ${kind}">
              ${escapeHtml(item.term)}
              <span class="topic-count">${formatNumber(item.count)}</span>
            </span>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderExamples(examples = []) {
  if (!examples.length) return '<p class="muted">Нет подходящих текстовых примеров.</p>';
  return `
    <ul class="example-list">
      ${examples
        .map(
          (item) => `
            <li class="example-item">
              <p>“${escapeHtml(item.text)}”</p>
              <div class="example-meta">
                <span>${item.rating ? `${item.rating}★` : "без оценки"}</span>
                ${item.date ? `<span>${escapeHtml(item.date)}</span>` : ""}
                ${item.color ? `<span>${escapeHtml(item.color)}</span>` : ""}
                ${item.size ? `<span>${escapeHtml(item.size)}</span>` : ""}
              </div>
            </li>
          `,
        )
        .join("")}
    </ul>
  `;
}

function renderRecommendations(items = []) {
  if (!items.length) return '<p class="muted">Нет отдельных рекомендаций для этого блока.</p>';
  return `
    <div class="recommendation-list">
      ${items.map(renderRecommendationCard).join("")}
    </div>
  `;
}

function renderPriorityActions(items = []) {
  if (!items.length) return "";
  return `
    <ol class="priority-action-list">
      ${items
        .map(
          (item) => `
            <li class="priority-action priority-${escapeHtml(item.priority || "medium")}">
              <div class="priority-action-meta">
                <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                <span class="area-badge">${item.area === "product" ? "Товар" : "Контент"}</span>
              </div>
              <strong>${escapeHtml(item.title)}</strong>
              <p>${escapeHtml(item.action)}</p>
            </li>
          `,
        )
        .join("")}
    </ol>
  `;
}

function renderRecommendationCard(item) {
  const area = item.area === "product" ? "Товар" : "Контент";
  return `
    <details class="recommendation-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
      <summary class="collapsible-summary">
        <span class="recommendation-top">
          <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
          <span class="area-badge">${area}</span>
        </span>
        <span class="summary-title">${escapeHtml(item.title)}</span>
        <span class="summary-subline">${escapeHtml(item.aspect || "")}</span>
      </summary>
      <div class="collapsible-body">
        <p class="recommendation-action">${escapeHtml(item.action)}</p>
        <p class="recommendation-reason">${escapeHtml(item.reason)}</p>
        ${renderEvidence(item.evidence)}
      </div>
    </details>
  `;
}

function renderHpvRecommendations(items = []) {
  if (!items.length) return "";
  return `
    <div class="hpv-block">
      <div class="section-head">
        <h2>ХПВ: характеристики в выгоды</h2>
        <span class="section-count">${formatNumber(items.length)}</span>
      </div>
      <div class="hpv-grid">
        ${items
          .map(
            (item) => `
              <details class="hpv-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
                <summary class="collapsible-summary">
                  <span class="recommendation-top">
                    <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                    <span class="area-badge">${escapeHtml(item.source || "Карточка")}</span>
                  </span>
                  <span class="summary-title">${escapeHtml(item.characteristic)}</span>
                  <span class="summary-subline">${escapeHtml(item.benefit)}</span>
                </summary>
                <div class="collapsible-body">
                  <div class="hpv-chain">
                    <div>
                      <span>Характеристика</span>
                      <p>${escapeHtml(item.characteristic)}</p>
                    </div>
                    <div>
                      <span>Преимущество</span>
                      <p>${escapeHtml(item.advantage)}</p>
                    </div>
                    <div>
                      <span>Выгода</span>
                      <p>${escapeHtml(item.benefit)}</p>
                    </div>
                  </div>
                  <div class="hpv-copy">
                    <p><strong>Для карточки:</strong> ${escapeHtml(item.cardText)}</p>
                    <p><strong>Для инфографики:</strong> ${escapeHtml(item.infographicText)}</p>
                  </div>
                  <p class="recommendation-reason">${escapeHtml(item.why)}</p>
                </div>
              </details>
            `,
          )
          .join("")}
      </div>
    </div>
  `;
}

function formatPhotoScore(value) {
  if (value === null || value === undefined || value === "") return "—";
  return Math.round(Number(value)).toLocaleString("ru-RU");
}

function formatPhotoMetricValue(item) {
  if (!item || item.value === null || item.value === undefined) return "—";
  const value = Number(item.value).toLocaleString("ru-RU", { maximumFractionDigits: 1 });
  return `${value}${item.unit === "%" ? "%" : ` ${item.unit || ""}`}`.trim();
}

function renderPhotoMetricCard(item) {
  return `
    <article class="photo-meter">
      <span>${escapeHtml(item.label)}</span>
      <strong>${escapeHtml(formatPhotoMetricValue(item))}</strong>
      <small>${escapeHtml(item.verdict || "")}</small>
    </article>
  `;
}

function renderPhotoTextList(items = [], emptyText = "Нет отдельных замечаний.") {
  const clean = items.filter(Boolean);
  if (!clean.length) return `<p class="muted">${escapeHtml(emptyText)}</p>`;
  return `
    <ul class="photo-note-list">
      ${clean.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
    </ul>
  `;
}

function renderPhotoRecommendations(items = []) {
  if (!items.length) return '<p class="muted">Критичных рекомендаций по первому фото не найдено.</p>';
  return `
    <div class="photo-action-list">
      ${items
        .map(
          (item) => `
            <details class="recommendation-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                  <span class="area-badge">Первое фото</span>
                </span>
                <span class="summary-title">${escapeHtml(item.title)}</span>
                <span class="summary-subline">${escapeHtml(item.action)}</span>
              </summary>
              <div class="collapsible-body">
                <p class="recommendation-action">${escapeHtml(item.action)}</p>
                <p class="recommendation-reason">${escapeHtml(item.reason || "")}</p>
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function formatCriterionScore(value) {
  if (value === null || value === undefined || value === "") return "—";
  return `${Math.round(Number(value))}/100`;
}

function renderPhotoCriteria(items = []) {
  if (!items.length) return "";
  return `
    <div class="photo-criteria-block">
      <h3 class="group-title">Чек-лист обложки</h3>
      <div class="photo-criteria-grid">
        ${items
          .map(
            (item) => `
              <details class="photo-criterion-card collapsible-card status-${escapeHtml(item.status || "normal")}">
                <summary class="collapsible-summary">
                  <span class="recommendation-top">
                    <span class="priority-badge">${escapeHtml(formatCriterionScore(item.score))}</span>
                    <span class="area-badge">${escapeHtml(item.status || "оценка")}</span>
                  </span>
                  <span class="summary-title">${escapeHtml(item.label)}</span>
                  <span class="summary-subline">${escapeHtml(item.summary || "")}</span>
                </summary>
                <div class="collapsible-body">
                  <p class="recommendation-action">${escapeHtml(item.action || "")}</p>
                  ${
                    (item.evidence || []).length
                      ? `<ul class="photo-note-list">${item.evidence.map((line) => `<li>${escapeHtml(line)}</li>`).join("")}</ul>`
                      : ""
                  }
                </div>
              </details>
            `,
          )
          .join("")}
      </div>
    </div>
  `;
}

function renderFirstPhotoAnalysis(photo, product = {}) {
  if (!photo) return "";
  const score = photo.ok ? `${formatPhotoScore(photo.score)}/100` : "нет оценки";
  const imageUrl = mediaUrl(photo.imageUrl || product.imageUrl || "");
  const sourceUrl = mediaUrl(photo.sourceUrl || product.sourceImageUrl || product.imageUrl || "");
  const imageSrc = imageUrl || sourceUrl;
  const fallbackSrc = sourceUrl && sourceUrl !== imageSrc ? sourceUrl : "";
  const image = imageSrc
    ? `
      <a class="photo-preview-card" href="${escapeHtml(sourceUrl || imageUrl)}" target="_blank" rel="noreferrer" aria-label="Открыть первое фото">
        <img src="${escapeHtml(imageSrc)}" data-fallback-src="${escapeHtml(fallbackSrc)}" alt="" loading="lazy" onerror="handleImageError(this)">
        <span class="product-photo-fallback">Первое фото</span>
      </a>
    `
    : '<div class="photo-preview-card is-broken"><span class="product-photo-fallback">Первое фото</span></div>';

  return `
    <section class="photo-analysis-block">
      <details class="photo-analysis-card collapsible-card" open>
        <summary class="collapsible-summary">
          <span class="recommendation-top">
            <span class="area-badge">Первое фото</span>
            <span class="priority-badge">${escapeHtml(score)}</span>
          </span>
          <span class="summary-title">Анализ первого фото</span>
          <span class="summary-subline">${escapeHtml(photo.summary || "Визуальный аудит главного изображения карточки.")}</span>
        </summary>
        <div class="collapsible-body">
          <div class="photo-analysis-layout">
            ${image}
            <div class="photo-analysis-content">
              <div class="photo-score-row">
                <div>
                  <span>Визуальная сила</span>
                  <strong>${escapeHtml(score)}</strong>
                </div>
                <p>${escapeHtml(photo.scoreLabel || "Первое фото")}</p>
              </div>
              <div class="photo-meter-grid">
                ${(photo.metricCards || []).map(renderPhotoMetricCard).join("")}
              </div>
            </div>
          </div>

          ${renderPhotoCriteria(photo.criteria || [])}

          <div class="photo-insights-grid">
            <div>
              <h3 class="group-title">Что уже работает</h3>
              ${renderPhotoTextList(photo.strengths, "Сильные стороны фото пока не выделились.")}
            </div>
            <div>
              <h3 class="group-title">Риски</h3>
              ${renderPhotoTextList(photo.risks, "Критичных рисков по фото не найдено.")}
            </div>
            <div>
              <h3 class="group-title">ТЗ дизайнеру</h3>
              ${renderPhotoTextList(photo.designerBrief, "Достаточно протестировать альтернативный первый слайд.")}
            </div>
          </div>

          <div>
            <h3 class="group-title">Что переделать</h3>
            ${renderPhotoRecommendations(photo.recommendations)}
          </div>
        </div>
      </details>
    </section>
  `;
}

function renderPhotoCompareMetric(label, yourValue, competitorValue, unit = "") {
  return `
    <article class="competitor-metric">
      <div class="metric-label">${escapeHtml(label)}</div>
      <div class="competitor-values">
        <div>
          <span>У вас</span>
          <strong>${escapeHtml(formatPhotoScore(yourValue))}${unit ? escapeHtml(unit) : ""}</strong>
        </div>
        <div>
          <span>Конкуренты</span>
          <strong>${escapeHtml(formatPhotoScore(competitorValue))}${unit ? escapeHtml(unit) : ""}</strong>
        </div>
      </div>
    </article>
  `;
}

function renderCompetitorPhotoComparison(visual) {
  if (!visual) return "";
  const your = visual.your || {};
  const avg = visual.competitorsAvg || {};
  const best = visual.bestCompetitor || {};
  const items = visual.competitors || [];
  const bestImageUrl = mediaUrl(best.imageUrl || "");
  const bestSourceUrl = mediaUrl(best.sourceUrl || "");
  const bestImageSrc = bestImageUrl || bestSourceUrl;
  const bestFallbackSrc = bestSourceUrl && bestSourceUrl !== bestImageSrc ? bestSourceUrl : "";
  const bestCard = best.article
    ? `
      <article class="photo-best-card">
        ${bestImageSrc ? `<img src="${escapeHtml(bestImageSrc)}" data-fallback-src="${escapeHtml(bestFallbackSrc)}" alt="" loading="lazy" onerror="handleImageError(this)">` : ""}
        <div>
          <span>Лучшее первое фото среди найденных</span>
          <a href="${escapeHtml(best.url || "#")}" target="_blank" rel="noreferrer">${escapeHtml(best.title || `Артикул ${best.article}`)}</a>
          <strong>${formatPhotoScore(best.score)}/100</strong>
        </div>
      </article>
    `
    : "";
  const competitorStrip = items.length
    ? `
      <div class="photo-competitor-strip">
        ${items
          .slice(0, 10)
          .map(
            (item) => {
              const itemImageUrl = mediaUrl(item.imageUrl || "");
              const itemSourceUrl = mediaUrl(item.sourceUrl || "");
              const itemImageSrc = itemImageUrl || itemSourceUrl;
              const itemFallbackSrc = itemSourceUrl && itemSourceUrl !== itemImageSrc ? itemSourceUrl : "";
              return `
              <a href="${escapeHtml(item.url || "#")}" target="_blank" rel="noreferrer" class="photo-competitor-tile">
                ${itemImageSrc ? `<img src="${escapeHtml(itemImageSrc)}" data-fallback-src="${escapeHtml(itemFallbackSrc)}" alt="" loading="lazy" onerror="handleImageError(this)">` : ""}
                <span>${formatPhotoScore(item.score)}/100</span>
              </a>
            `;
            },
          )
          .join("")}
      </div>
    `
    : "";

  return `
    <div class="competitor-block photo-competitor-block">
      <div class="section-head">
        <h2>Сравнение первых фото</h2>
        <span class="section-count">${formatNumber(items.length)}</span>
      </div>
      <p class="competitor-verdict">${escapeHtml(visual.verdict || "")}</p>
      <div class="competitor-benchmark photo-benchmark">
        ${renderPhotoCompareMetric("Визуальная оценка", your.score, avg.score, "/100")}
        ${renderPhotoCompareMetric("Товар в кадре", your.metrics?.productSharePercent, avg.productSharePercent, "%")}
        ${renderPhotoCompareMetric("Контраст", your.metrics?.contrastScore, avg.contrastScore, "/100")}
        ${renderPhotoCompareMetric("Цветовой акцент", your.metrics?.saturationPercent, avg.saturationPercent, "%")}
        ${renderPhotoCompareMetric("Детальность", your.metrics?.detailScore, avg.detailScore, "/100")}
      </div>
      ${bestCard}
      ${competitorStrip}
      ${renderPhotoRecommendations(visual.actions)}
    </div>
  `;
}

function formatPercent(value) {
  if (value === null || value === undefined) return "—";
  return `${Number(value).toLocaleString("ru-RU", { maximumFractionDigits: 1 })}%`;
}

function formatBenchmarkValue(value, kind) {
  if (value === null || value === undefined) return "—";
  if (kind === "rating") return formatRating(value);
  if (kind === "percent") return formatPercent(value);
  if (kind === "count") return formatNumber(Math.round(Number(value)));
  return formatNumber(value);
}

function renderBenchmarkCard(label, yourValue, competitorValue, kind) {
  return `
    <article class="competitor-metric">
      <div class="metric-label">${escapeHtml(label)}</div>
      <div class="competitor-values">
        <div>
          <span>У вас</span>
          <strong>${formatBenchmarkValue(yourValue, kind)}</strong>
        </div>
        <div>
          <span>Конкуренты</span>
          <strong>${formatBenchmarkValue(competitorValue, kind)}</strong>
        </div>
      </div>
    </article>
  `;
}

function renderCompetitorLoading() {
  const target = document.getElementById("competitor-results");
  if (!target) return;
  target.hidden = false;
  target.innerHTML = `
    <div class="competitor-state">
      <div class="loading-mark" aria-hidden="true">…</div>
      <p>Собираю отзывы 10 конкурентов и сравниваю сильные/слабые стороны…</p>
    </div>
  `;
}

function renderCompetitorError(message) {
  const target = document.getElementById("competitor-results");
  if (!target) return;
  target.hidden = false;
  target.innerHTML = `
    <div class="competitor-state is-error">
      <div class="error-mark" aria-hidden="true">!</div>
      <p>${escapeHtml(message)}</p>
    </div>
  `;
}

function renderCompetitorActions(actions = []) {
  if (!actions.length) return '<p class="muted">Отдельных зон для усиления на фоне конкурентов не найдено.</p>';
  return `
    <div class="competitor-action-list">
      ${actions
        .map(
          (item) => `
            <article class="competitor-action priority-${escapeHtml(item.priority || "medium")}">
              <div class="recommendation-top">
                <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                <span class="area-badge">${escapeHtml(item.area || "Контент")}</span>
              </div>
              <h3>${escapeHtml(item.title)}</h3>
              <p class="recommendation-action">${escapeHtml(item.action)}</p>
              <p class="recommendation-reason">${escapeHtml(item.why)}</p>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderAspectComparison(rows = []) {
  if (!rows.length) return '<p class="muted">Недостаточно совпадающих тем в отзывах для сравнения аспектов.</p>';
  return `
    <div class="competitor-table-wrap">
      <table class="competitor-table">
        <thead>
          <tr>
            <th>Тема</th>
            <th>Статус</th>
            <th>У вас</th>
            <th>Конкуренты</th>
            <th>Что усилить</th>
          </tr>
        </thead>
        <tbody>
          ${rows
            .map(
              (row) => `
                <tr>
                  <td><strong>${escapeHtml(row.title)}</strong></td>
                  <td><span class="comparison-status priority-${escapeHtml(row.priority || "low")}">${escapeHtml(row.status)}</span></td>
                  <td>+${formatNumber(row.yourPositivePer100)} / -${formatNumber(row.yourNegativePer100)}</td>
                  <td>+${formatNumber(row.competitorPositivePer100)} / -${formatNumber(row.competitorNegativePer100)}</td>
                  <td>${escapeHtml(row.recommendation)}</td>
                </tr>
              `,
            )
            .join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderCompetitorList(items = []) {
  if (!items.length) return '<p class="muted">Конкуренты не найдены.</p>';
  return `
    <div class="competitor-list">
      ${items
        .map((item, index) => {
          const title = [item.brand, item.name].filter(Boolean).join(" · ") || `Артикул ${item.article}`;
          const strengths = (item.topStrengths || []).filter(Boolean).slice(0, 3);
          const weaknesses = (item.topWeaknesses || []).filter(Boolean).slice(0, 3);
          return `
            <article class="competitor-card">
              <div class="competitor-card-top">
                <span class="competitor-rank">#${index + 1}</span>
                <a href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">${escapeHtml(title)}</a>
              </div>
              <div class="competitor-card-meta">
                <span>${formatRating(item.reviewRating)}★</span>
                <span>${formatNumber(item.feedbacks)} отзывов</span>
                <span>${formatNumber(item.loadedReviews)} загружено</span>
                ${item.matchScore !== null && item.matchScore !== undefined ? `<span>похожесть ${formatNumber(item.matchScore)}</span>` : ""}
              </div>
              ${
                (item.matchReasons || []).length
                  ? `<div class="match-reasons">${item.matchReasons.map((reason) => `<span>${escapeHtml(reason)}</span>`).join("")}</div>`
                  : ""
              }
              ${
                strengths.length
                  ? `<p><strong>Хвалят:</strong> ${strengths.map(escapeHtml).join(", ")}</p>`
                  : ""
              }
              ${
                weaknesses.length
                  ? `<p><strong>Критикуют:</strong> ${weaknesses.map(escapeHtml).join(", ")}</p>`
                  : ""
              }
            </article>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderCompetitorAnalysis(data) {
  const target = document.getElementById("competitor-results");
  if (!target) return;

  const benchmark = data.benchmark || { your: {}, competitorsAvg: {} };
  const your = benchmark.your || {};
  const competitors = benchmark.competitorsAvg || {};
  const summary = data.summary || {};

  target.hidden = false;
  target.innerHTML = `
    <div class="section-head">
      <h2>Сравнение с конкурентами</h2>
      <span class="section-count">${formatNumber(summary.competitorCount || 0)} из ${formatNumber(summary.requestedCompetitors || 10)}</span>
    </div>
    <p class="competitor-verdict">${escapeHtml(summary.verdict || "")}</p>

    <div class="competitor-benchmark">
      ${renderBenchmarkCard("Средняя оценка", your.averageRating, competitors.averageRating, "rating")}
      ${renderBenchmarkCard("Всего отзывов", your.feedbackCount, competitors.feedbackCount, "count")}
      ${renderBenchmarkCard("Отзывы с текстом", your.textFeedbackCount, competitors.textFeedbackCount, "count")}
      ${renderBenchmarkCard("Позитив 4-5★", your.positiveRatingPercent, competitors.positiveRatingPercent, "percent")}
      ${renderBenchmarkCard("Негатив 1-3★", your.negativeRatingPercent, competitors.negativeRatingPercent, "percent")}
    </div>

    ${renderCompetitorPhotoComparison(data.visualComparison)}

    <div class="competitor-block">
      <div class="section-head">
        <h2>Что усилить</h2>
        <span class="section-count">${formatNumber((data.actionPlan || []).length)}</span>
      </div>
      ${renderCompetitorActions(data.actionPlan)}
    </div>

    <div class="competitor-block">
      <div class="section-head">
        <h2>Сравнение по темам</h2>
        <span class="section-count">на 100 отзывов</span>
      </div>
      ${renderAspectComparison(data.aspectComparison)}
    </div>

    <div class="competitor-block">
      <div class="section-head">
        <h2>Найденные конкуренты</h2>
        <span class="section-count">${formatNumber((data.competitors || []).length)}</span>
      </div>
      ${renderCompetitorList(data.competitors)}
    </div>
  `;
}

function renderResults(data) {
  const { product, summary, strengths, weaknesses, terms, examples, source } = data;
  const recommendations = data.recommendations || { content: [], product: [], priorityActions: [], hpv: [] };
  const firstPhoto = data.firstPhotoAnalysis || product.firstPhotoAnalysis;
  const productName = [product.brand, product.name].filter(Boolean).join(" · ") || `Артикул ${product.article}`;
  const productImageUrl = mediaUrl(product.imageUrl || "");
  const productSourceUrl = mediaUrl(firstPhoto?.sourceUrl || product.sourceImageUrl || "");
  const productImageSrc = productImageUrl || productSourceUrl;
  const productImageFallback = productSourceUrl && productSourceUrl !== productImageSrc ? productSourceUrl : "";
  const productPhoto = productImageSrc
    ? `
      <a class="product-photo-card" href="${escapeHtml(product.url)}" target="_blank" rel="noreferrer" aria-label="Открыть товар на Wildberries">
        <img src="${escapeHtml(productImageSrc)}" data-fallback-src="${escapeHtml(productImageFallback)}" alt="" loading="lazy" onerror="handleImageError(this)">
        <span class="product-photo-fallback">Фото товара</span>
      </a>
    `
    : "";

  statusBox.hidden = true;
  resultsBox.hidden = false;
  resultsBox.innerHTML = `
    <section class="product-strip ${productImageSrc ? "has-photo" : ""}">
      ${productPhoto}
      <div class="product-main">
        <h2 class="product-title">${escapeHtml(productName)}</h2>
        <div class="product-meta">
          <span>Артикул ${formatNumber(product.article)}</span>
          ${product.root ? `<span>root ${formatNumber(product.root)}</span>` : ""}
          ${product.supplier ? `<span>${escapeHtml(product.supplier)}</span>` : ""}
        </div>
        <p class="verdict">${escapeHtml(summary.verdict)}</p>
        <div class="source-line">
          <a href="${escapeHtml(product.url)}" target="_blank" rel="noreferrer">Открыть товар</a>
          <button
            class="export-button"
            type="button"
            data-export-article="${escapeHtml(product.article)}"
            data-export-limit="${escapeHtml(source?.limit || limitSelect.value)}"
          >
            Выгрузить в Excel
          </button>
          <button
            class="brief-button"
            type="button"
            data-brief-article="${escapeHtml(product.article)}"
            data-brief-limit="${escapeHtml(source?.limit || limitSelect.value)}"
          >
            Сделать ТЗ
          </button>
          <button
            class="competitor-button"
            type="button"
            data-competitor-article="${escapeHtml(product.article)}"
            data-competitor-limit="${escapeHtml(source?.limit || limitSelect.value)}"
          >
            Анализировать конкурентов
          </button>
          <span>Загружено ${formatNumber(summary.loadedReviews)} отзывов</span>
        </div>
      </div>
      <div class="score-pill" aria-label="Средняя оценка">
        <div class="score-value">${formatRating(summary.averageRating)}</div>
        <div class="score-caption">средняя оценка</div>
      </div>
    </section>

    <section class="metric-grid" aria-label="Ключевые метрики">
      ${metric("Всего отзывов", formatNumber(summary.feedbackCount), "по данным WB")}
      ${metric("С текстом", formatNumber(summary.textFeedbackCount), "для смыслового анализа")}
      ${metric("Оценки 4-5★", summary.positiveRatingPercent === null ? "—" : `${summary.positiveRatingPercent}%`, "позитивная доля")}
      ${metric("Оценки 1-3★", summary.negativeRatingPercent === null ? "—" : `${summary.negativeRatingPercent}%`, "проблемная доля")}
    </section>

    ${renderFirstPhotoAnalysis(firstPhoto, product)}

    <section class="recommendations-block">
      <div class="section-head">
        <h2>Рекомендации</h2>
        <span class="section-count">${(recommendations.content?.length || 0) + (recommendations.product?.length || 0) + (recommendations.hpv?.length || 0)}</span>
      </div>
      ${renderPriorityActions(recommendations.priorityActions)}
      ${renderHpvRecommendations(recommendations.hpv)}
      <div class="recommendation-grid">
        <div>
          <h3 class="group-title">Контент карточки</h3>
          ${renderRecommendations(recommendations.content)}
        </div>
        <div>
          <h3 class="group-title">Товар и поставка</h3>
          ${renderRecommendations(recommendations.product)}
        </div>
      </div>
    </section>

    <section id="competitor-results" class="competitor-results" hidden aria-live="polite"></section>

    <section class="analysis-grid">
      <div>
        <div class="section-head">
          <h2>Сильные стороны</h2>
          <span class="section-count">${strengths.length}</span>
        </div>
        ${renderAspects(strengths, "good")}
      </div>
      <div>
        <div class="section-head">
          <h2>Слабые стороны</h2>
          <span class="section-count">${weaknesses.length}</span>
        </div>
        ${renderAspects(weaknesses, "bad")}
      </div>
    </section>

    <section class="chart-grid">
      <article class="chart-card">
        <h2>Оценки</h2>
        ${renderDistribution(summary.distribution)}
      </article>
      <article class="chart-card">
        <h2>Размер</h2>
        ${renderSizeFit(summary.matchingSizePercentages)}
      </article>
    </section>

    <section class="chart-grid">
      <article class="chart-card">
        <h2>Часто хвалят</h2>
        ${renderTopics(terms.positive, "good")}
      </article>
      <article class="chart-card">
        <h2>Часто критикуют</h2>
        ${renderTopics(terms.negative, "bad")}
      </article>
    </section>

    <section class="example-grid">
      <article class="example-card">
        <h2>Примеры плюсов</h2>
        ${renderExamples(examples.positive)}
      </article>
      <article class="example-card">
        <h2>Примеры минусов</h2>
        ${renderExamples(examples.negative)}
      </article>
    </section>
  `;
}

async function analyze(article, limit) {
  const params = new URLSearchParams({ article, limit });
  const response = await fetch(apiUrl(`/api/analyze?${params.toString()}`));
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok) {
    throw new Error(payload?.error || "Не удалось выполнить анализ.");
  }
  return payload.data;
}

async function analyzeCompetitors(article, limit) {
  const params = new URLSearchParams({ article, limit, competitors: "10" });
  const response = await fetch(apiUrl(`/api/competitors?${params.toString()}`));
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok) {
    throw new Error(payload?.error || "Не удалось выполнить анализ конкурентов.");
  }
  return payload.data;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const article = articleInput.value.trim();
  if (!article) {
    showStatus("error", "Введите артикул или ссылку на товар.");
    articleInput.focus();
    return;
  }

  setLoading(true);
  showStatus("loading", "Загружаю карточку и отзывы Wildberries…");
  try {
    const data = await analyze(article, limitSelect.value);
    renderResults(data);
  } catch (error) {
    showStatus("error", error.message);
  } finally {
    setLoading(false);
  }
});

resultsBox.addEventListener("click", async (event) => {
  const competitorButton = event.target.closest("[data-competitor-article]");
  if (competitorButton) {
    const originalText = competitorButton.textContent;
    competitorButton.disabled = true;
    competitorButton.textContent = "Собираю конкурентов…";
    renderCompetitorLoading();
    try {
      const data = await analyzeCompetitors(
        competitorButton.dataset.competitorArticle,
        competitorButton.dataset.competitorLimit || limitSelect.value,
      );
      renderCompetitorAnalysis(data);
    } catch (error) {
      renderCompetitorError(error.message);
    } finally {
      competitorButton.disabled = false;
      competitorButton.textContent = originalText;
    }
    return;
  }

  const briefButton = event.target.closest("[data-brief-article]");
  if (briefButton) {
    const params = new URLSearchParams({
      article: briefButton.dataset.briefArticle,
      limit: briefButton.dataset.briefLimit || limitSelect.value,
    });
    window.location.href = apiUrl(`/api/brief?${params.toString()}`);
    return;
  }

  const button = event.target.closest("[data-export-article]");
  if (!button) return;
  const params = new URLSearchParams({
    article: button.dataset.exportArticle,
    limit: button.dataset.exportLimit || limitSelect.value,
  });
  window.location.href = apiUrl(`/api/export?${params.toString()}`);
});
