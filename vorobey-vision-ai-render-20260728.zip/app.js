const form = document.getElementById("analyze-form");
const articleInput = document.getElementById("article-input");
const marketplaceSelect = document.getElementById("marketplace-select");
const submitButton = document.getElementById("submit-button");
const statusBox = document.getElementById("status");
const resultsBox = document.getElementById("results");
const searchBand = document.querySelector(".search-band");
const authGate = document.getElementById("auth-gate");
const telegramLoginSlot = document.getElementById("telegram-login-slot");
const authChannelsBox = document.getElementById("auth-channels");
const authMessage = document.getElementById("auth-message");
const authRefreshButton = document.getElementById("auth-refresh-button");
const authLogoutButton = document.getElementById("auth-logout-button");
const authOpenBotButton = document.getElementById("auth-open-bot-button");
const fullscreenButton = document.getElementById("fullscreen-button");
const fullscreenButtonLabel = document.getElementById("fullscreen-button-label");

const PUBLIC_API_ORIGIN = "https://vorobey-vision-ai.onrender.com";
const API_ORIGIN = window.location.protocol === "file:" ? PUBLIC_API_ORIGIN : "";
const DEFAULT_REVIEW_LIMIT = 200;
const numberFormat = new Intl.NumberFormat("ru-RU");
const MARKETPLACES = {
  wb: { label: "WB", full: "Wildberries", mark: "WB" },
  ozon: { label: "Ozon", full: "Ozon", mark: "OZ" },
};
let authState = { enabled: false, allowed: true, botUsername: "", channels: [] };
let telegramWidgetLoaded = false;
let telegramMiniAppTried = false;

function apiUrl(path) {
  return `${API_ORIGIN}${path}`;
}

function mediaUrl(value) {
  if (!value) return "";
  if (API_ORIGIN && String(value).startsWith("/")) return `${API_ORIGIN}${value}`;
  return value;
}

function currentMarketplace() {
  return marketplaceSelect?.value || "wb";
}

function marketplaceMeta(value = currentMarketplace()) {
  return MARKETPLACES[value] || MARKETPLACES.wb;
}

function browserFullscreenElement() {
  return document.fullscreenElement || document.webkitFullscreenElement || null;
}

function updateFullscreenButton(isFullscreen = Boolean(browserFullscreenElement())) {
  if (!fullscreenButton) return;
  const label = isFullscreen ? "Выйти из полноэкранного режима" : "Развернуть на весь экран";
  fullscreenButton.setAttribute("aria-pressed", String(isFullscreen));
  fullscreenButton.setAttribute("aria-label", label);
  fullscreenButton.title = label;
  if (fullscreenButtonLabel) fullscreenButtonLabel.textContent = isFullscreen ? "Свернуть" : "Развернуть";
}

async function toggleFullscreen() {
  const root = document.documentElement;
  const telegram = telegramWebApp();
  const isFullscreen = Boolean(browserFullscreenElement());

  try {
    if (isFullscreen) {
      const exit = document.exitFullscreen || document.webkitExitFullscreen;
      if (exit) await exit.call(document);
      else if (typeof telegram?.exitFullscreen === "function") telegram.exitFullscreen();
    } else {
      const request = root.requestFullscreen || root.webkitRequestFullscreen;
      if (request) await request.call(root);
      else if (typeof telegram?.requestFullscreen === "function") telegram.requestFullscreen();
      else if (typeof telegram?.expand === "function") telegram.expand();
    }
  } catch (error) {
    if (!isFullscreen && typeof telegram?.expand === "function") telegram.expand();
  }

  updateFullscreenButton();
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatNumber(value) {
  if (value === null || value === undefined || value === "") return "—";
  return numberFormat.format(value);
}

function formatRating(value) {
  if (!value) return "—";
  return Number(value).toLocaleString("ru-RU", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  });
}

function handleImageError(img) {
  const fallbackSrc = img.dataset.fallbackSrc;
  if (fallbackSrc && img.src !== fallbackSrc) {
    img.dataset.fallbackSrc = "";
    img.src = fallbackSrc;
    return;
  }

  const card = img.closest(".product-photo-card, .photo-preview-card, .photo-best-card, .photo-competitor-tile");
  if (card) card.classList.add("is-broken");
  img.remove();
}

function setLoading(isLoading) {
  submitButton.disabled = isLoading;
  articleInput.disabled = isLoading;
  if (marketplaceSelect) marketplaceSelect.disabled = isLoading;
  submitButton.innerHTML = isLoading
    ? '<span class="button-icon" aria-hidden="true">…</span> Анализирую'
    : '<span class="button-icon" aria-hidden="true">↗</span> Анализировать';
}

function showStatus(type, message, details = "") {
  resultsBox.hidden = true;
  statusBox.hidden = false;
  statusBox.className = `status is-${type}`;
  const mark = type === "error" ? "!" : type === "loading" ? "…" : marketplaceMeta().mark;
  const klass = type === "error" ? "error" : type === "loading" ? "loading" : "empty";
  statusBox.innerHTML = `
    <div class="${klass}-state">
      <div class="${klass}-mark" aria-hidden="true">${mark}</div>
      <p>${escapeHtml(message)}${details ? `<br><span class="muted">${escapeHtml(details)}</span>` : ""}</p>
    </div>
  `;
}

function channelUrl(channel) {
  const clean = String(channel || "").trim().replace(/^@/, "");
  if (!clean || clean.startsWith("-")) return "";
  return `https://t.me/${clean}`;
}

function renderAuthChannels(channels = [], missing = []) {
  if (!authChannelsBox) return;
  const missingSet = new Set(missing || []);
  authChannelsBox.innerHTML = channels
    .map((channel) => {
      const url = channelUrl(channel);
      const isMissing = missingSet.has(channel);
      const label = isMissing ? "Нужна подписка" : "Канал";
      return url
        ? `<a class="auth-channel ${isMissing ? "is-missing" : ""}" href="${escapeHtml(url)}" target="_blank" rel="noreferrer"><span>${escapeHtml(label)}</span><strong>${escapeHtml(channel)}</strong></a>`
        : `<span class="auth-channel ${isMissing ? "is-missing" : ""}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(channel)}</strong></span>`;
    })
    .join("");
}

function renderTelegramWidget(botUsername) {
  if (!telegramLoginSlot || !botUsername || telegramWidgetLoaded) return;
  telegramLoginSlot.innerHTML = "";
  const script = document.createElement("script");
  script.async = true;
  script.src = "https://telegram.org/js/telegram-widget.js?22";
  script.setAttribute("data-telegram-login", botUsername);
  script.setAttribute("data-size", "large");
  script.setAttribute("data-radius", "8");
  script.setAttribute("data-userpic", "false");
  script.setAttribute("data-onauth", "onTelegramAuth(user)");
  script.setAttribute("data-request-access", "write");
  telegramLoginSlot.appendChild(script);
  telegramWidgetLoaded = true;
}

function channelListText(channels = []) {
  return (channels || []).filter(Boolean).join(", ");
}

function authProblemMessage(auth) {
  const errors = auth?.errors || [];
  if (errors.length) {
    const channels = channelListText(errors.map((item) => item.channel));
    return `Бот не может проверить подписку в каналах: ${channels}. Добавьте @${auth.botUsername || "vorobey_vision_access_bot"} администратором в эти каналы и нажмите «Проверить доступ».`;
  }
  const missing = auth?.missing || [];
  if (missing.length) {
    return `Подписка не подтверждена: ${channelListText(missing)}. Подпишитесь и нажмите «Проверить доступ».`;
  }
  return "Подпишитесь на отмеченные каналы и нажмите «Проверить доступ».";
}

function telegramWebApp() {
  return window.Telegram?.WebApp || null;
}

function telegramInitDataFromUrl() {
  const sources = [window.location.hash, window.location.search]
    .filter(Boolean)
    .map((value) => value.replace(/^[#?]/, ""));
  for (const source of sources) {
    const params = new URLSearchParams(source);
    const initData = params.get("tgWebAppData");
    if (initData) return initData;
  }
  return "";
}

function telegramInitData() {
  return telegramWebApp()?.initData || telegramInitDataFromUrl();
}

function hasTelegramMiniAppInitData() {
  return Boolean(telegramInitData());
}

function prepareTelegramMiniApp() {
  const tg = telegramWebApp();
  if (!tg) return;
  try {
    tg.ready();
    tg.expand();
  } catch (_error) {
    // Telegram WebApp methods are only available inside Telegram clients.
  }
}

async function authenticateTelegramMiniApp() {
  const initData = telegramInitData();
  if (!initData || telegramMiniAppTried) return false;
  telegramMiniAppTried = true;
  if (authMessage) authMessage.textContent = "Проверяю вход внутри Telegram…";

  const response = await fetch(apiUrl("/api/auth/telegram-webapp"), {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ initData }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok) {
    const error = new Error(payload?.error || "Не удалось войти через Telegram Mini App.");
    error.payload = payload;
    throw error;
  }
  applyAuthState(payload.auth);
  return true;
}

function applyAuthState(auth) {
  authState = auth || { enabled: false, allowed: true, channels: [] };
  const enabled = Boolean(authState.enabled);
  const allowed = !enabled || Boolean(authState.allowed);
  const inTelegramMiniApp = hasTelegramMiniAppInitData();

  if (authGate) authGate.hidden = allowed;
  if (searchBand) searchBand.hidden = !allowed;
  if (!allowed) {
    statusBox.hidden = true;
    resultsBox.hidden = true;
  }

  renderAuthChannels(authState.channels || [], authState.missing || []);
  if (authLogoutButton) authLogoutButton.hidden = !authState.user;
  if (authRefreshButton) authRefreshButton.hidden = !enabled;
  if (authOpenBotButton) {
    authOpenBotButton.hidden = !enabled || inTelegramMiniApp;
    authOpenBotButton.href = authState.botUrl || `https://t.me/${authState.botUsername || "vorobey_vision_access_bot"}`;
  }

  if (authMessage) {
    if (!enabled) {
      authMessage.textContent = "";
    } else if (!authState.user && inTelegramMiniApp) {
      authMessage.textContent = "Проверяю вход внутри Telegram…";
    } else if (!authState.user) {
      authMessage.textContent = "Откройте бота и запустите сервис кнопкой внутри Telegram. Браузерный вход ниже оставлен как запасной вариант.";
    } else if (allowed) {
      authMessage.textContent = `Доступ открыт${authState.user.username ? ` для @${authState.user.username}` : ""}.`;
    } else {
      authMessage.textContent = authProblemMessage(authState);
    }
  }

  if (enabled && !allowed) {
    renderTelegramWidget(authState.botUsername);
  }
}

async function refreshAuthStatus() {
  try {
    const response = await fetch(apiUrl("/api/auth/status"), { credentials: "include" });
    const payload = await response.json().catch(() => null);
    if (payload?.auth) {
      applyAuthState(payload.auth);
      if (payload.auth.enabled && !payload.auth.allowed && !payload.auth.user && hasTelegramMiniAppInitData()) {
        try {
          await authenticateTelegramMiniApp();
        } catch (error) {
          const auth = error?.payload?.auth;
          if (auth) applyAuthState(auth);
          else if (authMessage) authMessage.textContent = error.message;
        }
      }
    }
  } catch (_error) {
    applyAuthState({ enabled: false, allowed: true, channels: [] });
  }
}

window.onTelegramAuth = async function onTelegramAuth(user) {
  if (authMessage) authMessage.textContent = "Проверяю Telegram и подписку…";
  try {
    const response = await fetch(apiUrl("/api/auth/telegram"), {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user || {}),
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload?.ok) {
      const error = new Error(payload?.error || "Не удалось войти через Telegram.");
      error.payload = payload;
      throw error;
    }
    applyAuthState(payload.auth);
  } catch (error) {
    const auth = error?.payload?.auth;
    if (auth) applyAuthState(auth);
    else if (authMessage) authMessage.textContent = error.message;
  }
};

function metric(label, value, context = "") {
  return `
    <article class="metric-card">
      <div class="metric-label">${escapeHtml(label)}</div>
      <div class="metric-value">${value}</div>
      ${context ? `<div class="metric-context">${escapeHtml(context)}</div>` : ""}
    </article>
  `;
}

function renderResultSection({ title, eyebrow = "Блок анализа", count = "", summary = "", body = "", open = false, className = "" }) {
  const countHtml = count !== "" && count !== null && count !== undefined
    ? `<span class="result-section-count">${escapeHtml(count)}</span>`
    : "";
  return `
    <details class="result-section${className ? ` ${className}` : ""}"${open ? " open" : ""}>
      <summary class="result-section-summary">
        <span class="result-section-title">
          <span class="result-section-eyebrow">${escapeHtml(eyebrow)}</span>
          <strong>${escapeHtml(title)}</strong>
          ${summary ? `<span>${escapeHtml(summary)}</span>` : ""}
        </span>
        ${countHtml}
      </summary>
      <div class="result-section-body">
        ${body}
      </div>
    </details>
  `;
}

function renderDistribution(distribution = {}) {
  const stars = [5, 4, 3, 2, 1];
  const max = Math.max(...stars.map((star) => Number(distribution[String(star)] || 0)), 1);
  return `
    <div class="rating-bars" role="img" aria-label="Распределение оценок">
      ${stars
        .map((star) => {
          const count = Number(distribution[String(star)] || 0);
          const width = Math.round((count / max) * 100);
          return `
            <div class="rating-row">
              <span>${star}★</span>
              <div class="bar"><span style="width:${width}%"></span></div>
              <span>${formatNumber(count)}</span>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderSizeFit(sizeFit = {}) {
  const items = [
    ["ok", "В размер"],
    ["smaller", "Маломерит"],
    ["bigger", "Большемерит"],
  ].filter(([key]) => sizeFit[key] !== undefined && sizeFit[key] !== null);

  if (!items.length) {
    return '<p class="muted">Нет данных по соответствию размеру.</p>';
  }

  return `
    <div class="rating-bars" role="img" aria-label="Соответствие размеру">
      ${items
        .map(([key, label]) => {
          const value = Math.max(0, Math.min(100, Number(sizeFit[key] || 0)));
          return `
            <div class="rating-row size-row">
              <span>${escapeHtml(label)}</span>
              <div class="bar"><span style="width:${value}%"></span></div>
              <span>${value}%</span>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderAspects(items, kind) {
  if (!items.length) {
    return `<p class="muted">${kind === "good" ? "Сильные стороны пока не выделились." : "Повторяющихся слабых сторон в текстах не найдено."}</p>`;
  }
  return `
    <div class="aspect-list">
      ${items
        .map(
          (item) => `
            <article class="aspect-card">
              <div class="aspect-top">
                <div>
                  <h3 class="aspect-title">${escapeHtml(item.title)}</h3>
                  <p class="aspect-summary">${escapeHtml(item.summary)}</p>
                </div>
                <span class="aspect-badge ${kind}">${formatNumber(item.mentions)}</span>
              </div>
              ${renderEvidence(item.evidence)}
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderEvidence(evidence = []) {
  if (!evidence.length) return "";
  return `
    <ul class="evidence-list">
      ${evidence
        .slice(0, 2)
        .map(
          (item) => `
            <li>
              “${escapeHtml(item.text)}”
              <small>${item.rating ? `${item.rating}★` : "без оценки"}${item.date ? ` · ${escapeHtml(item.date)}` : ""}</small>
            </li>
          `,
        )
        .join("")}
    </ul>
  `;
}

function renderTopics(terms = [], kind) {
  if (!terms.length) return '<p class="muted">Недостаточно повторяющихся слов.</p>';
  return `
    <div class="topic-cloud">
      ${terms
        .map(
          (item) => `
            <span class="topic ${kind}">
              ${escapeHtml(item.term)}
              <span class="topic-count">${formatNumber(item.count)}</span>
            </span>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderExamples(examples = []) {
  if (!examples.length) return '<p class="muted">Нет подходящих текстовых примеров.</p>';
  return `
    <ul class="example-list">
      ${examples
        .map(
          (item) => `
            <li class="example-item">
              <p>“${escapeHtml(item.text)}”</p>
              <div class="example-meta">
                <span>${item.rating ? `${item.rating}★` : "без оценки"}</span>
                ${item.date ? `<span>${escapeHtml(item.date)}</span>` : ""}
                ${item.color ? `<span>${escapeHtml(item.color)}</span>` : ""}
                ${item.size ? `<span>${escapeHtml(item.size)}</span>` : ""}
              </div>
            </li>
          `,
        )
        .join("")}
    </ul>
  `;
}

function renderRecommendations(items = []) {
  if (!items.length) return '<p class="muted">Нет отдельных рекомендаций для этого блока.</p>';
  return `
    <div class="recommendation-list">
      ${items.map(renderRecommendationCard).join("")}
    </div>
  `;
}

function renderPriorityActions(items = []) {
  if (!items.length) return "";
  return `
    <ol class="priority-action-list">
      ${items
        .map(
          (item) => `
            <li class="priority-action priority-${escapeHtml(item.priority || "medium")}">
              <div class="priority-action-meta">
                <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                <span class="area-badge">${item.area === "product" ? "Товар" : "Контент"}</span>
              </div>
              <strong>${escapeHtml(item.title)}</strong>
              <p>${escapeHtml(item.action)}</p>
            </li>
          `,
        )
        .join("")}
    </ol>
  `;
}

function renderRecommendationCard(item) {
  const area = item.area === "product" ? "Товар" : "Контент";
  return `
    <details class="recommendation-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
      <summary class="collapsible-summary">
        <span class="recommendation-top">
          <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
          <span class="area-badge">${area}</span>
        </span>
        <span class="summary-title">${escapeHtml(item.title)}</span>
        <span class="summary-subline">${escapeHtml(item.aspect || "")}</span>
      </summary>
      <div class="collapsible-body">
        <p class="recommendation-action">${escapeHtml(item.action)}</p>
        <p class="recommendation-reason">${escapeHtml(item.reason)}</p>
        ${renderEvidence(item.evidence)}
      </div>
    </details>
  `;
}

function renderHpvRecommendations(items = []) {
  if (!items.length) return "";
  return `
    <div class="hpv-block">
      <div class="section-head">
        <h2>ХПВ: характеристики в выгоды</h2>
        <span class="section-count">${formatNumber(items.length)}</span>
      </div>
      <div class="hpv-grid">
        ${items
          .map(
            (item) => `
              <details class="hpv-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
                <summary class="collapsible-summary">
                  <span class="recommendation-top">
                    <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                    <span class="area-badge">${escapeHtml(item.source || "Карточка")}</span>
                  </span>
                  <span class="summary-title">${escapeHtml(item.characteristic)}</span>
                  <span class="summary-subline">${escapeHtml(item.benefit)}</span>
                </summary>
                <div class="collapsible-body">
                  <div class="hpv-chain">
                    <div>
                      <span>Характеристика</span>
                      <p>${escapeHtml(item.characteristic)}</p>
                    </div>
                    <div>
                      <span>Преимущество</span>
                      <p>${escapeHtml(item.advantage)}</p>
                    </div>
                    <div>
                      <span>Выгода</span>
                      <p>${escapeHtml(item.benefit)}</p>
                    </div>
                  </div>
                  <div class="hpv-copy">
                    <p><strong>Для карточки:</strong> ${escapeHtml(item.cardText)}</p>
                    <p><strong>Для инфографики:</strong> ${escapeHtml(item.infographicText)}</p>
                  </div>
                  <p class="recommendation-reason">${escapeHtml(item.why)}</p>
                </div>
              </details>
            `,
          )
          .join("")}
      </div>
    </div>
  `;
}

function renderSeoStatusClass(value = "") {
  const status = String(value).toLowerCase();
  if (status.includes("критично")) return "priority-high";
  if (status.includes("срочно")) return "priority-high";
  if (status.includes("проверить")) return "priority-medium";
  if (status.includes("недостаточно")) return "priority-medium";
  return "priority-low";
}

function renderSeoPanel(title, summary, body, open = false) {
  return `
    <details class="seo-panel collapsible-card"${open ? " open" : ""}>
      <summary class="collapsible-summary">
        <span class="summary-title">${escapeHtml(title)}</span>
        ${summary ? `<span class="summary-subline">${escapeHtml(summary)}</span>` : ""}
      </summary>
      <div class="collapsible-body">
        ${body}
      </div>
    </details>
  `;
}

function renderSeoScore(score) {
  return score === null || score === undefined || score === "" ? "—" : `${formatNumber(score)}/100`;
}

function renderSeoEvaluationCard(title, evaluation = {}, meta = "") {
  const issues = evaluation.issues || [];
  const strengths = evaluation.strengths || [];
  return `
    <details class="seo-card collapsible-card ${issues.length ? "priority-high" : "priority-low"}" open>
      <summary class="collapsible-summary">
        <span class="recommendation-top">
          <span class="priority-badge">${escapeHtml(renderSeoScore(evaluation.score))}</span>
          ${meta ? `<span class="area-badge">${escapeHtml(meta)}</span>` : ""}
        </span>
        <span class="summary-title">${escapeHtml(title)}</span>
        <span class="summary-subline">${escapeHtml(evaluation.recommendedActionLabel || evaluation.keywordSpamLevel || "оценка")}</span>
      </summary>
      <div class="collapsible-body">
        ${
          evaluation.components
            ? `<div class="seo-component-grid">${Object.entries(evaluation.components)
                .map(([key, value]) => `<span><strong>${escapeHtml(key)}</strong>${escapeHtml(renderSeoScore(value))}</span>`)
                .join("")}</div>`
            : ""
        }
        ${strengths.map((item) => `<p class="recommendation-reason">${escapeHtml(item)}</p>`).join("")}
        ${issues
          .map(
            (item) => `
              <article class="seo-issue-row priority-${escapeHtml(item.severity || "medium")}">
                <strong>${escapeHtml(item.title || "Проблема")}</strong>
                <p>${escapeHtml(item.description || "")}</p>
                ${item.recommendation ? `<small>${escapeHtml(item.recommendation)}</small>` : ""}
                <span class="area-badge">confidence ${escapeHtml(item.confidence ?? "—")}</span>
              </article>
            `,
          )
          .join("")}
        ${evaluation.suggestedTitle ? `<p class="recommendation-action"><strong>Предлагаемое наименование:</strong> ${escapeHtml(evaluation.suggestedTitle)}</p>` : ""}
        ${evaluation.suggestedDescription ? `<p class="recommendation-action"><strong>Улучшенный вариант описания:</strong> ${escapeHtml(evaluation.suggestedDescription)}</p>` : ""}
      </div>
    </details>
  `;
}

function renderSeoAttributesEvaluation(evaluation = {}) {
  const rows = evaluation.rows || [];
  const header = `
    <div class="metric-grid seo-mini-metrics">
      ${metric("Оценка", renderSeoScore(evaluation.score), "характеристики")}
      ${metric("Важные поля", `${formatNumber(evaluation.filledImportant || 0)} / ${formatNumber(evaluation.totalImportant || 0)}`, "заполнено")}
      ${metric("Проблемы", formatNumber((evaluation.issues || []).length), "P0")}
      ${metric("Противоречия", formatNumber((evaluation.contradictions || []).length), "между полями")}
    </div>
  `;
  const table = rows.length
    ? `
      <div class="seo-table-wrap">
        <table class="seo-table">
          <thead>
            <tr>
              <th>Характеристика</th>
              <th>Значение</th>
              <th>SEO-важность</th>
              <th>Статус</th>
              <th>Рекомендация</th>
            </tr>
          </thead>
          <tbody>
            ${rows
              .map(
                (item) => `
                  <tr>
                    <td>${escapeHtml(item.attributeName || "")}</td>
                    <td>${escapeHtml(item.value || "—")}</td>
                    <td>${escapeHtml(item.seoImportance || "")}</td>
                    <td>${escapeHtml(item.status || "")}</td>
                    <td>${escapeHtml(item.recommendation || "")}</td>
                  </tr>
                `,
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `
    : '<p class="muted">Характеристики не найдены.</p>';
  const issues = renderSeoEvaluationCard("Проблемы характеристик", { score: evaluation.score, issues: evaluation.issues || [] }, "P0");
  return `${header}${table}${issues}`;
}

function renderSeoConsistency(consistency = {}) {
  const conflicts = consistency.conflicts || [];
  if (!conflicts.length) return '<p class="muted">Противоречий между наименованием, характеристиками и описанием не найдено.</p>';
  return `
    <div class="seo-task-list">
      ${conflicts
        .map(
          (item) => `
            <article class="seo-task priority-high">
              <div class="priority-action-meta">
                <span class="priority-badge">${escapeHtml(item.severity || "high")}</span>
                <span class="area-badge">${escapeHtml(item.group || "consistency")}</span>
              </div>
              <strong>${escapeHtml(item.fieldA || "")} ↔ ${escapeHtml(item.fieldB || "")}</strong>
              <p>${escapeHtml(item.description || "")}</p>
              <small>confidence ${escapeHtml(item.confidence ?? "—")}</small>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoSemanticPlacement(placement = {}) {
  const items = placement.items || [];
  if (!items.length) return '<p class="muted">Семантика ограничена публичными данными карточки и отзывами.</p>';
  return `
    <div class="seo-table-wrap">
      <table class="seo-table">
        <thead>
          <tr>
            <th>Кластер</th>
            <th>Запрос</th>
            <th>Релевантность</th>
            <th>Куда использовать</th>
            <th>Статус</th>
            <th>Почему</th>
          </tr>
        </thead>
        <tbody>
          ${items
            .slice(0, 18)
            .map(
              (item) => `
                <tr>
                  <td>${escapeHtml(item.cluster || "")}</td>
                  <td>${escapeHtml(item.query || "")}</td>
                  <td>${escapeHtml(item.relevanceLabel || item.relevance || "")}</td>
                  <td>${escapeHtml(item.placementLabel || item.placement || "")}</td>
                  <td>${escapeHtml(item.status || "")}</td>
                  <td>${escapeHtml(item.reason || "")}</td>
                </tr>
              `,
            )
            .join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderSeoP0Audit(seo = {}) {
  const p0 = seo.p0Audit || {};
  if (!p0.ok) return "";
  const titleEvaluation = p0.titleEvaluation || seo.titleEvaluation || {};
  const attributesEvaluation = p0.attributesEvaluation || seo.attributesEvaluation || {};
  const descriptionEvaluation = p0.descriptionEvaluation || seo.descriptionEvaluation || {};
  return renderSeoPanel(
    "P0 SEO-аудит карточки",
    "Наименование, характеристики, описание и распределение семантики.",
    `
      <div class="metric-grid seo-mini-metrics">
        ${metric("Card SEO Score", renderSeoScore(p0.score || seo.cardSeoScore), p0.scoreLabel || seo.cardSeoScoreLabel || "")}
        ${metric("Наименование", renderSeoScore(titleEvaluation.score), titleEvaluation.recommendedActionLabel || "")}
        ${metric("Характеристики", renderSeoScore(attributesEvaluation.score), `${formatNumber(attributesEvaluation.filledImportant || 0)} из ${formatNumber(attributesEvaluation.totalImportant || 0)}`)}
        ${metric("Описание", renderSeoScore(descriptionEvaluation.score), `переспам: ${descriptionEvaluation.keywordSpamLevel || "—"}`)}
      </div>
      <div class="seo-two-column">
        ${renderSeoEvaluationCard("Наименование", titleEvaluation, "TitleEvaluator")}
        ${renderSeoEvaluationCard("Описание", descriptionEvaluation, "DescriptionEvaluator")}
      </div>
      ${renderSeoPanel("Характеристики", "AttributesEvaluator", renderSeoAttributesEvaluation(attributesEvaluation))}
      ${renderSeoPanel("Противоречия", "ConsistencyChecker", renderSeoConsistency(p0.consistency || seo.consistency || {}))}
      ${renderSeoPanel("Распределение семантики", "SemanticPlacementEngine", renderSeoSemanticPlacement(p0.semanticPlacement || seo.semanticPlacement || {}))}
    `,
    true,
  );
}

function renderSeoModuleScores(items = []) {
  if (!items.length) return '<p class="muted">Модульная SEO-оценка пока не сформирована.</p>';
  return `
    <div class="seo-module-grid">
      ${items
        .map(
          (item) => `
            <details class="seo-module-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.status || "Статус")}</span>
                  <span class="area-badge">Вес ${escapeHtml(item.weight || 0)}%</span>
                </span>
                <span class="summary-title">${escapeHtml(item.label || "SEO-модуль")}</span>
                <span class="summary-subline">${escapeHtml(item.reason || "")}</span>
              </summary>
              <div class="collapsible-body">
                <div class="seo-score-line">
                  <span>${escapeHtml(renderSeoScore(item.score))}</span>
                  <div class="bar"><span style="width:${Math.max(0, Math.min(100, Number(item.score || 0)))}%"></span></div>
                </div>
                <p class="recommendation-action">${escapeHtml(item.action || "")}</p>
                <p class="recommendation-reason">${escapeHtml(item.expectedImpact || "")}</p>
                ${
                  item.dataRequired?.length
                    ? `<div class="seo-keyword-cloud">${item.dataRequired
                        .map((field) => `<span class="seo-keyword is-query">${escapeHtml(field)}</span>`)
                        .join("")}</div>`
                    : ""
                }
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoFunnel(funnel = {}) {
  const stages = funnel.stages || [];
  if (!stages.length) return '<p class="muted">Воронка пока не рассчитана.</p>';
  return `
    <div class="seo-funnel">
      ${funnel.bottleneck ? `<p class="seo-bottleneck">${escapeHtml(funnel.bottleneck)}</p>` : ""}
      ${stages
        .map(
          (item) => `
            <details class="seo-funnel-stage collapsible-card ${renderSeoStatusClass(item.status)}">
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.status || "Статус")}</span>
                  <span class="area-badge">${escapeHtml(item.metric || "Метрика")}</span>
                </span>
                <span class="summary-title">${escapeHtml(item.label || "Этап")}</span>
                <span class="summary-subline">${escapeHtml(item.value || "Недостаточно данных")}</span>
              </summary>
              <div class="collapsible-body">
                <p class="recommendation-reason">${escapeHtml(item.interpretation || "")}</p>
                <p class="recommendation-action">${escapeHtml(item.action || "")}</p>
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoAudit(items = []) {
  if (!items.length) return '<p class="muted">SEO-аудит не нашел отдельных замечаний.</p>';
  return `
    <div class="seo-grid">
      ${items
        .map(
          (item) => `
            <details class="seo-card collapsible-card ${renderSeoStatusClass(item.status)}">
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                  <span class="area-badge">${escapeHtml(item.status || "проверить")}</span>
                </span>
                <span class="summary-title">${escapeHtml(item.label || "SEO-пункт")}</span>
                <span class="summary-subline">${escapeHtml(item.summary || "")}</span>
              </summary>
              <div class="collapsible-body">
                <div class="seo-score-line">
                  <span>${formatNumber(item.score || 0)}/100</span>
                  <div class="bar"><span style="width:${Math.max(0, Math.min(100, Number(item.score || 0)))}%"></span></div>
                </div>
                <p class="recommendation-action">${escapeHtml(item.action || "")}</p>
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoKeywords(items = []) {
  if (!items.length) return '<p class="muted">Недостающих ключевых сигналов не найдено.</p>';
  return `
    <div class="seo-grid">
      ${items
        .map(
          (item) => `
            <details class="seo-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                  <span class="area-badge">${escapeHtml(item.where || "Карточка")}</span>
                </span>
                <span class="summary-title">${escapeHtml(item.term || "Ключ")}</span>
                <span class="summary-subline">${escapeHtml(item.reason || "")}</span>
              </summary>
              <div class="collapsible-body">
                <p class="recommendation-action">${escapeHtml(item.action || "")}</p>
                <p class="recommendation-reason">${escapeHtml(item.source || "")}${item.intent ? ` · ${escapeHtml(item.intent)}` : ""}</p>
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoTasks(items = []) {
  if (!items.length) return '<p class="muted">Нет отдельных SEO-задач.</p>';
  return `
    <div class="seo-task-list">
      ${items
        .map(
          (item) => `
            <article class="seo-task priority-${escapeHtml(item.priority || "medium")}">
              <div class="priority-action-meta">
                <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                <span class="area-badge">${escapeHtml(item.block || "Карточка")}</span>
              </div>
              <strong>${escapeHtml(item.title || "SEO-задача")}</strong>
              <p>${escapeHtml(item.action || "")}</p>
              <small>${escapeHtml(item.reason || "")}</small>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoSemanticCore(items = []) {
  if (!items.length) return '<p class="muted">Семантическое ядро пока не собрано.</p>';
  return `
    <div class="seo-keyword-cloud">
      ${items
        .slice(0, 16)
        .map(
          (item) => `
            <span class="seo-keyword ${item.inTitle ? "is-used" : "is-missing"}">
              ${escapeHtml(item.term || "")}
              <small>${item.inTitle ? "в названии" : "добавить"}</small>
            </span>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoClusters(items = []) {
  if (!items.length) return '<p class="muted">Кластеры пока не сформированы.</p>';
  return `
    <div class="seo-cluster-list">
      ${items
        .map(
          (item) => `
            <details class="seo-cluster-card collapsible-card" ${item.status === "primary" ? "open" : ""}>
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.statusLabel || "Кластер")}</span>
                  <span class="area-badge">Opportunity ${escapeHtml(item.opportunityScore || "—")}/100</span>
                </span>
                <span class="summary-title">${escapeHtml(item.mainQuery || item.name || "Кластер")}</span>
                <span class="summary-subline">${escapeHtml(item.sourceNote || "")}</span>
              </summary>
              <div class="collapsible-body">
                <div class="seo-keyword-cloud">
                  ${(item.queries || [])
                    .slice(0, 10)
                    .map((query) => `<span class="seo-keyword ${query.inTitle ? "is-used" : "is-query"}">${escapeHtml(query.query || "")}<small>${escapeHtml(query.status || "гипотеза")}</small></span>`)
                    .join("")}
                </div>
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoCardAudit(card = {}) {
  if (!card || (!card.title && !card.attributes && !card.description)) {
    return '<p class="muted">Аудит карточки пока не сформирован.</p>';
  }
  const title = card.title || {};
  const attributes = card.attributes || {};
  const description = card.description || {};
  return `
    <div class="seo-card-audit">
      <details class="seo-card collapsible-card" open>
        <summary class="collapsible-summary">
          <span class="summary-title">Название</span>
          <span class="summary-subline">${escapeHtml(title.mainQuery || title.primaryCluster || "главный запрос не определен")}</span>
        </summary>
        <div class="collapsible-body">
          ${title.current ? `<p><strong>Сейчас:</strong> ${escapeHtml(title.current)}</p>` : ""}
          ${(title.problems || []).map((item) => `<p class="recommendation-reason">${escapeHtml(item)}</p>`).join("")}
          <p class="recommendation-action">${escapeHtml(title.recommendation || "")}</p>
          ${title.example ? `<p><strong>Пример направления:</strong> ${escapeHtml(title.example)}</p>` : ""}
        </div>
      </details>
      <details class="seo-card collapsible-card">
        <summary class="collapsible-summary">
          <span class="summary-title">Характеристики</span>
          <span class="summary-subline">Заполнено: ${escapeHtml(attributes.filledCount || 0)} · важно для фильтров</span>
        </summary>
        <div class="collapsible-body">
          <div class="seo-keyword-cloud">
            ${(attributes.filterRelated || []).map((item) => `<span class="seo-keyword is-used">${escapeHtml(item)}</span>`).join("")}
          </div>
          ${(attributes.missing || []).length ? `<p class="recommendation-reason">Проверить: ${(attributes.missing || []).map((item) => escapeHtml(item.label)).join(", ")}</p>` : ""}
          <p class="recommendation-action">${escapeHtml(attributes.recommendation || "")}</p>
        </div>
      </details>
      <details class="seo-card collapsible-card">
        <summary class="collapsible-summary">
          <span class="summary-title">Описание</span>
          <span class="summary-subline">${escapeHtml(description.wordCount || 0)} значимых слов</span>
        </summary>
        <div class="collapsible-body">
          ${(description.problems || []).map((item) => `<p class="recommendation-reason">${escapeHtml(item)}</p>`).join("")}
          <p class="recommendation-action">${escapeHtml(description.recommendation || "")}</p>
        </div>
      </details>
    </div>
  `;
}

function renderSeoRecommendations(items = []) {
  if (!items.length) return "";
  return `
    <div class="recommendation-list">
      ${items
        .map(
          (item) => `
            <article class="recommendation-card seo-recommendation priority-${escapeHtml(item.priority || "medium")}">
              <div class="collapsible-body">
                <div class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                  <span class="area-badge">${escapeHtml(item.moduleLabel || "SEO")}</span>
                </div>
                <strong class="summary-title">${escapeHtml(item.problem || item.title || "Рекомендация")}</strong>
                ${item.evidence ? `<p class="recommendation-reason"><strong>Основание:</strong> ${escapeHtml(item.evidence)}</p>` : ""}
                <p class="recommendation-action">${escapeHtml(item.recommendation || item.action || "")}</p>
                ${item.expectedImpact ? `<p class="recommendation-reason"><strong>Эффект:</strong> ${escapeHtml(item.expectedImpact)}</p>` : ""}
                ${item.checkAfter ? `<p class="recommendation-reason"><strong>Проверить:</strong> ${escapeHtml(item.checkAfter)}</p>` : ""}
                <div class="recommendation-top">
                  ${item.effortLabel ? `<span class="area-badge">Сложность: ${escapeHtml(item.effortLabel)}</span>` : ""}
                  ${item.confidenceLabel ? `<span class="area-badge">Уверенность: ${escapeHtml(item.confidenceLabel)}</span>` : ""}
                </div>
              </div>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoDataNeeds(items = []) {
  if (!items.length) return '<p class="muted">Для текущих SEO-блоков дополнительных данных не требуется.</p>';
  return `
    <div class="seo-data-list">
      ${items
        .map(
          (item) => `
            <article class="seo-data-need">
              <strong>${escapeHtml(item.module || "Данные")}</strong>
              <div class="seo-keyword-cloud">
                ${(item.fields || []).map((field) => `<span class="seo-keyword is-query">${escapeHtml(field)}</span>`).join("")}
              </div>
              <p>${escapeHtml(item.why || "")}</p>
              <small>${escapeHtml(item.source || "")}</small>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderSeoAnalysis(seo = {}) {
  if (!seo || !seo.ok) return "";
  return renderResultSection({
    title: "SEO карточки",
    eyebrow: "Раздел на доработке",
    count: "скоро",
    summary: "Блок SEO на доработке.",
    body: `
      <div class="seo-placeholder">
        <p>Блок SEO на доработке.</p>
      </div>
    `,
  });
}

function formatPhotoScore(value) {
  if (value === null || value === undefined || value === "") return "—";
  return Math.round(Number(value)).toLocaleString("ru-RU");
}

function formatPhotoMetricValue(item) {
  if (!item || item.value === null || item.value === undefined) return "—";
  const value = Number(item.value).toLocaleString("ru-RU", { maximumFractionDigits: 1 });
  return `${value}${item.unit === "%" ? "%" : ` ${item.unit || ""}`}`.trim();
}

function renderPhotoMetricCard(item) {
  return `
    <article class="photo-meter">
      <span>${escapeHtml(item.label)}</span>
      <strong>${escapeHtml(formatPhotoMetricValue(item))}</strong>
      <small>${escapeHtml(item.verdict || "")}</small>
    </article>
  `;
}

function renderPhotoTextList(items = [], emptyText = "Нет отдельных замечаний.") {
  const clean = items.filter(Boolean);
  if (!clean.length) return `<p class="muted">${escapeHtml(emptyText)}</p>`;
  return `
    <ul class="photo-note-list">
      ${clean.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
    </ul>
  `;
}

function renderPhotoRecommendations(items = []) {
  if (!items.length) return '<p class="muted">Критичных рекомендаций по первому фото не найдено.</p>';
  return `
    <div class="photo-action-list">
      ${items
        .map(
          (item) => `
            <details class="recommendation-card collapsible-card priority-${escapeHtml(item.priority || "medium")}">
              <summary class="collapsible-summary">
                <span class="recommendation-top">
                  <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                  <span class="area-badge">Первое фото</span>
                </span>
                <span class="summary-title">${escapeHtml(item.title)}</span>
                <span class="summary-subline">${escapeHtml(item.action)}</span>
              </summary>
              <div class="collapsible-body">
                <p class="recommendation-action">${escapeHtml(item.action)}</p>
                <p class="recommendation-reason">${escapeHtml(item.reason || "")}</p>
              </div>
            </details>
          `,
        )
        .join("")}
    </div>
  `;
}

function formatCriterionScore(value) {
  if (value === null || value === undefined || value === "") return "—";
  return `${Math.round(Number(value))}/100`;
}

function renderPhotoCriteria(items = []) {
  if (!items.length) return "";
  return `
    <div class="photo-criteria-block">
      <h3 class="group-title">Чек-лист обложки</h3>
      <div class="photo-criteria-grid">
        ${items
          .map(
            (item) => `
              <details class="photo-criterion-card collapsible-card status-${escapeHtml(item.status || "normal")}">
                <summary class="collapsible-summary">
                  <span class="recommendation-top">
                    <span class="priority-badge">${escapeHtml(formatCriterionScore(item.score))}</span>
                    <span class="area-badge">${escapeHtml(item.status || "оценка")}</span>
                  </span>
                  <span class="summary-title">${escapeHtml(item.label)}</span>
                  <span class="summary-subline">${escapeHtml(item.summary || "")}</span>
                </summary>
                <div class="collapsible-body">
                  <p class="recommendation-action">${escapeHtml(item.action || "")}</p>
                  ${
                    (item.evidence || []).length
                      ? `<ul class="photo-note-list">${item.evidence.map((line) => `<li>${escapeHtml(line)}</li>`).join("")}</ul>`
                      : ""
                  }
                </div>
              </details>
            `,
          )
          .join("")}
      </div>
    </div>
  `;
}

function renderFirstPhotoAnalysis(photo, product = {}) {
  if (!photo) return "";
  const score = photo.ok ? `${formatPhotoScore(photo.score)}/100` : "нет оценки";
  const imageUrl = mediaUrl(photo.imageUrl || product.imageUrl || "");
  const sourceUrl = mediaUrl(photo.sourceUrl || product.sourceImageUrl || product.imageUrl || "");
  const imageSrc = imageUrl || sourceUrl;
  const fallbackSrc = sourceUrl && sourceUrl !== imageSrc ? sourceUrl : "";
  const image = imageSrc
    ? `
      <a class="photo-preview-card" href="${escapeHtml(sourceUrl || imageUrl)}" target="_blank" rel="noreferrer" aria-label="Открыть первое фото">
        <img src="${escapeHtml(imageSrc)}" data-fallback-src="${escapeHtml(fallbackSrc)}" alt="" loading="lazy" onerror="handleImageError(this)">
        <span class="product-photo-fallback">Первое фото</span>
      </a>
    `
    : '<div class="photo-preview-card is-broken"><span class="product-photo-fallback">Первое фото</span></div>';

  return renderResultSection({
    title: "Анализ первого фото",
    eyebrow: "Обложка",
    count: score,
    summary: photo.summary || "Визуальный аудит главного изображения карточки.",
    className: "photo-analysis-block",
    body: `
      <div class="photo-analysis-layout">
        ${image}
        <div class="photo-analysis-content">
          <div class="photo-score-row">
            <div>
              <span>Визуальная сила</span>
              <strong>${escapeHtml(score)}</strong>
            </div>
            <p>${escapeHtml(photo.scoreLabel || "Первое фото")}</p>
          </div>
          <div class="photo-meter-grid">
            ${(photo.metricCards || []).map(renderPhotoMetricCard).join("")}
          </div>
        </div>
      </div>

      ${renderPhotoCriteria(photo.criteria || [])}

      <div class="photo-insights-grid">
        <div>
          <h3 class="group-title">Что уже работает</h3>
          ${renderPhotoTextList(photo.strengths, "Сильные стороны фото пока не выделились.")}
        </div>
        <div>
          <h3 class="group-title">Риски</h3>
          ${renderPhotoTextList(photo.risks, "Критичных рисков по фото не найдено.")}
        </div>
        <div>
          <h3 class="group-title">ТЗ дизайнеру</h3>
          ${renderPhotoTextList(photo.designerBrief, "Достаточно протестировать альтернативный первый слайд.")}
        </div>
      </div>

      <div>
        <h3 class="group-title">Что переделать</h3>
        ${renderPhotoRecommendations(photo.recommendations)}
      </div>
    `,
  });
}

function renderPhotoCompareMetric(label, yourValue, competitorValue, unit = "") {
  return `
    <article class="competitor-metric">
      <div class="metric-label">${escapeHtml(label)}</div>
      <div class="competitor-values">
        <div>
          <span>У вас</span>
          <strong>${escapeHtml(formatPhotoScore(yourValue))}${unit ? escapeHtml(unit) : ""}</strong>
        </div>
        <div>
          <span>Конкуренты</span>
          <strong>${escapeHtml(formatPhotoScore(competitorValue))}${unit ? escapeHtml(unit) : ""}</strong>
        </div>
      </div>
    </article>
  `;
}

function renderVisualInsightBlock(title, items = [], emptyText = "Нет отдельных выводов.") {
  const clean = (items || []).filter(Boolean);
  return `
    <details class="visual-insight-card collapsible-card" open>
      <summary class="collapsible-summary">
        <span class="recommendation-top">
          <span class="area-badge">Обложка</span>
          <span class="priority-badge">${formatNumber(clean.length)}</span>
        </span>
        <span class="summary-title">${escapeHtml(title)}</span>
        <span class="summary-subline">${escapeHtml(clean[0] || emptyText)}</span>
      </summary>
      <div class="collapsible-body">
        ${renderPhotoTextList(clean, emptyText)}
      </div>
    </details>
  `;
}

function renderAbHypotheses(items = []) {
  const clean = (items || []).filter(Boolean).slice(0, 3);
  if (!clean.length) return "";
  return `
    <div class="ab-hypothesis-block">
      <h3 class="group-title">Гипотезы для A/B-теста</h3>
      <div class="ab-hypothesis-grid">
        ${clean
          .map(
            (item, index) => `
              <details class="ab-hypothesis-card collapsible-card" open>
                <summary class="collapsible-summary">
                  <span class="recommendation-top">
                    <span class="area-badge">A/B тест</span>
                    <span class="priority-badge">#${index + 1}</span>
                  </span>
                  <span class="summary-title">${escapeHtml(item.title || "Гипотеза")}</span>
                  <span class="summary-subline">${escapeHtml(item.reason || "")}</span>
                </summary>
                <div class="collapsible-body">
                  <div class="ab-variants">
                    <div>
                      <span>Вариант A</span>
                      <p>${escapeHtml(item.variantA || "")}</p>
                    </div>
                    <div>
                      <span>Вариант B</span>
                      <p>${escapeHtml(item.variantB || "")}</p>
                    </div>
                  </div>
                  <p class="recommendation-reason">${escapeHtml(item.reason || "")}</p>
                  <p class="recommendation-action">${escapeHtml(item.successMetric || "")}</p>
                </div>
              </details>
            `,
          )
          .join("")}
      </div>
    </div>
  `;
}

function renderCompetitorPhotoComparison(visual) {
  if (!visual) return "";
  const your = visual.your || {};
  const avg = visual.competitorsAvg || {};
  const best = visual.bestCompetitor || {};
  const items = visual.competitors || [];
  const bestImageUrl = mediaUrl(best.imageUrl || "");
  const bestSourceUrl = mediaUrl(best.sourceUrl || "");
  const bestImageSrc = bestImageUrl || bestSourceUrl;
  const bestFallbackSrc = bestSourceUrl && bestSourceUrl !== bestImageSrc ? bestSourceUrl : "";
  const bestCard = best.article
    ? `
      <article class="photo-best-card">
        ${bestImageSrc ? `<img src="${escapeHtml(bestImageSrc)}" data-fallback-src="${escapeHtml(bestFallbackSrc)}" alt="" loading="lazy" onerror="handleImageError(this)">` : ""}
        <div>
          <span>Лучшее первое фото среди найденных</span>
          <a href="${escapeHtml(best.url || "#")}" target="_blank" rel="noreferrer">${escapeHtml(best.title || `Артикул ${best.article}`)}</a>
          <strong>${formatPhotoScore(best.score)}/100</strong>
        </div>
      </article>
    `
    : "";
  const competitorStrip = items.length
    ? `
      <div class="photo-competitor-strip">
        ${items
          .slice(0, 10)
          .map(
            (item) => {
              const itemImageUrl = mediaUrl(item.imageUrl || "");
              const itemSourceUrl = mediaUrl(item.sourceUrl || "");
              const itemImageSrc = itemImageUrl || itemSourceUrl;
              const itemFallbackSrc = itemSourceUrl && itemSourceUrl !== itemImageSrc ? itemSourceUrl : "";
              return `
              <a href="${escapeHtml(item.url || "#")}" target="_blank" rel="noreferrer" class="photo-competitor-tile">
                ${itemImageSrc ? `<img src="${escapeHtml(itemImageSrc)}" data-fallback-src="${escapeHtml(itemFallbackSrc)}" alt="" loading="lazy" onerror="handleImageError(this)">` : ""}
                <span>${formatPhotoScore(item.score)}/100</span>
              </a>
            `;
            },
          )
          .join("")}
      </div>
    `
    : "";

  return `
    <div class="competitor-block photo-competitor-block">
      <div class="section-head">
        <h2>Сравнение первых фото</h2>
        <span class="section-count">${formatNumber(items.length)}</span>
      </div>
      <p class="competitor-verdict">${escapeHtml(visual.verdict || "")}</p>
      ${visual.clickVerdict ? `<p class="competitor-verdict photo-click-verdict">${escapeHtml(visual.clickVerdict)}</p>` : ""}
      <div class="competitor-benchmark photo-benchmark">
        ${renderPhotoCompareMetric("Визуальная оценка", your.score, avg.score, "/100")}
        ${renderPhotoCompareMetric("Понятность", your.criteria?.find?.((item) => item.key === "one_second_meaning")?.score, avg.oneSecondMeaningScore, "/100")}
        ${renderPhotoCompareMetric("Мотивация", your.criteria?.find?.((item) => item.key === "needs_objections")?.score, avg.needsObjectionsScore, "/100")}
        ${renderPhotoCompareMetric("Товар в кадре", your.metrics?.productSharePercent, avg.productSharePercent, "%")}
        ${renderPhotoCompareMetric("Контраст", your.metrics?.contrastScore, avg.contrastScore, "/100")}
        ${renderPhotoCompareMetric("Заметность", your.criteria?.find?.((item) => item.key === "competitive_standout")?.score, avg.competitiveStandoutScore, "/100")}
      </div>
      <div class="visual-insight-grid">
        ${renderVisualInsightBlock("Паттерны конкурентов", visual.marketPatterns, "Паттерны конкурентов пока не выделены.")}
        ${renderVisualInsightBlock("Сильные стороны нашей обложки", visual.yourCoverStrengths, "Сильные стороны обложки пока не выделены.")}
        ${renderVisualInsightBlock("Слабые стороны нашей обложки", visual.yourCoverWeaknesses, "Слабые стороны обложки пока не выделены.")}
      </div>
      ${renderAbHypotheses(visual.abTestHypotheses)}
      ${bestCard}
      ${competitorStrip}
      ${renderPhotoRecommendations(visual.actions)}
    </div>
  `;
}

function formatPercent(value) {
  if (value === null || value === undefined) return "—";
  return `${Number(value).toLocaleString("ru-RU", { maximumFractionDigits: 1 })}%`;
}

function formatBenchmarkValue(value, kind) {
  if (value === null || value === undefined) return "—";
  if (kind === "rating") return formatRating(value);
  if (kind === "percent") return formatPercent(value);
  if (kind === "count") return formatNumber(Math.round(Number(value)));
  return formatNumber(value);
}

function renderBenchmarkCard(label, yourValue, competitorValue, kind) {
  return `
    <article class="competitor-metric">
      <div class="metric-label">${escapeHtml(label)}</div>
      <div class="competitor-values">
        <div>
          <span>У вас</span>
          <strong>${formatBenchmarkValue(yourValue, kind)}</strong>
        </div>
        <div>
          <span>Конкуренты</span>
          <strong>${formatBenchmarkValue(competitorValue, kind)}</strong>
        </div>
      </div>
    </article>
  `;
}

function renderCompetitorLoading() {
  const target = document.getElementById("competitor-results");
  if (!target) return;
  target.hidden = false;
  target.innerHTML = `
    <div class="competitor-state">
      <div class="loading-mark" aria-hidden="true">…</div>
      <p>Собираю отзывы 10 конкурентов и сравниваю сильные/слабые стороны…</p>
    </div>
  `;
  target.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderCompetitorError(message) {
  const target = document.getElementById("competitor-results");
  if (!target) return;
  target.hidden = false;
  target.innerHTML = `
    <div class="competitor-state is-error">
      <div class="error-mark" aria-hidden="true">!</div>
      <p>${escapeHtml(message)}</p>
    </div>
  `;
  target.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderCompetitorActions(actions = []) {
  if (!actions.length) return '<p class="muted">Отдельных зон для усиления на фоне конкурентов не найдено.</p>';
  return `
    <div class="competitor-action-list">
      ${actions
        .map(
          (item) => `
            <article class="competitor-action priority-${escapeHtml(item.priority || "medium")}">
              <div class="recommendation-top">
                <span class="priority-badge">${escapeHtml(item.priorityLabel || "Средний")}</span>
                <span class="area-badge">${escapeHtml(item.area || "Контент")}</span>
              </div>
              <h3>${escapeHtml(item.title)}</h3>
              <p class="recommendation-action">${escapeHtml(item.action)}</p>
              <p class="recommendation-reason">${escapeHtml(item.why)}</p>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderAspectComparison(rows = []) {
  if (!rows.length) return '<p class="muted">Недостаточно совпадающих тем в отзывах для сравнения аспектов.</p>';
  return `
    <div class="competitor-table-wrap">
      <table class="competitor-table">
        <thead>
          <tr>
            <th>Тема</th>
            <th>Статус</th>
            <th>У вас</th>
            <th>Конкуренты</th>
            <th>Что усилить</th>
          </tr>
        </thead>
        <tbody>
          ${rows
            .map(
              (row) => `
                <tr>
                  <td><strong>${escapeHtml(row.title)}</strong></td>
                  <td><span class="comparison-status priority-${escapeHtml(row.priority || "low")}">${escapeHtml(row.status)}</span></td>
                  <td>+${formatNumber(row.yourPositivePer100)} / -${formatNumber(row.yourNegativePer100)}</td>
                  <td>+${formatNumber(row.competitorPositivePer100)} / -${formatNumber(row.competitorNegativePer100)}</td>
                  <td>${escapeHtml(row.recommendation)}</td>
                </tr>
              `,
            )
            .join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderCompetitorList(items = []) {
  if (!items.length) return '<p class="muted">Конкуренты не найдены.</p>';
  return `
    <div class="competitor-list">
      ${items
        .map((item, index) => {
          const title = [item.brand, item.name].filter(Boolean).join(" · ") || `Артикул ${item.article}`;
          const strengths = (item.topStrengths || []).filter(Boolean).slice(0, 3);
          const weaknesses = (item.topWeaknesses || []).filter(Boolean).slice(0, 3);
          return `
            <article class="competitor-card">
              <div class="competitor-card-top">
                <span class="competitor-rank">#${index + 1}</span>
                <a href="${escapeHtml(item.url)}" target="_blank" rel="noreferrer">${escapeHtml(title)}</a>
              </div>
              <div class="competitor-card-meta">
                <span>${formatRating(item.reviewRating)}★</span>
                <span>${formatNumber(item.feedbacks)} отзывов</span>
                <span>${formatNumber(item.loadedReviews)} загружено</span>
                ${item.matchScore !== null && item.matchScore !== undefined ? `<span>похожесть ${formatNumber(item.matchScore)}</span>` : ""}
              </div>
              ${
                (item.matchReasons || []).length
                  ? `<div class="match-reasons">${item.matchReasons.map((reason) => `<span>${escapeHtml(reason)}</span>`).join("")}</div>`
                  : ""
              }
              ${
                strengths.length
                  ? `<p><strong>Хвалят:</strong> ${strengths.map(escapeHtml).join(", ")}</p>`
                  : ""
              }
              ${
                weaknesses.length
                  ? `<p><strong>Критикуют:</strong> ${weaknesses.map(escapeHtml).join(", ")}</p>`
                  : ""
              }
            </article>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderCompetitorAnalysis(data) {
  const target = document.getElementById("competitor-results");
  if (!target) return;

  const benchmark = data.benchmark || { your: {}, competitorsAvg: {} };
  const your = benchmark.your || {};
  const competitors = benchmark.competitorsAvg || {};
  const summary = data.summary || {};

  target.hidden = false;
  target.innerHTML = renderResultSection({
    title: "Сравнение с конкурентами",
    eyebrow: "Конкуренты",
    count: `${formatNumber(summary.competitorCount || 0)} из ${formatNumber(summary.requestedCompetitors || 10)}`,
    summary: summary.verdict || "Сравнительная характеристика по отзывам и первому фото.",
    open: true,
    body: `
      <p class="competitor-verdict">${escapeHtml(summary.verdict || "")}</p>

      <div class="competitor-benchmark">
        ${renderBenchmarkCard("Средняя оценка", your.averageRating, competitors.averageRating, "rating")}
        ${renderBenchmarkCard("Всего отзывов", your.feedbackCount, competitors.feedbackCount, "count")}
        ${renderBenchmarkCard("Отзывы с текстом", your.textFeedbackCount, competitors.textFeedbackCount, "count")}
        ${renderBenchmarkCard("Позитив 4-5★", your.positiveRatingPercent, competitors.positiveRatingPercent, "percent")}
        ${renderBenchmarkCard("Негатив 1-3★", your.negativeRatingPercent, competitors.negativeRatingPercent, "percent")}
      </div>

      ${renderCompetitorPhotoComparison(data.visualComparison)}

      <div class="competitor-block">
        <div class="section-head">
          <h2>Что усилить</h2>
          <span class="section-count">${formatNumber((data.actionPlan || []).length)}</span>
        </div>
        ${renderCompetitorActions(data.actionPlan)}
      </div>

      <div class="competitor-block">
        <div class="section-head">
          <h2>Сравнение по темам</h2>
          <span class="section-count">на 100 отзывов</span>
        </div>
        ${renderAspectComparison(data.aspectComparison)}
      </div>

      <div class="competitor-block">
        <div class="section-head">
          <h2>Найденные конкуренты</h2>
          <span class="section-count">${formatNumber((data.competitors || []).length)}</span>
        </div>
        ${renderCompetitorList(data.competitors)}
      </div>
    `,
  });
  target.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderResults(data) {
  const { product, summary, strengths, weaknesses, terms, examples, source } = data;
  const recommendations = data.recommendations || { content: [], product: [], priorityActions: [], hpv: [] };
  const firstPhoto = data.firstPhotoAnalysis || product.firstPhotoAnalysis;
  const seoAnalysis = data.seoAnalysis || {};
  const marketplace = product.marketplace || source?.marketplace || currentMarketplace();
  const market = marketplaceMeta(marketplace);
  const productLookup = product.sku || product.offerId || product.article;
  const productName = [product.brand, product.name].filter(Boolean).join(" · ") || `Артикул ${product.article}`;
  const productImageUrl = mediaUrl(product.imageUrl || "");
  const productSourceUrl = mediaUrl(firstPhoto?.sourceUrl || product.sourceImageUrl || "");
  const productImageSrc = productImageUrl || productSourceUrl;
  const productImageFallback = productSourceUrl && productSourceUrl !== productImageSrc ? productSourceUrl : "";
  const productPhoto = productImageSrc
    ? `
      <a class="product-photo-card" href="${escapeHtml(product.url)}" target="_blank" rel="noreferrer" aria-label="Открыть товар на ${escapeHtml(market.full)}">
        <img src="${escapeHtml(productImageSrc)}" data-fallback-src="${escapeHtml(productImageFallback)}" alt="" loading="lazy" onerror="handleImageError(this)">
        <span class="product-photo-fallback">Фото товара</span>
      </a>
    `
    : "";
  const strengthItems = strengths || [];
  const weaknessItems = weaknesses || [];
  const positiveTerms = terms?.positive || [];
  const negativeTerms = terms?.negative || [];
  const positiveExamples = examples?.positive || [];
  const negativeExamples = examples?.negative || [];
  const recommendationCount = (recommendations.content?.length || 0) + (recommendations.product?.length || 0) + (recommendations.hpv?.length || 0);
  const signalCount = strengthItems.length + weaknessItems.length;
  const topicCount = positiveTerms.length + negativeTerms.length;
  const exampleCount = positiveExamples.length + negativeExamples.length;

  statusBox.hidden = true;
  resultsBox.hidden = false;
  resultsBox.innerHTML = `
    <section class="product-strip ${productImageSrc ? "has-photo" : ""}">
      ${productPhoto}
      <div class="product-main">
        <h2 class="product-title">${escapeHtml(productName)}</h2>
        <div class="product-meta">
          <span>Артикул ${formatNumber(product.article)}</span>
          ${product.sku ? `<span>SKU ${formatNumber(product.sku)}</span>` : ""}
          ${product.offerId ? `<span>offer ${escapeHtml(product.offerId)}</span>` : ""}
          ${product.root ? `<span>root ${formatNumber(product.root)}</span>` : ""}
          ${product.supplier ? `<span>${escapeHtml(product.supplier)}</span>` : ""}
        </div>
        <p class="verdict">${escapeHtml(summary.verdict)}</p>
        ${source?.warning ? `<p class="source-warning">${escapeHtml(source.warning)}</p>` : ""}
        <div class="source-line">
          <a href="${escapeHtml(product.url)}" target="_blank" rel="noreferrer">Открыть товар</a>
          <button
            class="export-button"
            type="button"
            data-export-article="${escapeHtml(productLookup)}"
            data-export-limit="${escapeHtml(source?.limit || DEFAULT_REVIEW_LIMIT)}"
            data-export-marketplace="${escapeHtml(marketplace)}"
          >
            Выгрузить в Excel
          </button>
          <button
            class="brief-button"
            type="button"
            data-brief-article="${escapeHtml(productLookup)}"
            data-brief-limit="${escapeHtml(source?.limit || DEFAULT_REVIEW_LIMIT)}"
            data-brief-marketplace="${escapeHtml(marketplace)}"
          >
            Сделать ТЗ
          </button>
          ${
            marketplace === "ozon"
              ? '<span>Конкуренты Ozon: нужен отдельный источник данных</span>'
              : `<button
                  class="competitor-button"
                  type="button"
                  data-competitor-article="${escapeHtml(productLookup)}"
                  data-competitor-limit="${escapeHtml(source?.limit || DEFAULT_REVIEW_LIMIT)}"
                  data-competitor-marketplace="${escapeHtml(marketplace)}"
                >
                  Анализировать конкурентов
                </button>`
          }
          <span>Загружено ${formatNumber(summary.loadedReviews)} отзывов</span>
        </div>
      </div>
      <div class="score-pill" aria-label="Средняя оценка">
        <div class="score-value">${formatRating(summary.averageRating)}</div>
        <div class="score-caption">средняя оценка</div>
      </div>
    </section>

    <section id="competitor-results" class="competitor-results" hidden aria-live="polite"></section>

    ${renderResultSection({
      title: "Ключевые метрики",
      eyebrow: "Обзор",
      count: "4",
      summary: `Отзывы, рейтинг и доля проблемных оценок по ${market.label}.`,
      open: true,
      body: `
        <div class="metric-grid" aria-label="Ключевые метрики">
          ${metric("Всего отзывов", formatNumber(summary.feedbackCount), `по данным ${market.label}`)}
          ${metric("С текстом", formatNumber(summary.textFeedbackCount), "для смыслового анализа")}
          ${metric("Оценки 4-5★", summary.positiveRatingPercent === null ? "—" : `${summary.positiveRatingPercent}%`, "позитивная доля")}
          ${metric("Оценки 1-3★", summary.negativeRatingPercent === null ? "—" : `${summary.negativeRatingPercent}%`, "проблемная доля")}
        </div>
      `,
    })}

    ${renderFirstPhotoAnalysis(firstPhoto, product)}

    ${renderSeoAnalysis(seoAnalysis)}

    ${renderResultSection({
      title: "Рекомендации",
      eyebrow: "Что улучшить",
      count: formatNumber(recommendationCount),
      summary: "Контент, товар, поставка и формулировки ХПВ.",
      body: `
        <div class="recommendations-block">
          ${renderPriorityActions(recommendations.priorityActions)}
          ${renderHpvRecommendations(recommendations.hpv)}
          <div class="recommendation-grid">
            <div>
              <h3 class="group-title">Контент карточки</h3>
              ${renderRecommendations(recommendations.content)}
            </div>
            <div>
              <h3 class="group-title">Товар и поставка</h3>
              ${renderRecommendations(recommendations.product)}
            </div>
          </div>
        </div>
      `,
    })}

    ${renderResultSection({
      title: "Сильные и слабые стороны",
      eyebrow: "Отзывы",
      count: formatNumber(signalCount),
      summary: "Что покупатели хвалят и где чаще появляются риски.",
      body: `
        <div class="analysis-grid">
          <div>
            <div class="section-head">
              <h2>Сильные стороны</h2>
              <span class="section-count">${strengthItems.length}</span>
            </div>
            ${renderAspects(strengthItems, "good")}
          </div>
          <div>
            <div class="section-head">
              <h2>Слабые стороны</h2>
              <span class="section-count">${weaknessItems.length}</span>
            </div>
            ${renderAspects(weaknessItems, "bad")}
          </div>
        </div>
      `,
    })}

    ${renderResultSection({
      title: "Оценки и размер",
      eyebrow: "Статистика",
      count: "2",
      summary: "Распределение оценок и сигналы по посадке/размеру.",
      body: `
        <div class="chart-grid">
          <article class="chart-card">
            <h2>Оценки</h2>
            ${renderDistribution(summary.distribution)}
          </article>
          <article class="chart-card">
            <h2>Размер</h2>
            ${renderSizeFit(summary.matchingSizePercentages)}
          </article>
        </div>
      `,
    })}

    ${renderResultSection({
      title: "Частые темы в отзывах",
      eyebrow: "Слова покупателей",
      count: formatNumber(topicCount),
      summary: "Повторяющиеся формулировки, которые помогают понять ожидания.",
      body: `
        <div class="chart-grid">
          <article class="chart-card">
            <h2>Часто хвалят</h2>
            ${renderTopics(positiveTerms, "good")}
          </article>
          <article class="chart-card">
            <h2>Часто критикуют</h2>
            ${renderTopics(negativeTerms, "bad")}
          </article>
        </div>
      `,
    })}

    ${renderResultSection({
      title: "Примеры отзывов",
      eyebrow: "Доказательства",
      count: formatNumber(exampleCount),
      summary: "Живые фразы покупателей, на которых основаны выводы.",
      body: `
        <div class="example-grid">
          <article class="example-card">
            <h2>Примеры плюсов</h2>
            ${renderExamples(positiveExamples)}
          </article>
          <article class="example-card">
            <h2>Примеры минусов</h2>
            ${renderExamples(negativeExamples)}
          </article>
        </div>
      `,
    })}
  `;
}

async function analyze(article, limit, marketplace) {
  const params = new URLSearchParams({ article, limit, marketplace });
  const response = await fetch(apiUrl(`/api/analyze?${params.toString()}`), { credentials: "include" });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok) {
    const error = new Error(payload?.error || "Не удалось выполнить анализ.");
    error.payload = payload;
    throw error;
  }
  return payload.data;
}

async function analyzeCompetitors(article, limit, marketplace) {
  const params = new URLSearchParams({ article, limit, marketplace, competitors: "10" });
  const response = await fetch(apiUrl(`/api/competitors?${params.toString()}`), { credentials: "include" });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok) {
    const error = new Error(payload?.error || "Не удалось выполнить анализ конкурентов.");
    error.payload = payload;
    throw error;
  }
  return payload.data;
}

function handleAuthError(error) {
  const auth = error?.payload?.auth;
  if (!auth) return false;
  applyAuthState(auth);
  return true;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const article = articleInput.value.trim();
  if (!article) {
    showStatus("error", "Введите артикул или ссылку на товар.");
    articleInput.focus();
    return;
  }

  setLoading(true);
  const marketplace = currentMarketplace();
  showStatus("loading", `Загружаю карточку и отзывы ${marketplaceMeta(marketplace).full}…`);
  try {
    const data = await analyze(article, DEFAULT_REVIEW_LIMIT, marketplace);
    renderResults(data);
  } catch (error) {
    if (handleAuthError(error)) return;
    showStatus("error", error.message);
  } finally {
    setLoading(false);
  }
});

marketplaceSelect?.addEventListener("change", () => {
  const marketplace = currentMarketplace();
  articleInput.placeholder =
    marketplace === "ozon"
      ? "SKU, offer_id или ссылка Ozon"
      : "Например, 98952842";
});

resultsBox.addEventListener("click", async (event) => {
  const competitorButton = event.target.closest("[data-competitor-article]");
  if (competitorButton) {
    const originalText = competitorButton.textContent;
    competitorButton.disabled = true;
    competitorButton.textContent = "Собираю конкурентов…";
    renderCompetitorLoading();
    try {
      const data = await analyzeCompetitors(
        competitorButton.dataset.competitorArticle,
        competitorButton.dataset.competitorLimit || DEFAULT_REVIEW_LIMIT,
        competitorButton.dataset.competitorMarketplace || currentMarketplace(),
      );
      renderCompetitorAnalysis(data);
    } catch (error) {
      if (handleAuthError(error)) return;
      renderCompetitorError(error.message);
    } finally {
      competitorButton.disabled = false;
      competitorButton.textContent = originalText;
    }
    return;
  }

  const briefButton = event.target.closest("[data-brief-article]");
  if (briefButton) {
    const params = new URLSearchParams({
      article: briefButton.dataset.briefArticle,
      limit: briefButton.dataset.briefLimit || DEFAULT_REVIEW_LIMIT,
      marketplace: briefButton.dataset.briefMarketplace || currentMarketplace(),
    });
    window.location.href = apiUrl(`/api/brief?${params.toString()}`);
    return;
  }

  const button = event.target.closest("[data-export-article]");
  if (!button) return;
  const params = new URLSearchParams({
    article: button.dataset.exportArticle,
    limit: button.dataset.exportLimit || DEFAULT_REVIEW_LIMIT,
    marketplace: button.dataset.exportMarketplace || currentMarketplace(),
  });
  window.location.href = apiUrl(`/api/export?${params.toString()}`);
});

authRefreshButton?.addEventListener("click", async () => {
  const originalText = authRefreshButton.textContent;
  authRefreshButton.disabled = true;
  authRefreshButton.textContent = "Проверяю…";
  if (authMessage) authMessage.textContent = "Проверяю подписку в Telegram…";
  if (hasTelegramMiniAppInitData()) telegramMiniAppTried = false;
  try {
    await refreshAuthStatus();
  } finally {
    authRefreshButton.disabled = false;
    authRefreshButton.textContent = originalText;
  }
});

authLogoutButton?.addEventListener("click", async () => {
  const originalText = authLogoutButton.textContent;
  authLogoutButton.disabled = true;
  authLogoutButton.textContent = "Выхожу…";
  try {
    await fetch(apiUrl("/api/auth/logout"), {
      method: "POST",
      credentials: "include",
    });
  } finally {
    authLogoutButton.disabled = false;
    authLogoutButton.textContent = originalText;
    telegramMiniAppTried = false;
    telegramWidgetLoaded = false;
    if (telegramLoginSlot) telegramLoginSlot.innerHTML = "";
    await refreshAuthStatus();
  }
});

fullscreenButton?.addEventListener("click", toggleFullscreen);
document.addEventListener("fullscreenchange", () => updateFullscreenButton());
document.addEventListener("webkitfullscreenchange", () => updateFullscreenButton());

prepareTelegramMiniApp();
refreshAuthStatus();
window.addEventListener("load", () => {
  prepareTelegramMiniApp();
  refreshAuthStatus();
});
window.setTimeout(refreshAuthStatus, 1800);
window.setTimeout(refreshAuthStatus, 4500);
