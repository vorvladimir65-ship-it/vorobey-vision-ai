import importlib.util
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


APP_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = APP_ROOT / "server.py"
SPEC = importlib.util.spec_from_file_location("wb_review_analyzer_server_ozon_credentials", SERVER_PATH)
server = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = server
SPEC.loader.exec_module(server)


class FakeResponse:
    headers = {}

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def read(self):
        return json.dumps({"items": []}).encode("utf-8")


class OzonCredentialsTests(unittest.TestCase):
    def test_explicit_credentials_override_environment(self):
        with patch.dict(
            server.os.environ,
            {"OZON_CLIENT_ID": "environment-client", "OZON_API_KEY": "environment-key"},
        ):
            credentials = server.ozon_api_credentials((" user-client ", " user-key "))

        self.assertEqual(credentials, ("user-client", "user-key"))

    def test_seller_request_sends_explicit_credentials(self):
        captured = {}

        def fake_urlopen(request, timeout):
            captured["request"] = request
            captured["timeout"] = timeout
            return FakeResponse()

        with patch.object(server, "urlopen", side_effect=fake_urlopen):
            result = server.ozon_seller_request(
                "/v3/product/info/list",
                {"sku": [123]},
                credentials=("user-client", "user-key"),
            )

        request = captured["request"]
        self.assertEqual(request.get_header("Client-id"), "user-client")
        self.assertEqual(request.get_header("Api-key"), "user-key")
        self.assertEqual(result, {"items": []})


if __name__ == "__main__":
    unittest.main()
