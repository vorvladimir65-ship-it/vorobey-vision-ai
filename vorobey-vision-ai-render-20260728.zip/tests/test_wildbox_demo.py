import json
import os
import unittest
from unittest.mock import patch
import wildbox_demo as demo


class DemoTests(unittest.TestCase):
    def setUp(self):
        demo.CACHE.clear()
        demo.NEXT_CALL = 0
        demo.SESSION = None

    def test_query_routes_and_url_validation(self):
        self.assertEqual(demo.parse_query(" 199252123 "), ("article", "199252123"))
        self.assertEqual(demo.parse_query("https://www.wildberries.ru/catalog/199252123/detail.aspx?x=1"), ("article", "199252123"))
        self.assertEqual(demo.parse_query("Масла  эфирные"), ("search", "масла эфирные"))
        for query in ("", "x" * 201, "https://evil.test/catalog/123/detail.aspx", "https://wildberries.ru.evil.test/catalog/123/detail.aspx", "0", "9" * 20):
            with self.subTest(query=query), self.assertRaises(demo.DemoError):
                demo.parse_query(query)

    def test_utf8_sse_preserves_unusual_unicode(self):
        payload = {"result": {"name": "Масла\u0085тест"}}
        raw = ("event: message\r\ndata: " + json.dumps(payload, ensure_ascii=False) + "\r\n\r\n").encode()
        self.assertEqual(demo.parse_rpc(raw), payload)
        self.assertEqual(demo.parse_rpc(json.dumps(payload).encode()), payload)

    def test_missing_metrics_are_not_zero_and_actual_dates_are_preserved(self):
        data = {"results": [{"id": 123, "name": "Набор", "orders": 0,
            "dynamic": [{"date": "2026-11-14", "price": 100}, {"date": "2026-11-12", "price": 120}]}], "notes": ["Данные ограничены тарифом"]}
        result = demo.normalize(data, "article", "123", "2026-10-18", "2026-11-16")
        self.assertIsNone(result["rows"][0]["proceeds"])
        self.assertEqual(result["rows"][0]["orders"], 0)
        self.assertEqual(result["actualTo"], "2026-11-14")
        self.assertEqual(result["actualFrom"], "2026-11-12")
        self.assertIn("Данные ограничены тарифом", result["notes"])

    def test_no_results_and_truncation_are_not_hidden(self):
        result = demo.normalize({"rows": [], "guidance": "Уточните запрос", "sample": {"truncated": True}}, "search", "масло", "2026-10-18", "2026-11-16")
        self.assertEqual(result["rows"], [])
        self.assertTrue(any("часть доступной выборки" in note for note in result["notes"]))
        self.assertTrue(result["sample"]["truncated"])

    def test_search_filters_accessories_and_hides_technical_guidance(self):
        result = demo.normalize({"rows": [
            {"id": 1, "name": "Аромалампа для эфирных масел", "orders": 100},
            {"id": 2, "name": "Подарочный набор эфирных масел", "orders": 20}],
            "notes": ["подставлены значения по умолчанию: extra_fields=id"],
            "guidance": "use extra_fields"}, "search", "набор эфирных масел", "2026-10-18", "2026-11-16")
        self.assertEqual([row["id"] for row in result["rows"]], ["2"])
        self.assertNotIn("extra_fields", " ".join(result["notes"]))

    @patch.dict(os.environ, {"WILDBOX_TOKEN": "test-not-a-real-token"})
    @patch.object(demo, "tool_call", return_value={"results": [{"id": 123, "orders": 2}]})
    def test_cache_avoids_another_upstream_call(self, call):
        first = demo.search("123")
        first["rows"][0]["orders"] = 999
        second = demo.search("123")
        self.assertTrue(second["cached"])
        self.assertEqual(second["rows"][0]["orders"], 2)
        self.assertEqual(call.call_count, 1)

    @patch.dict(os.environ, {"WILDBOX_TOKEN": "test-not-a-real-token"})
    @patch.object(demo, "tool_call")
    def test_busy_lane_does_not_call_upstream(self, call):
        demo.LOCK.acquire()
        try:
            with self.assertRaises(demo.DemoError) as raised:
                demo.search("123")
            self.assertEqual(raised.exception.status, 429)
            call.assert_not_called()
        finally:
            demo.LOCK.release()

    @patch.object(demo, "rpc", return_value={"isError": True, "content": [{"text": "Rate limit exceeded. Retry after 25 s."}]})
    def test_upstream_rate_limit_is_respected(self, rpc):
        demo.SESSION = "test-session"
        with self.assertRaises(demo.DemoError) as raised:
            demo.tool_call("test", {}, "test-token")
        self.assertEqual(raised.exception.retry_after, 25)
        self.assertGreater(demo.NEXT_CALL, demo.time.monotonic() + 24)

    @patch.object(demo, "rpc", return_value={"isError": True, "content": [{"text": "Not included in subscription secret-token"}]})
    def test_access_error_does_not_leak_upstream_text(self, rpc):
        demo.SESSION = "test-session"
        with self.assertRaises(demo.DemoError) as raised:
            demo.tool_call("test", {}, "secret-token")
        self.assertEqual(raised.exception.status, 403)
        self.assertNotIn("secret-token", str(raised.exception))

    @patch.dict(os.environ, {"WILDBOX_TOKEN": ""})
    def test_missing_token_has_clear_error(self):
        with self.assertRaises(demo.DemoError) as raised:
            demo.search("123")
        self.assertEqual(raised.exception.status, 503)

    def test_v2_daily_shape_and_period_aggregation(self):
        data = {"rows": [{"wb_article": 123, "product_name": "Масла", "daily": [
            {"date": "2026-11-15", "orders": 2, "proceeds": 200, "price": 100, "quantity": 12},
            {"date": "2026-11-16", "orders": 1, "proceeds": 120, "price": 120, "quantity": 11}]}]}
        result = demo.normalize(data, "article", "123", "2026-10-18", "2026-11-16")
        self.assertEqual(result["rows"][0], {"id": "123", "name": "Масла", "url": "https://www.wildberries.ru/catalog/123/detail.aspx", "orders": 3, "proceeds": 320, "price": 110, "quantity": 11})
        self.assertEqual(len(result["series"]), 2)
        data["next_cursor"] = "next-page"
        result = demo.normalize(data, "article", "123", "2026-10-18", "2026-11-16")
        self.assertIsNone(result["rows"][0]["orders"])
        self.assertTrue(any("часть периода" in note for note in result["notes"]))

    @patch.dict(os.environ, {"WILDBOX_TOKEN": "test-token"})
    @patch.object(demo.time, "sleep")
    @patch.object(demo, "tool_call", side_effect=[{"rows": []}, {"rows": [{"wb_article": 123, "product_name": "Масло", "orders": 4}]}])
    def test_empty_saved_serp_falls_back_once(self, call, sleep):
        result = demo.search("масло")
        self.assertEqual(result["rows"][0]["orders"], 4)
        self.assertEqual(call.call_count, 2)
        self.assertEqual(call.call_args.args[0], "get_market_sales")
        self.assertFalse(call.call_args.args[1]["saved_serp"])

    @patch.dict(os.environ, {"WILDBOX_TOKEN": "test-token"})
    @patch.object(demo, "tool_call", return_value={"rows": [{"wb_article": 123, "product_name": "Масло"}]})
    def test_article_uses_v2_tool_contract(self, call):
        demo.search("123")
        name, args, _ = call.call_args.args
        self.assertEqual(name, "get_market_sales")
        self.assertEqual(args["wb_articles"], [123])
        self.assertTrue(args["daily"])
        self.assertEqual(demo.ENDPOINT, "https://wildbox.ru/mcp/v2")

    @patch.object(demo.time, "sleep")
    @patch.object(demo, "rpc", side_effect=[demo.SessionExpired("expired"), {}, {}, {"structuredContent": {"rows": []}}])
    def test_expired_session_reconnects_once(self, rpc, sleep):
        demo.SESSION = None
        # Simulate first tools/call failing and invalidating its session.
        def respond(method, params, token, **kwargs):
            if method == "tools/call" and not getattr(respond, "failed", False):
                respond.failed = True
                demo.SESSION = None
                raise demo.SessionExpired("expired")
            if method == "initialize":
                demo.SESSION = "new-session"
            return {"structuredContent": {"rows": []}} if method == "tools/call" else {}
        rpc.side_effect = respond
        demo.SESSION = "old-session"
        self.assertEqual(demo.tool_call("get_market_sales", {}, "test-token"), {"rows": []})
        self.assertEqual([c.args[0] for c in rpc.call_args_list], ["tools/call", "initialize", "notifications/initialized", "tools/call"])

    @patch.object(demo, "rpc", return_value={"isError": True, "content": [{"text": "Адреса /mcp и /mcp/v1 отключаются, подключите https://wildbox.ru/mcp/v2."}]})
    def test_migration_error_is_not_reported_as_no_data(self, rpc):
        demo.SESSION = "test-session"
        with self.assertRaises(demo.DemoError) as raised:
            demo.tool_call("test", {}, "test-token")
        self.assertIn("обновление интеграции", str(raised.exception))


if __name__ == "__main__":
    unittest.main()
