import importlib.util
import sys
import unittest
from pathlib import Path


APP_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = APP_ROOT / "server.py"
SPEC = importlib.util.spec_from_file_location("wb_review_analyzer_server", SERVER_PATH)
server = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = server
SPEC.loader.exec_module(server)


def build_audit(title, description="", attributes=None, queries=None, category="Брюки"):
    attributes = attributes or []
    queries = queries or []
    product = {
        "name": title,
        "imt_name": title,
        "description": description,
        "characteristics": attributes,
    }
    card_meta = {
        "title": title,
        "name": title,
        "description": description,
        "category": category,
        "attributes": attributes,
    }
    semantic_core = [
        {"term": query, "query": query, "frequency": 100 - index}
        for index, query in enumerate(queries)
    ]
    return server.build_card_seo_p0(product, card_meta, semantic_core, title, category, description)


class SeoP0AuditTests(unittest.TestCase):
    def test_good_title_has_main_cluster_without_spam(self):
        audit = build_audit(
            "Брюки палаццо с высокой посадкой",
            "Широкие брюки палаццо с высокой посадкой подходят для деловых и повседневных образов.",
            [
                {"name": "Посадка", "value": "высокая"},
                {"name": "Крой", "value": "широкий"},
                {"name": "Цвет", "value": "черный"},
                {"name": "Материал", "value": "полиэстер"},
            ],
            ["брюки палаццо", "брюки высокая посадка", "широкие брюки"],
        )

        title = audit["titleEvaluation"]
        self.assertGreaterEqual(title["score"], 85)
        self.assertEqual(title["keywordSpamLevel"], "none")
        self.assertGreaterEqual(title["mainClusterCoverage"], 90)
        self.assertEqual(title["recommendedAction"], "keep")

    def test_spam_title_requires_rewrite(self):
        audit = build_audit(
            "Брюки женские штаны брюки палаццо широкие классические офисные",
            "Описание товара.",
            [{"name": "Крой", "value": "широкий"}],
            ["брюки палаццо", "широкие брюки", "брюки офисные"],
        )

        title = audit["titleEvaluation"]
        self.assertIn(title["keywordSpamLevel"], ("medium", "high"))
        self.assertLess(title["components"]["readabilityScore"], 65)
        self.assertEqual(title["recommendedAction"], "rewrite")

    def test_attribute_semantics_are_not_compensated_by_description(self):
        audit = build_audit(
            "Брюки палаццо",
            "Подходят для офиса и прогулок.",
            [
                {"name": "Посадка", "value": ""},
                {"name": "Крой", "value": "широкий"},
            ],
            ["брюки высокая посадка", "широкие брюки"],
        )

        placement_items = audit["semanticPlacement"]["items"]
        fit_item = next(item for item in placement_items if "посад" in item["query"])
        cut_item = next(item for item in placement_items if "широк" in item["query"])
        self.assertEqual(fit_item["placement"], "attribute")
        self.assertEqual(fit_item["status"], "Не заполнено")
        self.assertEqual(cut_item["placement"], "attribute")
        self.assertEqual(cut_item["status"], "Используется")

        gaps = audit["attributesEvaluation"]["missingSeoRelevant"]
        self.assertTrue(any(item["attributeGroup"] == "Посадка" for item in gaps))
        self.assertTrue(all("сначала подтвердить" in item["recommendation"] for item in gaps))

    def test_consistency_conflict_is_high_priority(self):
        audit = build_audit(
            "Брюки с высокой посадкой",
            "Брюки с высокой посадкой.",
            [{"name": "Посадка", "value": "низкая"}],
            ["брюки высокая посадка"],
        )

        self.assertGreaterEqual(len(audit["consistency"]["conflicts"]), 1)
        self.assertEqual(audit["issues"][0]["area"], "consistency")
        self.assertIn(audit["issues"][0]["severity"], ("critical", "high"))

    def test_spam_description_requires_rewrite(self):
        audit = build_audit(
            "Брюки палаццо",
            "Брюки женские широкие, брюки женские классические, брюки женские офисные, женские брюки палаццо.",
            [{"name": "Крой", "value": "широкий"}],
            [
                "брюки женские широкие",
                "брюки женские классические",
                "брюки женские офисные",
                "женские брюки палаццо",
            ],
        )

        description = audit["descriptionEvaluation"]
        self.assertIn(description["keywordSpamLevel"], ("medium", "high"))
        self.assertLess(description["spamScore"], 70)
        self.assertTrue(any(issue["id"] == "description-spam" for issue in description["issues"]))

    def test_good_description_stays_natural(self):
        audit = build_audit(
            "Брюки палаццо с высокой посадкой",
            "Широкие брюки палаццо с высокой посадкой подходят для деловых и повседневных образов. Свободный крой комфортен в течение дня и легко сочетается с рубашками, жакетами и базовыми футболками.",
            [
                {"name": "Посадка", "value": "высокая"},
                {"name": "Крой", "value": "свободный"},
            ],
            ["брюки палаццо", "брюки высокая посадка", "брюки в офис", "деловые брюки"],
        )

        description = audit["descriptionEvaluation"]
        self.assertGreaterEqual(description["readabilityScore"], 80)
        self.assertEqual(description["keywordSpamLevel"], "none")

    def test_incomplete_data_returns_limited_audit(self):
        audit = server.build_card_seo_p0({}, {}, [], "", "", "")

        self.assertTrue(audit["ok"])
        self.assertEqual(audit["descriptionEvaluation"]["score"], 0)
        self.assertTrue(any(issue["id"] == "attributes-missing-all" for issue in audit["issues"]))
        self.assertTrue(any(issue["id"] == "semantics-missing" for issue in audit["issues"]))


if __name__ == "__main__":
    unittest.main()
