import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path


APP_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = APP_ROOT / "server.py"
SPEC = importlib.util.spec_from_file_location("wb_review_analyzer_server_admin_stats", SERVER_PATH)
server = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = server
SPEC.loader.exec_module(server)


class AdminStatsTests(unittest.TestCase):
    ENV_KEYS = [
        "VVAI_STATS_PATH",
        "STATS_PATH",
        "TELEGRAM_BOT_TOKEN",
        "ADMIN_TELEGRAM_IDS",
        "ADMIN_TELEGRAM_USERNAMES",
    ]

    def setUp(self):
        self.saved_env = {key: os.environ.get(key) for key in self.ENV_KEYS}
        self.tmpdir = tempfile.TemporaryDirectory()
        os.environ["VVAI_STATS_PATH"] = str(Path(self.tmpdir.name) / "stats.json")
        for key in self.ENV_KEYS:
            if key != "VVAI_STATS_PATH":
                os.environ.pop(key, None)

    def tearDown(self):
        for key, value in self.saved_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        self.tmpdir.cleanup()

    def test_records_user_actions_and_summary(self):
        session = {
            "id": 100,
            "first_name": "Иван",
            "last_name": "Воробьев",
            "username": "vorobevFM",
            "source": "test",
        }
        auth = {
            "allowed": True,
            "missing": [],
            "checks": [{"channel": "@vorobevFM", "status": "administrator", "ok": True}],
        }

        server.record_stats_event("login", session, auth, {"source": "test"})
        server.record_stats_event("analyze", session, details={"article": 123})
        server.record_stats_event("export", session, details={"article": 123})

        summary = server.stats_summary()
        user = summary["recentUsers"][0]

        self.assertEqual(summary["totalUsers"], 1)
        self.assertEqual(summary["logins"], 1)
        self.assertEqual(summary["analyses"], 1)
        self.assertEqual(summary["exports"], 1)
        self.assertEqual(user["username"], "vorobevFM")
        self.assertEqual(user["analysisCount"], 1)
        self.assertEqual(user["exportCount"], 1)
        self.assertTrue(user["allowed"])

    def test_admin_access_can_be_granted_by_env_user_id(self):
        os.environ["ADMIN_TELEGRAM_IDS"] = "100"

        allowed = server.admin_access_payload({"id": 100, "username": "any"})
        denied = server.admin_access_payload({"id": 200, "username": "other"})
        anonymous = server.admin_access_payload(None)

        self.assertTrue(allowed["allowed"])
        self.assertFalse(denied["allowed"])
        self.assertFalse(anonymous["allowed"])


if __name__ == "__main__":
    unittest.main()
