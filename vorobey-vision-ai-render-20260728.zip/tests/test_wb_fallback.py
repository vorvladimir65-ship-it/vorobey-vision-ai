import importlib.util
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


APP_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = APP_ROOT / "server.py"
SPEC = importlib.util.spec_from_file_location("wb_review_analyzer_server_fallback", SERVER_PATH)
server = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = server
SPEC.loader.exec_module(server)


class WbProductFallbackTests(unittest.TestCase):
    def test_builds_product_from_card_metadata_when_card_api_is_blocked(self):
        metadata = {
            "nm_id": 98952842,
            "imt_id": 3269260929,
            "imt_name": "Носки",
            "subj_name": "Носки",
            "nm_colors_names": "белый, черный",
            "selling": {"brand_name": "Тестовый бренд", "supplier_id": 123},
            "media": {"photo_count": 4},
            "data": {"subject_id": 212, "subject_root_id": 4, "tech_size": "36-41"},
        }

        with patch.object(server, "remote_json", side_effect=server.AppError("HTTP 403", 502)):
            with patch.object(server, "fetch_card_metadata", return_value=(metadata, "https://basket/card.json")):
                product, source_url = server.fetch_product(98952842)

        self.assertEqual(product["id"], 98952842)
        self.assertEqual(product["root"], 3269260929)
        self.assertEqual(product["name"], "Носки")
        self.assertEqual(product["brand"], "Тестовый бренд")
        self.assertEqual(product["pics"], 4)
        self.assertEqual(product["subjectId"], 212)
        self.assertEqual(product["colors"], [{"name": "белый"}, {"name": "черный"}])
        self.assertEqual(product["sizes"], [{"name": "36-41"}])
        self.assertEqual(source_url, "https://basket/card.json")

    def test_preserves_primary_error_when_all_sources_fail(self):
        error = server.AppError("Wildberries вернул HTTP 403.", 502)
        with patch.object(server, "remote_json", side_effect=error):
            with patch.object(server, "fetch_card_metadata", return_value=({}, None)):
                with self.assertRaises(server.AppError) as caught:
                    server.fetch_product(98952842)

        self.assertIs(caught.exception, error)


if __name__ == "__main__":
    unittest.main()
