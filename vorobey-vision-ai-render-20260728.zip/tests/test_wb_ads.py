import unittest
from io import BytesIO

from openpyxl import Workbook

from wb_ads import AdsError, process


HEADERS = ["ID", "Кампания", "Показы", "Клики", "Затраты", "Заказанные товары, шт", "Добавления в корзину", "Валюта"]
SAMPLE = [
    (27618, 1282, "13130.52", 23, 170), (68523, 1543, "11298.37", 35, 205),
    (18563, 724, "9160.94", 4, 30), (11463, 729, "8290.99", 13, 82),
    (20099, 598, "7186.48", 23, 94), (41408, 1005, "6911.78", 16, 128),
    (8405, 419, "5373.91", 2, 29), (8681, 251, "5177.36", 2, 25),
    (25426, 718, "4575.53", 9, 55), (16588, 277, "3195.24", 2, 20),
    (10147, 147, "3034.33", 0, 11), (5400, 290, "1635.98", 1, 22),
    (1297, 38, "1009.23", 3, 6), (3123, 24, "990.91", 0, 1),
    (292, 22, "234.13", 0, 1), (1, 1, "0.68", 0, 0),
    (1, 0, "0", 0, 0), (1, 0, "0", 0, 0), (1, 0, "0", 0, 0), (2, 0, "0", 0, 0),
]


def csv_report(rows, headers=HEADERS):
    return "\n".join(";".join(map(str, row)) for row in [headers, *rows]).encode("utf-8")


def analyze(data, **options):
    return process(data, analyze=True, start="2026-11-19", end="2026-11-25", partial=True, **options)


class WbAdsTests(unittest.TestCase):
    def test_reference_totals_and_rounding(self):
        rows = [[chr(65 + index), f"Тест {index}", *values, "RUB"] for index, values in enumerate(SAMPLE)]
        report = analyze(csv_report(rows))
        values = report["groups"][0]["values"]
        for key, expected in {
            "spend": "81206.38", "impressions": "267039", "clicks": "8068", "units": "133", "carts": "879",
            "ctr": "3.02", "cpc": "10.07", "costPerUnit": "610.57", "costPerCart": "92.38", "unitsPerClick": "1.65",
            "spendToAmount": None,
        }.items():
            self.assertEqual(values[key], expected, key)
        self.assertEqual(report["campaigns"][6]["values"]["costPerUnit"], "2686.96")
        self.assertEqual(report["observations"][0], {"kind": "noUnits", "key": 11})
        self.assertTrue(report["period"]["partial"])
        rows[10][4] = "1.00"
        modified = analyze(csv_report(rows))
        self.assertNotEqual(modified["groups"][0]["values"]["spend"], values["spend"])
        self.assertNotEqual(modified["observations"][0], report["observations"][0])

    def test_duplicates_totals_currency_missing_and_zero(self):
        first = ["0001234567890123456", "Итоги рабочего дня", 12, 0, "1\u00a0234,50", 0, 0, "₽"]
        report = analyze(csv_report([
            first, first, ["", "Итого", 12, 0, 1234.50, 0, 0, "RUB"],
            ["2", "Missing clicks", 12, "", 3, 1, 3, "RUB"],
            ["3", "Separate currency", 100, 10, 42, 0, 0, "USD"],
        ]))
        self.assertEqual(report["preview"]["duplicates"], 1)
        self.assertEqual(report["preview"]["totals"], 1)
        self.assertEqual(report["preview"]["missing"]["Клики"], 1)
        self.assertEqual(report["campaigns"][0]["id"], first[0])
        self.assertEqual(report["campaigns"][0]["values"]["clicks"], "0")
        self.assertIsNone(report["campaigns"][0]["values"]["cpc"])
        self.assertEqual(report["campaigns"][0]["unavailable"]["cpc"], "zero")
        self.assertIsNone(report["groups"][0]["values"]["clicks"])
        self.assertEqual(report["groups"][0]["unavailable"]["clicks"], "missing")
        self.assertEqual(report["groups"][0]["values"]["spend"], "1237.50")
        self.assertEqual(report["groups"][1]["values"]["spend"], "42.00")

    def test_rejects_conflicts_unknown_schema_and_bad_inputs(self):
        a = ["1", "Demo", 7, 3, "5", 1, 2, "RUB"]
        b = [*a]
        b[4] = "8"
        with self.assertRaisesRegex(AdsError, "ID повторяется"):
            analyze(csv_report([a, b]))
        for value in ("-1", "NaN", "не число", "Infinity"):
            b[4] = value
            with self.subTest(value=value), self.assertRaisesRegex(AdsError, "Строка 2"):
                analyze(csv_report([b]))
        with self.assertRaisesRegex(AdsError, "сводку"):
            analyze(csv_report([a + ["2026-11-25"]], HEADERS + ["Дата"]))
        with self.assertRaisesRegex(AdsError, "Неоднозначные"):
            analyze(csv_report([a + ["5"]], HEADERS + ["Расходы"]))
        with self.assertRaises(AdsError):
            process(b"PK\x03\x04broken")
        with self.assertRaisesRegex(AdsError, "XLS не поддерживается"):
            process(b"\xd0\xcf\x11\xe0old")
        with self.assertRaisesRegex(AdsError, "10 МБ"):
            process(b"x" * (10 * 1024 * 1024 + 1))

    def test_xlsx_sheet_choice_and_uncached_formula(self):
        workbook = Workbook()
        for sheet in (workbook.active, workbook.create_sheet("Другой лист")):
            sheet.append(HEADERS + ["Старт", "Частота"])
            sheet.append(["009876543210987654321", "Формула", 10, 2, "=1+1", 0, 1, "RUB", "2022-01-01", 0.3])
        buffer = BytesIO()
        workbook.save(buffer)
        data = buffer.getvalue()
        self.assertEqual(len(process(data)["preview"]["sheets"]), 2)
        report = analyze(data, sheet=1)
        self.assertEqual(report["period"]["start"], "2026-11-19")
        self.assertEqual(report["preview"]["sheetName"], "Другой лист")
        self.assertIsNone(report["groups"][0]["values"]["spend"])
        self.assertEqual(report["preview"]["missing"]["Затраты"], 1)
        self.assertEqual(report["campaigns"][0]["id"], "009876543210987654321")
        self.assertNotIn("Частота", [field["column"] for field in report["preview"]["fields"]])

    def test_currency_not_assumed_and_period_required(self):
        data = csv_report([["1", "Test", 10, 2, 6, 1, 3]], HEADERS[:-1])
        self.assertIsNone(analyze(data)["groups"][0]["values"]["spend"])
        self.assertEqual(analyze(data)["groups"][0]["values"]["ctr"], "20.00")
        with self.assertRaisesRegex(AdsError, "даты"):
            process(data, analyze=True, start="20261119", end="2026-11-25")

    def test_xlsx_percentage_cells_are_compared_in_percentage_points(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(HEADERS + ["CTR(%)"])
        sheet.append(["1", "Test", 10, 2, 6, 1, 3, "RUB", 0.2])
        sheet["I2"].number_format = "0.00%"
        buffer = BytesIO()
        workbook.save(buffer)
        self.assertEqual(analyze(buffer.getvalue())["preview"]["discrepancies"], 0)


if __name__ == "__main__":
    unittest.main()
