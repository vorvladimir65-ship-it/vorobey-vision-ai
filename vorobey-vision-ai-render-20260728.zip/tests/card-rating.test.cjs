const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const source = readFileSync(path.join(__dirname, "../card-rating.js"), "utf8");
const build = vm.runInNewContext(source + "\nbuildCardRating");
const data = {
  product: { marketplace: "wb", name: "Test product" },
  summary: { averageRating: 4.5, feedbackCount: 10 },
  seoAnalysis: {
    titleEvaluation: { score: 80, issues: [{ description: "Title issue", recommendation: "Fix title" }] },
    descriptionAudit: { ok: true, qualityScore: 70, completeness: 60, criticalContradictions: [{ fix: "Fix contradiction" }] },
    attributesEvaluation: { totalImportant: 4, filledImportant: 2 },
  },
  firstPhotoAnalysis: { ok: true, score: 60 },
};

test("averages available criteria and preserves the reason and critical issues", () => {
  const rating = build(data);
  assert.equal(rating.score, 70);
  assert.equal(rating.measured, 5);
  assert.equal(rating.criteria[0].action, "Fix title");
  assert.equal(rating.criteria[2].action, "Fix contradiction");
  assert.equal(rating.critical.length, 1);
  assert.equal(rating.criteria[5].score, null);
});

test("adds a comparison only when there are comparable peer ratings", () => {
  const comparison = { summary: { competitorCount: 4 }, benchmark: { your: { averageRating: 4.5 }, competitorsAvg: { averageRating: 4.3 } } };
  const rating = build(data, comparison);
  assert.equal(rating.criteria[5].score, 60);
  assert.equal(rating.score, 68);
  comparison.benchmark.competitorsAvg.averageRating = null;
  assert.equal(build(data, comparison).measured, 5);
});

test("missing data is not a zero and a measured zero is not missing", () => {
  const missing = build({ product: { marketplace: "ozon" }, firstPhotoAnalysis: { ok: false, score: 0 } });
  assert.equal(missing.score, null);
  assert.equal(missing.measured, 0);
  const zero = build({ firstPhotoAnalysis: { ok: true, score: 0 } });
  assert.equal(zero.score, 0);
  assert.equal(zero.measured, 1);
});
