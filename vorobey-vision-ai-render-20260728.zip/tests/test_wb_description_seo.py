import importlib.util
import sys
import unittest
from pathlib import Path


APP_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = APP_ROOT / "server.py"
SPEC = importlib.util.spec_from_file_location("wb_review_analyzer_description_seo", SERVER_PATH)
server = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = server
SPEC.loader.exec_module(server)


def build_description_audit(description, attributes=None, queries=None, title="Брюки палаццо", category="Брюки"):
    attributes = attributes or []
    product = {
        "name": title,
        "brand": "Тестовый бренд",
        "characteristics": attributes,
        "searchQueries": queries or [],
    }
    card_meta = {
        "title": title,
        "description": description,
        "category": category,
        "attributes": attributes,
    }
    semantic_core = []
    p0 = server.build_card_seo_p0(product, card_meta, semantic_core, title, category, description)
    return server.build_wb_description_audit(
        product,
        card_meta,
        semantic_core,
        p0,
        title,
        category,
        description,
    )


class WbDescriptionSeoTests(unittest.TestCase):
    def test_detects_official_wb_description_violations(self):
        audit = build_description_audit(
            "Брюки женские!!! #брюки ссылка shop.ru артикул WB 12345678 / купите сейчас.",
            [{"name": "Крой", "value": "широкий"}],
        )
        issue_ids = {item["id"] for item in audit["issues"]}

        self.assertIn("description-domain", issue_ids)
        self.assertIn("description-article", issue_ids)
        self.assertIn("description-seo-tags", issue_ids)
        self.assertIn("description-special-symbols", issue_ids)
        self.assertTrue(all(item["basisLabel"] for item in audit["issues"]))

    def test_critical_contradiction_is_separate_from_quality_score(self):
        audit = build_description_audit(
            "Брюки с высокой посадкой подходят для повседневных образов.",
            [{"name": "Посадка", "value": "низкая"}],
            title="Брюки с высокой посадкой",
        )

        self.assertGreaterEqual(len(audit["criticalContradictions"]), 1)
        self.assertEqual(audit["criticalContradictions"][0]["priority"], "critical")
        self.assertIsInstance(audit["qualityScore"], int)

    def test_unconfirmed_target_query_is_not_recommended(self):
        audit = build_description_audit(
            "Широкие брюки для повседневных образов.",
            [{"name": "Крой", "value": "широкий"}],
            queries=[{"query": "брюки кожаные", "frequency": 500}],
        )
        row = next(item for item in audit["queryCoverage"] if item["query"] == "брюки кожаные")

        self.assertIn(row["status"], ("Исключить", "Недостаточно данных"))
        self.assertIn("Не добавлять", row["recommendation"])
        self.assertEqual(row["frequency"], 500)

    def test_missing_wb_statistics_reduce_completeness(self):
        audit = build_description_audit(
            "Широкие брюки с высокой посадкой подходят для повседневных образов.",
            [
                {"name": "Крой", "value": "широкий"},
                {"name": "Посадка", "value": "высокая"},
            ],
        )
        statuses = {item["id"]: item["status"] for item in audit["dataAvailability"]}

        self.assertLess(audit["completeness"], 100)
        self.assertEqual(statuses["queries"], "Недостаточно данных")
        self.assertEqual(statuses["queryStats"], "Недостаточно данных")
        self.assertEqual(statuses["fieldLimit"], "Недостаточно данных")

    def test_suggested_description_uses_only_confirmed_facts(self):
        audit = build_description_audit(
            "Брюки из натуральной кожи с золотой фурнитурой.",
            [
                {"name": "Материал", "value": "полиэстер"},
                {"name": "Крой", "value": "широкий"},
                {"name": "Назначение", "value": "повседневное"},
            ],
        )
        suggestion = audit["suggestedDescription"].lower()

        self.assertIn("полиэстер", suggestion)
        self.assertIn("широкий", suggestion)
        self.assertNotIn("натуральной кожи", suggestion)
        self.assertNotIn("золотой фурнитурой", suggestion)


if __name__ == "__main__":
    unittest.main()
