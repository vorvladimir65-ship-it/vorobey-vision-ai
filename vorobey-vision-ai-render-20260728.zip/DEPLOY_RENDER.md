# Публикация VOROBEY VISION AI на Render

## ИИ поиск · DEMO (Wildbox)

В Environment Variables сервиса задайте `WILDBOX_TOKEN`. Значение хранится только
на сервере и передаётся в заголовке `X-Wildbox-Token` на `https://wildbox.ru/mcp/v2`.
Не добавляйте токен в Git, архив, HTML или JavaScript. `WILDBOX_DEMO_ENABLED=false`
отключает запросы DEMO без удаления настройки ключа.

Отдельная строка принимает артикул, ссылку на карточку WB или поисковую фразу.
Данные запрашиваются за 30 завершённых дней по московскому времени. Результаты
кэшируются на час (до 256 запросов в памяти), вызовы ограничены одной общей
линией с интервалом не менее 10 секунд и учитывают ограничения Wildbox.
При занятости или ограничении пользователь видит время до повторного запроса.
DEMO рассчитан на один процесс/экземпляр сервера; перед масштабированием
нужно перенести лимитер и кэш в общее хранилище.

Доступ использует существующую проверку Telegram. Это рыночные оценки Wildbox,
а не внутренние продажи кабинета. Поиск по названию выбирает до пяти строк
по совпадению слов из ограниченной выборки; он не является полноценным
LLM-чатом. Недоступные показатели показываются как «Нет данных».

Проверка: `python -m unittest discover -s tests -v`, затем запросы в строке
«ИИ поиск»: `199252123` и `набор эфирных масел 12`. Версия: `wildbox-ai-demo-3`.

1. Создайте репозиторий на GitHub и загрузите в него содержимое этой папки.
2. В Render нажмите New -> Web Service.
3. Подключите GitHub и выберите репозиторий с приложением.
4. Укажите:
   - Name: `vorobey-vision-ai`
   - Language / Runtime: `Python 3`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python server.py`
   - Health Check Path: `/health`
5. Для анализа Ozon продавец выбирает Ozon в интерфейсе и вводит свои `Client-Id` и `Api-Key`. Ключи передаются по HTTPS только для текущего запроса и не сохраняются. Переменные `OZON_CLIENT_ID` и `OZON_API_KEY` в Render можно оставить как необязательный резервный доступ владельца сервиса.
6. Для закрытого доступа через Telegram добавьте Environment Variables:
   - `TELEGRAM_BOT_TOKEN` — токен бота из BotFather. Не публикуйте его в GitHub.
   - `AUTH_SESSION_SECRET` — любая длинная секретная строка для подписи сессий.
   - `TELEGRAM_BOT_USERNAME` — `vorobey_vision_access_bot`
   - `TELEGRAM_REQUIRED_CHANNELS` — `@Elena_opora_psy,@vorobevFM`
   - `TELEGRAM_ACCESS_MODE` — `all`
   - `PUBLIC_BASE_URL` — `https://vorobey-vision-ai.onrender.com`
   - `TELEGRAM_AUTO_SETUP` — `true`
7. В BotFather выполните `/setdomain` для бота и укажите домен:
   `vorobey-vision-ai.onrender.com`
8. Добавьте бота администратором в оба Telegram-канала. Без этого Telegram может не дать проверить подписку через `getChatMember`.
9. Нажмите Create Web Service и дождитесь статуса Live.

После публикации сервис будет доступен по публичной ссылке вида:
`https://vorobey-vision-ai.onrender.com`

Если приложение загружено в большой общий репозиторий, в Render укажите Root Directory:
`outputs/wb-review-analyzer`

WB может работать без ключей. Ozon без Seller API ключей может не загружаться из облака, потому что публичные страницы Ozon часто блокируют серверные запросы.

Telegram-защита включается только если задан `TELEGRAM_BOT_TOKEN`. Если переменной нет, сервис остается открытым.

Основной сценарий входа — Telegram Mini App: пользователь пишет боту, получает кнопку `Открыть анализатор`, открывает сервис внутри Telegram, а приложение автоматически проверяет подписанного Telegram-пользователя. Браузерный Telegram Login Widget остается резервным вариантом для тех, кто открыл сайт напрямую.
