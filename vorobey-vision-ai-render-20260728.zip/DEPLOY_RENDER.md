# Публикация VOROBEY VISION AI на Render

1. Создайте репозиторий на GitHub и загрузите в него содержимое этой папки.
2. В Render нажмите New -> Web Service.
3. Подключите GitHub и выберите репозиторий с приложением.
4. Укажите:
   - Name: `vorobey-vision-ai`
   - Language / Runtime: `Python 3`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python server.py`
   - Health Check Path: `/health`
5. Для анализа Ozon добавьте Environment Variables:
   - `OZON_CLIENT_ID` — Client-Id из кабинета Ozon Seller API
   - `OZON_API_KEY` — Api-Key из кабинета Ozon Seller API
6. Нажмите Create Web Service и дождитесь статуса Live.

После публикации сервис будет доступен по публичной ссылке вида:
`https://vorobey-vision-ai.onrender.com`

Если приложение загружено в большой общий репозиторий, в Render укажите Root Directory:
`outputs/wb-review-analyzer`

WB может работать без ключей. Ozon без Seller API ключей может не загружаться из облака, потому что публичные страницы Ozon часто блокируют серверные запросы.
