"""Stateless analysis of campaign-level WB exports."""

import csv
import re
import time
from collections import Counter, defaultdict
from datetime import date
from decimal import Decimal, ROUND_HALF_UP, localcontext
from io import BytesIO, StringIO
from zipfile import ZipFile

from defusedxml.ElementTree import iterparse
from openpyxl import load_workbook
from openpyxl.utils.cell import column_index_from_string

MAX_BYTES = 10 * 1024 * 1024
MAX_ROWS = 100_000
MAX_COLUMNS = 80
MAX_CELLS = 2_500_000
LABELS = {
    "id": "ID", "name": "Кампания", "spend": "Затраты", "impressions": "Показы",
    "clicks": "Клики", "units": "Заказанные товары, шт", "carts": "Добавления в корзину",
    "currency": "Валюта", "amount": "Сумма заказов",
    "ctr": "CTR", "cpc": "CPC", "cpm": "CPM", "cr": "CR",
}
ALIASES = {
    "id": ("id", "id кампании", "номер кампании", "advert id"),
    "name": ("кампания", "название кампании"),
    "spend": ("затраты", "расходы", "затраты ₽", "расходы ₽", "затраты руб", "расходы руб"),
    "impressions": ("показы",), "clicks": ("клики",),
    "units": ("заказанные товары шт", "заказанные товары", "заказано товаров шт"),
    "carts": ("добавления в корзину",),
    "currency": ("валюта", "код валюты"),
    "amount": ("сумма заказов", "сумма заказов ₽", "заказов на сумму ₽"),
    "ctr": ("ctr", "ctr %"), "cpc": ("cpc", "cpc ₽"),
    "cpm": ("cpm", "cpm ₽"), "cr": ("cr", "cr %"),
}
HEADERS = {alias: key for key, aliases in ALIASES.items() for alias in aliases}
BASE = ("spend", "impressions", "clicks", "units", "carts", "amount")
COUNTS = {"impressions", "clicks", "units", "carts"}
METRICS = {
    "ctr": ("clicks", "impressions", 100), "cpc": ("spend", "clicks", 1),
    "cpm": ("spend", "impressions", 1000), "unitsPerClick": ("units", "clicks", 100),
    "costPerUnit": ("spend", "units", 1), "costPerCart": ("spend", "carts", 1),
    "spendToAmount": ("spend", "amount", 100),
}
TOTAL_LABEL = re.compile(r"(?:итого|всего|общий итог|итог по всем кампаниям)(?:\s*:)?")
DETAIL = {"дата", "день", "артикул", "артикул wb", "nm id", "поисковый запрос", "зона показов"}
ROUND = Decimal("0.01")


class AdsError(ValueError):
    pass


def check_time(deadline):
    if time.monotonic() > deadline:
        raise AdsError("Файл обрабатывается слишком долго. Сократите период или число листов.")


def header(value):
    return " ".join(re.sub(r"[(),.:]", " ", str(value or "").casefold()).split())


def columns(row):
    names = [header(cell) for cell in row]
    mapping = defaultdict(list)
    for index, name in enumerate(names):
        if name in HEADERS:
            mapping[HEADERS[name]].append(index)
    if "spend" in mapping and COUNTS.intersection(mapping):
        return dict(mapping), bool(DETAIL.intersection(names))
    return {}, False


def validate_archive(data, deadline):
    with ZipFile(BytesIO(data)) as archive:
        files = archive.infolist()
        if (
            len(files) > 300 or sum(info.file_size for info in files) > 64 * 1024 * 1024
            or any(info.flag_bits & 1 or "vbaproject" in info.filename.lower() for info in files)
        ):
            raise AdsError("XLSX слишком сложный, защищён или содержит макросы. Сохраните простой XLSX без макросов.")
        if "xl/workbook.xml" not in archive.namelist():
            raise AdsError("Содержимое файла не похоже на XLSX.")
        cells = rows = 0
        for info in files:
            if not re.fullmatch(r"xl/worksheets/[^/]+\.xml", info.filename):
                continue
            with archive.open(info) as stream:
                for _, element in iterparse(stream):
                    kind = element.tag.rsplit("}", 1)[-1]
                    if kind == "c":
                        cells += 1
                        match = re.fullmatch(r"([A-Z]{1,3})([1-9][0-9]{0,6})", element.get("r", ""))
                        if not match or column_index_from_string(match[1]) > MAX_COLUMNS or int(match[2]) > MAX_ROWS + 25:
                            raise AdsError("В XLSX слишком много строк или столбцов.")
                    elif kind == "row":
                        rows += 1
                        if int(element.get("r", "0")) > MAX_ROWS + 25:
                            raise AdsError("В XLSX слишком много строк.")
                    if cells > MAX_CELLS or rows > MAX_ROWS + 25:
                        raise AdsError("Лимит XLSX: 100 000 строк и 2,5 млн ячеек.")
                    if kind in {"c", "row"}:
                        check_time(deadline)
                    element.clear()


def csv_rows(data):
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = data.decode("cp1251")
    if "\x00" in text or any(ord(char) < 32 and char not in "\r\n\t" for char in text[:4096]):
        raise AdsError("Содержимое файла не похоже на CSV.")
    candidates = []
    for delimiter in (";", ",", "\t"):
        try:
            with StringIO(text, newline="") as stream:
                for index, row in enumerate(csv.reader(stream, delimiter=delimiter, strict=True)):
                    if index >= 25:
                        break
                    mapping, _ = columns(row)
                    if mapping:
                        candidates.append((len(mapping), delimiter))
                        break
        except csv.Error:
            continue
    if not candidates:
        if not text.strip():
            raise AdsError("Файл пуст.")
        raise AdsError("Не найдены затраты и показатели взаимодействия. Нужна общая выгрузка по кампаниям WB.")
    delimiter = max(candidates)[1]
    with StringIO(text, newline="") as stream:
        yield from csv.reader(stream, delimiter=delimiter, strict=True)


def workbook_rows(sheet):
    percent_columns = None
    for row in sheet.iter_rows():
        if percent_columns is None:
            values = tuple(cell.value for cell in row)
            mapping, _ = columns(values)
            if mapping:
                percent_columns = set(mapping.get("ctr", []) + mapping.get("cr", []))
            yield values
            continue
        yield tuple(
            format(Decimal(str(cell.value)) * 100, "f")
            if index in percent_columns and type(cell.value) in (int, float) and "%" in cell.number_format
            else cell.value
            for index, cell in enumerate(row)
        )


def number(value, key, row):
    if value is None or not str(value).strip():
        return None
    raw = format(Decimal(str(value)), "f") if type(value) is float else str(value)
    raw = re.sub(r"[\s\u00a0\u202f]", "", raw)
    if key in {"ctr", "cr"}:
        raw = raw.removesuffix("%")
    raw = raw.replace(",", ".")
    if not re.fullmatch(r"[+-]?\d{1,16}(?:\.\d{1,12})?", raw):
        raise AdsError(f"Строка {row}: «{LABELS[key]}» не является допустимым числом. Проверьте ячейку.")
    val = Decimal(raw)
    if val < 0 or key in COUNTS and val != val.to_integral_value():
        raise AdsError(f"Строка {row}: неверное значение в поле «{LABELS[key]}».")
    return val


def clean_text(value):
    return "" if value is None else str(value).strip()


def collect(rows, mapping, start, deadline):
    campaigns, ids, seen = [], set(), set()
    missing = Counter()
    duplicates = totals = technical = discrepancies = 0
    cells = 0
    for line, row in enumerate(rows, start):
        check_time(deadline)
        cells += len(row)
        if line - start >= MAX_ROWS or len(row) > MAX_COLUMNS or cells > MAX_CELLS:
            raise AdsError("Отчёт превышает лимит строк или ячеек.")
        if not any(clean_text(cell) for cell in row):
            continue

        def get(key):
            index = mapping.get(key, [len(row)])[0]
            return row[index] if index < len(row) else None

        raw_id, name = get("id"), clean_text(get("name"))
        key = clean_text(raw_id)
        if TOTAL_LABEL.fullmatch(key.casefold()) or (
            not key and (TOTAL_LABEL.fullmatch(name.casefold()) or
                         not name and TOTAL_LABEL.fullmatch(clean_text(row[0]).casefold()))
        ):
            totals += 1
            continue
        signature = tuple(row)
        if signature in seen:
            duplicates += 1
            continue
        seen.add(signature)
        if isinstance(raw_id, float) or type(raw_id) is int and abs(raw_id) >= 10**15:
            raise AdsError(f"Строка {line}: сохраните ID кампании как текст, чтобы не потерять точность.")
        if len(key) > 128:
            raise AdsError(f"Строка {line}: ID кампании слишком длинный. Проверьте сопоставление столбцов.")
        if key and key in ids:
            raise AdsError(f"Строка {line}: ID повторяется с другими данными. Нужен отчёт с одной строкой на кампанию, без разбивки по товарам, дням или зонам.")
        if key:
            ids.add(key)
        else:
            technical += 1
            if not name:
                raise AdsError(f"Строка {line}: нет ID и названия кампании. Проверьте, не является ли строка промежуточным итогом.")
        raw_currency = clean_text(get("currency")).upper()
        currency = {"₽": "RUB", "РУБ": "RUB", "РУБ.": "RUB", "RUR": "RUB"}.get(raw_currency, raw_currency)
        if not currency and re.search(r"₽|\bруб\b", clean_text(mapping.get("_spend_header")), re.I):
            currency = "RUB"
        if currency and not re.fullmatch(r"[A-Z]{3}", currency):
            raise AdsError(f"Строка {line}: укажите валюту трёхбуквенным кодом, например RUB.")
        values = {field: number(get(field), field, line) for field in BASE}
        for field in BASE:
            missing[field] += values[field] is None
        missing["currency"] += not currency
        reported = [(metric, number(get(col), col, line))
                    for col, metric in (("ctr", "ctr"), ("cpc", "cpc"), ("cpm", "cpm"), ("cr", "unitsPerClick"))
                    if col in mapping]
        if reported:
            calculated = ratios(values)
            discrepancies += any(
                supplied is not None and (computed := calculated[metric]) is not None
                and abs(supplied - computed) > max(Decimal("0.05"), abs(computed) * Decimal("0.02"))
                for metric, supplied in reported
            )
        campaigns.append({"row": line, "id": key, "name": name[:250], "currency": currency, "values": values})
    return campaigns, {
        "count": len(campaigns), "duplicates": duplicates, "totals": totals, "technical": technical,
        "discrepancies": discrepancies, "missing": {LABELS[k]: v for k, v in missing.items() if v and k in mapping},
        "unavailable": [LABELS[k] for k in (*BASE, "currency") if k not in mapping and (k != "currency" or not any(c["currency"] for c in campaigns))],
    }


def read_report(data, sheet_index, deadline):
    workbook = None
    try:
        if not data:
            raise AdsError("Файл пуст.")
        if data.startswith(b"\xd0\xcf\x11\xe0") or data.lstrip().lower().startswith((b"<html", b"<?xml", b"<!doctype")):
            raise AdsError("Формат XLS не поддерживается. Откройте файл в Excel и сохраните в XLSX либо CSV.")
        if data.startswith(b"PK"):
            validate_archive(data, deadline)
            workbook = load_workbook(BytesIO(data), read_only=True, data_only=True, keep_links=False)
            if len(workbook.worksheets) > 24:
                raise AdsError("В книге слишком много листов. Оставьте только листы со статистикой.")
            for ws in workbook.worksheets:
                ws.reset_dimensions()
            sources = [(ws.title, workbook_rows(ws)) for ws in workbook.worksheets]
        else:
            sources = [("CSV", csv_rows(data))]
        candidates = []
        for index, (name, rows) in enumerate(sources):
            for line, row in enumerate(rows, 1):
                check_time(deadline)
                if len(row) > MAX_COLUMNS:
                    raise AdsError("В отчёте больше 80 столбцов.")
                mapping, detail = columns(row)
                if mapping and not detail:
                    candidates.append((index, name, rows, line, mapping, row))
                    break
                if detail or line >= 25:
                    break
        if not candidates:
            raise AdsError("Не найден лист общей статистики WB. Выгрузите сводку по кампаниям, а не отчёт по товарам, дням или зонам.")
        choices = [{"index": candidate[0], "name": candidate[1]} for candidate in candidates]
        selected = next((item for item in candidates if item[0] == sheet_index), None)
        if selected is None:
            if sheet_index is not None:
                raise AdsError("Выбранный лист не подходит для анализа.")
            if len(candidates) > 1:
                return {"sheets": choices}, []
            selected = candidates[0]
        index, name, rows, line, mapping, raw_headers = selected
        ambiguous = [LABELS[key] for key, values in mapping.items() if len(values) > 1]
        if ambiguous:
            raise AdsError(f"Неоднозначные столбцы: {', '.join(ambiguous)}. Оставьте в копии файла только нужный столбец для каждого поля.")
        resolved = [{"label": LABELS[key], "column": clean_text(raw_headers[positions[0]])} for key, positions in mapping.items()]
        mapping["_spend_header"] = raw_headers[mapping["spend"][0]]
        campaigns, preview = collect(rows, mapping, line + 1, deadline)
        return {**preview, "sheets": choices, "sheet": index, "sheetName": name, "fields": resolved}, campaigns
    except AdsError:
        raise
    except Exception as exc:
        raise AdsError("Не удалось прочитать файл. Проверьте, что он не повреждён и сохранён в формате XLSX или CSV.") from exc
    finally:
        if workbook is not None:
            workbook.close()


def ratio(numerator, denominator, factor=1):
    if numerator is None or denominator is None or denominator == 0:
        return None
    return numerator * factor / denominator


def ratios(values):
    return {key: ratio(values[num], values[den], factor) for key, (num, den, factor) in METRICS.items()}


def unavailable(values, *, unknown_currency=False):
    reasons = {key: "missing" for key, value in values.items() if value is None}
    for key, (num, den, _) in METRICS.items():
        if values[num] is None or values[den] is None:
            reasons[key] = "missing"
        elif values[den] == 0:
            reasons[key] = "zero"
    if unknown_currency:
        for key in ("spend", "amount", "cpc", "cpm", "costPerUnit", "costPerCart", "spendToAmount"):
            reasons[key] = "currency"
    return reasons


def present(values):
    return {key: None if value is None else str(value.quantize(
        Decimal("1") if key in COUNTS else ROUND, rounding=ROUND_HALF_UP
    )) for key, value in values.items()}


def summarize(campaigns, deadline):
    grouped = defaultdict(list)
    for index, campaign in enumerate(campaigns, 1):
        campaign["key"] = index
        grouped[campaign["currency"]].append(campaign)
    groups, output, observations = [], [], []
    for currency, items in grouped.items():
        check_time(deadline)
        totals = {field: sum((c["values"][field] for c in items), Decimal(0))
                  if all(c["values"][field] is not None for c in items) else None for field in BASE}
        if not currency:
            totals["spend"] = totals["amount"] = None
        for item in items:
            check_time(deadline)
            values = item["values"]
            reasons = unavailable(values)
            for share, field in (("spendShare", "spend"), ("unitShare", "units")):
                if field == "spend" and not currency:
                    reasons[share] = "currency"
                elif values[field] is None or totals[field] is None:
                    reasons[share] = "missing"
                elif totals[field] == 0:
                    reasons[share] = "zero"
            output.append({**item, "unavailable": reasons, "values": present({
                **values, **ratios(values),
                "spendShare": ratio(values["spend"], totals["spend"], 100),
                "unitShare": ratio(values["units"], totals["units"], 100),
            })})
        groups.append({"currency": currency, "count": len(items), "values": present({**totals, **ratios(totals)}),
                       "unavailable": unavailable(totals, unknown_currency=not currency)})
        if not currency:
            continue
        for kind, eligible, sort_key in (
            ("noUnits", lambda v: v["units"] == 0 and (v["spend"] or 0) > 0, "spend"),
            ("carts", lambda v: v["units"] is not None and (v["carts"] or 0) > v["units"] > 0 and (v["clicks"] or 0) > 0, "carts"),
            ("share", lambda v: (v["units"] or 0) > 0 and totals["spend"] and totals["units"]
             and (v["spend"] or 0) * totals["units"] > v["units"] * totals["spend"], "spend"),
        ):
            item = max((c for c in items if eligible(c["values"])), key=lambda c: c["values"][sort_key], default=None)
            if item:
                observations.append({"kind": kind, "key": item["key"]})
    priority = {"noUnits": 0, "carts": 1, "share": 2}
    observations.sort(key=lambda item: priority[item["kind"]])
    return {"groups": groups, "campaigns": output, "observations": observations[:3]}


def process(data, *, sheet=None, analyze=False, start="", end="", partial=False):
    if len(data) > MAX_BYTES:
        raise AdsError("Максимальный размер файла — 10 МБ.")
    deadline = time.monotonic() + 15
    with localcontext() as context:
        context.prec = 50
        preview, campaigns = read_report(data, sheet, deadline)
        if not analyze or "sheet" not in preview:
            return {"preview": preview}
        try:
            if date.fromisoformat(start).isoformat() != start or date.fromisoformat(end).isoformat() != end or start > end:
                raise ValueError
        except ValueError as exc:
            raise AdsError("Подтвердите корректные даты начала и окончания отчёта.") from exc
        return {"preview": preview, "period": {"start": start, "end": end, "partial": partial}, **summarize(campaigns, deadline)}
