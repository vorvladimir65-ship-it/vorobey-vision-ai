(() => {
  const byId = (name) => document.getElementById(`ads-${name}`);
  const demo = byId("demo");
  if (!demo) return;
  const form = byId("form"), fileInput = byId("file"), sheet = byId("sheet");
  const start = byId("start"), end = byId("end"), confirmed = byId("confirmed"), partial = byId("partial");
  const status = byId("status"), previewBox = byId("preview"), controls = byId("controls");
  const result = byId("result"), overview = byId("overview"), sort = byId("sort");
  const mask = byId("mask"), tablePanel = byId("table-panel"), analyzeButton = byId("analyze");
  const esc = escapeHtml;
  const limit = 10 * 1024 * 1024;
  const pageSize = 50;
  const fields = [
    ["spend", "Расходы", "money"], ["impressions", "Показы", "count"],
    ["clicks", "Клики", "count"], ["carts", "Корзины", "count"],
    ["units", "Заказанные единицы", "count"], ["costPerUnit", "Расходы на единицу", "money"],
    ["ctr", "CTR", "percent"], ["cpc", "CPC", "money"], ["cpm", "CPM", "money"],
    ["unitsPerClick", "Единицы / клики", "percent"], ["costPerCart", "Стоимость корзины", "money"],
    ["spendShare", "Доля расходов", "percent"], ["unitShare", "Доля единиц", "percent"],
    ["spendToAmount", "Доля затрат от суммы заказов", "percent"],
  ];
  const format = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 });
  const money = new Intl.NumberFormat("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const display = (value, type, currency) => value == null ? "—" :
    `${(type === "money" ? money : format).format(value)}${type === "money" && currency ? ` ${currency}` : type === "percent" ? "%" : ""}`;
  const dateLabel = (value) => value.split("-").reverse().join(".");
  let report, currentRequest, sortedRows, sortedReport, sortedField, page = 0;

  for (const [key, label] of fields) sort.add(new Option(`${label}: по убыванию`, key));

  function clearReport() {
    report = null;
    sortedReport = sortedRows = null;
    result.hidden = true;
    overview.replaceChildren();
    byId("table").replaceChildren();
    tablePanel.open = false;
    page = 0;
  }

  function setBusy(busy) {
    analyzeButton.disabled = busy;
    sheet.disabled = busy;
    for (const input of [start, end, confirmed, partial]) input.disabled = busy;
  }

  function cancelRequest() {
    currentRequest?.abort();
    currentRequest = null;
    setBusy(false);
  }

  function reset() {
    cancelRequest();
    clearReport();
    mask.checked = false;
    controls.hidden = previewBox.hidden = byId("sheet-field").hidden = true;
    previewBox.replaceChildren();
    sheet.replaceChildren();
    status.textContent = "";
    byId("file-name").textContent = "";
    start.value = end.value = "";
    confirmed.checked = partial.checked = false;
  }

  function suggestDates(name) {
    const dates = [...name.matchAll(/(?<!\d)(\d{4}[-_.]\d{2}[-_.]\d{2}|\d{2}[._-]\d{2}[._-]\d{4})(?!\d)/g)];
    if (dates.length !== 2) return;
    const normalized = dates.map(([, raw]) => {
      const parts = raw.split(/[-_.]/);
      return (parts[0].length === 4 ? parts : parts.reverse()).join("-");
    });
    if (normalized[0] <= normalized[1]) [start.value, end.value] = normalized;
  }

  function showPreview(data) {
    const selector = byId("sheet-field");
    selector.hidden = data.sheets.length < 2;
    sheet.replaceChildren(new Option("Выберите лист", ""));
    for (const item of data.sheets) sheet.add(new Option(item.name, item.index));
    sheet.value = data.sheet ?? "";
    if (data.sheet === undefined) {
      status.textContent = "В файле несколько подходящих листов. Выберите один.";
      return;
    }
    const stats = [
      ["Кампании", data.count], ["Исключённые дубли", data.duplicates],
      ["Исключённые итоги", data.totals], ["Строки с техническим ключом", data.technical],
      ["Строки с заметным расхождением CTR, CPC, CPM или CR", data.discrepancies],
    ];
    const missing = Object.entries(data.missing).map(([key, count]) => `${key}: ${count}`).join(", ");
    previewBox.innerHTML = `
      <h3>Проверка файла · ${esc(data.sheetName)}</h3>
      <p>${stats.map(([label, count]) => `${label}: ${format.format(count)}`).join(" · ")}</p>
      <details><summary>Распознанные столбцы и пропуски</summary>
        <ul>${data.fields.map(({label, column}) => `<li>${esc(label)} ← ${esc(column)}</li>`).join("")}</ul>
        <p>Пустые значения: ${esc(missing || "нет в распознанных полях")}. Отсутствующие поля: ${esc(data.unavailable.join(", ") || "нет")}.</p>
      </details>`;
    previewBox.hidden = false;
    controls.hidden = !data.count;
    status.textContent = data.count ? "" : "На листе нет строк кампаний для анализа.";
  }

  async function request(mode, selectedSheet) {
    const file = fileInput.files[0];
    if (!file) return;
    const controller = new AbortController();
    currentRequest = controller;
    setBusy(true);
    status.textContent = mode === "analyze" ? "Проверяю данные и рассчитываю показатели…" : "Проверяю файл…";
    const headers = {"Content-Type": "application/octet-stream"};
    if (selectedSheet !== "") headers["X-Ads-Sheet"] = selectedSheet;
    if (mode === "analyze") Object.assign(headers, {
      "X-Ads-Confirmed": "1", "X-Ads-Start": start.value, "X-Ads-End": end.value,
      "X-Ads-Partial": partial.checked ? "1" : "0",
    });
    try {
      const response = await fetch(apiUrl("/api/wb-ads"), {method: "POST", credentials: "include", headers, body: file, signal: controller.signal});
      const payload = await response.json().catch(() => null);
      if (currentRequest !== controller) return;
      if (!response.ok || !payload?.ok) {
        if (payload?.auth) applyAuthState(payload.auth);
        if (currentRequest === controller) status.textContent = payload?.error || "Не удалось обработать файл.";
        return;
      }
      showPreview(payload.data.preview);
      if (payload.data.period) {
        report = payload.data;
        result.hidden = false;
        renderReport();
        status.textContent = "Анализ готов.";
      }
    } catch {
      if (currentRequest === controller) status.textContent = "Не удалось загрузить файл. Проверьте соединение и повторите.";
    } finally {
      if (currentRequest === controller) {
        currentRequest = null;
        setBusy(false);
      }
    }
  }

  const campaignName = (item) => {
    if (mask.checked) return `Кампания ${item.key}`;
    return [item.name, item.id && `ID ${item.id}`].filter(Boolean).join(" · ") || `Строка ${item.row}`;
  };
  const fact = (item, key) => {
    const [, , type] = fields.find(([field]) => field === key);
    return display(item.values[key], type, item.currency);
  };
  const metricCell = (item, key) => {
    const note = {missing: "Недостаточно данных", zero: "Знаменатель равен нулю", currency: "Не указана валюта"}[item.unavailable?.[key]];
    return note ? `<span title="${note}" aria-label="${note}">—</span>` : esc(fact(item, key));
  };

  function insight(kind, item) {
    const name = campaignName(item);
    if (kind === "noUnits") return [
      `${name}: расходы ${fact(item, "spend")}, заказанных единиц нет.`,
      `${name}: проверьте, достаточно ли кликов и завершён ли период учёта. Сверьте остатки и детализацию кампании; сам по себе ноль не повод отключать рекламу.`,
    ];
    if (kind === "carts") return [
      `${name}: ${fact(item, "clicks")} кликов, ${fact(item, "carts")} добавлений в корзину и ${fact(item, "units")} заказанных единиц. Это отдельные события, а не когортная конверсия.`,
      `${name}: проверьте наличие, цену и сроки доставки в периоде отчёта. Сопоставьте события по дневной статистике, прежде чем объяснять разницу.`,
    ];
    return [
      `${name}: ${fact(item, "spendShare")} расходов и ${fact(item, "unitShare")} заказанных единиц в своей валютной группе.`,
      `${name}: уточните, какие товары и цели были у кампании. Перед сравнением затрат на единицу подтвердите сопоставимость товаров, цен и маржи.`,
    ];
  }

  function renderReport() {
    const {period, groups, campaigns, observations} = report;
    const byKey = new Map(campaigns.map((item) => [item.key, item]));
    const reasons = observations.map(({kind, key}) => insight(kind, byKey.get(key)));
    const active = campaigns.some(({values}) =>
      ["spend", "impressions", "clicks", "carts", "units"].some((key) => Number(values[key]) > 0));
    const list = (index) => `<ol>${reasons.map((item) => `<li>${esc(item[index])}</li>`).join("")}</ol>`;
    overview.innerHTML = `
      <h3>Результат за ${dateLabel(period.start)}–${dateLabel(period.end)}</h3>
      ${period.partial ? '<p class="ads-partial"><strong>Последний день неполный.</strong> Итоги могут измениться.</p>' : ""}
      ${active ? "" : "<p>В выгрузке нет подтверждённой рекламной активности. Проверьте выбранный период и пропуски.</p>"}
      ${groups.map((group) => `<div class="ads-group">
        <h3>${esc(group.currency || "Валюта не указана")} · кампаний: ${format.format(group.count)}</h3>
        <dl class="ads-metrics">${fields.slice(0, 6).map(([key, label]) =>
          `<div><dt>${esc(label)}</dt><dd>${metricCell(group, key)}</dd></div>`).join("")}</dl>
        <p>CTR: ${esc(fact(group, "ctr"))} · CPC: ${esc(fact(group, "cpc"))} · CPM: ${esc(fact(group, "cpm"))} ·
        Единицы / клики: ${esc(fact(group, "unitsPerClick"))} · Стоимость корзины: ${esc(fact(group, "costPerCart"))} ·
        Доля затрат от суммы заказов: ${esc(fact(group, "spendToAmount"))}</p>
      </div>`).join("")}
      <h3>Наблюдения по данным</h3>
      ${reasons.length ? list(0) : "<p>Недостаточно данных для отдельных наблюдений.</p>"}
      <h3>Что проверить</h3>
      ${reasons.length ? list(1) : "<p>Сверьте период и заполненность полей в выгрузке.</p>"}
      <p class="ads-limit">«—» означает, что есть пропуск, знаменатель равен нулю или для денежного итога не указана валюта. Валюты не складываются. Заказанные единицы не равны выкупам; отчёт не показывает прибыль. ИИ-комментарий в DEMO недоступен, наблюдения рассчитаны по правилам сервиса.</p>`;
    tablePanel.hidden = !campaigns.length;
    renderTable();
  }

  function renderTable() {
    if (!report) return;
    const key = sort.value;
    if (sortedReport !== report || sortedField !== key) {
      sortedReport = report;
      sortedField = key;
      const moneyField = fields.find(([field]) => field === key)?.[2] === "money";
      sortedRows = [...report.campaigns].sort((a, b) => {
        if (moneyField && a.currency !== b.currency) return a.currency.localeCompare(b.currency);
        const x = a.values[key], y = b.values[key];
        return x === null ? (y === null ? 0 : 1) : y === null ? -1 : Number(y) - Number(x);
      });
    }
    const last = Math.max(0, Math.ceil(sortedRows.length / pageSize) - 1);
    page = Math.min(page, last);
    const rows = sortedRows.slice(page * pageSize, (page + 1) * pageSize);
    byId("table").innerHTML = `<table class="ai-table"><thead><tr><th scope="col">Кампания</th><th scope="col">Валюта</th>
      ${fields.map(([, label]) => `<th scope="col">${esc(label)}</th>`).join("")}
      </tr></thead><tbody>${rows.map((item) => `<tr><th scope="row">${esc(campaignName(item))}</th><td>${esc(item.currency || "—")}</td>
        ${fields.map(([field]) => `<td>${metricCell(item, field)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    byId("page").textContent = `Страница ${page + 1} из ${last + 1}`;
    byId("prev").disabled = page === 0;
    byId("next").disabled = page === last;
  }

  byId("pick-file").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => {
    reset();
    const file = fileInput.files[0];
    if (!file) return;
    byId("file-name").textContent = file.name;
    if (/\.xls$/i.test(file.name)) {
      status.textContent = "Формат XLS не поддерживается. Откройте файл в Excel и сохраните в XLSX либо CSV.";
      return;
    }
    if (!/\.(xlsx|csv)$/i.test(file.name) || file.size > limit || file.size === 0) {
      status.textContent = "Выберите непустой XLSX или CSV размером до 10 МБ.";
      return;
    }
    suggestDates(file.name);
    request("preview", "");
  });
  sheet.addEventListener("change", () => {
    clearReport();
    confirmed.checked = false;
    controls.hidden = previewBox.hidden = true;
    if (sheet.value !== "") request("preview", sheet.value);
    else status.textContent = "Выберите лист для проверки.";
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (currentRequest || controls.hidden || !confirmed.checked) return;
    if (start.value > end.value) {
      status.textContent = "Начало периода не может быть позже конца.";
      return;
    }
    clearReport();
    request("analyze", sheet.value);
  });
  for (const input of [start, end, partial]) input.addEventListener("change", () => {
    if (input !== partial) confirmed.checked = false;
    clearReport();
  });
  mask.addEventListener("change", renderReport);
  sort.addEventListener("change", () => { page = 0; renderTable(); });
  byId("prev").addEventListener("click", () => { page -= 1; renderTable(); });
  byId("next").addEventListener("click", () => { page += 1; renderTable(); });
  byId("copy").addEventListener("click", async () => {
    if (!report) return;
    try {
      await navigator.clipboard.writeText(overview.innerText);
      if (report) status.textContent = "Краткий результат скопирован.";
    } catch {
      if (report) status.textContent = "Браузер не разрешил копирование. Выделите текст результата вручную.";
    }
  });
  demo.addEventListener("ads-access-revoked", () => {
    form.reset();
    reset();
  });
})();
